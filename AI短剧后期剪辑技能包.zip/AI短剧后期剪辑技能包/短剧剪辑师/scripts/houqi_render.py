#!/usr/bin/env python3
"""按剪辑方案（plan.json）一键出片：逐镜头裁切 → 锐化 → LUT → 颗粒 → 转场 → 片名卡 → 对白响度 → 配乐压低 → 成片响度和限幅。

用法：
    python3 houqi_render.py plan.json            # 全部做完
    python3 houqi_render.py plan.json --title    # 只出片名卡，先看效果
    python3 houqi_render.py plan.json --draft    # 快速预览版（画质低、速度快）

只依赖 ffmpeg / ffprobe。plan.json 的写法见 references/plan格式.md，示例见 assets/plan_示例.json。
不会改动原素材；所有中间文件放在输出文件旁边的「_houqi_work」文件夹里。
"""
import argparse, json, os, re, shutil, subprocess, sys

DEF = {
    'fps': 24, 'aspect': '2.4', 'lut': None, 'sharpen': 0.35, 'grain': 3, 'trim_frames': 1,
    'fade_in': 1.2, 'fade_out': 1.5, 'tail_black': 1.0, 'dip': {'out': 0.4, 'black': 0.3, 'in': 0.4},
    'audio_edge': 0.03, 'dialogue_lufs': -16.0, 'final_lufs': -16.0, 'limit_db': -2.0,
    'title': None, 'music': None, 'story_srt': None,
}
MUSIC_DEF = {'lufs': -27.0, 'duck': True, 'title_lift': 2.0, 'fade_out': 4.0, 'align_end': False}


def run(cmd, cwd=None):
    r = subprocess.run(cmd, cwd=cwd, capture_output=True, text=True)
    if r.returncode != 0:
        sys.exit('ffmpeg 出错：\n' + ' '.join(cmd) + '\n' + r.stderr[-2000:])
    return r


def dur(f):
    return float(subprocess.check_output(['ffprobe', '-v', 'error', '-show_entries', 'format=duration', '-of', 'csv=p=0', f]).decode().strip())


def vsize(f):
    o = subprocess.check_output(['ffprobe', '-v', 'error', '-select_streams', 'v:0', '-show_entries', 'stream=width,height', '-of', 'csv=p=0', f]).decode().strip()
    w, h = o.split(',')[:2]
    return int(w), int(h)


def has_audio(f):
    o = subprocess.check_output(['ffprobe', '-v', 'error', '-select_streams', 'a', '-show_entries', 'stream=index', '-of', 'csv=p=0', f]).decode().strip()
    return bool(o)


def even(x):
    x = int(round(x))
    return x - (x % 2)


def find_font():
    for p in ['/System/Library/Fonts/PingFang.ttc', '/System/Library/Fonts/STHeiti Medium.ttc', 'C:/Windows/Fonts/msyhbd.ttc',
              'C:/Windows/Fonts/msyh.ttc', '/usr/share/fonts/opentype/noto/NotoSerifCJK-Regular.ttc',
              '/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc', '/usr/share/fonts/noto-cjk/NotoSansCJK-Regular.ttc']:
        if os.path.exists(p):
            return p
    return None


def offset_expr(shots, head, default):
    """shots: [[开始秒, 结束秒, 偏移像素], ...]，按原素材时间。返回 ffmpeg 表达式。"""
    if not shots:
        return str(default)
    expr = str(shots[-1][2])
    for s0, s1, off in reversed(shots[:-1]):
        expr = f'if(lt(t+{head:.4f},{s1}),{off},{expr})'
    return expr


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('plan')
    ap.add_argument('--title', action='store_true', help='只出片名卡')
    ap.add_argument('--draft', action='store_true', help='快速预览')
    a = ap.parse_args()
    base = os.path.dirname(os.path.abspath(a.plan))
    plan = {**DEF, **json.load(open(a.plan, encoding='utf-8'))}
    P = lambda p: p if os.path.isabs(p) else os.path.join(base, p)
    out = P(plan['output'])
    work = os.path.join(os.path.dirname(out), '_houqi_work')
    os.makedirs(work, exist_ok=True)
    fps = plan['fps']; asp = plan['aspect']
    OW, OH = (1080, 1920) if asp == '9:16' else (1920, 1080)
    crf = '28' if a.draft else '14'
    preset = 'ultrafast' if a.draft else 'veryfast'
    SEG = ['-c:v', 'libx264', '-preset', preset, '-crf', crf, '-pix_fmt', 'yuv420p', '-c:a', 'pcm_s16le', '-ar', '48000', '-ac', '2', '-f', 'mov']

    # LUT 和字体复制到工作文件夹，避免路径里的空格、冒号让 ffmpeg 出错
    lut = None
    if plan['lut']:
        shutil.copy(P(plan['lut']), os.path.join(work, 'grade.cube')); lut = 'grade.cube'

    # ---------- 片名卡
    title = plan['title']
    title_file = None
    if title:
        if title.get('video'):
            title_file = os.path.join(work, 'title.mov')
            run(['ffmpeg', '-v', 'error', '-y', '-i', P(title['video']), '-f', 'lavfi', '-i', 'anullsrc=r=48000:cl=stereo', '-shortest',
                 '-vf', f'scale={OW}:{OH}:force_original_aspect_ratio=decrease,pad={OW}:{OH}:(ow-iw)/2:(oh-ih)/2:black,setsar=1,fps={fps}',
                 '-map', '0:v', '-map', '1:a'] + SEG + [title_file])
        else:
            font = title.get('font') and P(title['font']) or find_font()
            if not font:
                sys.exit('没找到中文字体，请在 plan.json 的 title.font 里填一个字体文件路径（.ttf/.ttc/.otf）')
            shutil.copy(font, os.path.join(work, 'font' + os.path.splitext(font)[1])); fnt = 'font' + os.path.splitext(font)[1]
            secs = float(title.get('seconds', 3.75))
            lines = [('series', title.get('series', ''), 0.028, 0.40, 'F3ECE1@0.66'), ('name', title.get('name', ''), 0.089, 0.50, 'F3ECE1'),
                     ('ep', title.get('ep', ''), 0.024, 0.62, 'F3ECE1@0.58')]
            dt = []
            for k, txt, size, yy, col in lines:
                if not txt: continue
                open(os.path.join(work, f't_{k}.txt'), 'w', encoding='utf-8').write(txt)
                fs = int(OH * size) if asp != '9:16' else int(OW * size * 1.6)
                dt.append(f"drawtext=fontfile={fnt}:textfile=t_{k}.txt:fontsize={fs}:fontcolor=0x{col}:x=(w-text_w)/2:y=h*{yy}-text_h/2")
            fi = float(title.get('fade', 0.6))
            vf = ','.join(dt + [f'fade=t=in:st=0:d={fi}', f'fade=t=out:st={secs - fi:.3f}:d={fi}', 'format=yuv420p'])
            title_file = os.path.join(work, 'title.mov')
            run(['ffmpeg', '-v', 'error', '-y', '-f', 'lavfi', '-i', f'color=c=black:s={OW}x{OH}:r={fps}:d={secs}', '-f', 'lavfi', '-i',
                 'anullsrc=r=48000:cl=stereo', '-t', str(secs), '-vf', vf] + SEG + ['title.mov'], cwd=work)
        print('片名卡：', title_file)
        if a.title:
            prev = os.path.join(os.path.dirname(out), '片名卡预览.mp4')
            run(['ffmpeg', '-v', 'error', '-y', '-i', title_file, '-c:v', 'libx264', '-crf', '18', '-pix_fmt', 'yuv420p', '-an', prev])
            print('已导出', prev); return
    elif a.title:
        sys.exit('plan.json 里没有 title')

    # ---------- 逐段处理
    clips = plan['clips']; n = len(clips)
    segs = []; t_story = 0.0
    head = plan['trim_frames'] / fps
    dip = plan['dip']; edge = plan['audio_edge']
    for i, c in enumerate(clips):
        src = P(c['file']); D = dur(src); W, H = vsize(src)
        a0 = c['in'] if c.get('in') is not None else head
        a1 = c['out'] if c.get('out') is not None else D - head
        L = a1 - a0
        vf = []
        if asp == '2.4':
            ch = even(W / 2.4); oh = even(OW / 2.4)
            vf.append(f"crop={W}:{ch}:0:'{offset_expr(c.get('shots'), a0, (H - ch) // 2)}'")
            vf.append(f'scale={OW}:{oh}:flags=lanczos')
        elif asp == '9:16':
            cw = even(H * 9 / 16)
            vf.append(f"crop={cw}:{H}:'{offset_expr(c.get('shots'), a0, (W - cw) // 2)}':0")
            vf.append(f'scale={OW}:{OH}:flags=lanczos')
        else:
            vf.append(f'scale={OW}:{OH}:flags=lanczos')
        if plan['sharpen']: vf.append(f"unsharp=5:5:{plan['sharpen']}:5:5:0")
        if lut: vf.append(f'lut3d={lut}')
        if plan['grain']: vf.append(f"noise=c0s={plan['grain']}:c0f=t")
        if asp == '2.4': vf.append(f'pad={OW}:{OH}:0:({OH}-ih)/2:black')
        vf += ['setsar=1', f'fps={fps}', 'format=yuv420p']
        af = ['aresample=48000', 'aformat=channel_layouts=stereo']
        prev_dip = i > 0 and clips[i - 1].get('transition_out') == 'dip'
        if i == 0 and plan['fade_in']:
            vf.append(f"fade=t=in:st=0:d={plan['fade_in']}"); af.append('afade=t=in:st=0:d=0.3')
        elif prev_dip:
            vf.append(f"fade=t=in:st=0:d={dip['in']}"); af.append('afade=t=in:st=0:d=0.3')
        else:
            af.append(f'afade=t=in:st=0:d={edge}')
        if i == n - 1 and plan['fade_out']:
            fo = plan['fade_out']; vf.append(f'fade=t=out:st={L - fo:.3f}:d={fo}'); af.append(f'afade=t=out:st={L - fo:.3f}:d={fo}')
        elif c.get('transition_out') == 'dip':
            vf.append(f"fade=t=out:st={L - dip['out']:.3f}:d={dip['out']}"); af.append(f"afade=t=out:st={L - dip['out']:.3f}:d={dip['out']}")
        else:
            af.append(f'afade=t=out:st={L - edge:.3f}:d={edge}')
        seg = os.path.join(work, f'seg_{i + 1:02d}.mov')
        cmd = ['ffmpeg', '-v', 'error', '-y', '-ss', f'{a0:.4f}', '-t', f'{L:.4f}', '-i', src]
        if has_audio(src):
            cmd += ['-vf', ','.join(vf), '-af', ','.join(af)]
        else:
            cmd += ['-f', 'lavfi', '-t', f'{L:.4f}', '-i', 'anullsrc=r=48000:cl=stereo', '-vf', ','.join(vf), '-map', '0:v', '-map', '1:a']
        run(cmd + SEG + [seg], cwd=work)
        segs.append(seg); t_story += L
        print(f'第 {i + 1}/{n} 段处理完：{os.path.basename(src)}，{L:.2f} 秒')
        if c.get('transition_out') == 'dip' and i < n - 1:
            gap = os.path.join(work, f'gap_{i + 1:02d}.mov')
            run(['ffmpeg', '-v', 'error', '-y', '-f', 'lavfi', '-i', f"color=c=black:s={OW}x{OH}:r={fps}:d={dip['black']}", '-f', 'lavfi', '-i',
                 'anullsrc=r=48000:cl=stereo', '-t', str(dip['black'])] + SEG + [gap])
            segs.append(gap); t_story += dip['black']
    if plan['tail_black']:
        tail = os.path.join(work, 'tail.mov')
        run(['ffmpeg', '-v', 'error', '-y', '-f', 'lavfi', '-i', f"color=c=black:s={OW}x{OH}:r={fps}:d={plan['tail_black']}", '-f', 'lavfi', '-i',
             'anullsrc=r=48000:cl=stereo', '-t', str(plan['tail_black'])] + SEG + [tail])
        segs.append(tail)

    def concat(files, dst, extra):
        lst = os.path.join(work, 'list.txt')
        with open(lst, 'w', encoding='utf-8') as fh:
            for f in files: fh.write("file '" + f.replace("'", "'\\''") + "'\n")
        run(['ffmpeg', '-v', 'error', '-y', '-f', 'concat', '-safe', '0', '-i', lst] + extra + [dst])

    story = os.path.join(work, 'story.mov')
    concat(segs, story, ['-c', 'copy'])

    # ---------- 声音
    X264 = ['-c:v', 'libx264', '-preset', 'ultrafast' if a.draft else 'medium', '-crf', '28' if a.draft else '18', '-pix_fmt', 'yuv420p',
            '-r', str(fps), '-x264-params', f'keyint={fps * 2}:min-keyint={fps}:scenecut=0']
    dia = os.path.join(work, 'dia.wav')
    run(['ffmpeg', '-v', 'error', '-y', '-i', story, '-vn', '-af', f"loudnorm=I={plan['dialogue_lufs']}:TP=-1.5:LRA=11,aresample=48000", '-c:a', 'pcm_s16le', dia])
    vids = ([title_file] if title_file else []) + [story]
    video = os.path.join(work, 'video.mp4')
    if title_file:
        concat(vids, os.path.join(work, 'joined.mov'), ['-c', 'copy'])
        run(['ffmpeg', '-v', 'error', '-y', '-i', os.path.join(work, 'joined.mov'), '-an'] + X264 + [video])
    else:
        run(['ffmpeg', '-v', 'error', '-y', '-i', story, '-an'] + X264 + [video])
    Pt = dur(title_file) if title_file else 0.0
    T = dur(video); ms = int(round(Pt * 1000))
    music = plan['music']
    premix = os.path.join(work, 'premix.wav')
    if music:
        m = {**MUSIC_DEF, **music}; mf = P(m['file'])
        off = max(0.0, dur(mf) - T) if m['align_end'] else 0.0
        LF = m['title_lift'] if title_file else 1.0
        lift = f"if(lt(t,{Pt - 0.35:.3f}),{LF},if(lt(t,{Pt + 0.65:.3f}),{LF}-({LF}-1)*(t-{Pt - 0.35:.3f}),1.0))"
        g = (f"[0:a]aresample=48000,adelay={ms}|{ms},apad,atrim=0:{T:.3f},asplit=2[dia][sc];"
             f"[1:a]aresample=48000,aformat=channel_layouts=stereo,atrim={off:.3f}:{off + T:.3f},asetpts=PTS-STARTPTS,apad,atrim=0:{T:.3f},"
             f"loudnorm=I={m['lufs']}:TP=-8:LRA=7,acompressor=threshold=-30dB:ratio=2:attack=200:release=1000,"
             f"volume='{lift}':eval=frame,afade=t=in:st=0:d=0.05,afade=t=out:st={T - m['fade_out']:.3f}:d={m['fade_out']}[m0];")
        if m['duck']:
            g += "[m0][sc]sidechaincompress=threshold=0.02:ratio=5:attack=40:release=600:makeup=1[mm];[dia][mm]"
        else:
            g += "[sc]anullsink;[dia][m0]"
        g += 'amix=inputs=2:duration=first:dropout_transition=0:normalize=0[out]'
        run(['ffmpeg', '-v', 'error', '-y', '-i', dia, '-i', mf, '-filter_complex', g, '-map', '[out]', '-c:a', 'pcm_s16le', premix])
    else:
        run(['ffmpeg', '-v', 'error', '-y', '-i', dia, '-af', f'aresample=48000,adelay={ms}|{ms},apad,atrim=0:{T:.3f}', '-c:a', 'pcm_s16le', premix])
    e = subprocess.run(['ffmpeg', '-nostats', '-i', premix, '-af', 'ebur128', '-f', 'null', '-'], capture_output=True, text=True).stderr
    I = float(re.findall(r'I:\s+([-\d.]+) LUFS', e)[-1]); gain = plan['final_lufs'] - I
    lim = 10 ** (plan['limit_db'] / 20)
    aud = os.path.join(work, 'audio.m4a')
    run(['ffmpeg', '-v', 'error', '-y', '-i', premix, '-af', f'volume={gain:.2f}dB,alimiter=limit={lim:.3f}:attack=5:release=50:level=disabled,aresample=48000',
         '-c:a', 'aac', '-b:a', '256k', aud])
    run(['ffmpeg', '-v', 'error', '-y', '-i', video, '-i', aud, '-map', '0:v', '-map', '1:a', '-c', 'copy', '-movflags', '+faststart', out])

    # ---------- 字幕：把正片时间轴的 SRT 往后挪片名卡的时长
    if plan['story_srt']:
        txt = open(P(plan['story_srt']), encoding='utf-8-sig').read()
        def sh(mm):
            h, m_, s, ms_ = map(int, mm.groups()); t = h * 3600 + m_ * 60 + s + ms_ / 1000 + Pt
            return f'{int(t // 3600):02d}:{int(t % 3600 // 60):02d}:{int(t % 60):02d},{int(round((t - int(t)) * 1000)) % 1000:03d}'
        txt = re.sub(r'(\d+):(\d+):(\d+),(\d+)', sh, txt)
        open(os.path.splitext(out)[0] + '.srt', 'w', encoding='utf-8').write(txt)

    e = subprocess.run(['ffmpeg', '-nostats', '-i', out, '-af', 'ebur128=peak=true', '-f', 'null', '-'], capture_output=True, text=True).stderr
    fi = re.findall(r'I:\s+([-\d.]+) LUFS', e)[-1]; fp = re.findall(r'Peak:\s+([-\d.]+) dBFS', e)[-1]
    print(f'\n完成：{out}\n时长 {T:.2f} 秒（片名卡 {Pt:.2f} 秒）｜成片响度 {fi} LUFS｜真峰值 {fp} dBTP')
    print('下一步：发到手机上看一遍、外放听一遍。')


if __name__ == '__main__':
    main()
