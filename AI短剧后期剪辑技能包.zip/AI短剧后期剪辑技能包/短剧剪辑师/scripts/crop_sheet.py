#!/usr/bin/env python3
"""出裁切对照图：每个镜头取中间一帧，画出裁切窗口，拼成一张大图，先给人确认再出片。

用法：
    python3 crop_sheet.py plan.json [输出图片.jpg]

只依赖 ffmpeg / ffprobe。窗口按 plan.json 的 aspect（2.4 或 9:16）和每个镜头的偏移画。
"""
import json, os, shutil, subprocess, sys, tempfile


def dur(f):
    return float(subprocess.check_output(['ffprobe', '-v', 'error', '-show_entries', 'format=duration', '-of', 'csv=p=0', f]).decode().strip())


def vsize(f):
    o = subprocess.check_output(['ffprobe', '-v', 'error', '-select_streams', 'v:0', '-show_entries', 'stream=width,height', '-of', 'csv=p=0', f]).decode().strip()
    w, h = o.split(',')[:2]
    return int(w), int(h)


def even(x):
    x = int(round(x)); return x - (x % 2)


def main():
    plan_path = sys.argv[1]
    base = os.path.dirname(os.path.abspath(plan_path))
    plan = json.load(open(plan_path, encoding='utf-8'))
    asp = plan.get('aspect', '2.4')
    out = sys.argv[2] if len(sys.argv) > 2 else os.path.join(base, '裁切对照图.jpg')
    tmp = tempfile.mkdtemp()
    k = 0
    font = None
    for fp in ['/System/Library/Fonts/PingFang.ttc', 'C:/Windows/Fonts/msyh.ttc', 'C:/Windows/Fonts/arial.ttf',
               '/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc', '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf']:
        if os.path.exists(fp):
            ext = os.path.splitext(fp)[1]; shutil.copy(fp, os.path.join(tmp, 'font' + ext)); font = fp; break
    for ci, c in enumerate(plan['clips'], 1):
        src = c['file'] if os.path.isabs(c['file']) else os.path.join(base, c['file'])
        W, H = vsize(src); D = dur(src)
        shots = c.get('shots') or [[0, D, None]]
        for si, (s0, s1, off) in enumerate(shots, 1):
            t = (s0 + min(s1, D)) / 2
            if asp == '2.4':
                ch = even(W / 2.4); y = off if off is not None else (H - ch) // 2
                box = f'drawbox=x=0:y={y}:w={W}:h={ch}:color=0xEE8A3A:t=6'
                shade = f"drawbox=x=0:y=0:w={W}:h={y}:color=black@0.55:t=fill,drawbox=x=0:y={y + ch}:w={W}:h={max(H - y - ch, 0)}:color=black@0.55:t=fill"
            elif asp == '9:16':
                cw = even(H * 9 / 16); x = off if off is not None else (W - cw) // 2
                box = f'drawbox=x={x}:y=0:w={cw}:h={H}:color=0xEE8A3A:t=6'
                shade = f"drawbox=x=0:y=0:w={x}:h={H}:color=black@0.55:t=fill,drawbox=x={x + cw}:y=0:w={max(W - x - cw, 0)}:h={H}:color=black@0.55:t=fill"
            else:
                box = shade = 'null'
            k += 1
            label = 'null'
            if font:
                open(os.path.join(tmp, f'l{k}.txt'), 'w', encoding='utf-8').write(f'{ci:02d}-{si}')
                label = f"drawbox=x=0:y=0:w={W // 6}:h={H // 9}:color=black@0.7:t=fill,drawtext=fontfile=font{ext}:textfile=l{k}.txt:fontsize={H // 13}:fontcolor=0xEE8A3A:x={W // 60}:y={H // 60}"
            subprocess.run(['ffmpeg', '-v', 'error', '-y', '-ss', f'{t:.3f}', '-i', os.path.abspath(src), '-frames:v', '1',
                            '-vf', f'{shade},{box},{label},scale=640:-2', f'{k:04d}.png'], check=True, cwd=tmp)
            print(f'段 {ci:02d} 镜头 {si}：第 {k} 格')
    cols = 4; rows = (k + cols - 1) // cols
    subprocess.run(['ffmpeg', '-v', 'error', '-y', '-framerate', '1', '-i', os.path.join(tmp, '%04d.png'),
                    '-vf', f'tile={cols}x{rows}:padding=6:margin=6:color=0x222222', '-frames:v', '1', '-q:v', '3', out], check=True)
    shutil.rmtree(tmp)
    print(f'已生成 {out}：共 {k} 个镜头，按「段 → 镜头」从左到右、从上到下排列')


if __name__ == '__main__':
    main()
