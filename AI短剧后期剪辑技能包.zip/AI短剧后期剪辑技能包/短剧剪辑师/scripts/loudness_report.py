#!/usr/bin/env python3
"""体检用：逐段测素材的规格和响度，输出一张表。

用法：
    python3 loudness_report.py 素材文件夹 [--csv 报告.csv]

只依赖 ffmpeg / ffprobe（需要先装好，命令行能直接运行）。
测的是整段的综合响度（LUFS）和真峰值（dBTP）。
"""
import argparse, csv, json, os, re, subprocess, sys

EXT = ('.mp4', '.mov', '.mkv', '.m4v', '.webm', '.wav', '.mp3', '.m4a', '.aac', '.flac')


def probe(path):
    out = subprocess.run(['ffprobe', '-v', 'error', '-print_format', 'json', '-show_streams', '-show_format', path],
                         capture_output=True, text=True, check=True).stdout
    d = json.loads(out)
    v = next((s for s in d['streams'] if s['codec_type'] == 'video'), None)
    a = next((s for s in d['streams'] if s['codec_type'] == 'audio'), None)
    fps = ''
    if v and v.get('r_frame_rate', '0/0') != '0/0':
        n, m = v['r_frame_rate'].split('/')
        fps = round(float(n) / float(m), 3)
    return {
        'dur': round(float(d['format'].get('duration', 0)), 3),
        'size': f"{v['width']}x{v['height']}" if v else '',
        'fps': fps,
        'audio': bool(a),
    }


def loudness(path):
    err = subprocess.run(['ffmpeg', '-nostats', '-i', path, '-vn', '-af', 'ebur128=peak=true', '-f', 'null', '-'],
                         capture_output=True, text=True).stderr
    i = re.findall(r'I:\s+([-\d.]+) LUFS', err)
    p = re.findall(r'Peak:\s+([-\d.inf]+) dBFS', err)
    return (float(i[-1]) if i else None, float(p[-1]) if p and p[-1] != '-inf' else None)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('folder')
    ap.add_argument('--csv')
    ap.add_argument('--target', type=float, default=-16.0, help='对白目标响度，默认 -16 LUFS')
    a = ap.parse_args()
    files = sorted(f for f in os.listdir(a.folder) if f.lower().endswith(EXT))
    if not files:
        sys.exit('文件夹里没有找到视频或音频文件')
    rows = []
    for f in files:
        p = os.path.join(a.folder, f)
        info = probe(p)
        I, TP = loudness(p) if info['audio'] else (None, None)
        rows.append(dict(file=f, **info, lufs=I, peak=TP))
        print(f'测完 {f}', file=sys.stderr)

    print('\n| 段 | 文件 | 时长(秒) | 分辨率 | 帧率 | 响度 LUFS | 真峰值 dBTP |')
    print('|---|---|---|---|---|---|---|')
    for k, r in enumerate(rows, 1):
        l = '无声' if r['lufs'] is None else r['lufs']
        pk = '' if r['peak'] is None else r['peak']
        print(f"| {k:02d} | {r['file']} | {r['dur']} | {r['size']} | {r['fps']} | {l} | {pk} |")

    ls = [r['lufs'] for r in rows if r['lufs'] is not None]
    print()
    print(f"共 {len(rows)} 段，总时长 {sum(r['dur'] for r in rows):.1f} 秒")
    sizes = {r['size'] for r in rows if r['size']}
    fpss = {r['fps'] for r in rows if r['fps']}
    if len(sizes) > 1: print(f'⚠ 分辨率不统一：{sorted(sizes)}，出片前要统一')
    if len(fpss) > 1: print(f'⚠ 帧率不统一：{sorted(fpss)}，出片前统一成同一个帧率')
    if ls:
        lo, hi = min(ls), max(ls)
        print(f'响度范围 {lo} ~ {hi} LUFS，最大差 {hi - lo:.1f} LU')
        if hi - lo > 2: print(f'⚠ 段和段之间差超过 2 LU，听起来会一段大一段小，对白要统一到 {a.target} LUFS')
        print('注：整段响度会被大段静音拉低；台词少的段读数偏低是正常的，以听感为准。')
    loud = [r['file'] for r in rows if r['peak'] is not None and r['peak'] > -1]
    if loud: print(f'⚠ 真峰值超过 -1 dB：{loud}，最后要加限幅')
    silent = [r['file'] for r in rows if not r['audio']]
    if silent: print(f'提示：这些素材没有声音：{silent}，需要后期配音或只放配乐')

    if a.csv:
        with open(a.csv, 'w', newline='', encoding='utf-8-sig') as fh:
            w = csv.DictWriter(fh, fieldnames=list(rows[0].keys()))
            w.writeheader(); w.writerows(rows)
        print(f'已写入 {a.csv}')


if __name__ == '__main__':
    main()
