# ToonFlow v5.2.5：视频接不上的修复

基线：v5.2.4-reference-video。对照《ToonFlow 为什么接不上》报告（index.html）逐条核实源码、配置、请求记录和试片截图，然后修复。

## 一、报告核实结果

| # | 报告说法 | 核实 | 依据 |
|---|---|---|---|
| 1 | 60 秒试片后 5 条绕过流水线，3 分钟内全部提交，只有一张 first_frame | **对** | `config.v524-preview.json` 里 `preview.maxClips = 1`；`clip2–6-请求.json` 的 `created_at` 从 1794672649 到 1794672808，共 159 秒；每个请求只有 1 个 `first_frame`；`concat.py` 只是按包拼接 |
| 2 | `continuationContext()` 没人调用；`trimHeadFrames` 从未被赋值 | **对** | 全项目只有定义（pipeline.ts 第 1102 行）。备份 `pipeline.v5orig.ts.bak` 第 804 行原本调用了它，后来为了遵守 ai& “首帧不能带参考图”的限制，把整段删了，属于回归。`h3ps.test.ts` 里“续接参考随视频提交”这条测试因此会失败 |
| 3 | 正式配置把续接关了；参考图分支只带首帧和角色图 | **对** | `work/run/config.json`：`continuation.mode = "never"`、`chainContinuous = false`、没有 `rhythm`；第 986–988 行没有传场景图和上一镜画面 |
| 4 | ai& 首尾帧和参考素材不能同请求、没有 seed | **对** | `aiand.ts` 文件头和 `plan()` 里的 `badRequest`；首帧分支第 1003–1006 行删掉参考图和参考人声 |
| 5 | `scorer: none` 固定 1 分；严格质检 0/22、0/6，“上一镜不过就不续接” | **对** | `scoring.ts` 第 61 行；`pipeline_flow_v4.md` 第 18–19 行；`continuationGate()` 要求 `lastFrameHandsOk === true` |
| 6 | 第 1 条 10 秒里切了 3 次，结尾停在手套特写 | **对，补充一点** | `v524-10s/视频请求.json` 写着 “exactly 3 planned cuts”。这条提示词和 `分镜.md` 是手写的；当前 `clips.ts` 已经是一镜一条（`maxShots` 缺省 1），流水线本身不会再这样打包 |
| 7 | 道具/空间状态只在文字里；接力只在段内 | **对** | `segmentShots()` 每段 `previous` 重新开始，段与段 `runPool` 并行 |
| 8 | 完整流程没跑通过 | **对** | `FAILURE_REPORT.md`：E01-04-09 台词 17.2 秒 > 15 秒；`pipeline_flow_v4.md` 第 27 行：2 小时 50 分只完成 2/17 |

报告之外又发现三点：

- **第 1 条的首帧本身就在门外。** `v524-10s/首帧.jpg` 背景是街道和路灯，剧本写的是“旧公寓门内”。所以门内/门外的错不是从第 2 条才开始，就算接力做对了，也会把“门外”一路带下去。
- **正式配置设了 `shotQa`，但没有设 `qaGate: "block"`**，外部逐帧质检实际上不会运行（第 1077 行）。这是有意放宽（严格质检通过率接近 0，开 block 会挡住导出），本次保持不变。
- `h3ps.test.ts` 的“逐帧质检钩子”测试在 v5.2.4 上本来就过不了：没设 `qaGate`，质检从未执行；而且它期望的 `qa` 结构（带 `score`）和警告文字是旧版的。v5.2.5 已改写这条测试（见下）。
- 截图核对：5 个接缝的描述和截图一致（`end*.jpg` 是每条第 9 秒的画面，不是严格的最后一帧，结论不受影响）。

## 二、修了什么

### 代码（`toonflow-app/apps/server/src/autoflow/`）

1. **续接上下文真正接进视频请求**（`pipeline.ts`）
   - 参考图模式（`input: "reference"`）：除了首帧和角色图，再带**场景图、道具图、上一镜结尾 3 帧**。
   - 直驱模式（`directReference`）：同样带上一镜结尾帧。
   - 首帧模式：供应商允许混用时（`videoModel.framesWithReferences`，缺省 ai& 为 false、其他为 true）恢复 v5 原版做法，首帧 + 结尾帧 + 角色锚点；ai& 仍然只发首帧，靠“首帧 = 上一镜尾帧”保证连续。
2. **接力镜头改走首帧模式**（`chainedVideoInput`，缺省 `firstFrame`）：即使整体是参考图模式，接力镜头也把上一镜尾帧作为真正的 `first_frame` 提交，姿势、道具、门的样子直接接上。设 `"follow"` 恢复旧行为。
3. **手指质检和接力分开**（`continuation.ts`，`continuation.handsGate`，缺省 `warn`）：手指/肢体瑕疵只记警告，不再切断接力、续接和“上一镜画面作参考”。人物明显变样（`chainable=false`）和角色特征串用仍然断链。设 `"block"` 恢复旧行为。
4. **同场景跨段接力**（`chainAcrossSegments`，缺省 false）：相邻两段是同一场景时，下一段第一镜也承接上一段最后一镜。开启后段落串行生成（会变慢）。
5. **结尾交接提示**（`endOnSubject`，缺省 true）：下一镜要接力时，视频提示词末尾追加“最后一秒不切，停在主角脸清楚可见的画面上，不停在插入特写/空镜/眼睛大特写”，并写入上一镜的结束状态（`spatialContract.endState` / `endFrame`）。提示词接近 ai& 7000 字符上限时自动不加。
6. **逐帧质检不通过的镜头不接力**：`qaGate: "block"` 下外部质检判 fail 的镜头，不再作为下一镜的首帧和参考图（v5.2.4 只挡了续接，没挡接力）。
7. **接缝去重帧**：首帧就是上一镜尾帧的镜头，`trimHeadFrames = 1`，拼接时丢掉重复的第 0 帧，并触发 `stitch.ts` 里已有的音频交叉淡化。
8. **H3 提示词**（`promptStyles/h3.ts`）：新增 `tailFrame` 参考图类型，`subject_definitions` / `retention_analysis` 写明“延续位置、门内门外、道具状态、天气光线；人物外观以角色图为准”。
9. **配置校验**（`service.ts`）：上面新增的字段都加进了 schema（原 schema 是 strict，不加会直接报错）。

### 配置

- `work/run/config.json`（正式整章）：`chainContinuous: true`、`chainAcrossSegments: true`、`chainedVideoInput: "firstFrame"`、`endOnSubject: true`、`continuation: { mode: "qa", frames: 3, handsGate: "warn" }`。原文件备份为 `work/run/config.v524.json.bak`。
- 新增 `config.v525-60s-preview.json` + `launch_v525_60s_preview.sh.txt`：用正式流水线出 6 条 10 秒，串行接力，花费上限 5 美元。

### 60 秒试片（门缝）

新增 `work/preview/v525-60s/submit_chain.py` 和 `concat_chain.py`，替代旧的 `v524-60s/submit.py`：

- 第 1 条改用角色图做参考、在屋内开拍（旧首帧在门外，不再用）。
- 第 2–6 条：等上一条完成，抽最后一帧直接当 `first_frame`。
- 每条一个镜头、不切；结尾停在林夏的脸上；提示词写明门内门外、门链状态、照片和手机在哪只手。
- `--dry-run` 只打印请求不花钱；`--only 2` 先做两条看接缝（约 $1.10）；中断后重跑不会重复提交。
- 拼接时接力条丢掉第 0 帧（需要 ffmpeg；没有就退回 PyAV 无损拼接）。
- 全部 6 条约 $3.30（10 秒 × $0.055 × 6，只在成功时扣费）。

### 测试

- `h3ps.test.ts`：续接门控测试按新规则更新（手指缺省不断链、`handsGate: "block"` 断链、人物变样仍断链）；新增端到端测试：参考图模式带续接帧和场景图、接力镜头走首帧模式并裁 1 帧、首帧请求不混参考图（模拟 ai&）、同场景跨段续接。
- `references.test.ts`：新增结尾帧排序和截断测试。
- `h3ps.test.ts`“逐帧质检钩子”：改为 `qaGate: "block"`，按现行结构断言（`qa = { pass, issues }`、`qaResult.status = "fail"`、警告“逐帧质检fail”），并断言第一镜不通过时导出被拒、下一镜不续接。
- 复核了 `hardening.test.ts` 和 `pipeline.test.ts` 里与接力相关的断言，按代码推演仍应通过：缺省不接力；尾帧手指不过时，关键帧参考仍优先挂通过检查的上一镜首帧。

## 三、没有验证的部分

- 当前环境没有 Bun、tsc 和依赖，**没有运行任何测试，也没有做类型检查**；只做了括号/模板字符串配平检查，并人工复读了改动。请先在部署环境运行：
  `cd toonflow-app/apps/server && bun test test/autoflow/h3ps.test.ts test/autoflow/references.test.ts test/autoflow/pipeline.test.ts`
- `submit_chain.py` 只在本地用 `--dry-run` 跑过，确认了请求结构和提示词长度（约 1.2k 字符）；没有调用 ai&，没有生成视频。
- 接力能解决姿势、道具、门的样子对不上，但 H3 在 10 秒内仍可能让道具或背景慢慢走样，需要看实际成片。
- 声音：接力条走首帧模式，ai& 不允许同时带参考人声，每条配音仍由模型各自生成，音色一致性没有解决。项目里已有后处理可以用：先跑 `worker/voice/voice_sim.py RUN_DIR voice.json` 找出音色偏离的镜头，再跑 `worker/voice/unify.py RUN_DIR voice.json OUT_DIR`（Demucs 分离人声 → Seed-VC 转向该角色最典型的一镜 → 重新混音；声纹相似度升高、台词识别不下降才采用）。依赖 CAM++、faster-whisper、Demucs、Seed-VC，本次没有运行。
- 整章流程还卡在分镜阶段（v5.2 的拆镜修复尚未做真实回归），本次没有动分镜。
