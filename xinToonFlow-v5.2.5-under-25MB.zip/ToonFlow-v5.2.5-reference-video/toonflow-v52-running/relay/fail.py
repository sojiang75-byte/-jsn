#!/usr/bin/env python3
"""Mark a relay job failed (Toonflow may then resubmit it).  Usage: python3 fail.py <id> <reason...>"""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import *

if len(sys.argv) < 3:
    raise SystemExit(__doc__)
job_id, reason = check_id(sys.argv[1]), " ".join(sys.argv[2:])
qpath, dpath = job_paths(job_id)
job = read_json(qpath)
if not job:
    raise SystemExit(f"no pending job {job_id}")
write_json(dpath, {"id": job_id, "type": job["type"], "status": "failed", "error": {"code": "generation_failed", "message": reason},
                   "finished_at": now_iso(), "request": job})
os.remove(qpath)
print(f"failed {job_id}: {reason}")
