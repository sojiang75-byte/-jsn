# grok-relay：Grok Imagine 本机文件队列中继

Toonflow 的 `grokRelay` 供应商（图片 `grok-imagine-image`、视频 `grok-imagine-video`）把请求发给本机中继；
中继把每个请求写成 `queue/<id>.json`，助手在对话里用 Grok Imagine 生成后用 `finish.py` 回填，Toonflow 轮询拿到结果。

```bash
mkdir -p /workspace/relay && cp tools/grok-relay/*.py /workspace/relay/
cd /workspace/relay && nohup python3 server.py >> server.log 2>&1 &   # 只监听 127.0.0.1:8787
python3 /workspace/relay/next.py                 # 列出待处理任务（提示词、参数、参考图绝对路径）
python3 /workspace/relay/finish.py <id> <文件>   # 回填结果（复制到 outputs/，写 done/<id>.json）
python3 /workspace/relay/fail.py <id> <原因>     # 标记失败（Toonflow 可换种子重提）
```

- 接口：`POST /v1/images/generations`、`POST /v1/videos`（seconds ≤ 15）、`GET /v1/{images|videos}/{id}`、`.../content`、`GET /v1/jobs?status=queued`、`GET /health`。
- 参考图（路径 / data URL / base64）保存在 `inputs/<id>/`，任务文件里是绝对路径。
- `Idempotency-Key` 相同的提交返回原任务（原任务失败的除外），提交响应丢失也不会排两份。
- 任务排队超过 `RELAY_JOB_TIMEOUT_HOURS`（缺省 24）小时报失败；`RELAY_ROOT`、`RELAY_PORT` 可改目录和端口。
- 不收费、没有密钥；Toonflow 花费记录按 $0 记。
