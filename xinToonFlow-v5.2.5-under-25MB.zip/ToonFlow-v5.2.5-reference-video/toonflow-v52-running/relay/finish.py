#!/usr/bin/env python3
"""Attach a generated file to a relay job.  Usage: python3 finish.py <id> <result file> [--force]"""
import hashlib, os, shutil, subprocess, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import *

args = [a for a in sys.argv[1:] if a != "--force"]
if len(args) != 2:
    raise SystemExit(__doc__)
job_id, source = check_id(args[0]), os.path.abspath(args[1])
qpath, dpath = job_paths(job_id)
job = read_json(qpath) or (read_json(dpath) or {}).get("request")
if not job:
    raise SystemExit(f"no such job: {job_id}")
if os.path.exists(dpath) and "--force" not in sys.argv:
    raise SystemExit(f"{job_id} already has a result ({dpath}); pass --force to replace it")
if not os.path.isfile(source) or os.path.getsize(source) == 0:
    raise SystemExit(f"result file missing or empty: {source}")
ext = os.path.splitext(source)[1].lower()
table = IMAGE_EXT if job["type"] == "image" else VIDEO_EXT
with open(source, "rb") as f:
    head = f.read(16)
if job["type"] == "image":
    ext = ".png" if head[:8] == b"\x89PNG\r\n\x1a\n" else ".jpg" if head[:3] == b"\xff\xd8\xff" else ".webp" if head[8:12] == b"WEBP" else ext
elif head[4:8] == b"ftyp":
    ext = ext if ext in (".mp4", ".mov") else ".mp4"
if ext not in table:
    raise SystemExit(f"{job['type']} job needs one of {', '.join(table)}; got {source}")
target = os.path.join(OUTPUTS, job_id + ext)
shutil.copyfile(source, target)
sha = hashlib.sha256(open(target, "rb").read()).hexdigest()
record = {"id": job_id, "type": job["type"], "status": "completed", "file": target, "mime_type": table[ext],
          "bytes": os.path.getsize(target), "sha256": sha, "source": source, "finished_at": now_iso(), "request": job}
if job["type"] == "video":
    try:
        out = subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration:stream=codec_type,width,height", "-of", "json", target],
                             capture_output=True, text=True, timeout=60).stdout
        info = json.loads(out)
        record["duration"] = round(float(info["format"]["duration"]), 3)
        streams = info.get("streams", [])
        record["has_audio"] = any(s.get("codec_type") == "audio" for s in streams)
        video = next((s for s in streams if s.get("codec_type") == "video"), {})
        record["width"], record["height"] = video.get("width"), video.get("height")
        want = job.get("params", {}).get("seconds")
        if want and abs(record["duration"] - float(want)) > 1.5:
            print(f"warning: clip is {record['duration']}s, request asked for {want}s", file=sys.stderr)
    except Exception as e:  # ffprobe missing or not a real video (smoke tests)
        record["probe_error"] = str(e)[:200]
write_json(dpath, record)
if os.path.exists(qpath):
    os.remove(qpath)
print(f"completed {job_id} -> {target}")
