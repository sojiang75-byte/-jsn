#!/usr/bin/env python3
"""List pending relay jobs with full details.  Usage: python3 next.py [--json] [--one] [--all]"""
import json, os, sys, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import *

def pending():
    jobs = []
    for name in os.listdir(QUEUE):
        if name.endswith(".json") and name.count(".") == 1:
            status, job = job_status(name[:-5])
            if status == "queued" or ("--all" in sys.argv and job):
                jobs.append((status, job))
    return sorted(jobs, key=lambda item: item[1].get("created_ts", 0))

jobs = pending()
if "--one" in sys.argv:
    jobs = jobs[:1]
if "--json" in sys.argv:
    print(json.dumps([job for _, job in jobs], ensure_ascii=False, indent=2))
    sys.exit(0)
if not jobs:
    print("No pending jobs.")
    sys.exit(0)
print(f"{len(jobs)} pending job(s), oldest first:\n")
for status, job in jobs:
    p, refs = job.get("params", {}), job.get("references", {})
    age = int(time.time() - job.get("created_ts", time.time()))
    print("=" * 78)
    print(f"id:      {job['id']}   type: {job['type']}   status: {status}   queued: {job.get('created_at')} ({age // 60} min ago)")
    print(f"params:  {json.dumps(p, ensure_ascii=False)}")
    for role in ("first_frame", "last_frame"):
        if refs.get(role):
            print(f"{role}: {refs[role]}")
    for i, path in enumerate(refs.get("images", []), 1):
        print(f"ref image {i}: {path}")
    print("prompt:")
    print(job.get("prompt", ""))
    ext = "png" if job["type"] == "image" else "mp4"
    print(f"\n-> python3 {ROOT}/finish.py {job['id']} /path/to/result.{ext}")
    print(f"-> python3 {ROOT}/fail.py {job['id']} \"reason\"")
print("=" * 78)
