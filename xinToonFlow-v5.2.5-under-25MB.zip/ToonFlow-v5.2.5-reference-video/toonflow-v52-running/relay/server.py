#!/usr/bin/env python3
"""Local OpenAI-style relay for Grok Imagine (images + videos).

Binds 127.0.0.1 only. Each request becomes queue/<id>.json; the assistant generates the media
in chat and runs finish.py / fail.py, which writes done/<id>.json. No API key is needed or stored.

  POST /v1/images/generations   {prompt, size?, aspect_ratio?, n?, seed?, images?: [path|data-url|base64|{path}|{b64_json}|{image_url:{url}}]}
  POST /v1/videos               {prompt, seconds<=15, aspect_ratio?, resolution?, generate_audio?, seed?,
                                 first_frame?, last_frame?, images?/references?: [...same forms...]}
  GET  /v1/images/{id}  /v1/videos/{id}          -> {id, object, status: queued|completed|failed, ...}
  GET  /v1/images/{id}/content  /v1/videos/{id}/content   -> the png/mp4 bytes once completed
  GET  /v1/jobs?status=queued   GET /health
Header Idempotency-Key (or body field idempotency_key): repeating a submit with the same key returns the
existing job (unless that job failed), so a lost response never creates a duplicate job.
"""
import base64, binascii, hashlib, json, os, re, secrets, shutil, sys, time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from threading import Lock
from urllib.parse import urlparse, parse_qs
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import *

MAX_BODY = 300 * 1024 * 1024
MAX_SECONDS = 15
MAX_REFS = 12
submit_lock = Lock()

class BadRequest(Exception):
    pass

def sniff(data):
    if data[:8] == b"\x89PNG\r\n\x1a\n": return ".png"
    if data[:3] == b"\xff\xd8\xff": return ".jpg"
    if data[:4] == b"RIFF" and data[8:12] == b"WEBP": return ".webp"
    raise BadRequest("reference image must be PNG, JPEG or WebP")

def save_ref(job_id, name, value):
    """Store one reference image under inputs/<id>/ and return its absolute path."""
    if isinstance(value, dict):
        value = value.get("path") or value.get("b64_json") or value.get("data") or value.get("url") or (value.get("image_url") or {}).get("url")
    if not isinstance(value, str) or not value.strip():
        raise BadRequest(f"{name}: unsupported reference")
    value = value.strip()
    folder = os.path.join(INPUTS, job_id)
    os.makedirs(folder, exist_ok=True)
    if value.startswith("file://"):
        value = value[7:]
    if value.startswith("/"):
        if not os.path.isfile(value):
            raise BadRequest(f"{name}: file not found: {value}")
        with open(value, "rb") as f:
            data = f.read()
    elif re.match(r"^https?://", value, re.I):
        raise BadRequest(f"{name}: remote URLs are not fetched; send a local path or base64")
    else:
        raw = value.split(",", 1)[1] if value.startswith("data:") else value
        try:
            data = base64.b64decode(raw, validate=True)
        except (binascii.Error, ValueError):
            raise BadRequest(f"{name}: invalid base64")
    path = os.path.join(folder, name + sniff(data))
    with open(path, "wb") as f:
        f.write(data)
    return path

def ref_list(body):
    items = body.get("images") or body.get("references") or body.get("reference_images") or []
    if isinstance(items, dict):  # {images:[...]} (aiand-style references)
        items = items.get("images") or []
    if not isinstance(items, list):
        raise BadRequest("images must be a list")
    if len(items) > MAX_REFS:
        raise BadRequest(f"at most {MAX_REFS} reference images")
    return items

def public(job, status, record):
    kind = "image" if job["type"] == "image" else "video"
    out = {"id": job["id"], "object": f"{kind}.generation" if kind == "image" else "video", "type": kind, "status": status,
           "created_at": job.get("created_ts"), "model": job.get("params", {}).get("model")}
    if kind == "video":
        out["seconds"] = job.get("params", {}).get("seconds")
    if status == "completed":
        out["file"] = record.get("file")
        out["mime_type"] = record.get("mime_type")
        out["completed_at"] = record.get("finished_at")
        out["content_url"] = f"/v1/{kind}s/{job['id']}/content"
        if kind == "image":
            out["data"] = [{"url": f"http://127.0.0.1:{PORT}/v1/images/{job['id']}/content"}]
    if status == "failed":
        out["error"] = record.get("error") or {"code": "failed", "message": record.get("reason", "failed")}
    return out

def find_by_key(key):
    for folder in (QUEUE, DONE):
        for name in os.listdir(folder):
            if not name.endswith(".json") or name.count(".") != 1:
                continue
            rec = read_json(os.path.join(folder, name))
            req = (rec or {}).get("request", rec) or {}
            if req.get("idempotency_key") == key:
                status, record = job_status(req["id"])
                if status in ("queued", "completed"):
                    return req, status, record
    return None

def create(kind, body, key):
    prompt = body.get("prompt")
    if not isinstance(prompt, str) or not prompt.strip():
        raise BadRequest("prompt is required")
    params = {k: body[k] for k in ("model", "size", "aspect_ratio", "resolution", "seed", "n", "quality", "generate_audio", "seconds", "negative_prompt", "style") if k in body and body[k] is not None}
    if "aspect_ratio" not in params and body.get("ratio"):
        params["aspect_ratio"] = body["ratio"]
    if kind == "video":
        seconds = body.get("seconds", body.get("duration", 6))
        try:
            seconds = float(seconds)
        except (TypeError, ValueError):
            raise BadRequest("seconds must be a number")
        if not 1 <= seconds <= MAX_SECONDS:
            raise BadRequest(f"seconds must be 1-{MAX_SECONDS} (Grok Imagine video limit), got {seconds:g}")
        params["seconds"] = int(seconds) if seconds == int(seconds) else seconds
    with submit_lock:
        if key:
            hit = find_by_key(key)
            if hit:
                return hit[0], hit[1], hit[2], False
        job_id = f"{'img' if kind == 'image' else 'vid'}_{time.strftime('%Y%m%d_%H%M%S')}_{secrets.token_hex(3)}"
        refs = {}
        try:
            if kind == "video":
                for role in ("first_frame", "last_frame"):
                    if body.get(role):
                        refs[role] = save_ref(job_id, role, body[role])
                for item in body.get("image_reference") or []:  # aiand/OpenAI-style [{data|path, role}]
                    role = item.get("role", "first_frame") if isinstance(item, dict) else "first_frame"
                    refs[role] = save_ref(job_id, role, item)
            images = [save_ref(job_id, f"ref{i + 1}", v) for i, v in enumerate(ref_list(body))]
        except BadRequest:
            shutil.rmtree(os.path.join(INPUTS, job_id), ignore_errors=True)
            raise
        if images:
            refs["images"] = images
        job = {"id": job_id, "type": kind, "status": "queued", "created_at": now_iso(), "created_ts": time.time(),
               "prompt": prompt.strip(), "params": params, "references": refs, "idempotency_key": key or None}
        write_json(os.path.join(QUEUE, f"{job_id}.json"), job)
        return job, "queued", job, True

PORT = int(os.environ.get("RELAY_PORT", "8787"))

class Handler(BaseHTTPRequestHandler):
    server_version = "grok-relay/1.0"

    def log_message(self, fmt, *args):
        sys.stderr.write(f"[{now_iso()}] {self.command} {self.path.split('?')[0]} {args[1] if len(args) > 1 else ''}\n")

    def send(self, code, payload):
        data = json.dumps(payload, ensure_ascii=False).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def error(self, code, message, kind="invalid_request_error"):
        self.send(code, {"error": {"code": kind, "message": message}})

    def do_POST(self):
        path = urlparse(self.path).path.rstrip("/")
        kind = {"/v1/images/generations": "image", "/v1/videos": "video"}.get(path)
        if not kind:
            return self.error(404, f"unknown endpoint {path}", "not_found")
        length = int(self.headers.get("Content-Length") or 0)
        if length <= 0 or length > MAX_BODY:
            return self.error(413 if length else 400, "JSON body required (max 300 MB)")
        try:
            body = json.loads(self.rfile.read(length))
            if not isinstance(body, dict):
                raise BadRequest("JSON object expected")
            key = self.headers.get("Idempotency-Key") or body.get("idempotency_key")
            job, status, record, created = create(kind, body, str(key)[:200] if key else None)
        except (BadRequest, json.JSONDecodeError) as e:
            return self.error(400, str(e))
        out = public(job, status, record)
        out["deduplicated"] = not created
        self.send(200, out)

    def do_GET(self):
        url = urlparse(self.path)
        path = url.path.rstrip("/")
        if path in ("/health", "/v1/health"):
            q = len([n for n in os.listdir(QUEUE) if n.endswith(".json")])
            return self.send(200, {"ok": True, "queued": q, "root": ROOT})
        if path == "/v1/jobs":
            want = parse_qs(url.query).get("status", [None])[0]
            jobs = []
            for folder in (QUEUE, DONE):
                for name in sorted(os.listdir(folder)):
                    if name.endswith(".json") and name.count(".") == 1:
                        status, record = job_status(name[:-5])
                        if record and (not want or status == want):
                            jobs.append(public(record.get("request", record), status, record))
            return self.send(200, {"object": "list", "data": jobs})
        m = re.match(r"^/v1/(images|videos)/([A-Za-z0-9_]+)(/content)?$", path)
        if not m:
            return self.error(404, f"unknown endpoint {path}", "not_found")
        job_id = m.group(2)
        if not ID_RE.match(job_id) or job_id[:3] != ("img" if m.group(1) == "images" else "vid"):
            return self.error(404, "job not found", "not_found")
        status, record = job_status(job_id)
        if status == "missing":
            return self.error(404, "job not found", "not_found")
        job = record.get("request", record)
        if not m.group(3):
            return self.send(200, public(job, status, record))
        if status != "completed":
            return self.error(409, f"job is {status}", "not_ready")
        file = record.get("file")
        if not file or not os.path.isfile(file):
            return self.error(410, "result file missing", "gone")
        size = os.path.getsize(file)
        self.send_response(200)
        self.send_header("Content-Type", record.get("mime_type") or "application/octet-stream")
        self.send_header("Content-Length", str(size))
        self.end_headers()
        with open(file, "rb") as f:
            shutil.copyfileobj(f, self.wfile)

class Server(ThreadingHTTPServer):
    daemon_threads = True
    allow_reuse_address = True

if __name__ == "__main__":
    for d in (QUEUE, DONE, INPUTS, OUTPUTS):
        os.makedirs(d, exist_ok=True)
    httpd = Server(("127.0.0.1", PORT), Handler)
    sys.stderr.write(f"[{now_iso()}] grok-relay listening on http://127.0.0.1:{PORT}/v1 (root {ROOT})\n")
    httpd.serve_forever()
