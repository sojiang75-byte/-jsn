"""Shared helpers for the Grok Imagine file-queue relay (/workspace/relay)."""
import json, os, re, time, datetime

ROOT = os.path.abspath(os.environ.get("RELAY_ROOT") or os.path.dirname(os.path.abspath(__file__)))
QUEUE, DONE, INPUTS, OUTPUTS = (os.path.join(ROOT, d) for d in ("queue", "done", "inputs", "outputs"))
ID_RE = re.compile(r"^(img|vid)_[0-9a-z_]{6,64}$")
# Jobs still queued after this many hours report status "failed" (code relay_timeout).
TIMEOUT_HOURS = float(os.environ.get("RELAY_JOB_TIMEOUT_HOURS", "24"))
IMAGE_EXT = {".png": "image/png", ".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".webp": "image/webp"}
VIDEO_EXT = {".mp4": "video/mp4", ".mov": "video/quicktime", ".webm": "video/webm"}

def now_iso():
    return datetime.datetime.now(datetime.timezone.utc).astimezone().isoformat(timespec="seconds")

def write_json(path, data):
    tmp = f"{path}.tmp{os.getpid()}"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    os.replace(tmp, path)

def read_json(path):
    try:
        with open(path, encoding="utf-8") as f:
            return json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        return None

def check_id(job_id):
    if not ID_RE.match(job_id or ""):
        raise SystemExit(f"invalid job id: {job_id!r}")
    return job_id

def job_paths(job_id):
    return os.path.join(QUEUE, f"{job_id}.json"), os.path.join(DONE, f"{job_id}.json")

def job_status(job_id):
    """(status, record) where status is queued|completed|failed|missing."""
    qpath, dpath = job_paths(job_id)
    done = read_json(dpath)
    if done:
        return done.get("status", "completed"), done
    job = read_json(qpath)
    if not job:
        return "missing", None
    if time.time() - job.get("created_ts", time.time()) > TIMEOUT_HOURS * 3600:
        return "failed", {**job, "status": "failed", "error": {"code": "relay_timeout", "message": f"no result within {TIMEOUT_HOURS:g} h"}}
    return "queued", job
