# Toonflow 改进版 v4（自动分镜 + 视频一致性质检）
目录：toonflow-app（服务端和自动流程源码）、worker（质检和自动 worker）、relay（xAI 中转）、pipeline_flow_v4.md（流程图和耗时）。
未包含：API 密钥（Nebius、xAI 要自己配）、node_modules、模型文件、生成的视频。
状态：质检的手部规则正在校准中，所以这是修复前的快照；校准完成后会再发更新版。
