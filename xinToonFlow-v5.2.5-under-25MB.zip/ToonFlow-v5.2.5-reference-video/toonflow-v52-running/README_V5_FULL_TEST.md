# ToonFlow v5 完整测试版

本包是在 v4 独立副本上升级，原始 v4 文件未修改。v4 项目/角色卡/分镜可继续读取；v5 新字段均为可选或带默认值，旧项目可渐进迁移。

## 本次包含的 v5 功能

1. **Project Bible**：项目级 canon、画风、角色/场景/资产设定结构；流水线落盘 `project_bible.json`。
2. **角色资产分层**：角色身份不变量、服装、临时状态、声音 ID/音色/语言/语速，与旧版 `invariant/outfits` 兼容。
3. **场景连续性**：固定布局、灯光基线、可用机位视图，自动注入首帧/视频/尾帧提示词。
4. **镜头导演合同**：视角（第三人称/第一人称/过肩/插入/主观/顶视）、主体视点、轴线与 A/B 侧、额外人物策略。
5. **空间合同**：角色画面位置、朝向、视线目标、镜头起止状态、叙事节拍（建立/动作/反应/揭示等）。
6. **对白合同**：对白语言锁、逐字台词提示、角色声音设定注入；不允许把对白语言错误当成画面问题。
7. **车辆/道具状态机**：定义合法状态与触发动作，质量门阻止无依据的车型/损坏状态跳变。
8. **跨集记忆**：分集规划时把前集已知角色状态、服装、伤情、地点、道具状态、canon 和未解决剧情线注入下一集；落盘 `cross_episode_memory.json`。
9. **参考图清单与文件指纹**：记录参考图序号、路径、类型、用途、文件大小与 SHA256；记录项目 Bible、分镜合同、角色卡、场景、道具、提示词、生成配置和 QA 策略指纹。
10. **最终装配防过期**：成片导出前重新核对指纹；输入变化或缺少 v5 指纹时阻止混入旧素材。
11. **统一 QA 裁决**：`pass / fail / abstain`，输出硬失败、软问题、弃权原因、检查项和证据。QA 不可用或证据不足不再静默放行。
12. **定向修复路由**：按身份、人物、车辆、画风、视角、语言、手部、连续性等 failure code 路由；弃权转复检/人工，不盲目重生。
13. **旧版兼容**：旧 v4 分镜没有 cameraContract / Bible / 状态机时仍可读取；但导出严格要求本次生成的完整 v5 指纹。

## 目录内关键文件

- `toonflow-app/apps/server/src/autoflow/v5Continuity.ts`：Bible、跨集记忆、状态机、SHA256 指纹。
- `toonflow-app/apps/server/src/autoflow/storyboard/schema.ts`：v5 镜头、空间、对白、场景、道具结构。
- `toonflow-app/apps/server/src/autoflow/storyboard/gates.ts`：导演合同、跨集连续性、道具状态机质量门。
- `toonflow-app/apps/server/src/autoflow/pipeline.ts`：指纹采集、记忆落盘、导出前过期检查。
- `worker/qa_contract.py`：统一 QA 状态。
- `worker/repair_router.py`：按 failure code 定向修复路由。

## 测试方式

### Python

在项目根目录运行：

```bash
python -m py_compile worker/*.py worker/voice/*.py
pytest -q worker/test_qa_contract.py worker/test_repair_router.py
```

### ToonFlow TypeScript/Bun

项目使用 Bun workspace（packageManager: bun@1.4.3）。安装 Bun 与依赖后，在 `toonflow-app` 目录运行：

```bash
bun install
bun test apps/server/test/autoflow
bun run typecheck
```

### 端到端测试建议

- 至少 3 集，包含主角换装、受伤、死亡/尸体、车辆损坏、道具转移、POV/过肩/顶视、双人对白、空镜。
- 第一轮生成后修改一个角色卡、一个场景灯光基线或模型配置，再尝试导出；预期过期指纹会阻止旧 clip 混入。
- 检查输出目录中的 `project_bible.json`、`cross_episode_memory.json`、`run.json`、`镜头/*/版本/*/clip.json`。
- QA `abstain` 应停在待人工审核，不得标记通过；语言错误优先走音轨修复路由，不应默认重绘画面。

## 已知边界（请在测试中重点反馈）

- 角色声音字段与跨镜 CAM++ 声纹评估/音轨统一脚本已具备接入基础，但不同项目的 speaker mapping 仍需配置；当前不能保证所有 TTS/视频供应商都支持独立音轨重做。
- QA 视觉模型仍可能误判；本包保留证据和 abstain，不会未经标注集校准就降低手部硬门槛。标注集校准工具为 `worker/evaluate_qa_calibration.py`。
- 声纹连续性使用现有 CAM++ 检测/音轨统一脚本，已改为读取项目角色 ID/名称，不再只适配固定三个人物；需要本地安装 `campplus_zh.onnx`、sherpa-onnx、faster-whisper、Demucs/Seed-VC 依赖后单独运行：`python worker/voice/voice_sim.py <RUN_DIR> <VOICE_JSON>`，如需统一异常音色再运行 `python worker/voice/unify.py <RUN_DIR> <VOICE_JSON> <OUT_DIR>`。此环节目前是独立后处理，不会在默认流水线中自动调用。
- 状态机的动作触发依据采用可解释的关键词匹配，复杂语义仍可能需要人工确认。
- 完整 Bun/TypeScript 测试需要在有 Bun 和依赖的环境执行；本交付不会把未运行的 TS 测试宣称为通过。

## 版本原则

- 原始 v4 不改动。
- 本目录为独立 v5 测试副本。
- 不建议把测试版直接覆盖生产项目；请先复制工作区并保留本包作为回归基线。


---

## v5.1 更新

本包已针对真实运行失败报告加入原文只读、Source Ledger、对白/音效程序回填、严格原文覆盖、枚举规范化、死亡状态继承、模型配置快照和 planner 原始输出归档。详细说明见 `README_V5_1_FIXES.md`。
