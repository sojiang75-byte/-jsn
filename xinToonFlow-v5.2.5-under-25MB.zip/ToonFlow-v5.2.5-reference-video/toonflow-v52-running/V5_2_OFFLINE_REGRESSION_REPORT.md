# ToonFlow v5.2 离线回归报告

- 基线：用户上传的 `toonflow-v51-running-src.tar.gz`
- 失败现场：`work/run/一键成片/v51-ch1/planner_attempts/storyboard_E00_attempt_04.json`
- 原文：`work/run/一键成片/v51-ch1/原文.md`
- 账本：`work/run/一键成片/v51-ch1/source_ledger.json`
- 测试日期：2026-11-04

## 原文基线核验

- `原文.md` 与 `剧本.md` 字节完全一致。
- 原文 SHA-256：`4ca6e1e05e2728b7955e49bf2a340c4e838249bfc2db04e7da0483000430ff7b`
- 与 `source_ledger.json` 中 `sourceHash` 一致。

## 失败现场复现

- 失败镜头：`E01-04-09`
- 原始时长字段：19 秒
- 原始 SRC 分配：`SRC0111`、`SRC0112`
- 原始对白分配：`Q0022`、`Q0023`
- 账本修复后、拆镜前 SRC/Q 校验：通过。

## v5.2 自动拆镜结果

| 新镜头 | 时长 | SRC | Q | 结果 |
|---|---:|---|---|---|
| E01-04-09 | 10 秒 | SRC0111 | Q0022 | 通过 |
| E01-04-10 | 15 秒 | SRC0112 | Q0023 | 通过 |

- 自动拆分镜头数：1
- 新增镜头数：1
- 拆镜警告：0
- 拆镜后 SRC/Q 账本校验：通过，0 个错误。
- 程序回填后 Q0022、Q0023 分别只出现在对应相邻镜头，文本与账本原文逐字一致。
- 拆分没有改写、删减或调换原文。

## beat 别名核验

输入 `dialogue`、`tension`、`establish`、`explosion`，输出分别为 `action`、`reaction`、`establishing`、`action`；均为 schema 合法值。

## 验证边界

已完成实际失败样本的离线程序回归和修改文件语法转译。当前容器没有 Bun，不能运行 Bun 单元测试或完整工作区类型检查；也没有调用真实 DeepSeek API。没有启动图片/视频模型，没有生成媒体资产。

**结论：** v5.2 的确定性拆镜和 beat 规范化在本次真实失败样本上离线通过；尚待部署环境运行 `stopAfter: "storyboard"` 做真实模型回归。此报告不代表整章生产已通过。
