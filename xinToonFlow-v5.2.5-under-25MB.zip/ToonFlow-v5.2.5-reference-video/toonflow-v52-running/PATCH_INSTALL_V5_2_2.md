# ToonFlow v5.2.2 补丁安装说明

1. 先备份当前 v5.2.1 项目目录。不要覆盖 v5.1 原始源码和历史运行记录。
2. 解压 `ToonFlow-v5.2.2-Patch-Only.zip` 到 v5.2.1 项目根目录，保持压缩包内相对路径。
3. 确认以下三个文件已更新：
   - `toonflow-app/apps/server/src/autoflow/storyboard/continuity.ts`
   - `toonflow-app/apps/server/src/autoflow/planner.ts`
   - `toonflow-app/apps/server/test/autoflow/storyboard.test.ts`
4. 在项目服务器安装依赖后，先运行对应 storyboard 测试，再执行 `launch_v52_storyboard.sh.txt`。
5. 只允许运行到 storyboard。不得启动图片 worker、视频 worker 或自动重做。

本补丁不包含真实模型回归结果。只有实际分镜所有质量门通过，才可进入整章生产。
