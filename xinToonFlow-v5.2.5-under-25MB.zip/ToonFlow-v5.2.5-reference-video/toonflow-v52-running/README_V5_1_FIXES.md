# ToonFlow v5.1 — 原文保护与分镜失败修复

本包基于用户上传的实际运行源码 `toonflow-v5-running-src(1).zip` 修改，原始上传包未覆盖；修复副本独立保存。

## 本次修复

1. **原文只读模式（默认开启）**：`writeScript()` 不再调用编剧模型改写章节，`剧本.md` 原样复制输入文本。可显式设置 `preserveSourceText: false` 回到创意扩写模式。
2. **Source Ledger 原文账本**：新增 `sourceLedger.ts`，以 SHA-256 标识原文，将章节切成连续原文片段 `SRCxxxx`，将引号内容拆为 `Qxxxx`；对白、拟声词、短人名/术语分别分类。多集时按连续原文范围分配给每集，避免每集重复认领整章。
3. **台词程序回填**：分镜模型只提交 `quoteAssignments` 和 `sourceRefs` ID；程序从原文账本恢复 `dialogue`、`sfx` 和 `source`，不会使用模型复制的台词文本。除引号对白外，也识别“角色名：台词”格式，并自动绑定角色 ID。
4. **漏项局部补齐**：模型漏分配的引号 ID，可根据其所在原文片段回填；漏掉的原文片段在存在邻近映射时归属最近镜头。未知 ID、重复/缺失、顺序错误、跨段拼接仍会被硬性拦截。
5. **严格覆盖门**：对白逐字检查不再删除标点、不再允许 80% 子串通过；拟声词单独检查；短人名/术语不再误判为台词。长对白按 50 字符连续片段分配，原文片段边界与 Q ID 对齐。source 必须逐字、顺序一致并覆盖全文。
6. **镜头枚举修复**：JSON 示例只展示单个合法枚举；列出合法候选值；对常见中文别名和竖线候选串做确定性规范化；POV 从 camera 运镜字段迁移到 `cameraContract.viewpoint`。
7. **死亡状态继承**：新增 `propagateDeadStates()`，角色一旦进入死亡账本，后续镜头/集自动继承；尸体描述识别扩充为更多中文和英文表达。
8. **时长保护**：对白拆成短的连续原文片段；镜头时长根据回填后的真实对白重新估算；若实际镜头总时长超过目标，自动上调该集目标时长，不通过删台词满足 60 秒限制。
9. **模型输出诊断**：每次分镜尝试的原始输出和错误单独保存到 `planner_attempts/`，多集按集号区分。
10. **真实模型配置记录**：运行时写入 `effective_models.json`；`monitor.py` 从实际配置读取模型，不再硬编码 Kimi-K3，避免 DeepSeek/Kimi 报告不一致；`autoresume.sh.txt` 调用的旧 `kimi_probe.py` 现改为读取 `config.json` 中实际选择的文本模型再探测。
11. **长输出处理**：Nebius OpenAI 兼容客户端遇到 `finish_reason=length` 时按上限扩展 `max_tokens` 重试，不把思考内容或截断 JSON 当作有效结果。
12. **旧 run 缓存保护**：发现旧 run 的 `剧本.md` 与原始输入不同，会使下游 cast/storyboard/shot 缓存失效，并为角色卡使用该 run 独立目录，避免继续复用被改写剧本的旧规划。

## 新增运行产物

- `原文.md`：输入章节原样备份。
- `剧本.md`：原文保护模式下与输入完全一致。
- `source_ledger.json`：原文 SHA-256、SRC 原文片段和 Q 引号台账。
- `effective_models.json`：本次实际文本/图片/视频/评分模型。
- `planner_attempts/storyboard_E##_attempt_##.json`：每次分镜模型原始输出。
- `planner_attempts/storyboard_E##_attempt_##_errors.json`：对应校验错误。

## 验证结果

- 修改过的 10 个 TypeScript 文件通过 TypeScript `transpileModule` 语法转译检查。
- Source Ledger 运行时 smoke test：原文切片拼接完全一致；对白/音效/短人名分类符合测试样例；未加引号角色对白、长对白跨镜分段、多集连续分配、重复台词计数和回填均通过。
- `llm.ts` 的 `finish_reason=length` 扩容重试通过注入式 mock 测试。
- Python Worker 回归测试：`worker/test_repair_router.py` 与 `worker/test_qa_contract.py`，共 10 项通过。
- `monitor.py`、`kimi_probe.py` 通过 Python `py_compile`；4 个启动/恢复 shell 脚本通过 `bash -n`。
- **尚未执行 Bun 全量测试、完整 TypeScript 类型检查、Nebius/DeepSeek 真实 API 测试和端到端媒体生成**：当前环境没有 Bun；全量 `tsc` 因缺少 `bun` 类型定义而以 TS2688 退出。已执行的 TypeScript 转译检查不等于完整类型检查。因此本包是完成代码改造的 v5.1 修复测试版，不宣称已通过生产级端到端验证。

## 重要边界

- 模型仍负责把原文片段安排到具体镜头，并给对白分配说话人。程序负责原文内容的恢复和完整性，不会凭空推断缺失的剧情人物。
- 如果自动补齐台词时无法从上下文确定说话人，会使用 `narrator` 作为保底并保留原文；应在回归测试中检查这类镜头的说话人归属。
- `preserveSourceText` 默认开启。对于“一个创意点子而非完整章节”的输入，可显式关闭，但关闭后不享有原文只读保证。
- 本次没有调用任何图片或视频生成 API，不产生新的媒体生成费用。

## 建议回归测试

先用 `stopAfter: "storyboard"` 跑失败章节，确认 `剧本.md` 与 `原文.md` 完全一致，检查 `source_ledger.json` 与 `planner_attempts/`，再通过分镜门后继续角色/场景/关键帧/视频阶段。
