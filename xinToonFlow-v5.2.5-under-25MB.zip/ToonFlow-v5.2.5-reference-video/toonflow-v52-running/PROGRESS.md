# v5 full chapter run — progress
Updated: 2026-11-03 22:28:12 ET

Run status: **failed**, stage: **storyboard**
Toonflow-logged spend (aiand H3 + text): $0.000  |  xAI image outputs in relay so far (not $-logged by Toonflow): 0 (incl. 1 connectivity test image)
PIDs: {'autoflow': 1657497, 'worker': 1657472, 'relay': 1657399}
**STOPPED (fail-fast) at 2026-11-03 22:28:07 ET: run failed — [2026-11-04 03:27:59] 失败：模型输出多次校验失败：【台词装得进镜头时长】E01-04-09 台词约需 17.2 秒，镜头只有 15 秒 | error=模型输出多次校验失败：【台词装得进镜头时长】E01-04-09 台词约需 17.2 秒，镜头只有 15 秒** — see FAILURE_REPORT.md

| shot | status | qa | video |
|---|---|---|---|

## Notes
### Storyboard-stage 'timed out' / 'socket connection closed' — diagnosis (07:45–08:05 AM ET)
- These are **Nebius-side failures of moonshotai/Kimi-K3 only**, not a pipeline/self-check failure and no media was generated yet (no shots, no H3 spend).
- Direct probes from the box: Kimi-K3 (even a 3-item tiny JSON request, streaming) got **0 bytes for 270 s, then "Remote end closed connection without response"**; a second probe timed out at 120 s with 0 bytes. Same moment, **Nemotron-3.5-Super-VL on the same Nebius endpoint answered in 1.3 s** → Kimi-K3 endpoint is hanging/overloaded, the network is fine.
- 12:06 UTC (07:06 ET) cast stage hit the 300 s request timeout; 12:17 UTC storyboard socket closed. v5 llm.ts had **no retry** for these → I added (copy only): retry ×4 with backoff on network errors/429/5xx, SSE streaming (TOONFLOW_LLM_STREAM=1), timeout 30 min (TOONFLOW_LLM_TIMEOUT_MS). Retries are happening (see run.log `[llm] transient error`), but every attempt dies the same way while Kimi-K3 is down.
- Handling: if the 4 retries are exhausted the run fails at storyboard → monitor classifies it as **INFRA stop** (not fail-fast), kills only v5 processes, and `autoresume.sh` probes Kimi-K3 every ~5 min and resumes the **same run dir** (script + cast cached) once it answers. Self-check failures still stop for good and write FAILURE_REPORT.md.

### Language model switched Kimi-K3 → DeepSeek (user decision, ~08:10 AM ET)
- Kimi-K3 still not answering at 08:12 ET (probe: read timeout). Nebius lists DeepSeek-V4-Flash-0731, V4-Pro, **V4-Pro-0813**, V4.1-Flash, V4.1-Flash-1017.
- Chosen: **deepseek-ai/DeepSeek-V4-Pro-0813** (newest Pro; quality over speed). Probes: tiny request 1.3 s; 40-item JSON streamed in 93 s with no stalls (max gap 0.7 s).
- config.json textModel = nebius deepseek-ai/DeepSeek-V4-Pro-0813, reasoningEffort low (old config kept as config.kimi.json.bak). Images (xAI), video (aiand H3), scorer (Nemotron) unchanged. autoresume.sh Kimi probing stopped.
- qa2 trait judge used Kimi-K3 (QA_TRAIT_MODELS=grok-4.7,Kimi-K3) → would abstain every shot. Substituted **nvidia/Nemotron-3.5-Super-VL** (vision; probed OK 1.5–2 s) via QA_TRAIT_MODELS in launch.sh + launch_worker.sh. Hand checks unchanged (grok-4.7 OK 8 s, gemma-3-27b OK but slow ~70 s).
- Resumed the SAME run dir (剧本.md + cast.json cached).
- 08:17 ET: first DeepSeek storyboard attempt ended "文本模型返回为空（finish_reason=length，只有思考内容）": DeepSeek-V4-Pro spent the whole default 8000-token budget thinking. Not a self-check failure. Fix (copy only): text max_tokens from env TOONFLOW_LLM_MAX_TOKENS=32000 (scorer keeps its own 2000). Resumed same run dir ~08:20 ET.


## Last log lines
```
[2026-11-04 03:16:28] 原文保护模式：章节原文逐字保留，跳过编剧改写阶段
[2026-11-04 03:17:15] 角色 6 个，场景 4 个
[2026-11-04 03:21:00] 校验未通过，第 1 次：episodes.0.segments.0.shots.0.spatialContract.beat：Invalid option: expected one of "establishing"|"action"|"reaction"|"reveal"|"insert"|"transition"；episodes.0.segments.0.shots.2.spatialContract.beat：Invalid option: expected one of "establishing"|"action"|"reaction"|"reveal"|"insert"|"transition"；episodes.0.segments.0.shots.3.spatialContract.beat：Invalid option: expected one of "establishing"|"action"|"reaction"|"reveal"|"insert"|"transition"
[2026-11-04 03:23:28] 原文账本自动补齐 0 个原文片段、2 条引号（原文由程序恢复）
[2026-11-04 03:23:28] 有 1 条对白的说话人无法从上下文确定，暂标为旁白，请在分镜确认时核对
[2026-11-04 03:23:28] 校验未通过，第 2 次：【每镜出场角色均有定义、角色卡与造型】E01-02-02 的角色 unused-primary 未在 characters 中定义
【台词装得进镜头时长】E01-04-09 台词约需 17.2 秒，镜头只有 15 秒
【单集剧情连续性：死者不复活、持物不无故换手】E01-04-05 中已死亡的 laoda 出场但未写明是尸体；E01-04-07 中已死亡的 laoer 出场但未写明是尸体；E01-04-10 中已死亡的 laowu 出场但未写明是尸体
【镜头视角、主体视点与轴线合同有效】E01-02-02 空间合同角色 xiaofeng 不在本镜角色清单中
[2026-11-04 03:25:47] 原文账本自动补齐 0 个原文片段、2 条引号（原文由程序恢复）
[2026-11-04 03:25:47] 有 1 条对白的说话人无法从上下文确定，暂标为旁白，请在分镜确认时核对
[2026-11-04 03:25:47] 校验未通过，第 3 次：【台词装得进镜头时长】E01-04-09 台词约需 17.2 秒，镜头只有 15 秒
[2026-11-04 03:27:59] 原文账本自动补齐 0 个原文片段、2 条引号（原文由程序恢复）
[2026-11-04 03:27:59] 有 1 条对白的说话人无法从上下文确定，暂标为旁白，请在分镜确认时核对
[2026-11-04 03:27:59] 校验未通过，第 4 次：【台词装得进镜头时长】E01-04-09 台词约需 17.2 秒，镜头只有 15 秒
[2026-11-04 03:27:59] 失败：模型输出多次校验失败：【台词装得进镜头时长】E01-04-09 台词约需 17.2 秒，镜头只有 15 秒
```