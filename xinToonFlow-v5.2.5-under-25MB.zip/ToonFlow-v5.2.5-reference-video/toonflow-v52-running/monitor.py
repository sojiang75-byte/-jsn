#!/usr/bin/env python3
"""v5 fail-fast monitor: stops the whole v5 production on the first shot self-check failure; writes PROGRESS.md."""
import json, os, re, signal, subprocess, sys, time, datetime, glob
V = '/workspace/v51run'; RUN = f'{V}/work/run/一键成片/v51-ch1/run.json'; RUNLOG = f'{V}/work/run/run.log'
WLOG = f'{V}/work/auto_worker.log'; PROG = f'{V}/PROGRESS.md'; TRIG = f'{V}/work/STOP_TRIGGER.json'
PIDS = json.load(open(f'{V}/work/pids.json'))  # {"autoflow":..,"worker":..,"relay":..}
NEVER = {603079}
from zoneinfo import ZoneInfo
def now(): return datetime.datetime.now(ZoneInfo('America/New_York')).strftime('%Y-%m-%d %H:%M:%S ET')
def alive(p):
    try: os.kill(p, 0); return True
    except Exception: return False
def kill_all(reason):
    killed = []
    for name in ('autoflow', 'worker', 'relay'):
        p = PIDS.get(name)
        if p and p not in NEVER and alive(p):
            subprocess.run(['pkill', '-TERM', '-P', str(p)]); os.kill(p, signal.SIGTERM); killed.append(f'{name}:{p}')
    # stray v5 children (qa2 run by the pipeline / worker, ffmpeg under v5run)
    out = subprocess.run(['pgrep', '-f', '/workspace/v51run/'], capture_output=True, text=True).stdout.split()
    for s in out:
        p = int(s)
        if p in NEVER or p == os.getpid(): continue
        try: os.kill(p, signal.SIGTERM); killed.append(str(p))
        except Exception: pass
    time.sleep(5)
    for name in ('autoflow', 'worker', 'relay'):
        p = PIDS.get(name)
        if p and p not in NEVER and alive(p): os.kill(p, signal.SIGKILL)
    return killed
def load_run():
    try: return json.load(open(RUN))
    except Exception: return None
def effective_models(run):
    try:
        out = (run or {}).get('outputDirectory') or '一键成片/v51-ch1'
        path = os.path.join(V, 'work', 'run', out, 'effective_models.json')
        return json.load(open(path, encoding='utf-8'))
    except Exception:
        return {}
def model_label(models):
    def item(key):
        value = models.get(key) or {}
        return f"{value.get('providerId','unknown')}/{value.get('modelId','unknown')}"
    return f"text={item('text')}; image={item('image')}; video={item('video')}; scorer={item('scorer')}"
def runlog_lines():
    try: return open(RUNLOG, encoding='utf-8', errors='replace').read().splitlines()
    except Exception: return []
def wlog_lines():
    try: return open(WLOG, encoding='utf-8', errors='replace').read().splitlines()
    except Exception: return []
START_W = len(wlog_lines())
PATS = [(r'标记需重做', 'Toonflow keyframe score (Nemotron) below threshold after all keyframe retries'),
        (r'视频未通过（第 (\d+)/(\d+) 次）', 'Toonflow video signal/consistency review'),
        (r'逐帧质检(fail|abstain)', 'pipeline qa2 per-shot QA'),
        (r'逐帧质检出错', 'pipeline qa2 error (abstain)'),
        (r'QA (fail|abstain)', 'pipeline QA status'),
        (r'分镜未通过质量门', 'storyboard gate'),
        (r'video 生成失败（第 (\d+)/(\d+) 次）', 'video generation failed (all attempts)'),
        (r'关键帧多次未达阈值', 'keyframe needsRedo')]
def check(run, rl, wl):
    logs = (run or {}).get('log', []) + rl
    for line in logs:
        for pat, check_name in PATS:
            m = re.search(pat, line)
            if not m: continue
            if 'video' in check_name and m.lastindex == 2 and m.group(1) != m.group(2): continue
            return {'check': check_name, 'line': line}
    for line in wl[START_W:]:
        if 'IMAGE_QA_FINAL' in line and 'shot=None' not in line and ('pass=False' in line or 'status=pass' not in line):
            return {'check': 'worker keyframe qa2 (--image) after worker retries', 'line': line}
    if run and run.get('status') == 'failed':
        return {'check': 'run failed', 'line': ((run.get('log') or ['?'])[-1]) + ' | error=' + str(run.get('error', ''))}
    if not alive(PIDS['autoflow']) and not (run and run.get('status') == 'done'):
        return {'check': 'autoflow process exited without done', 'line': '\n'.join(rl[-5:])}
    return None
def progress(run, rl, note=''):
    shots = (run or {}).get('shots', {}) or {}
    rows = [f"| {k} | {v.get('status')} | {(v.get('qaResult') or {}).get('status','')} | {'Y' if v.get('video') else ''} |" for k, v in sorted(shots.items())]
    spend = ((run or {}).get('spend') or {}).get('usd', 0)
    imgs = len(glob.glob(f'{V}/relay/outputs/img_*'))
    txt = [f'# v5 full chapter run — progress', f'Updated: {now()}', '', f"Run status: **{(run or {}).get('status','starting')}**, stage: **{(run or {}).get('stage','?')}**",
           f'Toonflow-logged spend (aiand H3 + text): ${spend:.3f}  |  xAI image outputs in relay so far (not $-logged by Toonflow): {imgs} (incl. 1 connectivity test image)',
           f"PIDs: {PIDS}", note, '', '| shot | status | qa | video |', '|---|---|---|---|', *rows, '', '## Notes', (open(f'{V}/work/NOTES.md').read() if os.path.exists(f'{V}/work/NOTES.md') else ''), '', '## Last log lines', '```', *((run or {}).get('log', [])[-25:] or rl[-25:]), '```']
    open(PROG + '.tmp', 'w').write('\n'.join(txt)); os.replace(PROG + '.tmp', PROG)

INFRA_RE = re.compile(r'timed out|socket connection|ECONN|fetch\(\)|RemoteDisconnected|HTTP 5\d\d|HTTP 429|文本模型返回为空|network', re.I)
def j(x): return json.dumps(x, ensure_ascii=False, indent=1)[:6000]
def failure_report(trig):
    run = load_run() or {}; line = trig['line']
    m = re.search(r'(E\d\d-\d\d-\d\d)', line) or re.search(r'shot=(E\d\d-\d\d-\d\d)', line)
    sid = m.group(1) if m else None; st = (run.get('shots') or {}).get(sid, {}) if sid else {}
    out = [f"# v5 FAILURE REPORT (fail-fast stop)", f"Generated automatically by monitor.py at {trig['at']} (America/New_York). Production cancelled; no auto-redo.", '',
           f"- **Shot:** {sid or 'n/a (run-level)'}", f"- **Check:** {trig['check']}", f"- **Trigger line:** `{line[:1500]}`",
           f"- **Run stage/status at stop:** {run.get('stage')} / {run.get('status')}", f"- **Killed:** {trig['killed']}",
           f"- **Toonflow-logged spend so far:** ${((run.get('spend') or {}).get('usd') or 0):.3f} (aiand H3 video + text; xAI images not $-logged; xAI image outputs in v5 relay: {len(glob.glob(f'{V}/relay/outputs/img_*'))} incl. 1 earlier connectivity image)",
           f"- **Models:** {model_label(effective_models(run))}; worker/relay submodels should be read from worker config and are not inferred here.", '']
    if st:
        out += ['## Shot state (run.json)', '```json', j({k: st.get(k) for k in ('status','keyframe','rejectedKeyframe','video','score','seed','warnings','qaResult','repairPlan','attempts')}), '```',
                '## Prompts used', '```', j(st.get('prompts')), '```', '## Reference images used', '```json', j(st.get('referenceManifests')), '```']
        d = None
        for f in (st.get('video'), st.get('keyframe'), st.get('rejectedKeyframe')):
            if f: d = os.path.dirname(os.path.join(V, 'work/run', f)); break
        if d and os.path.isdir(d): out += ['## Shot directory', f'`{d}`', '```', *sorted(os.listdir(d)), '```']
    if sid:
        ws = (json.load(open(f'{V}/work/worker_state.json')).get('jobs') or {})
        for jid, js in ws.items():
            if 'img_tries' in js:
                hit = [l for l in wlog_lines() if jid in l and f'shot={sid}' in l]
                if hit:
                    out += [f'## Worker keyframe job {jid}', '```', *[l[:600] for l in wlog_lines() if jid in l][-12:], '```']
                    for k in range(1, len(js['img_tries']) + 1):
                        qd = f'{V}/work/qa/{jid}_i{k}'
                        if os.path.isdir(qd): out += [f'- try {k}: image `{js["img_tries"][k-1]["file"]}`, qa dir `{qd}` (crops/strips + qa2.json)']
        qa_dirs = sorted(glob.glob(f'{V}/work/run/一键成片/v51-ch1/**/{sid}*/**/qa2*.json', recursive=True))
        if qa_dirs: out += ['## qa2 reports', *[f'- `{q}`' for q in qa_dirs]]
    out += ['', '## Recent run log', '```', *(run.get('log') or [])[-30:], '```', '', '## Cause guess / what to change', '_(to be filled in by the agent after inspecting the evidence)_']
    open(f'{V}/FAILURE_REPORT.md', 'w').write('\n'.join(out))
last_p = 0
while True:
    run = load_run(); rl = runlog_lines(); wl = wlog_lines()
    trig = check(run, rl, wl)
    if run and run.get('status') == 'done' and not trig:
        progress(run, rl, '**RUN FINISHED with no self-check failures.**'); open(f'{V}/work/DONE', 'w').write(now()); break
    if trig:
        trig['at'] = now(); trig['killed'] = kill_all(trig['check']); json.dump(trig, open(TRIG, 'w'), ensure_ascii=False, indent=1)
        trig['infra'] = trig['check'] in ('run failed', 'autoflow process exited without done') and bool(INFRA_RE.search(trig['line'])); json.dump(trig, open(TRIG, 'w'), ensure_ascii=False, indent=1)
        failure_report(trig)  # v5.1 deploy: user rule = any stop is final, always report, no autoresume
        progress(load_run(), runlog_lines(), (f"**INFRA STOP at {trig['at']} (not a self-check failure; autoresume.sh resumes the same run when the selected text model is reachable again): {trig['line'][:300]}**" if trig['infra'] else f"**STOPPED (fail-fast) at {trig['at']}: {trig['check']} — {trig['line'][:300]}** — see FAILURE_REPORT.md")); break
    if time.time() - last_p > 120: progress(run, rl); last_p = time.time()
    time.sleep(10)
