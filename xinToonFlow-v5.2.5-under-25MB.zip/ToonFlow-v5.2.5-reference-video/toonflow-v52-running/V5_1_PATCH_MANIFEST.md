# ToonFlow v5.1 修复包变更清单

基准：用户上传的 `toonflow-v5-running-src(1).zip`。原始压缩包与原始 v4 均未修改。本清单记录独立修复副本相对于上传包的文件差异。

## 修改文件

- `PROGRESS.md`
- `README_V5_FULL_TEST.md`
- `V5_CHANGELOG.md`
- `autoresume.sh.txt`
- `kimi_probe.py`
- `launch.sh.txt`
- `monitor.py`
- `toonflow-app/apps/server/src/autoflow/llm.ts`
- `toonflow-app/apps/server/src/autoflow/pipeline.ts`
- `toonflow-app/apps/server/src/autoflow/planner.ts`
- `toonflow-app/apps/server/src/autoflow/promptStyles/h3.ts`
- `toonflow-app/apps/server/src/autoflow/service.ts`
- `toonflow-app/apps/server/src/autoflow/storyboard/continuity.ts`
- `toonflow-app/apps/server/src/autoflow/storyboard/gates.ts`
- `toonflow-app/apps/server/src/autoflow/storyboard/schema.ts`
- `toonflow-app/apps/server/src/autoflow/storyboard/vocab.ts`
- `toonflow-app/apps/server/test/autoflow/storyboard.test.ts`

## 新增文件

- `README_V5_1_FIXES.md`
- `toonflow-app/apps/server/src/autoflow/sourceLedger.ts`
- `toonflow-app/apps/server/test/autoflow/sourceLedger.test.ts`

## 删除文件

- 无

## 验证

- 10 个修改/新增 TypeScript 文件通过语法解析与转译检查。
- Source Ledger 运行时测试：原文逐字重组、引号分类、重复台词计数、长对白分段、未加引号角色对白、多集连续分配均通过。
- 运镜/景别枚举规范化运行时测试通过。
- 死亡事件识别及后续镜头死亡状态继承运行时测试通过。
- LLM `finish_reason=length` token 扩容重试 mock 测试通过。
- Python Worker 测试 10/10 通过；监控/探测 Python 文件语法检查通过；启动/恢复 shell 脚本语法检查通过。
- 未运行 Bun 全量测试、完整 TypeScript 类型检查、真实模型 API 和真实视频生成；原因见 `README_V5_1_FIXES.md`。
