# ToonFlow v5.2.1 补丁安装说明

## 适用对象

基于用户上传的实际运行 v5.1 源码目录 `toonflow-v51-running/`。请先备份正在使用的目录；不要覆盖 v5.1 原始源码或既有回归记录。

## 安装

1. 解压 `ToonFlow-v5.2.1-Patch-Only.zip` 到 v5.1 项目根目录，保持 ZIP 内路径结构，允许覆盖同路径文件。
2. 确认 `config.v52-storyboard.example.json`、`launch_v52_storyboard.sh.txt`、`toonflow-app/apps/server/src/autoflow/planner.ts` 等文件已更新。
3. 将整个项目复制或解压到独立目录 `/workspace/v52run/toonflow-v52-running`；不要在 v5.1 原目录直接运行。
4. 确认原文文件 `/workspace/fengliu_ch1.md` 和 `/tmp/.tfkeys` 存在，且后者配置 Nebius 凭据。
5. 在新目录执行：

```bash
cd /workspace/v52run/toonflow-v52-running
bash launch_v52_storyboard.sh.txt
```

可用 `TOONFLOW_ROOT` 和 `TOONFLOW_STORY_FILE` 覆盖项目根目录和原文路径。

## 重要安全说明

- 配置保留原运行配置中的 `grokRelay/grok-imagine-image` 与 `aiand/minimaxai/minimax-h3`，因为真实模式依赖装配需要图片模型，且分镜时长门需要 H3 的 `[5..15]` 支持档位。
- 配置显式设置 `scorer: { "type": "none" }`，不调用图像评分模型。
- 这些媒体模型只用于参数校验/时长档位；`stopAfter=storyboard` 在所有媒体生成步骤之前返回，不会调用图片或视频生成接口。
- `stopAfter: "storyboard"` 在 `run.storyboard()` 完成后立即返回，位于角色卡图片、场景图、首帧和视频生成阶段之前。
- 启动脚本不启动 relay 或 worker；不自动重做；不应删除旧 v5.1 运行目录。

## 通过标准

检查日志与 `work/run/一键成片/v52-regression-01/`：
- 出现程序自动拆分超时对白的日志；
- Q0022、Q0023 分配到相邻镜头；
- 每镜不超过 15 秒；
- SRC/Q 原文账本校验通过；
- beat 字段全部符合 schema；
- storyboard 自检通过后停止，不生成任何媒体文件。
