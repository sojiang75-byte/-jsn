# V5.2 Patch Manifest

Base: user-uploaded `toonflow-v51-running-src.tar.gz` (actual running v5.1 source)

## Modified
- `toonflow-app/apps/server/src/autoflow/planner.ts`
  - normalize `spatialContract.beat` aliases.
  - add deterministic overlong dialogue splitting using Source Ledger Q/group boundaries.
  - revalidate SRC/Q ownership after splitting and before hydration.
  - renumber shots after insertion; maintain adjacent continuity.
  - add explicit prompt and repair feedback for multi-quote overlong shots.
- `toonflow-app/apps/server/test/autoflow/storyboard.test.ts`
  - add beat normalization regression test.
  - add deterministic Q-boundary split / ledger / exact-text regression test.
- `toonflow-app/apps/server/scripts/autoflow.ts`
  - treat an intentional `stopAfter` stop as a successful CLI exit.
- `launch.sh.txt`
- `config.v52-storyboard.example.json`（v5.2.1：补充服务层必填的图片模型选择，并关闭图像评分；不触发媒体生成）
  - route the default launcher to storyboard-only regression.
- `resume.sh.txt`
  - block the legacy v5.1 full-run resume path until the v5.2 storyboard regression passes.
- `work/STOP_TRIGGER.json`
  - archive the old v5.1 fail-fast sentinel as `work/STOP_TRIGGER.v51-failure.json` so it cannot stop the new run.
- `V5_CHANGELOG.md`
  - append v5.2 entry.

## Added
- `README_V5_2_FIXES.md`
- `V5_2_PATCH_MANIFEST.md`
- `V5_2_OFFLINE_REGRESSION_REPORT.md`
- `config.v52-storyboard.example.json`
- `launch_v52_storyboard.sh.txt`

## Unchanged
- Original v5.1 archive outside this working copy.
- User's existing v5.1 run artifacts and original chapter text inside the provided archive.
- Dual-model character-feature QA policy (Grok-4.7 + Nemotron).

## Validation
- Real attempt_04 + source_ledger offline regression: Q0022 and Q0023 moved to adjacent shots E01-04-09 and E01-04-10.
- Resulting durations at maxShotSeconds=15: 10s and 15s.
- Post-split Source Ledger validation: pass.
- Hydrated Q0022/Q0023 text exactly matches the ledger.
- TypeScript syntax transpilation: pass for changed TS files.
- Bun full tests / complete typecheck / live DeepSeek regression: not run in this environment.

## v5.2.1 启动配置复核
- `imageModel` 使用原运行配置中的 `grokRelay/grok-imagine-image`，满足 buildDeps 的真实模式参数校验。
- `videoModel` 使用原运行配置中的 `aiand/minimaxai/minimax-h3` 与 `[5..15]` 时长档位，保证分镜时长校验与后续生产模型一致。
- `scorer` 显式设为 `none`；媒体模型选择仅用于参数装配和时长档位，不触发生成。
- `stopAfter=storyboard` 的 pipeline 分支在 `run.storyboard()` 后立即返回，位于角色卡、场景图、首帧和视频生成调用之前。
- Q0022/Q0023 按真实 H3 档位预期分别对齐为 7 秒和 11 秒。


## v5.2.2 增量修改
- `toonflow-app/apps/server/src/autoflow/storyboard/continuity.ts`：尸体提及匹配限制在同一分句内，分号/句号等为硬边界，避免前一角色的尸体描述污染后一角色。
- `toonflow-app/apps/server/src/autoflow/planner.ts`：增加 `activity`、`活动` → `action` beat 别名。
- `toonflow-app/apps/server/test/autoflow/storyboard.test.ts`：增加“老二成为尸体；老五来不及呼叫”回归测试和 activity beat 测试。

## v5.2.2 验证
- TypeScript transpile syntax check：上述 3 个 TS 文件通过。
- 精确语义 smoke test：`老二` 的尸体匹配为 true，`老五` 为 false。
- beat alias smoke test：`activity` → `action`。
- Bun 全量测试、真实 DeepSeek 分镜回归未执行；不能据此宣称整章通过。
