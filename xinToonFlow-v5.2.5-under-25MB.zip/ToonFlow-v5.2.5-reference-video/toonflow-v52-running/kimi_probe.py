#!/usr/bin/env python3
"""Probe the text model selected in work/run/config.json (legacy filename retained for launch-script compatibility)."""
import json, os, sys, urllib.request

secrets = {}
try:
    for line in open('/tmp/.tfkeys', encoding='utf-8'):
        line = line.strip().replace('export ', '')
        if '=' in line:
            key, value = line.split('=', 1)
            secrets[key.strip()] = value.strip().strip('"').strip("'")
except OSError:
    pass

try:
    config = json.load(open('/workspace/v51run/work/run/config.json', encoding='utf-8'))
    selection = config.get('textModel') or {}
    model = selection.get('modelId')
    if not model:
        raise RuntimeError('textModel.modelId missing in config.json')
    effort = selection.get('reasoningEffort') or 'none'
    api_key = secrets.get('NEBIUS_API_KEY') or os.environ.get('NEBIUS_API_KEY')
    base_url = (secrets.get('NEBIUS_BASE_URL') or secrets.get('NEBIUS_API_URL') or os.environ.get('NEBIUS_BASE_URL') or 'https://api.tokenfactory.nebius.com/v1').rstrip('/')
    if not api_key:
        raise RuntimeError('NEBIUS_API_KEY missing')
    body = {
        'model': model,
        'max_tokens': 80,
        'reasoning_effort': effort,
        'messages': [{'role': 'user', 'content': 'Reply with OK only.'}],
    }
    req = urllib.request.Request(
        base_url + '/chat/completions',
        data=json.dumps(body).encode(),
        headers={'Authorization': 'Bearer ' + api_key, 'Content-Type': 'application/json'},
    )
    with urllib.request.urlopen(req, timeout=90) as response:
        payload = json.loads(response.read().decode('utf-8'))
        choices = payload.get('choices') or []
        content = (choices[0].get('message') or {}).get('content') if choices else None
        if not content:
            raise RuntimeError('model returned no content')
    print(f'TEXT_MODEL_OK {model}')
    sys.exit(0)
except Exception as error:
    print(f'TEXT_MODEL_DOWN {type(error).__name__}: {str(error)[:120]}')
    sys.exit(1)
