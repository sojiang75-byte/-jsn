# ToonFlow v5.2 修复说明

## 本版本基线

本版本以用户本次上传的 `toonflow-v51-running-src.tar.gz` 中实际运行的 v5.1 源码为基线制作，保留原项目结构、v5.1 原文账本、运行配置与失败现场文件；不覆盖用户原始压缩包。新增修复集中在分镜规划阶段。

## v5.2 修复内容

### 1. 程序级超时对白自动拆镜

- 在原文 SRC/Q 账本分配完成、初次账本校验通过后，先按 Q 的 `groupId` 计算独立对白时长。
- 同一镜头中的多段独立对白若合计超过 `maxShotSeconds`，程序按完整 Q/group 边界贪心拆分到相邻镜头，不再依赖模型自行修复。
- 对单段长对白，只有当 Source Ledger 已将其切成连续 Q 子片段时，才允许在这些原文边界拆分。
- 按拆分结果重新分配 `sourceRefs` 和 `quoteAssignments`，保持 SRC/Q 唯一性、原文顺序和说话人信息。
- 拆分后再次运行 `validateSourceLedger`；不满足无损分配条件时不强行拆分，明确记录警告并交给质量门拦截。
- 新增镜头沿用原角色、场景、镜头合同与连续性状态；后续子镜头设置为 `continuous`，不新增角色或改写台词。
- 拆分后重新编号段内镜头，并由既有时长保护逻辑上调单集目标时长。

### 2. 针对本次失败现场的修复

用户上传的实际运行目录包含 `work/run/一键成片/v51-ch1/planner_attempts/storyboard_E00_attempt_04.json` 和 `source_ledger.json`。已用该真实失败输出做离线回归：

- 原镜头 `E01-04-09` 同时分配 Q0022、Q0023，SRC0111、SRC0112。
- 修复后 Q0022 留在 `E01-04-09`，Q0023 移到相邻的 `E01-04-10`。
- SRC0111 / Q0022 与 SRC0112 / Q0023 分别归属对应镜头。
- 在 `maxShotSeconds=15`、语速 4.5 字/秒、每句留白 0.4 秒、模型档位 `[5,10,15]` 下，拆分后时长分别为 10 秒和 15 秒。
- 拆分后的 `validateSourceLedger` 结果为 `ok=true`；程序回填后两镜对白与账本原文逐字一致。

### 3. beat 枚举规范化

将 `spatialContract.beat` 纳入 `normalizeStoryboardEnums`：

- `dialogue`、`movement`、`combat`、`fight`、`explosion`、`impact` → `action`
- `tension`、`threat`、`suspense`、`response` → `reaction`
- `establish`、`setup`、`scene setting` → `establishing`
- `discovery`、`surprise` → `reveal`
- `detail`、`insert shot` → `insert`
- `bridge`、`passage` → `transition`
- 未知值仍交给 Zod 硬校验拒绝，不会静默吞掉。

### 4. 提示词与修复反馈

- 明确要求模型不要把多段独立对白塞进同一镜头；若合计超时，按完整 Q/group 边界分配到相邻镜头。
- 如果时长质量门仍失败，修复反馈会列出该镜头中的 Q ID，并明确要求分别拆到两个相邻镜头，原文不得合并或改写。

## 本地验证记录

- TypeScript `transpileModule` 语法转译：修改的 `planner.ts` 与 `storyboard.test.ts` 通过。
- 使用真实失败现场 attempt 04 + source ledger 离线运行拆镜函数：1 个镜头被拆分，新增 1 镜，无警告。
- 真实失败现场拆分后重新执行 Source Ledger 校验：通过（0 个错误）。
- 对真实失败现场回填原文：Q0022、Q0023 分别出现在两个相邻镜头，文本与账本一致。
- 新增 Bun 单元测试：覆盖 15 秒上限、相邻镜头编号、SRC/Q 重新归属、回填逐字一致，以及 beat 别名规范化。

## 尚未完成的验证

- 当前执行环境没有 Bun，未运行 Bun 全量测试。尝试对指定文件做 `tsc` 检查时，因源码包未安装 `zod`、Bun types 和工作区依赖，无法完成完整类型检查；报错中未出现新增拆镜函数的独立类型错误，但这不能替代完整类型检查。
- 未调用真实 DeepSeek API，未执行新的线上分镜回归。
- 未生成首帧、图片或视频；本次修复和离线回归没有媒体生成费用。
- 因此 v5.2 是代码修复与真实失败样本离线回归通过的版本，仍需用户在运行环境设置 `stopAfter: "storyboard"` 做真实模型回归后，才能决定是否整章制作。

## 安全分镜回归启动

完整包新增 `config.v52-storyboard.example.json` 和 `launch_v52_storyboard.sh.txt`：

- 默认工作根目录 `/workspace/v52run/toonflow-v52-running`，请将 ZIP 解压到 `/workspace/v52run`；也可用 `TOONFLOW_ROOT` 指向实际项目根目录。
- 默认原文路径 `/workspace/fengliu_ch1.md`，可用 `TOONFLOW_STORY_FILE` 覆盖。
- 只启动 ToonFlow 主进程；不启动 relay、worker。配置保留原运行配置中的图片/视频模型选择及 H3 `[5..15]` 时长档位，仅用于真实模式依赖装配和分镜时长校验；显式 `scorer: {type: "none"}`。`stopAfter: "storyboard"` 会在角色卡、场景图、首帧和视频生成之前返回，因此不会调用任何图片/视频生成接口。
- 配置 `stopAfter: "storyboard"`，只做文本分镜规划。
- 保留 `QA_TRAIT_MODELS=grok-4.7,nvidia/Nemotron-3.5-Super-VL` 双模型设置。
- 成功停在 storyboard 阶段会以正常退出码结束，避免被误判为失败。
- 原 v5.1 的 `work/STOP_TRIGGER.json` 已归档为 `work/STOP_TRIGGER.v51-failure.json`，保留证据但不再作为新版本的停止哨兵。
- 真实失败样本的离线复测记录见 `V5_2_OFFLINE_REGRESSION_REPORT.md`。
- `launch.sh.txt` 默认转到安全的分镜回归入口；`resume.sh.txt` 暂时阻止旧版整章续跑，避免误启动媒体生成。

## v5.2.1 启动配置修正

复核发现服务层 `buildDeps()` 在真实模式下即使 `stopAfter: "storyboard"` 也要求提供 `imageModel`，否则会在 DeepSeek 分镜开始前报“请选择图片模型 imageModel”。v5.2.1 已补回原运行配置中的图片/视频模型选择，并保留 H3 实际时长档位 `[5..15]`；显式将图像评分设为 `none`。这些模型选择只用于依赖装配与分镜时长校验；`runAutoflow()` 在 `run.storyboard()` 后立即因 `stopAfter: "storyboard"` 返回，图片/视频阶段不执行。

## 建议测试方式

1. 解压完整 ZIP 到新目录，例如 `/workspace/v52run`，不要覆盖 v5.1 原目录。
2. 确认 `/tmp/.tfkeys` 中已配置 Nebius API 凭据，并确认原文文件 `/workspace/fengliu_ch1.md` 存在。
3. 运行 `bash launch_v52_storyboard.sh.txt`，或先设置 `TOONFLOW_ROOT` / `TOONFLOW_STORY_FILE` 后运行。
4. 保留 fail-fast，不启用自动重做。
4. 检查日志是否出现“程序自动拆分 … 个超时对白镜头”。拆分后 Q0022/Q0023 预期时长为 7 秒和 11 秒（按原 H3 `[5..15]` 档位向上取整）。
5. 检查 Q0022/Q0023 是否分属两个相邻镜头、时长是否都不超过 15 秒、SRC/Q 账本是否通过。
6. 确认完整分镜自检通过后，再单独决定是否运行整章。保持 Grok-4.7 + Nemotron 双模型角色特征质检规则不变。


## v5.2.2 补充修复（2026-11-04）

根据 v5.2 实际分镜回归反馈，修复死亡状态识别的分句边界：`hasCorpseMention()` 现在先按句号、问号、感叹号、分号和换行切分，再在同一分句内匹配角色名与尸体/死亡词。这样 `老二成为尸体；老五来不及呼叫` 只会将老二判定为死亡，不会跨分号把老五误判为尸体。

另将 `spatialContract.beat` 的 `activity` / `活动` 规范化为合法值 `action`。新增两个针对性测试：分号后的另一角色不得继承尸体状态；`activity` 必须规范化为 `action`。

仍有 1 条说话人无法从原文上下文确定的对白，继续标记为 `narrator` 并要求人工复核；程序不得猜测角色。用户报告中提及的另外 2 个失败测试夹具没有提供具体断言/堆栈，本版本不宣称已修复或通过那两项测试。
