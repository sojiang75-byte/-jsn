import json
import os
import time
import urllib.error
import urllib.request
from pathlib import Path

ASSETS = Path(r"C:\Users\Administrator\.cursor\projects\c-Users-Administrator-Downloads-ToonFlow-v5-2-4-reference-video\assets")
OUT = Path(__file__).resolve().parent
BASE = "https://api.aiand.com/v1"
KEY = os.environ["AIAND_API_KEY"]
PROMPT = (
    "Start on the first frame and end on the last frame. "
    "She stands outside, on the right of a closed wooden door. The camera stays outside with her. "
    "One continuous 10-second shot with no cuts. "
    "Her right hand keeps hold of the door chain. Her left hand stays in her coat pocket. "
    "She tightens that one grip a little and says <d>[Chinese] 再敲我就报警。</d> "
    "No second person. No gloves. No extra hands. The door stays closed. "
    "Night rain, one street lamp. No music. No on-screen text."
)


def request(method, url, data=None, headers=None, timeout=180):
    req = urllib.request.Request(url, data=data, headers=headers or {}, method=method)
    last = None
    for attempt in range(4):
        try:
            with urllib.request.urlopen(req, timeout=timeout) as res:
                return res.status, res.read()
        except urllib.error.HTTPError as error:
            body = error.read()
            if error.code not in {429, 500, 502, 503, 504}:
                return error.code, body
            last = error
            print(f"retry {attempt + 1} http {error.code}", flush=True)
        except Exception as error:
            last = error
            print(f"retry {attempt + 1} {type(error).__name__}", flush=True)
        time.sleep(3 * (attempt + 1))
    raise last


def upload(name, src: Path):
    boundary = "----ToonFlowTry"
    raw = src.read_bytes()
    head = (
        f"--{boundary}\r\n"
        f'Content-Disposition: form-data; name="purpose"\r\n\r\nvision\r\n'
        f"--{boundary}\r\n"
        f'Content-Disposition: form-data; name="file"; filename="{name}.jpg"\r\n'
        f"Content-Type: image/jpeg\r\n\r\n"
    ).encode()
    tail = f"\r\n--{boundary}--\r\n".encode()
    status, body = request(
        "POST",
        f"{BASE}/files",
        data=head + raw + tail,
        headers={"Authorization": f"Bearer {KEY}", "Content-Type": f"multipart/form-data; boundary={boundary}"},
    )
    payload = json.loads(body)
    if status >= 300 or "id" not in payload:
        raise SystemExit(f"upload {name} {status} {body[:300]!r}")
    return payload["id"]


def main():
    state_path = OUT / "job.json"
    if state_path.exists() and json.loads(state_path.read_text(encoding="utf-8")).get("id"):
        job_id = json.loads(state_path.read_text(encoding="utf-8"))["id"]
        print(f"reuse {job_id}", flush=True)
    else:
        first = upload("first", ASSETS / "try-first.jpg")
        last = upload("last", ASSETS / "try-last.jpg")
        print(f"uploaded {first} {last}", flush=True)
        payload = {
            "model": "minimaxai/minimax-h3",
            "seconds": 10,
            "aspect_ratio": "9:16",
            "prompt": PROMPT,
            "image_reference": [
                {"file_id": first, "role": "first_frame"},
                {"file_id": last, "role": "last_frame"},
            ],
        }
        status, body = request(
            "POST",
            f"{BASE}/videos",
            data=json.dumps(payload).encode(),
            headers={"Authorization": f"Bearer {KEY}", "Content-Type": "application/json"},
        )
        data = json.loads(body)
        if status >= 300 or "id" not in data:
            raise SystemExit(f"submit {status} {body[:400]!r}")
        job_id = data["id"]
        state_path.write_text(json.dumps({"id": job_id, "first": first, "last": last}, indent=2), encoding="utf-8")
        print(f"submitted {job_id}", flush=True)
    while True:
        time.sleep(15)
        status, body = request("GET", f"{BASE}/videos/{job_id}", headers={"Authorization": f"Bearer {KEY}"})
        info = json.loads(body)
        print(info.get("status"), info.get("cost") or info.get("usage"), flush=True)
        if info.get("status") == "completed":
            _, mp4 = request("GET", f"{BASE}/videos/{job_id}/content", headers={"Authorization": f"Bearer {KEY}"})
            (OUT / "raw.mp4").write_bytes(mp4)
            print(f"saved {len(mp4)}", flush=True)
            return
        if info.get("status") in {"failed", "cancelled", "canceled", "expired"}:
            raise SystemExit(info)


if __name__ == "__main__":
    main()
