# validation: uploads five first frames and requests five 10s H3 clips — lab-only, billed on success
import json
import os
import time
import urllib.request
from pathlib import Path

ROOT = Path(r"C:\Users\Administrator\.cursor\projects\c-Users-Administrator-Downloads-ToonFlow-v5-2-4-reference-video\assets")
OUT = Path(__file__).resolve().parent
BASE = "https://api.aiand.com/v1"
KEY = os.environ["AIAND_API_KEY"]

CLIPS = [
    ("clip2", "clip2-first.jpg",
     "Start from this exact frame: the same woman in a black coat holds the door chain while a black-gloved hand is on the chain outside. "
     "One continuous 10-second shot with no cuts. She pulls the chain tight, looks toward the gap, and says <d>[Chinese] 再敲我就报警。</d> "
     "The gloved hand lets go and withdraws. Night rain, wet alley, a single street lamp. No music. No on-screen text."),
    ("clip3", "clip3-first.jpg",
     "Start from this exact frame: the same woman crouches by the chained door, reaching for a small photograph on the wet ground. "
     "One continuous 10-second shot with no cuts. She picks the photograph up, looks at it, and goes still when she recognizes her own face. "
     "No spoken words. Night rain, a single street lamp. No music. No on-screen text."),
    ("clip4", "clip4-first.jpg",
     "Start from this exact frame: one of her eyes fills the gap of the chained door, looking into an empty rainy alley. "
     "One continuous 10-second shot with no cuts. She searches the empty alley, then says <d>[Chinese] 人呢？</d> "
     "Nobody answers. Night rain. No music. No on-screen text."),
    ("clip5", "clip5-first.jpg",
     "Start from this exact frame: the same woman stands by the chained door, holding a phone with a blank glowing screen. "
     "One continuous 10-second shot with no cuts. The phone vibrates once. She looks at the blank screen and does not answer. "
     "Then one soft knock hits the door. No spoken words. Night rain. No music. No on-screen text."),
    ("clip6", "clip6-first.jpg",
     "Start from this exact frame: the same woman braces against the chained door, both hands on the handle. "
     "One continuous 10-second shot with no cuts. The loose chain lets the door creep open a finger-width, and she drives it shut with her shoulder and holds it. "
     "No spoken words. Night rain. No music. No on-screen text."),
]


def request(method, url, data=None, headers=None, timeout=120):
    req = urllib.request.Request(url, data=data, headers=headers or {}, method=method)
    with urllib.request.urlopen(req, timeout=timeout) as res:
        body = res.read()
        return res.status, dict(res.headers), body


def upload(name, src: Path):
    boundary = "----ToonFlowBoundary7"
    raw = src.read_bytes()
    head = (
        f"--{boundary}\r\n"
        f'Content-Disposition: form-data; name="purpose"\r\n\r\nvision\r\n'
        f"--{boundary}\r\n"
        f'Content-Disposition: form-data; name="file"; filename="{name}.jpg"\r\n'
        f"Content-Type: image/jpeg\r\n\r\n"
    ).encode()
    tail = f"\r\n--{boundary}--\r\n".encode()
    status, _, body = request(
        "POST",
        f"{BASE}/files",
        data=head + raw + tail,
        headers={
            "Authorization": f"Bearer {KEY}",
            "Content-Type": f"multipart/form-data; boundary={boundary}",
        },
    )
    payload = json.loads(body)
    if status >= 300 or "id" not in payload:
        raise SystemExit(f"upload {name} failed {status} {body[:300]!r}")
    return payload["id"]


def submit(name, file_id, prompt):
    payload = {
        "model": "minimaxai/minimax-h3",
        "seconds": 10,
        "aspect_ratio": "9:16",
        "prompt": prompt,
        "image_reference": [{"file_id": file_id, "role": "first_frame"}],
    }
    raw = json.dumps(payload).encode()
    status, _, body = request(
        "POST",
        f"{BASE}/videos",
        data=raw,
        headers={"Authorization": f"Bearer {KEY}", "Content-Type": "application/json"},
    )
    data = json.loads(body)
    if status >= 300 or "id" not in data:
        raise RuntimeError(f"submit {name} failed {status} {body[:400]!r}")
    (OUT / f"{name}-请求.json").write_text(
        json.dumps({**payload, "job": data}, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    return data["id"]


def poll(job_id):
    status, _, body = request(
        "GET",
        f"{BASE}/videos/{job_id}",
        headers={"Authorization": f"Bearer {KEY}"},
    )
    return json.loads(body)


def download(job_id, dest: Path):
    status, _, body = request(
        "GET",
        f"{BASE}/videos/{job_id}/content",
        headers={"Authorization": f"Bearer {KEY}"},
        timeout=180,
    )
    if status >= 300 or len(body) < 1000:
        raise RuntimeError(f"download {job_id} failed {status} {len(body)}")
    dest.write_bytes(body)


def main():
    jobs = {}
    state_path = OUT / "jobs.json"
    if state_path.exists():
        jobs = json.loads(state_path.read_text(encoding="utf-8"))
    for name, image, prompt in CLIPS:
        if jobs.get(name, {}).get("id"):
            print(f"reuse {name} {jobs[name]['id']}", flush=True)
            continue
        src = ROOT / image
        copied = OUT / f"{name}-首帧.jpg"
        copied.write_bytes(src.read_bytes())
        file_id = upload(name, src)
        print(f"uploaded {name} {file_id}", flush=True)
        job_id = submit(name, file_id, prompt)
        jobs[name] = {"id": job_id, "file_id": file_id}
        state_path.write_text(json.dumps(jobs, ensure_ascii=False, indent=2), encoding="utf-8")
        print(f"submitted {name} {job_id}", flush=True)
    pending = set(jobs)
    while pending:
        time.sleep(15)
        done = []
        for name in list(pending):
            info = poll(jobs[name]["id"])
            status = info.get("status")
            print(f"{name} {status}", flush=True)
            jobs[name]["status"] = status
            jobs[name]["cost"] = info.get("cost") or info.get("usage")
            if status == "completed":
                download(jobs[name]["id"], OUT / f"{name}.mp4")
                print(f"saved {name}.mp4", flush=True)
                done.append(name)
            elif status in {"failed", "cancelled", "expired"}:
                raise SystemExit(f"{name} {status} {info}")
        for name in done:
            pending.discard(name)
        state_path.write_text(json.dumps(jobs, ensure_ascii=False, indent=2), encoding="utf-8")
    print("ALL_DONE", flush=True)


if __name__ == "__main__":
    main()
