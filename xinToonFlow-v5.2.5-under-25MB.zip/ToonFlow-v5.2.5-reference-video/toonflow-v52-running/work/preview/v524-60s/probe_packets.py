import av
from pathlib import Path

base = Path(r"C:\Users\Administrator\Downloads\ToonFlow-v5.2.4-reference-video\toonflow-v52-running\work\preview")
files = [base / "v524-10s" / "成片.mp4", base / "v524-60s" / "clip2.mp4"]

out = av.open(str(base / "v524-60s" / "_probe.mp4"), "w")
src0 = av.open(str(files[0]))
print("in v tb", src0.streams.video[0].time_base, "dur", src0.streams.video[0].duration)
print("in a tb", src0.streams.audio[0].time_base, "dur", src0.streams.audio[0].duration)
vout = out.add_stream_from_template(src0.streams.video[0])
aout = out.add_stream_from_template(src0.streams.audio[0])
print("out v tb", vout.time_base, "out a tb", aout.time_base)
src0.close()

for label, path in (("a", files[0]), ("b", files[1])):
    inp = av.open(str(path))
    n = 0
    for packet in inp.demux(inp.streams.video[0], inp.streams.audio[0]):
        if packet.dts is None:
            continue
        print(label, packet.stream.type, "pts", packet.pts, "dts", packet.dts, "dur", packet.duration, "tb", packet.time_base, "key", packet.is_keyframe)
        n += 1
        if n >= 6:
            break
    inp.close()
out.close()
