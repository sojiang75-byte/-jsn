import cv2
from pathlib import Path

src = Path(__file__).resolve().parent / "成片.mp4"
cap = cv2.VideoCapture(str(src))
fps = cap.get(cv2.CAP_PROP_FPS)
frames = cap.get(cv2.CAP_PROP_FRAME_COUNT)
print("fps", fps, "frames", frames, "size", cap.get(cv2.CAP_PROP_FRAME_WIDTH), cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
for t in (5, 9, 15, 19, 25, 29, 35, 39, 45, 49, 55, 59):
    cap.set(cv2.CAP_PROP_POS_MSEC, t * 1000)
    ok, frame = cap.read()
    dest = Path(__file__).resolve().parent / f"frame-{t}.jpg"
    if ok:
        cv2.imwrite(str(dest), frame, [int(cv2.IMWRITE_JPEG_QUALITY), 85])
        print("wrote", dest.name, frame.shape)
    else:
        print("miss", t)
cap.release()
