import subprocess
from pathlib import Path

ffprobe = r"C:\ffmpeg\ffmpeg-8.0.1-essentials_build\bin\ffprobe.exe"
src = r"C:\Users\Administrator\Downloads\ToonFlow-v5.2.4-reference-video\toonflow-v52-running\work\preview\v524-60s\成片.mp4"
out = Path(__file__).with_name("_packets.txt")
subprocess.run(
    [
        ffprobe, "-v", "error", "-select_streams", "v:0",
        "-show_entries", "packet=pts_time,dts_time,flags",
        "-of", "csv=p=0", src,
    ],
    check=True,
    stdout=out.open("w", encoding="utf-8"),
)
rows = out.read_text(encoding="utf-8").splitlines()
print("packets", len(rows))
prev = None
bad = 0
for i, line in enumerate(rows):
    parts = line.split(",")
    if len(parts) < 2 or parts[1] in ("", "N/A"):
        continue
    dts = float(parts[1])
    if prev is not None and dts + 1e-6 < prev:
        bad += 1
        if bad <= 8:
            print("back", i, prev, dts, line)
    prev = dts
print("dts_back", bad)
print("first", rows[0] if rows else None)
print("last", rows[-1] if rows else None)
out.unlink(missing_ok=True)
