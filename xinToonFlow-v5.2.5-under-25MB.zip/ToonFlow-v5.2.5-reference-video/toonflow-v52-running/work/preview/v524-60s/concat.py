import av
from pathlib import Path

base = Path(r"C:\Users\Administrator\Downloads\ToonFlow-v5.2.4-reference-video\toonflow-v52-running\work\preview")
files = [base / "v524-10s" / "成片.mp4"] + [base / "v524-60s" / f"clip{i}.mp4" for i in range(2, 7)]
outp = base / "v524-60s" / "成片.mp4"


def bounds(path: Path):
    inp = av.open(str(path))
    mins, maxs = {}, {}
    streams = [inp.streams.video[0], inp.streams.audio[0]]
    for packet in inp.demux(*streams):
        if packet.dts is None:
            continue
        kind = packet.stream.type
        end = packet.dts + (packet.duration or 0)
        mins[kind] = packet.dts if kind not in mins else min(mins[kind], packet.dts)
        maxs[kind] = end if kind not in maxs else max(maxs[kind], end)
    inp.close()
    return mins, maxs


out = av.open(str(outp), "w")
src0 = av.open(str(files[0]))
vout = out.add_stream_from_template(src0.streams.video[0])
aout = out.add_stream_from_template(src0.streams.audio[0])
src0.close()

cursor = {"video": 0, "audio": 0}
targets = {"video": vout, "audio": aout}

for path in files:
    mins, maxs = bounds(path)
    shift = {kind: cursor[kind] - mins[kind] for kind in mins}
    inp = av.open(str(path))
    streams = [inp.streams.video[0], inp.streams.audio[0]]
    seen = {"video": cursor["video"], "audio": cursor["audio"]}
    for packet in inp.demux(*streams):
        if packet.dts is None:
            continue
        kind = packet.stream.type
        packet.stream = targets[kind]
        if packet.pts is not None:
            packet.pts += shift[kind]
        packet.dts += shift[kind]
        end = packet.dts + (packet.duration or 0)
        if end > seen[kind]:
            seen[kind] = end
        out.mux(packet)
    inp.close()
    cursor = seen
    print(path.name, cursor)

out.close()

chk = av.open(str(outp))
v = chk.streams.video[0]
a = chk.streams.audio[0]
print(
    "out",
    outp.stat().st_size,
    "v",
    round(float(v.duration * v.time_base), 3),
    "a",
    round(float(a.duration * a.time_base), 3),
)
chk.close()
