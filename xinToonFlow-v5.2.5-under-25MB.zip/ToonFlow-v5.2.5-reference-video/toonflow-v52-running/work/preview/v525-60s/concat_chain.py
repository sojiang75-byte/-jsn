# 把 submit_chain.py 生成的 clip1..clip6 拼成 成片.mp4。
# 第 2–6 条的第 0 帧就是上一条的最后一帧（接力首帧），直接拼会让同一画面出现两次、顿一下，所以每条丢掉第 0 帧，
# 音频同步丢掉同样长度。需要 ffmpeg 在 PATH 里；没有 ffmpeg 时退回 PyAV 无损拼接（不丢帧，只打印提示）。
import shutil
import subprocess
import sys
from pathlib import Path

OUT = Path(__file__).resolve().parent
FILES = [OUT / f"clip{i}.mp4" for i in range(1, 7)]
TARGET = OUT / "成片.mp4"
FPS = 24


def size_of(path: Path):
    try:
        import av
        with av.open(str(path)) as container:
            stream = container.streams.video[0]
            return stream.width, stream.height
    except Exception:
        return 768, 1344


def with_ffmpeg(files):
    width, height = size_of(files[0])
    inputs, filters, labels = [], [], []
    for index, path in enumerate(files):
        inputs += ["-i", str(path)]
        trim_v = ",trim=start_frame=1,setpts=PTS-STARTPTS" if index else ""
        trim_a = f",atrim=start={1 / FPS:.4f},asetpts=PTS-STARTPTS" if index else ""
        filters.append(f"[{index}:v:0]fps={FPS},scale={width}:{height}:force_original_aspect_ratio=decrease,"
                       f"pad={width}:{height}:(ow-iw)/2:(oh-ih)/2,setsar=1{trim_v},format=yuv420p[v{index}]")
        filters.append(f"[{index}:a:0]aresample=44100,aformat=channel_layouts=stereo{trim_a}[a{index}]")
        labels.append(f"[v{index}][a{index}]")
    filters.append(f"{''.join(labels)}concat=n={len(files)}:v=1:a=1[v][a]")
    command = ["ffmpeg", "-hide_banner", "-y", *inputs, "-filter_complex", ";".join(filters), "-map", "[v]", "-map", "[a]",
               "-c:v", "libx264", "-crf", "18", "-preset", "medium", "-c:a", "aac", "-b:a", "192k", "-movflags", "+faststart", str(TARGET)]
    subprocess.run(command, check=True)


def with_pyav(files):
    import av
    print("没有找到 ffmpeg：改用 PyAV 无损拼接，接力条开头的重复帧不会去掉（约 1/24 秒的停顿）。")
    out = av.open(str(TARGET), "w")
    first = av.open(str(files[0]))
    vout = out.add_stream_from_template(first.streams.video[0])
    aout = out.add_stream_from_template(first.streams.audio[0])
    first.close()
    targets = {"video": vout, "audio": aout}
    cursor = {"video": 0, "audio": 0}
    for path in files:
        inp = av.open(str(path))
        streams = [inp.streams.video[0], inp.streams.audio[0]]
        mins = {}
        for packet in inp.demux(*streams):
            if packet.dts is not None:
                kind = packet.stream.type
                mins[kind] = packet.dts if kind not in mins else min(mins[kind], packet.dts)
        inp.close()
        inp = av.open(str(path))
        seen = dict(cursor)
        for packet in inp.demux(*inp.streams.video[:1], *inp.streams.audio[:1]):
            if packet.dts is None:
                continue
            kind = packet.stream.type
            shift = cursor[kind] - mins[kind]
            packet.stream = targets[kind]
            if packet.pts is not None:
                packet.pts += shift
            packet.dts += shift
            seen[kind] = max(seen[kind], packet.dts + (packet.duration or 0))
            out.mux(packet)
        inp.close()
        cursor = seen
    out.close()


def main():
    missing = [path.name for path in FILES if not path.exists()]
    if missing:
        raise SystemExit(f"还没有生成：{', '.join(missing)}")
    if shutil.which("ffmpeg"):
        with_ffmpeg(FILES)
    else:
        with_pyav(FILES)
    print(f"写出 {TARGET.name}")


if __name__ == "__main__":
    sys.exit(main())
