# 门缝 60 秒 · 串行接力版（v5.2.5）
#
# 替换 v524-60s/submit.py。旧脚本的问题：5 张首帧各自单独画好，约 3 分钟内全部提交，
# 那时上一条还没生成完，所以上一条的结尾不可能传给下一条；每个请求只有一张首帧和一句 "the same woman"。
#
# 现在的做法：
#   1. 第 1 条用角色图做参考（references 模式），在屋内开拍。旧的首帧（v524-10s/首帧.jpg）背景是街道和路灯，
#      人已经在门外，和剧本“门内”矛盾，所以不再用它。
#   2. 第 2–6 条：等上一条生成完，抽它的最后一帧，直接作为这一条的 first_frame。
#   3. 每条只拍一个镜头、不切；结尾停在林夏脸清楚可见的画面上，不停在手套、眼睛等特写上。
#   4. 每条提示词都写明当前状态：她在门内、门外的人不露脸、门链挂没挂、照片和手机在哪只手。
#
# 计费：ai& H3 每条 10 秒 × $0.055 = $0.55，只在成功完成时扣费；6 条约 $3.30。任务提交后不能取消。
# 用法：
#   set AIAND_API_KEY=...            (PowerShell: $env:AIAND_API_KEY="...")
#   python submit_chain.py           # 生成 clip1..clip6，可中断后重跑，已完成的条不会重复提交
#   python submit_chain.py --dry-run # 只打印每条请求，不上传、不提交、不花钱
#   python concat_chain.py           # 拼成 成片.mp4（接力条丢掉重复的第 0 帧）
# 依赖：PyAV（import av）和 Pillow。
import argparse
import json
import os
import sys
import time
import urllib.request
from pathlib import Path

OUT = Path(__file__).resolve().parent
PREVIEW = OUT.parent
CHARACTER = PREVIEW / "v524-10s" / "角色.jpg"
BASE = os.environ.get("AIAND_BASE_URL", "https://api.aiand.com/v1").rstrip("/")
MODEL = "minimaxai/minimax-h3"
SECONDS = 10

LOOK = ("High-quality Japanese anime, cel-shaded, cinematic lighting, clean line art. 9:16. "
        "Lin Xia: short black hair, black long coat, dark shirt; her face, hair and clothes stay identical the whole time.")
PLACE = ("Lin Xia is INSIDE her dim old apartment, at the front door. The door opens inward only a few centimeters on a door chain. "
         "Rain, a wet alley and a street lamp are visible only through the gap. The stranger is OUTSIDE the door and never shows a face.")
RULES = ("One continuous 10-second shot with no cuts; the camera stays inside the apartment on the same side of the door. "
         "No new people with faces. Ambient sound only: rain, the door. No music. No on-screen text, subtitles or watermark.")


def ending(text, last=False):
    hand_off = "this is the final shot of the scene." if last else "the next clip starts from this final frame."
    return f"End of the shot: {text} Hold this for the last second without cutting; {hand_off}"


# (名称, 当前道具状态, 这一条的动作, 结尾画面)
CLIPS = [
    ("clip1",
     "The chain is hooked and taut. Both her hands are free.",
     "A hard knock hits the door. She presses close to the gap, grips the chain with her right hand and says <d>[Chinese] 谁？</d> "
     "A black-gloved hand slides in through the gap from outside and rests on the chain.",
     "medium close-up of her face beside the gap, the gloved hand still on the chain."),
    ("clip2",
     "The chain is hooked and taut; a black-gloved hand from outside rests on it; her right hand holds the chain.",
     "She pulls the chain tight, looks toward the gap and says <d>[Chinese] 再敲我就报警。</d> The gloved hand lets go and withdraws outside.",
     "her face beside the gap, the chain still hooked and taut, no hand outside."),
    ("clip3",
     "The chain is hooked and taut. Her hands are empty.",
     "A small photograph slides in under the door and lands on the floor inside. She crouches slowly, picks it up with her right hand, "
     "looks at it and goes still: it shows herself standing in front of this door. No spoken words.",
     "she is crouched by the door, face visible, the photograph in her right hand."),
    ("clip4",
     "The chain is hooked and taut. The photograph is in her right hand.",
     "Still holding the photograph, she rises and brings one eye to the gap, looking out at the empty rainy alley, then says "
     "<d>[Chinese] 人呢？</d> Nobody answers. She leans back from the gap.",
     "her face visible a little back from the gap, the photograph still in her right hand. Not an eye close-up."),
    ("clip5",
     "The chain is hooked and taut. The photograph is in her right hand. Her phone is in her left coat pocket.",
     "The phone in her pocket vibrates. She takes it out with her left hand; the screen shows an unknown number. She does not answer. "
     "Then one soft knock on the door. No spoken words.",
     "her face lit by the phone, the phone in her left hand, the photograph in her right hand."),
    ("clip6",
     "The chain is hooked. The phone is in her left hand, the photograph in her right hand.",
     "The chain slips out of its slot and the door creeps open a finger-width. She shoves the phone into her pocket, drives the door shut "
     "with her shoulder and presses her right hand on the chain. She stops and holds still. No spoken words.",
     "her face pressed to the closed door, right hand on the chain."),
]


def prompt_for(index, state, action, end):
    if index == 0:
        opening = "<Picture 1> is Lin Xia; keep her face, hair and clothes exactly as in <Picture 1>, ignore its plain background."
    else:
        opening = "Start from this exact frame and continue it: same place, same positions, same lighting, same rain."
    return " ".join([opening, LOOK, PLACE, f"Current state: {state}", f"Action: {action}", ending(end, index == len(CLIPS) - 1), RULES])


def request(method, url, key, data=None, content_type=None, timeout=120):
    headers = {"Authorization": f"Bearer {key}"}
    if content_type:
        headers["Content-Type"] = content_type
    req = urllib.request.Request(url, data=data, headers=headers, method=method)
    with urllib.request.urlopen(req, timeout=timeout) as res:
        return res.status, res.read()


def upload(key, name, src: Path):
    boundary = "----ToonFlowChain525"
    mime = "image/png" if src.suffix.lower() == ".png" else "image/jpeg"
    head = (f"--{boundary}\r\nContent-Disposition: form-data; name=\"purpose\"\r\n\r\nvision\r\n"
            f"--{boundary}\r\nContent-Disposition: form-data; name=\"file\"; filename=\"{name}{src.suffix}\"\r\n"
            f"Content-Type: {mime}\r\n\r\n").encode()
    tail = f"\r\n--{boundary}--\r\n".encode()
    status, body = request("POST", f"{BASE}/files", key, head + src.read_bytes() + tail, f"multipart/form-data; boundary={boundary}")
    payload = json.loads(body)
    if status >= 300 or "id" not in payload:
        raise SystemExit(f"upload {name} failed {status} {body[:300]!r}")
    return payload["id"]


def payload_for(index, file_id, prompt):
    body = {"model": MODEL, "seconds": SECONDS, "aspect_ratio": "9:16", "prompt": prompt}
    if index == 0:
        body["references"] = {"images": [{"file_id": file_id}]}
    else:
        body["image_reference"] = [{"file_id": file_id, "role": "first_frame"}]
    return body


def submit(key, name, body):
    status, raw = request("POST", f"{BASE}/videos", key, json.dumps(body).encode(), "application/json")
    data = json.loads(raw)
    if status >= 300 or "id" not in data:
        raise RuntimeError(f"submit {name} failed {status} {raw[:400]!r}")
    (OUT / f"{name}-请求.json").write_text(json.dumps({**body, "job": data}, ensure_ascii=False, indent=2), encoding="utf-8")
    return data["id"]


def wait_done(key, name, job_id):
    while True:
        time.sleep(15)
        _, raw = request("GET", f"{BASE}/videos/{job_id}", key)
        info = json.loads(raw)
        status = info.get("status")
        print(f"{name} {status}", flush=True)
        if status == "completed":
            return info
        if status in {"failed", "cancelled", "canceled", "expired"}:
            raise SystemExit(f"{name} {status} {info}")


def download(key, job_id, dest: Path):
    status, body = request("GET", f"{BASE}/videos/{job_id}/content", key, timeout=300)
    if status >= 300 or len(body) < 1000:
        raise RuntimeError(f"download {job_id} failed {status} {len(body)}")
    dest.write_bytes(body)


def last_frame(video: Path, dest: Path):
    import av  # PyAV
    with av.open(str(video)) as container:
        frame = None
        for frame in container.decode(video=0):
            pass
    if frame is None:
        raise SystemExit(f"{video.name} 没有视频帧")
    frame.to_image().save(dest, quality=95)
    return dest


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--dry-run", action="store_true", help="只打印请求，不上传、不提交")
    parser.add_argument("--only", type=int, default=6, help="只做前 N 条（先试 2 条看接缝，约 $1.10）")
    args = parser.parse_args()
    key = os.environ.get("AIAND_API_KEY", "")
    if not args.dry_run and not key:
        raise SystemExit("请先设置环境变量 AIAND_API_KEY")
    if not CHARACTER.exists():
        raise SystemExit(f"找不到角色图：{CHARACTER}")
    state_path = OUT / "jobs.json"
    jobs = json.loads(state_path.read_text(encoding="utf-8")) if state_path.exists() else {}
    for index, (name, state, action, end) in enumerate(CLIPS[: args.only]):
        video = OUT / f"{name}.mp4"
        prompt = prompt_for(index, state, action, end)
        if video.exists() and video.stat().st_size > 1000:
            print(f"已有 {video.name}，跳过", flush=True)
            continue
        start = CHARACTER if index == 0 else OUT / f"{CLIPS[index - 1][0]}-尾帧.jpg"
        if index > 0 and not start.exists():
            previous = OUT / f"{CLIPS[index - 1][0]}.mp4"
            if args.dry_run and not previous.exists():
                print(f"[dry-run] {name} 的首帧 = {previous.name} 的最后一帧（尚未生成）")
            else:
                last_frame(previous, start)
        if args.dry_run:
            print(f"\n[dry-run] {name}  {'参考图' if index == 0 else '首帧'}={start.name}\n{json.dumps(payload_for(index, '<file_id>', prompt), ensure_ascii=False, indent=2)}")
            continue
        job = jobs.get(name, {})
        if not job.get("id"):
            file_id = upload(key, name, start)
            job_id = submit(key, name, payload_for(index, file_id, prompt))
            job = jobs[name] = {"id": job_id, "file_id": file_id, "start": start.name}
            state_path.write_text(json.dumps(jobs, ensure_ascii=False, indent=2), encoding="utf-8")
            print(f"submitted {name} {job_id}", flush=True)
        info = wait_done(key, name, job["id"])
        job["status"] = "completed"
        job["cost"] = info.get("cost") or info.get("usage")
        download(key, job["id"], video)
        state_path.write_text(json.dumps(jobs, ensure_ascii=False, indent=2), encoding="utf-8")
        last_frame(video, OUT / f"{name}-尾帧.jpg")
        print(f"saved {video.name}，已抽尾帧给下一条", flush=True)
    print("ALL_DONE" if not args.dry_run else "DRY_RUN_DONE", flush=True)


if __name__ == "__main__":
    sys.exit(main())
