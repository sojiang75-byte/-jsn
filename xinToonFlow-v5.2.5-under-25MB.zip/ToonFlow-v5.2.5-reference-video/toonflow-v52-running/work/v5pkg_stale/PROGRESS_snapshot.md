# fx4 / v4 progress (times UTC on box; ET = UTC-5)

## State @ 04:22Z (23:22 ET)
- Step 1 (h3ps port) DONE. Toonflow tests 127/0 before; +h3ps hook test +2 propCards tests (rerun full suite at end).
- Step 2 QA (qa2.py) DONE + vehicle check D (VEHICLE_MODELS grok-4.3+gemma, card run/道具/vehicles.json).
- Vehicle card: run/道具/vehicles.json; also storyboard.json `props` (Toonflow schema propCardSchema, storyboard/propCards.ts,
  injected in generic prompts.ts + h3.ts; negative prompt). Worker auto_worker.py adds English vehicle_block + negatives.
- Worker fixes @03:3x: chars_for no longer adds cast from 站位 (root cause of 3-in-front-row); strip_blocking; trait_block never
  names absent chars; 持物 authoritative; pistol stripped from outfit. 萧枫 anchor hflipped (glove was on his LEFT hand; card says right);
  original kept at fx4/萧枫_anchor_orig.jpg.
- v3 baseline: run_qa_v3.sh -> qa2/v3/*.json (log /tmp/fx4_qav3.log, ALLDONE at end). Vehicle-only v3: qa2/v3veh/*.json (done).
  recall script: recall.py -> qa2/recall_v3.json. Vehicle recall 2/2 (E01-01-03 pickup, E01-02-01 police-lit van).
- Redo: pipeline launch 1 (03:20Z) --redo 13 shots; restarted 04:15Z with --redo E01-01-02,E01-02-05,E01-03-01,E01-03-04
  (=all 17 redone). DO NOT pass --redo again for these (would redo again). Resume = ./launch.sh (no args).
- E01-01-01 done (try 4, qa2 pass).
- Worker: ./launch_worker.sh (log auto_worker.log). fx3 worker stopped (fx3 files untouched).

## TODO
1. monitor until 成片.mp4; 2. phone copy /workspace/fengliu_ch1_v4.mp4 (<15MB, 2-pass 880k main yuv420p aac96k faststart) +
   full /workspace/fengliu_ch1_v4_full.mp4, contact sheet, qa json; 3. recall table; 4. bun test; 5. report.

## 04:35Z (23:35 ET) baseline QA on v3 finished: recall 11/16 (qa2/recall_v3.json). Misses: 萧枫纹身 x2 (E01-02-01, E01-02-04), 老大痣 E01-03-02, 前排三人 E01-02-04, 持枪手互换 E01-04-02. Vehicle 2/2.
## 04:35Z new steering: port laozhang_article.md ideas (assets sheets/product-photo vehicle refs, scene anchors, prompt locks, local edit, voice similarity, final mix). Working on it; see section LAOZHANG below.

## LAOZHANG port (started 04:36Z)
- auto_worker.py backed up as auto_worker.pre_laozhang.py; edits (NOT yet live until worker restart):
  prompt locks (DIALOGUE_LOCK / SILENT_LOCK, no subtitles, no music), SYS_IMG film-still/state + screen-left/right+anchor+meters+facing + one light,
  SYS_VID states-not-processes + speak-while-doing (no >3s static talking) + drop trait sentences about absent chars,
  vehicle_ref(): van product-photo ref image (assets/selected.json van_ext/van_int) appended to keyframe refs (NO_VEHICLE_REF=1 disables).
- make_assets.py -> assets/asset_van_{ext,int}_{1,2}.jpg, police ext (grey studio, single side light). log /tmp/fx4_assets.log
- voice/voice_sim.py (CAM++ zh onnx via sherpa-onnx in venv + faster-whisper line mapping) -> voice/v3_voice.json (log /tmp/fx4_voice_v3.log)
- torch cpu + demucs installing in venv (/tmp/fx4_torch.log) for vocal stems.
- 04:5xZ assets: van_ext_1 + van_int_2 selected (assets/selected.json). police asset came out without markings -> not used (police only needs to be "not the van").
- xAI image edits: max 5 input images (HTTP 400 at 6) -> add_vehicle_ref() drops a masked character's face close-up, else the scene ref.
- Worker restarted 04:41Z (pid 1183622) with laozhang prompt locks + van ref; 23daad (E01-01-03? keyframe) retranslated with van ref.
- Toonflow port: propCardSchema.image, propProductPrompt/shotPropImages, references propImages (prio 1, role prop), pipeline.propImages() stage,
  prompt locks (prompts.ts + h3.ts soundscape), stitch edge trim (edgeHead/Tail), new mastering.ts (speechSafeEdges, bed + 2-pass loudnorm -15/-1.5),
  pipeline option master {width,height,fps,...}. New test test/autoflow/laozhang.test.ts 7/7 pass.
- voice v3 (CAM++): 萧枫 sim-to-others 0.61-0.83 (pairwise 0.40-0.76), 老五 0.56-0.68, 老大 2 shots pairwise 0.30 raw / 0.435 demucs -> 老大 voice differs between E01-02-04 and E01-03-02.

## 2026-11-02 23:57 ET Seed-VC CPU feasibility: OK
- seed-vc inference.py patched (line 407 torchaudio.save -> soundfile; orig kept as inference.orig.py). 25 diffusion steps, CPU, ~26 s wall for a ~2 s line.
- E01-02-03 vocals -> target E01-04-02 (萧枫 best): CAM++ sim to target 0.752 -> 0.859; Whisper text preserved ("你开还是我开").
- Tool: voice/vc_eval.py SRC TGT OUT. Plan: voice/unify.py for v4 single-speaker outlier shots (demucs -> seed-vc -> remix no_vocals).

## 2026-11-02 23:57 ET A/B negatives vs positive x van ref (E01-01-02 keyframe, 4 arms x 3)
- Vehicle QA: 12/12 pass in all arms (neg_noref 3/3, pos_noref 3/3, neg_ref 3/3, pos_ref 3/3) -> QA not discriminative here.
- Visual review (ab/montage.jpg): every arm draws a white microvan; no police car / pickup in any arm. With the product ref the van's
  shape/size matches the asset more consistently (boxy microvan, same proportions across 3 tries); no-ref arms vary more (pos_noref #2 different body).
  No visible difference negatives vs positive-only on this shot.
- Decision: keep van product ref ON; keep the existing negatives (no measured harm, and they were what fixed police-car in v3); positive phrasing
  added in translation prompts in addition. Sample is small (n=3/arm) - recorded as "no measurable difference", not as proof.

## 2026-11-03 00:08 ET Export path ready + voice unify tool
- toonflow scripts/fx4_master.ts RUN_DIR OUT.mp4 [overrides.json]: speechSafeEdges + stitchVideos 1080x1920@24 crf18 + masterFilm.
  Dry run on fx3 (read only) -> export/v3_master_test.mp4: 110.4 s, 1080x1920 24fps, ebur128 I=-15.1 LUFS, true peak -1.2 dBFS. OK.
- voice/unify.py RUN VOICE_JSON OUT [--all-below X]: demucs -> seed-vc -> remix; accept only if CAM++ +0.03 and Whisper match not worse.
  v3 test (first pass): 老五 E01-01-03 0.686->0.787 but lost "快" (rejected); 萧枫 E01-01-04 0.671->0.777, E01-02-03 0.737->0.818 (accepted).
  Whisper traditional-vs-simplified skewed the text match -> added opencc t2s normalisation, re-running (log /tmp/fx4_unify_v3.log).
- Final export plan: after run done -> voice_sim fx4 -> unify outliers -> overrides.json -> fx4_master.ts -> phone copy (v3 spec).

## 2026-11-03 00:14 ET Voice unification validated on v3 (read-only test, outputs voice/unify_v3test/)
- Whisper check now beam 5 + zh prompt, best of VAD on/off, opencc t2s (greedy+VAD was dropping short lines).
- 老五 E01-01-03 0.686->0.787 text "快!搬钱!" kept (accepted); 老五 E01-03-05 0.584->0.581 (no gain, rejected);
  萧枫 E01-01-04 0.671->0.777 (accepted); 萧枫 E01-02-03 0.737->0.818 (accepted). Text 1.0->1.0 for all. ~1 min/shot CPU.
- 老大 has only 2 shots -> skipped (cannot tell which is the outlier); multi-speaker shots skipped (whole-stem VC would change other voices).
- Catchlight check: NOT done - style is 2D cel-shaded anime where catchlights are a drawing convention, anchors already approved in v2/v3;
  low value vs QA time.

## [from parent 12:25 AM] aid-studio borrow list (user approved borrowing; MIT, keep notice in THIRD_PARTY_NOTICES.md)
Research: /workspace/aid-studio (clone), prompts /workspace/aid-prompts/. Priority for v4:
1. Source-coverage gate: each shot gets `source` (verbatim chapter fragment); gate in storyboard/gates.ts: concatenated sources == chapter (ignore whitespace/quotes), every quoted dialogue line appears verbatim in some shot dialogue; feed missing pieces back in planner repair loop. In chapter mode skip/replace writeScript expansion (chapter text must stay unchanged).
2. Per-character fixed voice + separate dubbing (TTS with fixed voiceId in cards, replace model voices via demucs separation, new clipBin version, never overwrite original) - implement if feasible; at least voice-similarity check.
3. Scene 4-view (main, reverse, left, right) via 2x2 sheet + ffmpeg crop; shot.sceneView; slots (anchor+direction); forbid absolute compass directions.
4. Continuity protocol for single-shot redo: pass previous shot's CURRENT prompt + end state; inherit only visible state (identity, count, position, facing, props held/damaged, clothing, axis, light); never inherit dialogue/audio/lipsync.
5. Prop/vehicle state forms (PropCard.states[], per-state product photo; state may only progress with a cause) -> van vs police car.
6. Character sheet layout (face close-up, front/side/back, 6 expression cells), crop to single-view references for side/back shots.
7. Remap/drop reference numbering when refs are truncated; legend "图1=萧枫".
8. Input fingerprints in clip.json: only redo shots whose card/scene/prop/prompt hash changed; concat rejects stale versions.
9. Continuity checklist: injuries, location, alive, prop damage in continuity.ts.
Skip: platform layer, multi-shot grid generation, narration mode.
Record in PROGRESS.md what you did / skipped and why.

## 2026-11-03 00:30 ET aid-studio borrow list - status
- DONE #1 source-coverage gate: shot.source (schema), gates.ts sourceCoverage(); gate "coverage" (error: every quoted chapter line verbatim in some
  shot dialogue) + "sourceSpan" (warning: all shots have source, >=90% chapter covered, gaps listed). Planner rule 12 + JSON field; single-episode
  repair loop gets chapter=brief.story (missing lines fed back via gateFeedback); merged multi-episode = warning. Not applied to the running fx4 board
  (storyboard already fixed; chapter text unchanged).
- DONE #9 continuity checklist: continuity.injuries[] + continuity.props[{name,state}] (schema, prompt lines zh/en, annotate instructions, apply);
  continuityProblems: injury may not vanish within episode; prop state change requires a cause word in action. Location = segment sceneId (existing).
- PARTIAL #5 prop states: covered by continuity.props state + cause rule and the van product-photo reference; per-state product photos not generated
  (only one van state in ch1 - not worth it).
- PARTIAL #2 fixed voice: no TTS dubbing (would replace lip-synced model audio; no fixed-voiceId TTS available offline for zh with acceptable quality).
  Instead: CAM++ similarity check + Demucs/Seed-VC unification toward the character's most typical shot, new clip file, original never overwritten.
- PARTIAL #7: worker add_vehicle_ref drops refs by rule and the translation step maps refs by label each try (cached prompt cleared after ref change);
  explicit legend renumbering in Toonflow references.ts not done.
- SKIPPED #3 scene 4-view, #6 sheet re-layout, #4 redo continuity protocol, #8 input fingerprints: would require regenerating scene/character anchors or
  re-architecting clipBin mid-run; risk to already-accepted shots > benefit for this chapter. Recorded as future work.
- Tests: new test/autoflow/aidstudio.test.ts 5 pass; full suite 142 pass / 0 fail. THIRD_PARTY_NOTICES.md: aid-studio MIT notice added.

## 2026-11-03 00:30 ET INTERIM deliverable built (run still in progress: 1/17 v4 shots done)
- /workspace/fengliu_ch1_v4_master.mp4 (1080x1920 24fps, loudnorm out -16.2 LUFS, TP -1.5): fx4 E01-01-01 + voice-unified v3 E01-01-03/E01-01-04/E01-02-03
  + v3 clips for the rest (read only from fx3). /workspace/fengliu_ch1_v4.mp4 phone copy 13.4 MB (v3 spec). Contact: export/contact_v4.jpg.
- unify.py bug fixed: fx3 clips carry an mjpeg cover stream -> map 0:v:0.
- To refresh when the run finishes: overrides = fx4 done shots (+ unify outputs) -> scripts/fx4_master.ts -> phone copy command (see report).
- refresh: /workspace/fx4/refresh_v4.sh (after: voice_sim on fx4 -> voice/unify.py ... voice/unify_v4)
- 00:43 ET check: running keyframes done 1 / 17 {'E01-02-01': 'keyframe'}
- 00:44 ET FIX: keyframe QA had no shot continuity -> false '尸体' failures (E01-01-02 allows fallen guards). worker now maps keyframe job->shot via firstFrame (shot_for_image) and passes full shot info; backup auto_worker.pre_imgcont.py; worker restarted.
- 11-03 00:54 ET check: running keyframes done 1 / 17 {'E01-02-01': 'keyframe'}

## [from parent 1:00 AM] AFTER v4 finishes (do NOT change the running storyboard): v5 directing rules (user approved), source /workspace/selin_article.md
Add to planner rules + gates: (1) first shot of each scene establishes who/where/facing; (2) after a line of dialogue add a reaction/eye-contact shot; (3) shot/reverse-shot keeps all camera positions on one side of the character axis (180 rule); (4) every shot states each character's eyeline direction, adjacent shots must match; (5) delayed reveal (feet/back/vehicle before face) for mystery arrivals; (6) per-character clothing/detail comparison across shots (e.g. shoe laces).
- 11-03 01:04 ET check: running keyframes done 2 / 17 {}
- 11-03 01:14 ET check: running keyframes done 2 / 17 {'E01-02-02': 'keyframe'}
- 11-03 01:24 ET check: running keyframes done 2 / 17 {'E01-01-02': 'keyframe', 'E01-02-02': 'keyframe'}
2026-11-03 1:48 AM ET: user (t306u/t307u) stopped v4 video generation; autoflow and auto_worker killed. Fix QA over-strictness and consistency root cause first (no new generation), then restart v4.
- 11-03 01:47 ET STOPPED by user (autoflow+worker killed). Do not restart. Task now: calibrate QA hand rule, clean false-fail sources, root-cause analysis.

## QA calibration + root cause — status note (resumed after interruption; generation STOPPED, no daemons restarted)
Done so far (no video/first-frame generation; QA model calls on existing v3/v4 material only):
- qa2.py edited (backup: qa2.pre_calib.py). Changes:
  1. Hand check is now 2-stage (QA_HAND_RULE=strip default; QA_HAND_RULE=any = old rule). Stage 1 = old per-crop count (candidates);
     stage 2 = same hand box in 3 consecutive 0.5 s frames, conservative prompt, QA_HAND_CONFIRM_MODELS (default grok-4.7). Rows now carry box+det conf.
  2. Open-ended "unexpected" list REMOVED; replaced by SCENE_CHECKS (chandelier / police livery on van / garbled text / stray person /
     odd hair colour / three in front row), each only when its trigger matches the scene/shot text; extendable via QA_SCENE_CHECKS.
     Old list produced 621 'scene' issues over 37 reports (hair restated, "X missing", pistol descriptions...).
  3. Empty/unparseable replies (Kimi 6/203) = abstention: one retry only (QA_TRIES=2, no outer loop), not cached, listed in report['abstained'].
  4. aggregate(): trait needs >=2 models (+>=2 frames in video); scene/cast need >=2 frames or >=2 models; trait keys grouped across
     "(左:..右:..)" variants. Reason: grok-4.7 says 萧枫 wears gloves on BOTH hands in ~every frame even where the left hand is visibly bare
     (v3 E01-01-04 t0.5, checked by eye).
  5. cast check: a character named in the shot's own text (firstFrame/action/lastFrame) is not a stray.
- Eval data: eval/label/rows.json (639 v3 crops + box/conf), visual labels (23 not-hand crops, 6 claw-fist defect crops E01-01-02),
  eval/strip_verify.py + strip_cache.json (grok-4.7, gemma, Kimi on 208 strips), eval/strip_eval.py -> strip_eval.json.
- Running/finished: qa2/v3calib (v3 videos, new frame prompt), qa2/ff_v3 (v3 first frames 首帧.jpg) — mixed code versions, will re-run with final code.
- Killed orphan QA processes left from the stopped worker (pid 1302804; 1304727 had already exited) — QA only, no generation.

### Hand-rule calibration numbers (v3, 17 shots, 639 crops; positives = 4 human six-finger shots + 1 claw-fist shot E01-01-02 found by eye; 12 negative shots)
| rule | crops flagged | not-hand crops among them | shot recall (any time) | recall at reported time (±1.5 s) | false-fail shots |
|---|---|---|---|---|---|
| OLD: 1 crop, 1 model (any of grok-4.7/gemma) | 144 | 23 | 5/5 | 4/5 | 12/12 (100%) |
| both models agree on a crop | – | – | 1/5 | 0/5 | 3/12 |
| det conf>=0.45 | – | – | 5/5 | 4/5 | 11/12 |
| same hand flagged >=2 consecutive frames | – | – | 2/5 | 2/5 | 7/12 |
| NEW stage1 + grok-4.7 3-frame strip confirm | 10 | 1 | 3/5 | 2/5 | 5/12 (42%) |
| stage1 + gemma strip confirm | 0 | 0 | 0/5 | 0/5 | 0/12 |
| stage1 + Kimi-K3 strip confirm (run on the 12 grok-confirmed + 57 window crops) | 0 | 0 | 0/5 | 0/5 | 0/12 |
Honest finding: at the human-reported six-finger moments almost every crop is judged "ok" by every model in both stages
(e.g. E01-01-04 t2.75–5.25 all ok; E01-02-02 all ok). The old rule's "4/4 hand recall" came from flags on OTHER hands at other times
in the same shot (every shot gets flags, so every bad shot "passes recall"). Crop-level VLM finger counting does not see these defects.
Visual check of the 12 grok-strip "defect" crops: ~4 plausible (E01-03-03 t0.75 merged fingers on chest = the 1:11 defect; E01-03-05 t3.75
hand on head = the 1:23 defect; E01-01-02 t4.25/6.25 claw hand), ~8 normal fists/grips.

- 07:42 UTC: auto_worker.py root-cause prompt fixes added (backup auto_worker.pre_calib.py; NOT run, generation stopped): glove_rule (viewpoint-proof one-glove wording), bare-hands for other chars, hands_block (per-shot hand contents from storyboard continuity; says 老五's reference pistol is NOT held when hands 空), SCENE_TERMS (吊灯 = one industrial pendant lamp; van never police livery when 警灯 in prompt). NO_RC_FIXES=1 disables. Chapter text untouched.
- bun test (toonflow-app/apps/server): 142 pass / 0 fail.
- Baseline (old qa2, qa2/v3 + qa2/v3veh) via new eval/recall2.py: recall 11/16; shots failing 17/17; the 5 clean shots (no known defect) failing 5/5; 687 issues of which 646 match no known defect.
- More false-fail sources fixed in qa2.py: stray_person ignored when the shot's OWN text already puts unnamed people in frame (劫匪/黑影/人影…) and only counted when the same model also lists an unidentified living person; front_row_count only in car shots (it fired in the factory); a character placed by the segment 站位 but missing from the shot's list → warning '（分段站位里有此人，分镜名单没有）' instead of fail (real strays not in 站位 still fail). Checked by eye: v3 E01-03-01 / E01-02-03 do show extra cast following the 站位; E01-03-04/05 background figures are the 黑影/劫匪 the action describes.
