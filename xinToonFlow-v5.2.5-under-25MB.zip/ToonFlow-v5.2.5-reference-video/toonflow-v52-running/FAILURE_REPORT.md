# v5 FAILURE REPORT (fail-fast stop)
Generated automatically by monitor.py at 2026-11-03 22:28:07 ET (America/New_York). Production cancelled; no auto-redo.

- **Shot:** E01-04-09
- **Check:** run failed
- **Trigger line:** `[2026-11-04 03:27:59] 失败：模型输出多次校验失败：【台词装得进镜头时长】E01-04-09 台词约需 17.2 秒，镜头只有 15 秒 | error=模型输出多次校验失败：【台词装得进镜头时长】E01-04-09 台词约需 17.2 秒，镜头只有 15 秒`
- **Run stage/status at stop:** storyboard / failed
- **Killed:** ['worker:1657472', 'relay:1657399']
- **Toonflow-logged spend so far:** $0.000 (aiand H3 video + text; xAI images not $-logged; xAI image outputs in v5 relay: 0 incl. 1 earlier connectivity image)
- **Models:** text=nebius/deepseek-ai/DeepSeek-V4-Pro-0813; image=grokRelay/grok-imagine-image; video=aiand/minimaxai/minimax-h3; scorer=nebius/nvidia/Nemotron-3.5-Super-VL; worker/relay submodels should be read from worker config and are not inferred here.


## Recent run log
```
[2026-11-04 03:16:28] 原文保护模式：章节原文逐字保留，跳过编剧改写阶段
[2026-11-04 03:17:15] 角色 6 个，场景 4 个
[2026-11-04 03:21:00] 校验未通过，第 1 次：episodes.0.segments.0.shots.0.spatialContract.beat：Invalid option: expected one of "establishing"|"action"|"reaction"|"reveal"|"insert"|"transition"；episodes.0.segments.0.shots.2.spatialContract.beat：Invalid option: expected one of "establishing"|"action"|"reaction"|"reveal"|"insert"|"transition"；episodes.0.segments.0.shots.3.spatialContract.beat：Invalid option: expected one of "establishing"|"action"|"reaction"|"reveal"|"insert"|"transition"
[2026-11-04 03:23:28] 原文账本自动补齐 0 个原文片段、2 条引号（原文由程序恢复）
[2026-11-04 03:23:28] 有 1 条对白的说话人无法从上下文确定，暂标为旁白，请在分镜确认时核对
[2026-11-04 03:23:28] 校验未通过，第 2 次：【每镜出场角色均有定义、角色卡与造型】E01-02-02 的角色 unused-primary 未在 characters 中定义
【台词装得进镜头时长】E01-04-09 台词约需 17.2 秒，镜头只有 15 秒
【单集剧情连续性：死者不复活、持物不无故换手】E01-04-05 中已死亡的 laoda 出场但未写明是尸体；E01-04-07 中已死亡的 laoer 出场但未写明是尸体；E01-04-10 中已死亡的 laowu 出场但未写明是尸体
【镜头视角、主体视点与轴线合同有效】E01-02-02 空间合同角色 xiaofeng 不在本镜角色清单中
[2026-11-04 03:25:47] 原文账本自动补齐 0 个原文片段、2 条引号（原文由程序恢复）
[2026-11-04 03:25:47] 有 1 条对白的说话人无法从上下文确定，暂标为旁白，请在分镜确认时核对
[2026-11-04 03:25:47] 校验未通过，第 3 次：【台词装得进镜头时长】E01-04-09 台词约需 17.2 秒，镜头只有 15 秒
[2026-11-04 03:27:59] 原文账本自动补齐 0 个原文片段、2 条引号（原文由程序恢复）
[2026-11-04 03:27:59] 有 1 条对白的说话人无法从上下文确定，暂标为旁白，请在分镜确认时核对
[2026-11-04 03:27:59] 校验未通过，第 4 次：【台词装得进镜头时长】E01-04-09 台词约需 17.2 秒，镜头只有 15 秒
[2026-11-04 03:27:59] 失败：模型输出多次校验失败：【台词装得进镜头时长】E01-04-09 台词约需 17.2 秒，镜头只有 15 秒
```

## Cause guess / what to change
_(to be filled in by the agent after inspecting the evidence)_
## 原因分析（部署代理补充，2026-11-03 22:35 ET）
- 失败阶段：分镜（storyboard），4 次尝试（1 次初始 + 3 次修复）全部未过门；未出图、未出视频，媒体费用为 0。
- 第 1 次：`spatialContract.beat` 枚举不合法（模型给出 dialogue/establish/tension/explosion 等）。v5.1 的枚举规范化只覆盖了 size/camera/POV，**没有覆盖 spatialContract.beat**。
- 第 2 次：beat 问题已自修复，剩余：未定义角色 `unused-primary`、死者未标注尸体（laoda/laoer/laowu）、E01-04-09 台词超时。
- 第 3、4 次：只剩一项，且两次完全相同：**E01-04-09 一镜被分配了 Q0022+Q0023 两段萧枫对白（模型写 seconds=19），对白需约 17.2 秒，超过 maxShotSeconds=15**。v5.1 的"时长保护"只上调整集目标时长、按 50 字切长对白，但不会把超过单镜上限的多条引号拆到相邻镜头；修复提示也没能让模型自己拆镜，所以重试是重复同一错误。
- 另：有 1 条对白说话人无法确定，被标为旁白（narrator）。

## 建议（未自动执行）
1. 程序侧：quoteAssignments 回填后，若单镜对白估时 > maxShotSeconds，按 Q 边界自动拆成连续的子镜头（复制角色/场景/合同，id 递增），而不是靠模型修复。
2. 修复提示词中对 dialogueFit 错误明确写出"把 Q0022 与 Q0023 分到两个相邻镜头"。
3. 把 spatialContract.beat 也加入别名规范化（dialogue→action、establish→establishing、tension/threat→reaction、explosion→action 等）。
4. 修复后可先用 `stopAfter: "storyboard"` 低成本复跑确认通过门，再整章生产。
