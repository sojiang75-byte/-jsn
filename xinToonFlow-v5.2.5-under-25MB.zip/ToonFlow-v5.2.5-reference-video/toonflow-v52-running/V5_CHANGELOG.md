# ToonFlow v5 完整测试版变更记录

## 版本定位

从 v4 独立复制后升级，未覆盖原始 v4。目标是一次完整的长篇动漫/短剧端到端测试。

## 新增/改造模块

- `autoflow/v5Continuity.ts`：Project Bible、跨集记忆、道具状态机、输入指纹与文件 SHA256。
- `autoflow/qaContract.ts`：统一 QA 结果和失败路由。
- `storyboard/schema.ts`：镜头视角合同、额外人物策略、空间合同、对白语言、场景基线、道具状态机、Bible。
- `storyboard/gates.ts`：视角主体校验、跨集死亡/伤情/服装/道具连续性、道具合法状态转换。
- `storyboard/prompts.ts` / `promptStyles/h3.ts`：将视角、轴线、站位、视线、场景布局、灯光、角色临时状态、对白语言和声音设定写入生成提示词。
- `planner.ts`：分集规划时注入前集记忆；新生成分镜自动补齐 v5 导演合同。
- `pipeline.ts`：保存 Bible 与跨集记忆；采集输入/参考图指纹；最终装配时阻止过期 clip；QA abstain/fail 不自动通过。
- `clipBin.ts`：归档完整输入指纹。
- `worker/qa_contract.py`、`worker/repair_router.py`：统一 pass/fail/abstain 和 failure-code 路由；弃权/音轨错误不盲目重绘视频；自动视觉修复最多两次。
- `worker/evaluate_qa_calibration.py`：使用人工标注集计算 precision/recall/false reject/false accept/abstain，不擅自改阈值。
- `worker/voice/voice_sim.py`、`worker/voice/unify.py`：改为读取项目角色表，支持跨镜声纹检查和异常音色统一。

## 验证记录

- Python：`py_compile` 检查通过。
- Python 单测：10 项通过（统一 QA 7 项、修复路由 3 项）。
- TypeScript：所有本次修改文件通过 TypeScript transpile 语法诊断。
- 完整 Bun 测试和 TypeScript 类型检查：本打包环境没有安装 Bun、workspace node_modules 与 `@types/bun`，无法执行；需要在用户本地 Bun 环境运行 README 中命令。不得将语法转译检查等同于完整类型检查。


## v5.1 — 2026-11-03：原文保护与分镜失败修复

- 原文只读模式默认开启，编剧阶段不再改写用户章节。
- 新增 SHA-256 Source Ledger、SRC/Q ID 引用、台词/音效程序回填和严格顺序/完整性检查；支持角色名冒号式对白、长对白跨镜分段和多集连续切分。
- 修复运镜/景别枚举提示词与常见非法输出规范化；POV 统一归入镜头视角合同。
- 增加死亡状态自动继承、真实模型配置快照、每次分镜原始输出归档。
- 对长输出 `finish_reason=length` 增加 token 扩容重试；长对白不再通过删改原文满足固定时长。
- 自动恢复探测脚本改为读取 `config.json` 中当前文本模型，不再错误探测已停用的 Kimi-K3。
- Bun 全量测试与真实模型端到端测试尚待运行环境验证。


## v5.2（2026-11-04）
- 原文 SRC/Q 回填后新增程序级超时对白拆镜：按完整 Q/group 边界把超时独立对白拆到相邻镜头，拆后重新校验 SRC/Q 唯一归属与顺序。
- `spatialContract.beat` 纳入枚举别名规范化，覆盖 dialogue/tension/threat/establish/explosion 等常见输出。
- 分镜提示词和时长失败反馈明确要求将超时独立对白按 Q ID 分配到相邻镜头。
- 新增 Q 边界自动拆镜、原文回填和 beat 别名回归测试。
- 新增只跑分镜的安全启动配置；不启动 relay/worker，不配置图片或视频模型；成功 stopAfter 以正常退出码结束。旧 v5.1 STOP_TRIGGER 归档，旧整章续跑入口在本阶段阻止误启动。
- 新增基于真实 attempt_04 / source ledger 的离线回归报告。


## v5.2.2 — Death-clause boundary + beat alias
- Prevent corpse/death evidence from crossing semicolon and sentence boundaries between characters.
- Normalize `activity` / `活动` beat aliases to `action`.
- Add regression tests for the reported Laoer/LaoWu clause and activity beat.
- Keep unresolved dialogue speakers marked as narrator for human review.


## v5.2.5（视频接不上的修复）
- 续接上下文接进视频请求：参考图模式带场景图、道具图和上一镜结尾 3 帧；首帧模式在供应商允许时带结尾帧（ai& 不允许，仍只发首帧）。
- 接力镜头缺省按首帧模式提交（`chainedVideoInput`），首帧 = 上一镜尾帧；拼接时 `trimHeadFrames = 1` 去掉重复帧。
- 手指质检只记警告、不断链（`continuation.handsGate`，缺省 warn）。
- 同场景跨段接力（`chainAcrossSegments`）。
- 下一镜要接力时，提示词要求结尾停在主角脸上，并写入上一镜结束状态（`endOnSubject`）。
- 正式配置打开续接和接力；新增 60 秒试拍配置与串行接力脚本 `work/preview/v525-60s/`。
- 详见 `README_V5_2_5_FIXES.md`。未运行 Bun 测试与类型检查。
