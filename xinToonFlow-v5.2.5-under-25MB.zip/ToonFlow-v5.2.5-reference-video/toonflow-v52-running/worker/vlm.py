"""Minimal OpenAI-compatible vision calls (xAI + Nebius). Keys read from /tmp/.tfkeys; never printed."""
import base64, io, json, re, time, urllib.request
from PIL import Image
def _keys():
    k = {}
    for line in open('/tmp/.tfkeys'):
        line = line.strip().replace('export ', '')
        if '=' in line: a, b = line.split('=', 1); k[a.strip()] = b.strip().strip('"').strip("'")
    return k
_K = _keys()
ENDPOINTS = {'xai': ('https://api.x.ai/v1/chat/completions', _K.get('XAI_API_KEY')),
             'nebius': ('https://api.tokenfactory.nebius.com/v1/chat/completions', _K.get('NEBIUS_API_KEY'))}
def provider(model): return 'xai' if model.startswith('grok') else 'nebius'
def b64(img, fmt='JPEG', q=92):
    if isinstance(img, str): img = Image.open(img)
    buf = io.BytesIO(); img.convert('RGB').save(buf, fmt, quality=q); return 'data:image/jpeg;base64,' + base64.b64encode(buf.getvalue()).decode()
def ask(model, prompt, images=(), max_tokens=1500, temperature=0.0, tries=4, timeout=240, reasoning_effort=None):
    url, key = ENDPOINTS[provider(model)]
    content = [{'type': 'image_url', 'image_url': {'url': b64(i), **({'detail': 'high'} if provider(model) == 'xai' else {})}} for i in images]
    content.append({'type': 'text', 'text': prompt})
    body = {'model': model, 'messages': [{'role': 'user', 'content': content}], 'max_tokens': max_tokens, 'temperature': temperature}
    if reasoning_effort is None and provider(model) == 'nebius' and 'Kimi' in model: reasoning_effort = 'low'
    if reasoning_effort: body['reasoning_effort'] = reasoning_effort
    last = None
    for t in range(tries):
        try:
            req = urllib.request.Request(url, json.dumps(body).encode(), {'Authorization': 'Bearer ' + key, 'Content-Type': 'application/json'})
            with urllib.request.urlopen(req, timeout=timeout) as r: d = json.load(r)
            txt = d['choices'][0]['message'].get('content') or ''
            if txt.strip(): return txt
            last = RuntimeError('empty content (finish=%s)' % d['choices'][0].get('finish_reason')); body['max_tokens'] = min(16000, int(body['max_tokens'] * 2)); continue
        except Exception as e:
            last = e; msg = str(e)
            if 'HTTP Error 4' in msg and '429' not in msg: break
            time.sleep(3 * (t + 1))
    raise RuntimeError(f'{model}: {str(last)[:200]}')
def parse_json(text):
    text = re.sub(r'<think>.*?</think>', '', text, flags=re.S)
    m = re.search(r'```(?:json)?\s*(\{.*?\}|\[.*?\])\s*```', text, re.S)
    s = m.group(1) if m else None
    if s is None:
        i = min([p for p in (text.find('{'), text.find('[')) if p >= 0], default=-1)
        if i < 0: return None
        s = text[i:]
        for end in range(len(s), 0, -1):
            try: return json.loads(s[:end])
            except Exception: continue
        return None
    try: return json.loads(s)
    except Exception: return None
