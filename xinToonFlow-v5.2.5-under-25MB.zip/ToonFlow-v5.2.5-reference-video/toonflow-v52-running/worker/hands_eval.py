"""Run finger-count prompts of several VLMs over hand crops; cache per (model, crop). usage: hands_eval.py models shotdir...
Cache: /workspace/fx4/eval/hand_cache.json"""
import sys, os, json, threading, concurrent.futures as cf
sys.path.insert(0, '/workspace/fx4'); from vlm import ask, parse_json
CACHE = '/workspace/fx4/eval/hand_cache.json'
P = """Upscaled crop around one detected hand in a frame of an AI-generated anime video. AI video often draws 6 fingers, an extra thumb, fused/melted fingers, or a stray extra hand.
Count carefully for EACH hand in the crop: go digit by digit (thumb, index, middle, ring, little, any extra) counting every visible fingertip/finger segment, even when gripping something or wearing a fingerless glove.
Reply JSON only: {"hands":[{"count":N,"digits":["thumb","index",...],"malformed":true|false}],"verdict":"ok|bad|unclear","why":""}
verdict "bad" if any hand has more than 5 digits, two thumbs, fused or melted fingers, a hand growing from the wrong place, or other anatomical error; "unclear" if too small/blurred to judge."""
lock = threading.Lock()
cache = json.load(open(CACHE)) if os.path.exists(CACHE) else {}
def save():
    with lock:
        tmp = CACHE + '.tmp'; json.dump(cache, open(tmp, 'w')); os.replace(tmp, CACHE)
def one(model, crop):
    key = f'{model}|{crop}'
    if key in cache: return
    try:
        raw = ask(model, P, [crop], max_tokens=4000 if 'grok' not in model else 1500)
        res = parse_json(raw) or {'raw': raw[:300]}
    except Exception as e: res = {'error': str(e)[:200]}
    with lock: cache[key] = res
def verdict(res):
    if not isinstance(res, dict) or 'error' in res or 'raw' in res: return None
    hands = res.get('hands') or []
    try:
        if any(int(h.get('count', 0)) > 5 for h in hands if isinstance(h, dict)): return 'bad'
    except Exception: pass
    if any(isinstance(h, dict) and h.get('malformed') is True for h in hands): return 'bad'
    return res.get('verdict') if res.get('verdict') in ('ok', 'bad', 'unclear') else None
if __name__ == '__main__':
    models = sys.argv[1].split(','); crops = []
    for d in sys.argv[2:]: crops += [r['crop'] for r in json.load(open(d + '/hands.json'))]
    jobs = [(m, c) for m in models for c in crops if f'{m}|{c}' not in cache]
    print(len(jobs), 'calls', flush=True)
    with cf.ThreadPoolExecutor(int(os.environ.get('CONC', '12'))) as ex:
        for n, _ in enumerate(ex.map(lambda mc: one(*mc), jobs)):
            if n % 25 == 0: save(); print(n, flush=True)
    save(); print('DONE')
