"""Voice unification for outlier shots (laozhang §7): Demucs vocals/no_vocals split -> Seed-VC (CPU) toward the character's most
typical shot -> remix with no_vocals -> new clip (video stream copied). Only single-speaker outlier shots; accepted only if CAM++
similarity to the reference rises and the Whisper text match does not drop. Never touches the run's own files.
Usage: unify.py RUN_DIR VOICE_JSON OUT_DIR [--all-below X]"""
import json, os, re, subprocess, sys, difflib, numpy as np, soundfile as sf, scipy.signal as ss, sherpa_onnx
from math import gcd
from faster_whisper import WhisperModel
RUN, VJ, OUT = sys.argv[1:4]; H = os.path.dirname(os.path.abspath(__file__)); os.makedirs(OUT, exist_ok=True)
BELOW = float(sys.argv[sys.argv.index("--all-below") + 1]) if "--all-below" in sys.argv else None
NAMES = {c.get("id"): c.get("name", c.get("id")) for c in json.load(open(f"{RUN}/storyboard.json")).get("characters", []) if c.get("id")}
NAMES.update({"xiaofeng": "萧枫", "laowu": "老五", "laoda": "老大"})
ext = sherpa_onnx.SpeakerEmbeddingExtractor(sherpa_onnx.SpeakerEmbeddingExtractorConfig(model=f"{H}/campplus_zh.onnx", num_threads=4))
wm = WhisperModel("small", device="cpu", compute_type="int8")
sb = json.load(open(f"{RUN}/storyboard.json")); runj = json.load(open(f"{RUN}/run.json")); root = os.path.dirname(os.path.dirname(RUN))
vj = json.load(open(VJ)); shots = {sh["id"]: sh for ep in sb["episodes"] for sg in ep["segments"] for sh in sg["shots"]}
def clip(sid):
    v = runj["shots"][sid]["video"]; return v if os.path.isabs(v) else os.path.join(root, v)
def run(*a): subprocess.run(a, check=True, capture_output=True)
def load16(p):
    x, sr = sf.read(p, dtype="float32"); x = x.mean(1) if x.ndim > 1 else x; g = gcd(sr, 16000)
    return ss.resample_poly(x, 16000 // g, sr // g).astype("float32")
def emb(x):
    s = ext.create_stream(); s.accept_waveform(16000, x); s.input_finished(); e = np.array(ext.compute(s)); return e / np.linalg.norm(e)
def texts(p):
    x = load16(p); return ["".join(s.text for s in wm.transcribe(x, language="zh", vad_filter=v, beam_size=5, initial_prompt="以下是普通话的句子。")[0]) for v in (True, False)]
import opencc; _cc = opencc.OpenCC("t2s")
norm = lambda t: re.sub(r"\W", "", _cc.convert(t))
def ratio(heard, sid): return difflib.SequenceMatcher(None, norm(heard), norm("".join(d["text"] for d in shots[sid]["dialogue"]))).ratio()
def split(sid):
    d = f"{OUT}/sep/htdemucs/{sid}"
    if not os.path.exists(f"{d}/vocals.wav"):
        w = f"{OUT}/{sid}.wav"; run("ffmpeg", "-v", "error", "-y", "-i", clip(sid), "-ac", "2", "-ar", "44100", w)
        run(f"{H}/../venv/bin/python", "-m", "demucs", "--two-stems", "vocals", "-n", "htdemucs", "-o", f"{OUT}/sep", w)
    return f"{d}/vocals.wav", f"{d}/no_vocals.wav"
report = []
for name, c in vj["characters"].items():
    items = [i for i in c["shots"] if i["sim_to_others"] is not None]
    if len(items) < 3: report.append({"character": name, "skipped": "fewer than 3 shots: cannot tell which voice is the outlier"}); continue
    ref = max(items, key=lambda i: i["sim_to_others"])["shot"]
    for it in items:
        bad = it["outlier"] or (BELOW is not None and it["sim_to_others"] < BELOW)
        if not bad or it["shot"] == ref: continue
        sid = it["shot"]; spk = {NAMES.get(d["speaker"], d["speaker"]) for d in shots[sid]["dialogue"]}
        r = {"character": name, "shot": sid, "ref": ref, "sim_to_others": it["sim_to_others"]}
        if spk != {name}: r["skipped"] = f"multi-speaker shot {sorted(spk)}: whole-stem conversion would change the other voice"; report.append(r); continue
        sv, snv = split(sid); rv, _ = split(ref)
        vcdir = f"{OUT}/vc_{sid}"; os.makedirs(vcdir, exist_ok=True)
        if not any(f.endswith(".wav") for f in os.listdir(vcdir)): run(f"{H}/svenv/bin/python", f"{H}/seed-vc/inference.py", "--source", sv, "--target", rv, "--output", vcdir, "--diffusion-steps", "25", "--fp16", "False")
        conv = [f for f in os.listdir(vcdir) if f.endswith(".wav")][0]
        y, ysr = sf.read(f"{vcdir}/{conv}", dtype="float32"); nv, nsr = sf.read(snv, dtype="float32")
        g = gcd(ysr, nsr); y = ss.resample_poly(y, nsr // g, ysr // g).astype("float32"); y = np.pad(y, (0, max(0, len(nv) - len(y))))[:len(nv)]
        mix = nv + y[:, None]; pk = np.abs(mix).max(); mix = mix / pk * 0.89 if pk > 0.89 else mix
        mw = f"{OUT}/{sid}_mix.wav"; sf.write(mw, mix, nsr)
        e_ref = emb(load16(rv)); before = float(emb(load16(sv)) @ e_ref); after = float(emb(load16(f"{vcdir}/{conv}")) @ e_ref)
        tb = max(texts(f"{OUT}/{sid}.wav"), key=lambda t: ratio(t, sid)); ta = max(texts(mw), key=lambda t: ratio(t, sid)); rb, ra = ratio(tb, sid), ratio(ta, sid)
        r.update(sim_before=round(before, 3), sim_after=round(after, 3), text_before=tb, text_after=ta, match_before=round(rb, 2), match_after=round(ra, 2))
        r["accepted"] = after > before + 0.03 and ra >= rb - 0.05
        if r["accepted"]:
            outv = f"{OUT}/{sid}.mp4"
            run("ffmpeg", "-v", "error", "-y", "-i", clip(sid), "-i", mw, "-map", "0:v:0", "-map", "1:a", "-c:v", "copy", "-c:a", "aac", "-b:a", "192k", "-shortest", outv)
            r["clip"] = outv
        report.append(r); print(json.dumps(r, ensure_ascii=False), flush=True)
json.dump(report, open(f"{OUT}/unify.json", "w"), ensure_ascii=False, indent=1)
