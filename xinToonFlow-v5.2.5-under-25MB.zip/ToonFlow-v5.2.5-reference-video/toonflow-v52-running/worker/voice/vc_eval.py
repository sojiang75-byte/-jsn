import sys, numpy as np, soundfile as sf, sherpa_onnx, scipy.signal as ss
from faster_whisper import WhisperModel
H="/workspace/fx4/voice"
ex=sherpa_onnx.SpeakerEmbeddingExtractor(sherpa_onnx.SpeakerEmbeddingExtractorConfig(model=f"{H}/campplus_zh.onnx",num_threads=4))
def load(p):
    x,sr=sf.read(p,dtype="float32"); x=x.mean(1) if x.ndim>1 else x
    from math import gcd; g=gcd(sr,16000); return ss.resample_poly(x,16000//g,sr//g).astype("float32")
def emb(x):
    s=ex.create_stream(); s.accept_waveform(16000,x); s.input_finished(); e=np.array(ex.compute(s)); return e/np.linalg.norm(e)
src,tgt,out=[load(p) for p in sys.argv[1:4]]
es,et,eo=emb(src),emb(tgt),emb(out)
print("sim src-tgt %.3f  out-tgt %.3f  out-src %.3f"%(es@et,eo@et,eo@es))
m=WhisperModel("small",device="cpu",compute_type="int8")
for n,x in (("src",src),("out",out)):
    print(n,"".join(s.text for s in m.transcribe(x,language="zh")[0]))
