"""Speaker-similarity check across shots (laozhang §7): CAM++ (3D-Speaker campplus zh-cn, sherpa-onnx) embeddings of each
character's speech per shot; Whisper (faster-whisper) gives speech segments and maps them to the storyboard lines.
Optional Demucs vocal stem (--demucs) before embedding. Usage: voice_sim.py RUN_DIR OUT.json [--demucs]"""
import json, os, re, subprocess, sys, tempfile, difflib
import numpy as np, soundfile as sf, sherpa_onnx
from faster_whisper import WhisperModel
RUN, OUTP = sys.argv[1], sys.argv[2]; DEMUCS = "--demucs" in sys.argv
HERE = os.path.dirname(os.path.abspath(__file__))
NAMES = {c.get("id"): c.get("name", c.get("id")) for c in json.load(open(f"{RUN}/storyboard.json")).get("characters", []) if c.get("id")}
NAMES.update({"xiaofeng": "萧枫", "laowu": "老五", "laoda": "老大"})
cfg = sherpa_onnx.SpeakerEmbeddingExtractorConfig(model=f"{HERE}/campplus_zh.onnx", num_threads=4)
ext = sherpa_onnx.SpeakerEmbeddingExtractor(cfg)
wm = WhisperModel("small", device="cpu", compute_type="int8")
sb = json.load(open(f"{RUN}/storyboard.json")); runj = json.load(open(f"{RUN}/run.json"))
root = os.path.dirname(os.path.dirname(RUN))

def wav16(src, dst):
    subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", src, "-ac", "1", "-ar", "16000", dst], check=True)

def vocals(wav, tmp):
    if not DEMUCS: return wav
    subprocess.run([f"{HERE}/../venv/bin/python", "-m", "demucs", "--two-stems", "vocals", "-n", "htdemucs", "-o", tmp, wav], check=True, capture_output=True)
    v = f"{tmp}/htdemucs/{os.path.splitext(os.path.basename(wav))[0]}/vocals.wav"
    out = f"{tmp}/voc16.wav"; wav16(v, out); return out

def embed(samples):
    s = ext.create_stream(); s.accept_waveform(16000, samples); s.input_finished()
    e = np.array(ext.compute(s)); return e / (np.linalg.norm(e) + 1e-9)

def sim(a, b): return float(np.dot(a, b))
rows = []
for ep in sb["episodes"]:
    for sg in ep["segments"]:
        for sh in sg["shots"]:
            dl = sh.get("dialogue") or []
            if not dl: continue
            vid = (runj["shots"].get(sh["id"]) or {}).get("video")
            if not vid: continue
            src = os.path.join(root, vid) if not os.path.isabs(vid) else vid
            with tempfile.TemporaryDirectory() as tmp:
                w = f"{tmp}/a.wav"; wav16(src, w); w2 = vocals(w, tmp)
                audio, sr = sf.read(w2, dtype="float32")
                mix, _ = sf.read(w, dtype="float32")
                segs, _ = wm.transcribe(mix, language="zh", vad_filter=True, word_timestamps=True)
                segs = list(segs)
            # assign each word (multi-speaker shots) / segment to the storyboard line it belongs to
            per = {}
            norm = lambda t: re.sub(r"\W", "", t)
            for sgm in segs:
                units = [(w.start, w.end, w.word) for w in (sgm.words or [])] if len(dl) > 1 else [(sgm.start, sgm.end, sgm.text)]
                for st, en, tx in units:
                    best = max(dl, key=lambda d: (sum(ch in d["text"] for ch in norm(tx)) / max(1, len(norm(tx))), difflib.SequenceMatcher(None, norm(tx), norm(d["text"])).ratio()))
                    per.setdefault(best["speaker"], []).append(audio[int(st * 16000):int(en * 16000)])
            segs = [(x.start, x.end, x.text) for x in segs]
            for spk, chunks in per.items():
                x = np.concatenate(chunks) if chunks else np.zeros(0, np.float32)
                if len(x) < 16000 * 0.6: continue
                rows.append({"shot": sh["id"], "speaker": NAMES.get(spk, spk), "seconds": round(len(x) / 16000, 2), "emb": embed(x).tolist(),
                             "heard": "".join(t for _, _, t in segs)})
# per character: similarity of each shot to the leave-one-out centroid, pairwise matrix
res = {"model": "3D-Speaker CAM++ zh-cn 16k (sherpa-onnx)", "demucs": DEMUCS, "characters": {}}
for name in sorted({r["speaker"] for r in rows}):
    rs = [r for r in rows if r["speaker"] == name]; E = np.array([r["emb"] for r in rs])
    pair = [[round(sim(a, b), 3) for b in E] for a in E]
    items = []
    for i, r in enumerate(rs):
        others = np.delete(E, i, axis=0)
        loo = round(sim(E[i], others.mean(0) / (np.linalg.norm(others.mean(0)) + 1e-9)), 3) if len(others) else None
        items.append({"shot": r["shot"], "seconds": r["seconds"], "sim_to_others": loo, "heard": r["heard"]})
    vals = [it["sim_to_others"] for it in items if it["sim_to_others"] is not None]
    med = float(np.median(vals)) if vals else None
    for it in items:
        it["outlier"] = bool(it["sim_to_others"] is not None and (it["sim_to_others"] < 0.45 or (med is not None and it["sim_to_others"] < med - 0.2)))
    offd = [pair[i][j] for i in range(len(rs)) for j in range(len(rs)) if i < j]
    res["characters"][name] = {"shots": items, "pairwise": pair, "pairwise_range": [min(offd), max(offd)] if offd else None, "order": [r["shot"] for r in rs]}
json.dump(res, open(OUTP, "w"), ensure_ascii=False, indent=1)
for n, c in res["characters"].items():
    print(n, "pairwise", c["pairwise_range"], [(i["shot"], i["sim_to_others"], "OUTLIER" if i["outlier"] else "") for i in c["shots"]])
