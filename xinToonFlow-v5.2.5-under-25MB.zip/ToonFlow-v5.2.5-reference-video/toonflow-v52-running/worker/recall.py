"""Shot-level recall of qa2 on the known-bad v3 issues from the parent's review (+ vehicle complaint)."""
import json, re, os
D = '/workspace/fx4/qa2'
known = [  # (label, shot, category regex on issue text, kind)
 ('六指 0:22', 'E01-01-04', r'手指', 'hands'), ('六指 0:34', 'E01-02-02', r'手指', 'hands'),
 ('六指 1:11', 'E01-03-03', r'手指', 'hands'), ('六指 1:23', 'E01-03-05', r'手指', 'hands'),
 ('萧枫纹身 0:27', 'E01-02-01', r'萧枫.*纹身', 'trait'), ('萧枫纹身 0:43-0:49', 'E01-02-04', r'萧枫.*纹身', 'trait'),
 ('手套不一致', 'E01-01-04', r'萧枫手套', 'trait'), ('手套不一致', 'E01-02-01', r'萧枫手套', 'trait'),
 ('老五绿发', 'E01-01-01', r'发色|green|绿', 'trait'),
 ('老大痣缺失', 'E01-03-02', r'老大.*痣', 'trait'),
 ('前排三人', 'E01-02-04', r'前排|third person|three|3 人', 'scene'), ('前排三人', 'E01-02-01', r'前排|third person|three|3 人|老大不应', 'scene'),
 ('持枪手互换 1:36-1:41', 'E01-04-02', r'持枪手', 'continuity'),
 ('吊灯 1:50', 'E01-04-03', r'chandelier|吊灯|lamp', 'scene'),
 ('车辆：皮卡代替面包车', 'E01-01-03', r'车辆', 'vehicle'), ('车辆：警车代替面包车', 'E01-02-01', r'车辆', 'vehicle'),
]
def issues(shot):
    out = []
    for sub in ('v3', 'v3veh'):
        p = f'{D}/{sub}/{shot}.json'
        if os.path.exists(p): out += [i['issue'] for i in json.load(open(p)).get('issues', [])]
    return out
rows = []; hit = 0
for label, shot, rx, kind in known:
    iss = issues(shot); m = [i for i in iss if re.search(rx, i)]
    ok = bool(m); hit += ok
    rows.append({'label': label, 'shot': shot, 'detected': ok, 'evidence': m[:2], 'have_json': bool(iss) or os.path.exists(f'{D}/v3/{shot}.json')})
summary = {'recall': f'{hit}/{len(known)}', 'rows': rows,
           'shots_failing_v3': sorted(os.path.basename(p)[:-5] for p in os.listdir(f'{D}/v3') if p.endswith('.json') and not json.load(open(f'{D}/v3/{p}')).get('pass'))}
json.dump(summary, open(f'{D}/recall_v3.json', 'w'), ensure_ascii=False, indent=1)
print(summary['recall']); [print(('✔' if r['detected'] else '✘'), r['label'], r['shot'], '|', '; '.join(r['evidence'])[:150]) for r in rows]
