#!/usr/bin/env python3
"""QA v2 for AI-generated shots (fx4). Strict, multi-model, dense.
usage: qa2.py <video> <shot_info.json> [--out qa.json] [--prev prev_qa.json]
Prints one JSON line {"pass":bool,"score":float,"issues":[...]} as the LAST stdout line (Toonflow shotQa contract).

Checks
 A hands: frames every 0.5 s -> anime hand detector (deepghs YOLOv8 ONNX) -> upscaled crops -> finger counting by HAND_MODELS
          (stage 1: candidate if ANY model says >5 digits / malformed) -> stage 2 (QA_HAND_RULE=strip, default): the candidate hand in
          3 consecutive frames is re-judged by QA_HAND_CONFIRM_MODELS with a conservative prompt; only confirmed crops count.
          Shot fails if >= HAND_MIN_BAD confirmed crops. QA_HAND_RULE=any = old rule. Calibration: eval/hand_calibration.md.
 B traits: full frames every 1 s -> each TRAIT_MODEL lists every visible person with hair / tattoo per forearm / glove per hand /
          mole / mask / clothing / held object per hand / alive; compared with the character cards (expected traits from cards).
 C continuity & scene: people/body counts vs storyboard continuity, gun hand within shot (no swaps) and vs previous shot,
          expected hands from storyboard continuity, plus SPECIFIC scene/card checks (SCENE_CHECKS: chandelier, police van, stray person, odd hair, front row) — no open-ended list.
Any model failing any check -> fail (strictest)."""
import sys, os, json, re, glob, subprocess, tempfile, argparse, hashlib, threading, concurrent.futures as cf
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))  # v5run: use the v5 worker's own vlm/handdet
from vlm import ask, parse_json
from handdet import detect, crop
from PIL import Image

HAND_MODELS = os.environ.get('QA_HAND_MODELS', 'grok-4.7,google/gemma-3-27b-it').split(',')
TRAIT_MODELS = os.environ.get('QA_TRAIT_MODELS', 'grok-4.7,moonshotai/Kimi-K3').split(',')
HAND_FPS = float(os.environ.get('QA_HAND_FPS', '2'))
TRAIT_STEP = float(os.environ.get('QA_TRAIT_STEP', '1.0'))
HAND_MIN_BAD = int(os.environ.get('QA_HAND_MIN_BAD', '1'))
TRAIT_MIN_FRAMES = int(os.environ.get('QA_TRAIT_MIN_FRAMES', '1'))
CONC = int(os.environ.get('QA_CONC', '10'))
QA_TRIES = int(os.environ.get('QA_TRIES', '2'))
ABSTAINED = []
CALLS = [0]  # v5run: model calls made, to decide abstain by ratio
ABSTAIN_RATIO = float(os.environ.get('QA_ABSTAIN_RATIO', '0.2'))  # v5run: shot = abstain when >= this share of model calls gave no usable answer
CARDS_DIR = os.environ.get('QA_CARDS', '/workspace/fx4/run/角色')
CACHE = os.environ.get('QA_CACHE', '/workspace/fx4/qa_cache.json')
_lock = threading.Lock()
_cache = json.load(open(CACHE)) if os.path.exists(CACHE) else {}

def cached(key, fn):
    with _lock:
        if key in _cache: return _cache[key]
    val = fn()
    with _lock:
        _cache[key] = val
    return val

def save_cache():
    import fcntl
    with _lock, open(CACHE + '.lock', 'w') as lk:
        fcntl.flock(lk, fcntl.LOCK_EX)
        try: disk = json.load(open(CACHE)) if os.path.exists(CACHE) else {}
        except Exception: disk = {}
        disk.update(_cache)
        tmp = CACHE + f'.{os.getpid()}.tmp'; json.dump(disk, open(tmp, 'w')); os.replace(tmp, CACHE)

def fhash(path):
    h = hashlib.sha1()
    with open(path, 'rb') as f: h.update(f.read())
    return h.hexdigest()[:16]

def model_call(model, prompt, images, max_tokens=None):
    key = model + '|' + hashlib.sha1((prompt + '|' + '|'.join(fhash(i) for i in images)).encode()).hexdigest()
    def run():
        try:
            # one retry only (vlm.ask doubles max_tokens on an empty reply); no outer retry loop. An empty / unparseable reply is an
            # ABSTENTION: it is not cached, not counted as pass or fail, and is listed in report['abstained'].
            raw = ask(model, prompt, images, max_tokens=max_tokens or (5000 if 'grok' not in model else 2500), tries=QA_TRIES)
            return parse_json(raw) or {'raw': raw[:400]}
        except Exception as e:
            return {'error': str(e)[:200]}
    res = cached(key, run)
    with _lock: CALLS[0] += 1
    if isinstance(res, dict) and ('error' in res or 'raw' in res):  # do not cache errors / unparseable replies
        with _lock: _cache.pop(key, None); ABSTAINED.append({'model': model, 'image': os.path.basename(images[0]) if images else '', 'why': str(res.get('error') or 'unparseable')[:80]})
    return res

# ---------------- cards ----------------
def load_cards():
    cards = {}
    for f in glob.glob(f'{CARDS_DIR}/*/card.json'):
        c = json.load(open(f)); cards[c['id']] = c
    return cards

def card_text(c):
    inv = c.get('invariant', {}); o = (c.get('outfits') or [{}])[0]
    parts = [f"{c['name']}（{c.get('identity', {}).get('gender', '')}）", f"脸：{inv.get('face', '')}", f"发型：{inv.get('hair', '')}", f"体型：{inv.get('body', '')}"]
    if inv.get('marks'): parts.append(f"标记：{inv['marks']}")
    parts.append(f"服装：{o.get('upper', '')}；{o.get('lower', '')}；{o.get('shoes', '')}；配饰：{o.get('accessories', '')}")
    return '，'.join(p for p in parts if p)

def expected_traits(c):
    """Deterministic expectations from the card text (tattoo / glove side / mole / hair colour words)."""
    inv = c.get('invariant', {}); o = (c.get('outfits') or [{}])[0]
    text = json.dumps(c, ensure_ascii=False)
    exp = {}
    exp['tattoo'] = bool(re.search(r'纹身|刺青|花臂|tattoo', text))
    acc = o.get('accessories', '') + o.get('upper', '')
    if re.search(r'手套|glove', acc):
        both = re.search(r'双手|两只手|both', acc); right = re.search(r'右手', acc); left = re.search(r'左手', acc)
        exp['glove'] = 'both' if both else 'right' if right and not left else 'left' if left and not right else 'any'
    else: exp['glove'] = 'none'
    m = re.search(r'(左|右)(颊|脸颊|脸)[^，。；]*痣', inv.get('face', '') + inv.get('marks', ''))
    exp['mole'] = (m.group(1) + 'cheek') if m else None
    exp['hair'] = inv.get('hair', '')
    return exp

# ---------------- frames ----------------
def probe_duration(video):
    out = subprocess.run(['ffprobe', '-v', 'error', '-show_entries', 'format=duration', '-of', 'csv=p=0', video], capture_output=True, text=True).stdout
    return float(out.strip() or 0)

def sample(video, fps, outdir):
    os.makedirs(outdir, exist_ok=True)
    subprocess.run(['ffmpeg', '-v', 'error', '-y', '-i', video, '-vf', f'fps={fps}', '-q:v', '2', f'{outdir}/f%04d.jpg'], check=True)
    files = sorted(glob.glob(f'{outdir}/f*.jpg'))
    return [((i + 0.5) / fps, f) for i, f in enumerate(files)]

# ---------------- A: hands ----------------
HAND_PROMPT = """Upscaled crop around one detected hand in a frame of an AI-generated anime video. AI video often draws 6 fingers, an extra thumb, fused/melted fingers, or a stray extra hand.
Count carefully for EACH hand in the crop: go digit by digit (thumb, index, middle, ring, little, any extra) counting every visible fingertip/finger segment, even when gripping something or wearing a fingerless glove.
Reply JSON only: {"hands":[{"count":N,"digits":["thumb","index",...],"malformed":true|false}],"verdict":"ok|bad|unclear","why":""}
verdict "bad" if any hand has more than 5 digits, two thumbs, fused or melted fingers, a hand growing from the wrong place, or other anatomical error; "unclear" if too small/blurred to judge."""

def hand_verdict(res):
    if not isinstance(res, dict) or 'error' in res or 'raw' in res: return None
    hands = [h for h in (res.get('hands') or []) if isinstance(h, dict)]
    try:
        if any(int(h.get('count', 0)) > 5 for h in hands): return 'bad'
    except Exception: pass
    if any(h.get('malformed') is True for h in hands): return 'bad'
    return res.get('verdict') if res.get('verdict') in ('ok', 'bad', 'unclear') else None

HAND_RULE = os.environ.get('QA_HAND_RULE', 'strip')          # 'strip' (calibrated 2-stage, default) | 'any' (old: 1 crop, 1 model)
CONFIRM_MODELS = [m for m in os.environ.get('QA_HAND_CONFIRM_MODELS', 'grok-4.7').split(',') if m]
CONFIRM_MIN = int(os.environ.get('QA_HAND_CONFIRM_MIN', '1'))  # how many confirm models must say "defect" (certain)
HAND_CONF_MIN = float(os.environ.get('QA_HAND_CONF_MIN', '0.0'))  # detector confidence floor for stage-1 candidates
STRIP_PROMPT = """{n} of the SAME region of an AI-generated 2D anime video, centred on one detected hand{lr}.
Decide whether this hand has a REAL anatomical defect that a viewer would notice: six or more fingers, two thumbs, an extra hand/arm,
fingers melted or fused into a blob, or a finger growing from the wrong place. Judge the {mid}; {side}
NOT defects: fingers hidden behind an object or the steering wheel, gripping a gun or wheel, fist, foreshortening, fingerless gloves,
motion blur, simplified anime drawing, a finger count you cannot see clearly. If the crop is not a hand at all (face, shoe, jeans,
background), say not_hand.
Count the visible digits of the {mid} hand one by one first.
Reply JSON only: {{"is_hand":true|false,"digits_visible":N,"defect":"none|extra_finger|extra_hand|fused|wrong_place|other","certain":true|false,"verdict":"defect|ok|not_hand|unclear","why":""}}
Use "defect" only when you are certain."""

def strip_verdict(res):
    if not isinstance(res, dict) or 'error' in res or 'raw' in res: return None
    if res.get('is_hand') is False or res.get('verdict') == 'not_hand': return 'not_hand'
    if res.get('verdict') == 'defect': return 'defect' if res.get('certain') is True else 'unclear'
    return res.get('verdict') if res.get('verdict') in ('ok', 'unclear') else None

def make_strip(frames, i, b, out):
    """Same box in frames i-1, i, i+1 (0.5 s apart), 2.2x context, 400 px tiles."""
    x1, y1, x2, y2 = b; cx, cy = (x1 + x2) / 2, (y1 + y2) / 2; s = max(max(x2 - x1, y2 - y1) * 2.2, 140)
    idx = [j for j in (i - 1, i, i + 1) if 0 <= j < len(frames)]
    tiles = []
    for j in idx:
        im = Image.open(frames[j][1]).convert('RGB'); W, H = im.size
        tiles.append(im.crop((max(0, cx - s / 2), max(0, cy - s / 2), min(W, cx + s / 2), min(H, cy + s / 2))).resize((400, 400), Image.LANCZOS))
    o = Image.new('RGB', (406 * len(tiles) - 6, 400), 'white')
    for k, t in enumerate(tiles): o.paste(t, (k * 406, 0))
    o.save(out, quality=92)
    n = len(tiles)
    return out, STRIP_PROMPT.format(n='Three consecutive frames (0.5 s apart, left to right)' if n == 3 else (f'{n} consecutive frames (0.5 s apart, left to right)' if n > 1 else 'One frame'), lr='',
                                    mid='middle frame' if n == 3 else ('frame' if n == 1 else 'frame showing the hand most clearly'),
                                    side='use the side frames to tell a real defect (persists or is clearly visible) from normal things.' if n > 1 else '')

def check_hands(frames, work, pool):
    """Stage 1 (screen, high recall): every detected hand crop, finger count by HAND_MODELS; candidate if ANY model says bad.
    Stage 2 (confirm, HAND_RULE=strip): the candidate hand is shown in 3 consecutive frames (same box, more context) to
    CONFIRM_MODELS with a conservative prompt; the crop is bad only if >= CONFIRM_MIN models answer defect+certain.
    Calibration (eval/hand_calibration.md): stage 1 alone failed 100% of v3 shots (13/13 clean shots), most flags were faces,
    shoes, torn jeans or normal gripping hands."""
    crops = []
    for i, (t, f) in enumerate(frames):
        im = Image.open(f)
        for k, b in enumerate(detect(im, conf=0.3)):
            conf = b[4] if len(b) > 4 else 1.0; b = tuple(b[:4])
            if (b[2] - b[0]) < 14 or (b[3] - b[1]) < 14 or conf < HAND_CONF_MIN: continue
            p = f'{work}/hand_t{t:05.2f}_{k}.jpg'; crop(im, b).save(p, quality=92); crops.append((i, t, p, b, conf))
    futs = {(m, p): pool.submit(model_call, m, HAND_PROMPT, [p]) for m in HAND_MODELS for _, _, p, _, _ in crops}
    bad = []; rows = []; cand = []
    for i, t, p, b, conf in crops:
        verdicts = {m: hand_verdict(futs[(m, p)].result()) for m in HAND_MODELS}
        row = {'t': round(t, 2), 'crop': p, 'box': [round(float(x), 1) for x in b], 'conf': round(float(conf), 3), 'verdicts': verdicts}
        rows.append(row)
        flagged = [m for m, v in verdicts.items() if v == 'bad']
        if flagged: cand.append((i, t, p, b, flagged, row))
    if HAND_RULE == 'any':
        bad = [{'t': round(t, 2), 'crop': p, 'models': fl} for _, t, p, _, fl, _ in cand]
        return {'crops': len(crops), 'candidates': len(cand), 'bad': bad, 'rows': rows, 'rule': 'any'}
    sfuts = {}
    for i, t, p, b, fl, row in cand:
        sp, prompt = make_strip(frames, i, b, p[:-4] + '_strip.jpg')
        for m in CONFIRM_MODELS: sfuts[(m, p)] = pool.submit(model_call, m, prompt, [sp], 1500 if 'grok' in m else 3000)
    suspect = []
    for i, t, p, b, fl, row in cand:
        cv = {m: strip_verdict(sfuts[(m, p)].result()) for m in CONFIRM_MODELS}
        row['confirm'] = cv
        conf_models = [m for m, v in cv.items() if v == 'defect']
        if len(conf_models) >= CONFIRM_MIN:
            bad.append({'t': round(t, 2), 'crop': p, 'models': fl, 'confirmed_by': conf_models})
        elif not any(v == 'not_hand' for v in cv.values()):
            suspect.append({'t': round(t, 2), 'crop': p, 'models': fl})
    return {'crops': len(crops), 'candidates': len(cand), 'bad': bad, 'suspect': suspect, 'rows': rows, 'rule': f'strip(confirm={",".join(CONFIRM_MODELS)}>= {CONFIRM_MIN})'}

# ---------------- B+C: traits, continuity, scene ----------------
FRAME_PROMPT = """You are a strict continuity supervisor checking one frame of an AI-generated anime shot.
Characters that may appear (reference descriptions):
{cast}
Expected in this shot: {expected}
Scene / this shot (the 站位 part is segment-level staging and may describe moments outside this shot): {scene}
Continuity notes from the storyboard: {continuity}

For EVERY visible person (including background people and bodies) report what you SEE, not what is expected:
- "who": one of the names above if they match the description, otherwise "unknown";
- "hair": colour and style you see; "tattoo_left_forearm"/"tattoo_right_forearm": true/false/null(not visible);
- "glove_left_hand"/"glove_right_hand": true/false/null; "left_cheek_mole": true/false/null(face too small or turned);
- "holding_left_hand"/"holding_right_hand": object or "nothing" or null — use the PERSON's own left/right (not screen side);
- "state": "standing|sitting|crouching|kneeling|lying_alive|dead_body"; "seat": for a car interior: "driver|front_passenger|rear|outside|n/a".
Then answer ONLY these specific checks (true = the problem IS clearly visible in this frame, false = not visible / not applicable):
{checks}
Do not report anything else: no free-form "unexpected" list, no things that are merely missing or off-screen, no camera/composition differences.
Reply JSON only: {{"people":[{{"who":"","hair":"","tattoo_left_forearm":null,"tattoo_right_forearm":null,"glove_left_hand":null,"glove_right_hand":null,"left_cheek_mole":null,"holding_left_hand":null,"holding_right_hand":null,"state":"","seat":""}}],"front_row_count":null,"dead_bodies":0,"checks":{{{check_keys}}}}}"""

# Specific scene checks (replace the old open-ended "unexpected" list, which produced 621 mostly-false scene issues on 37 v3/v4
# reports: hair colour restated, things "missing", pistol descriptions...). Each check is asked only when its trigger matches the
# scene / shot text. Extra checks can be added in QA_SCENE_CHECKS (json list of {id, trigger(regex), question, issue}).
SCENE_CHECKS = [
    {'id': 'chandelier', 'trigger': r'吊灯|一盏|灯', 'question': 'a crystal chandelier, or more than one hanging lamp, when the scene describes a single industrial lamp',
     'issue': '场景灯具不符（应只有一盏工业吊灯）'},
    {'id': 'police_livery_on_van', 'trigger': r'面包车', 'question': 'the white bread van / minivan the gang rides in is drawn with police livery, a roof light bar or police text',
     'issue': '面包车被画成警车'},
    {'id': 'readable_text', 'trigger': r'.', 'question': 'large garbled pseudo-text or a watermark/caption burned into the picture (ignore small signs in the far background)',
     'issue': '画面出现乱码文字/水印'},
    {'id': 'stray_person', 'trigger': r'.', 'question': 'a clearly visible extra person who is neither one of the expected characters nor covered by the allowed-extras note (count only people in the foreground/midground)',
     'issue': '出现分镜外人物', 'unless_text': r'劫匪|黑影|人群|路人|警察|众人|行人|围观|手下|其他人|人影'},
    {'id': 'odd_hair_colour', 'trigger': r'.', 'question': 'any person with green, blue, pink, purple or red hair (no character card has such hair)',
     'issue': '出现卡外发色（绿/蓝/粉/紫/红发）', 'unless_card_hair': r'绿|蓝|粉|紫|红'},
    {'id': 'front_row_three', 'trigger': r'车内|驾驶|副驾|前排|后座', 'question': 'three or more people sitting side by side in the FRONT row of a car',
     'issue': '车内前排出现三人'},
]
try: SCENE_CHECKS += json.load(open(os.environ['QA_SCENE_CHECKS'])) if os.environ.get('QA_SCENE_CHECKS') else []
except Exception: pass

def active_checks(info, cards=None):
    shot = info.get('shot') or {}
    hairs = ' '.join((c.get('invariant') or {}).get('hair', '') for c in (cards or {}).values())
    txt = (info.get('scene') or '') + json.dumps({k: shot.get(k) for k in ('firstFrame', 'action', 'description')}, ensure_ascii=False)
    # unless_text: the shot's OWN text (not the segment 站位) already puts unnamed people in frame, e.g. 劫匪接连倒地 / 黑影闪过
    # (still ASKED so the frame prompt and its cache stay stable; the answer is ignored for the shot -> see suppressed_checks)
    return [c for c in SCENE_CHECKS if re.search(c['trigger'], txt) and not (c.get('unless_card_hair') and re.search(c['unless_card_hair'], hairs))]

def suppressed_checks(info):
    shot = info.get('shot') or {}
    own = json.dumps({k: shot.get(k) for k in ('firstFrame', 'action', 'endFrame', 'lastFrame', 'description', 'composition')}, ensure_ascii=False) + str((shot.get('continuity') or {}).get('extras') or '')
    return {c['id'] for c in SCENE_CHECKS if c.get('unless_text') and re.search(c['unless_text'], own)}

GUN = re.compile(r'gun|pistol|revolver|firearm|枪', re.I)

def frame_prompt(info, cards):
    shot = info['shot']; ids = [c['id'] for c in shot.get('characters', [])]
    cast = '\n'.join(f'- {card_text(c)}' for c in cards.values())
    expected = '、'.join(cards[i]['name'] for i in ids if i in cards) or '无人物（空镜）'
    cont = shot.get('continuity') or {}
    notes = []
    for h in cont.get('hands', []) or []:
        if h.get('id') in cards: notes.append(f"{cards[h['id']]['name']} 左手:{h.get('left') or '空'} 右手:{h.get('right') or '空'}")
    if cont.get('dead'): notes.append('已死亡：' + '、'.join(cards[i]['name'] for i in cont['dead'] if i in cards))
    notes.append('允许的其他人物/尸体：' + (cont.get('extras') or '未注明'))
    scene = info.get('scene') or ''
    scene = f"{scene} | 本镜画面：{shot.get('firstFrame', '')} | 动作：{shot.get('action', '')}"
    chk = active_checks(info, cards)
    return FRAME_PROMPT.format(cast=cast, expected=expected, scene=scene[:1500], continuity='；'.join(notes),
                               checks='\n'.join(f'- "{c["id"]}": {c["question"]}' for c in chk) or '- (none)',
                               check_keys=','.join(f'"{c["id"]}":false' for c in chk))

def name_to_id(cards, who):
    for i, c in cards.items():
        if who and (c['name'] in who or who in c['name'] or i == who): return i
    return None

def side_of_gun(p):
    l, r = str(p.get('holding_left_hand') or ''), str(p.get('holding_right_hand') or '')
    gl, gr = bool(GUN.search(l)), bool(GUN.search(r))
    return 'both' if gl and gr else 'left' if gl else 'right' if gr else None

def check_frames(frames, info, cards, pool):
    prompt = frame_prompt(info, cards)
    futs = {(m, f): pool.submit(model_call, m, prompt, [f]) for m in TRAIT_MODELS for _, f in frames}
    shot = info['shot']; on_screen = [c['id'] for c in shot.get('characters', [])]
    exp = {i: expected_traits(cards[i]) for i in cards}
    allowed_extra = (shot.get('continuity') or {}).get('extras') or ''
    sup = suppressed_checks(info); active = [c for c in active_checks(info, cards) if c['id'] not in sup]
    shot_text = json.dumps({k: shot.get(k) for k in ('firstFrame', 'action', 'lastFrame', 'description')}, ensure_ascii=False)
    findings = []  # (kind, key, t, model, detail)
    gun_sides = {}  # char -> list of (t, side, model)
    observations = []
    for t, f in frames:
        for m in TRAIT_MODELS:
            res = futs[(m, f)].result()
            if not isinstance(res, dict) or 'people' not in res: continue
            observations.append({'t': round(t, 2), 'model': m, 'res': res})
            for p in res.get('people') or []:
                if not isinstance(p, dict): continue
                cid = name_to_id(cards, str(p.get('who') or ''))
                if not cid: continue
                e = exp[cid]; nm = cards[cid]['name']
                if str(p.get('state')) == 'dead_body': continue
                if cid not in on_screen and nm not in shot_text:
                    # a character named in this shot's own text (画面/动作/首帧) is not a stray; the segment 站位 is NOT used (it names everyone)
                    # placed in frame by the segment 站位 (the shot list omits him) -> warning, not fail (v3 E01-03-01/02-03/03-02: the
                    # video follows the segment staging; no human reported these). Not in 站位 either -> real stray -> fail.
                    staged = nm in (info.get('scene') or '').split('站位', 1)[-1] if '站位' in (info.get('scene') or '') else False
                    findings.append(('cast_staged' if staged else 'cast', f'{nm}不应出现在本镜' + ('（分段站位里有此人，分镜名单没有）' if staged else ''), t, m, ''))
                tat = [p.get('tattoo_left_forearm'), p.get('tattoo_right_forearm')]
                if not e['tattoo'] and any(x is True for x in tat):
                    findings.append(('trait', f'{nm}手臂出现纹身（角色卡无纹身）', t, m, ''))
                gl, gr = p.get('glove_left_hand'), p.get('glove_right_hand')
                if e['glove'] == 'right' and (gl is True or gr is False):
                    findings.append(('trait', f'{nm}手套应只戴右手（左:{gl} 右:{gr}）', t, m, ''))
                if e['glove'] == 'left' and (gr is True or gl is False):
                    findings.append(('trait', f'{nm}手套应只戴左手（左:{gl} 右:{gr}）', t, m, ''))
                if e['glove'] == 'none' and (gl is True or gr is True):
                    findings.append(('trait', f'{nm}不应戴手套', t, m, ''))
                if e['mole'] == '左cheek' and p.get('left_cheek_mole') is False:
                    findings.append(('trait', f'{nm}左颊黑痣缺失', t, m, ''))
                hair = str(p.get('hair') or '').lower()
                if hair and e['hair']:
                    want_yellow = bool(re.search(r'黄|金|blond|yellow', e['hair']))
                    if want_yellow and not re.search(r'yellow|blond|gold|黄|金', hair):
                        findings.append(('trait', f'{nm}发色不符（应{e["hair"]}，见 {hair}）', t, m, ''))
                    if re.search(r'green|绿|blue|蓝|pink|粉|purple|紫|red|红', hair) and not re.search(r'绿|蓝|粉|紫|红', e['hair']):
                        findings.append(('trait', f'{nm}发色不符（应{e["hair"]}，见 {hair}）', t, m, ''))
                s = side_of_gun(p)
                if s: gun_sides.setdefault(cid, []).append((t, s, m))
            chk = res.get('checks') if isinstance(res.get('checks'), dict) else {}
            unknown = [p for p in res.get('people') or [] if isinstance(p, dict) and not name_to_id(cards, str(p.get('who') or '')) and str(p.get('state')) != 'dead_body']
            for c in active:
                if chk.get(c['id']) is not True: continue
                if c['id'] == 'stray_person' and not unknown: continue  # the same model must also list an unidentified living person
                findings.append(('scene', c['issue'], t, m, ''))
            fr = res.get('front_row_count')
            if isinstance(fr, int) and fr > 2 and any(c['id'] == 'front_row_three' for c in active): findings.append(('scene', f'车内前排出现 {fr} 人', t, m, ''))
            bodies = res.get('dead_bodies')
            if isinstance(bodies, int) and bodies > 0 and re.search(r'^(无|没有|none)?$', allowed_extra.strip()) and not (shot.get('continuity') or {}).get('dead'):
                findings.append(('scene', f'出现 {bodies} 具尸体（分镜此刻没有尸体）', t, m, ''))
    # gun hand consistency within the shot (majority per model, then swaps)
    gun_summary = {}
    for cid, lst in gun_sides.items():
        sides = [s for _, s, _ in lst]
        left, right = sides.count('left'), sides.count('right')
        gun_summary[cid] = 'right' if right >= left else 'left'
        # v5run: ported calibrated gun-swap rule from fx4/qa2.py (minority side in >=2 consecutive frames of one model, or >=2 models same frame)
        minority = 'left' if left < right else 'right'
        mt = sorted({t for t, sd, _ in lst if sd == minority})
        by_m = {}
        for t, sd, m in lst: by_m.setdefault(m, []).append((t, sd))
        run = any(any(x[1] == minority and y[1] == minority for x, y in zip(sorted(v), sorted(v)[1:])) for v in by_m.values())
        same_t = any(len({m for t2, sd, m in lst if sd == minority and t2 == t}) >= 2 for t in mt)
        if left >= 2 and right >= 2 and (run or same_t):
            findings.append(('continuity', f'{cards[cid]["name"]}持枪手在本镜内左右互换（左{left}帧/右{right}帧）', lst[0][0], 'multi', ''))
        want = None
        for h in (shot.get('continuity') or {}).get('hands', []) or []:
            if h.get('id') == cid:
                if GUN.search(str(h.get('right') or '')): want = 'right'
                elif GUN.search(str(h.get('left') or '')): want = 'left'
        if want and ((want == 'right' and left > right) or (want == 'left' and right > left)):
            findings.append(('continuity', f'{cards[cid]["name"]}持枪手与分镜不符（应{"右" if want == "right" else "左"}手）', lst[0][0], 'multi', ''))
    return findings, gun_summary, observations

# ---------------- D: fixed vehicle card (props) ----------------
VEHICLE_MODELS = [m for m in os.environ.get('VEHICLE_MODELS', 'grok-4.3,google/gemma-3-27b-it').split(',') if m]
VEHICLE_FILE = os.environ.get('QA_VEHICLES', '/workspace/fx4/run/道具/vehicles.json')
VEH_PROMPT = """You check vehicle continuity in one frame of an AI-generated anime shot.
List every vehicle you can SEE (including the vehicle the camera is inside, if the frame is an interior view of a car).
For each: "type" (one of: minivan, panel van, police car, sedan, SUV, pickup, armored truck, cargo truck, bus, other), "color", "police_markings" (true if it has police livery, a roof light bar or police text), "role" ("interior" if the camera/people are inside it, "main" if it is the main subject, else "background"), "occupied" (true if people are visibly sitting inside it in this frame).
Reply JSON only: {"camera_inside_vehicle": false, "vehicles": [{"type": "", "color": "", "police_markings": false, "role": "", "occupied": false}]}"""

def load_vehicles():
    try: return json.load(open(VEHICLE_FILE)).get('vehicles', [])
    except Exception: return []

def expected_vehicles(info, vcards):
    shot = info.get('shot') or {}
    txt = json.dumps({k: shot.get(k) for k in ('firstFrame', 'action', 'description', 'lastFrame', 'camera', 'dialogue') if shot.get(k)}, ensure_ascii=False)
    scene_id = info.get('sceneId') or ''
    scene = info.get('scene') or ''
    out = []
    for v in vcards:
        if any(k in txt for k in v.get('match', [])) or scene_id in v.get('scenes', []) or (v['id'] == 'van' and scene.startswith('面包车与高桥')):
            out.append(v)
    return out

def check_vehicle(frames, info, pool):
    vcards = load_vehicles(); exp = expected_vehicles(info, vcards)
    if not exp: return [], None
    ids = {v['id'] for v in exp}
    scene = info.get('scene') or ''
    ok_cards = exp + [v for v in vcards if v not in exp and any(k in scene.split('；站位')[0] for k in [v['name']] + v.get('match', [])[:2])]
    futs = {(m, f): pool.submit(model_call, m, VEH_PROMPT, [f]) for m in VEHICLE_MODELS for _, f in frames}
    findings = []; types = {}; obs = []
    van = next((v for v in vcards if v['id'] == 'van'), None)
    VANLIKE = (van['typeAccept'] + '|suv') if van else 'van'
    for t, f in frames:
        for m in VEHICLE_MODELS:
            res = futs[(m, f)].result()
            if not isinstance(res, dict) or 'vehicles' not in res: continue
            obs.append({'t': round(t, 2), 'model': m, 'res': res})
            for v in res.get('vehicles') or []:
                if not isinstance(v, dict): continue
                ty = str(v.get('type') or '').lower(); col = str(v.get('color') or '').lower(); role = str(v.get('role') or '')
                pol = v.get('police_markings') is True or 'police' in ty
                if role not in ('interior', 'main'): continue
                types.setdefault(role, []).append('police car' if pol else ty)
                if 'van' in ids and role == 'interior':
                    # interior views: sedan/minivan is ambiguous from inside; only police equipment is a hard error
                    if pol: findings.append(('vehicle', '车辆不符：人物所在车辆是警车/带警用标识（车辆卡：白色面包车）', t, m, ''))
                elif role == 'main':
                    if pol:
                        if 'van' in ids and v.get('occupied') is True:
                            findings.append(('vehicle', '车辆不符：载着主角们的车被画成警车（车辆卡：白色面包车）', t, m, ''))
                        elif 'police' not in ids: findings.append(('vehicle', '车辆不符：主体车辆带警用标识（本镜车辆卡：' + '/'.join(c['name'] for c in exp) + '）', t, m, ''))
                        continue
                    ok = any(re.search(VANLIKE if c['id'] == 'van' else c['typeAccept'], ty) for c in ok_cards)
                    if ty and not ok:
                        findings.append(('vehicle', f'车辆不符：主体车辆为 {ty}（本镜车辆卡：{"/".join(c["name"] for c in exp)}）', t, m, ''))
                    if 'van' in ids and van and re.search(VANLIKE, ty) and col and not re.search(van['colorAccept'], col):
                        findings.append(('vehicle', f'面包车颜色不符：{col}（车辆卡：白色）', t, m, ''))
    summary = {'expected': sorted(ids), 'seen': {r: max(set(l), key=l.count) for r, l in types.items() if l}, 'observations': obs}
    return findings, summary

def aggregate(findings, min_frames, image=False):
    """Calibrated (see eval/hand_calibration.md + PROGRESS.md 'QA calibration'):
    - trait (glove side / tattoo / hair / mole): >= 2 models must report it; in a video also in >= 2 frames. grok-4.7 reports
      "gloves on both hands" for 萧枫 in almost every frame even when the left hand is visibly bare (v3 E01-01-04), so one model
      alone is not enough. Real cases kept: v4 E01-02-01 keyframe i1 (both hands gloved), i3 (glove on left), v3 E01-02-04 老五 gloves.
    - scene / cast: >= 2 frames or >= 2 models (image: >= 2 models).  - continuity: always.  - vehicle: caller passes min_frames=2."""
    by = {}
    for kind, key, t, m, _ in findings:
        g = re.sub(r'（[^（）]*）$', '', key) if kind == 'trait' else key  # group "手套应只戴右手（左:True 右:True）" variants
        d = by.setdefault((kind, g), {'frames': set(), 'models': set(), 'examples': []})
        d['frames'].add(round(t, 2)); d['models'].add(m)
        if key not in d['examples']: d['examples'].append(key)
    out = []
    for (kind, g), d in by.items():
        key = d['examples'][0] if len(d['examples']) == 1 else g + '（' + ' / '.join(e[len(g):].strip('（）') for e in d['examples'][:3]) + '）'
        nf, nm = len(d['frames']), len(d['models'])
        if kind == 'continuity': ok = True
        elif kind == 'trait': ok = nm >= 2 and (image or nf >= max(2, min_frames))
        elif kind in ('scene', 'cast', 'cast_staged'): ok = nm >= 2 or (not image and nf >= max(2, min_frames))
        else: ok = nf >= min_frames or nm >= 2
        if ok: out.append({'kind': kind, 'issue': key, 'times': sorted(d['frames'])[:8], 'models': sorted(d['models'])})
    return out

def main():
    ap = argparse.ArgumentParser(); ap.add_argument('video'); ap.add_argument('info'); ap.add_argument('--out'); ap.add_argument('--prev')
    ap.add_argument('--skip-hands', action='store_true'); ap.add_argument('--skip-vehicle', action='store_true'); ap.add_argument('--skip-frames', action='store_true')
    ap.add_argument('--image', action='store_true', help='first arg is a still image (keyframe) instead of a video')
    a = ap.parse_args()
    info = json.load(open(a.info)); cards = load_cards()
    info.setdefault('shot', {}); info['shot'].setdefault('characters', [])
    if 'scene' not in info and os.environ.get('QA_STORYBOARD'):
        b = json.load(open(os.environ['QA_STORYBOARD']))
        for e in b['episodes']:
            for s in e['segments']:
                if s['id'] == info.get('segmentId'):
                    sc = next((x for x in b['scenes'] if x['id'] == s['sceneId']), {})
                    info['scene'] = f"{sc.get('name', '')}：{sc.get('description', '')}；站位：{s.get('blocking', '')}"
    work = tempfile.mkdtemp(prefix='qa2_')
    pool = cf.ThreadPoolExecutor(CONC)
    issues = []; warnings = []; report = {'video': a.video, 'shotId': info.get('shotId')}
    try:
        if not a.skip_hands:
            hf = [(0.0, a.video)] if a.image else sample(a.video, HAND_FPS, f'{work}/h')
            hands = check_hands(hf, work, pool); report['hands'] = {k: hands[k] for k in ('crops', 'candidates', 'bad', 'suspect', 'rows', 'rule') if k in hands}
            if len(hands['bad']) >= HAND_MIN_BAD:
                ts = sorted({b['t'] for b in hands['bad']})
                issues.append({'kind': 'hands', 'issue': f'手指异常（多指/畸形）{len(hands["bad"])} 处', 'times': ts[:8], 'models': sorted({m for b in hands['bad'] for m in b['models']})})
            if hands.get('suspect'):  # stage-1 only: NOT a fail (calibration: 12/12 clean v3 shots had such flags), but surfaced for a human look
                warnings.append({'kind': 'hands', 'issue': f'手指可疑（单模型初筛、复核未确认）{len(hands["suspect"])} 处，建议人工看', 'times': sorted({b['t'] for b in hands['suspect']})[:8]})
        if not a.skip_frames:
            ff = [(0.0, a.video)] if a.image else sample(a.video, 1.0 / TRAIT_STEP, f'{work}/t')
            findings, guns, obs = check_frames(ff, info, cards, pool)
            report['gun_hand'] = guns; report['observations'] = obs
            agg = aggregate(findings, TRAIT_MIN_FRAMES, image=a.image)
            issues += [x for x in agg if x['kind'] != 'cast_staged']; warnings += [x for x in agg if x['kind'] == 'cast_staged']
        if not a.skip_vehicle:
            vf = [(0.0, a.video)] if a.image else sample(a.video, 1.0 / TRAIT_STEP, f'{work}/v')
            vfind, vsum = check_vehicle(vf, info, pool); report['vehicle'] = vsum
            issues += aggregate(vfind, 2)
            if vsum and a.prev and os.path.exists(a.prev):
                pv = (json.load(open(a.prev)).get('vehicle') or {})
                for role in ('interior',):
                    a1, b1 = (pv.get('seen') or {}).get(role), (vsum.get('seen') or {}).get(role)
                    if a1 and b1 and ('police' in a1) != ('police' in b1):
                        issues.append({'kind': 'vehicle', 'issue': f'车辆与上一镜不一致（上一镜 {a1}，本镜 {b1}）', 'times': [], 'models': ['multi']})
        if not a.skip_frames:
            if a.prev and os.path.exists(a.prev):
                prev = json.load(open(a.prev))
                for cid, side in guns.items():
                    ps = (prev.get('gun_hand') or {}).get(cid)
                    if ps and ps != side and info.get('segmentId') and prev.get('segmentId') == info.get('segmentId'):
                        issues.append({'kind': 'continuity', 'issue': f'{cards[cid]["name"]}持枪手与上一镜不一致（上一镜{ps}，本镜{side}）', 'times': [], 'models': ['multi']})
    finally:
        save_cache(); pool.shutdown(wait=False)
    report['segmentId'] = info.get('segmentId'); report['issues'] = issues; report['warnings'] = warnings; report['abstained'] = ABSTAINED
    score = max(0.0, 1.0 - 0.2 * len(issues))
    report['pass'] = not issues; report['score'] = score
    _r = len(ABSTAINED) / CALLS[0] if CALLS[0] else 1.0
    report['status'] = 'fail' if issues else ('abstain' if (not CALLS[0] or _r >= ABSTAIN_RATIO) else 'pass'); report['modelCalls'] = CALLS[0]
    if a.out:
        json.dump(report, open(a.out, 'w'), ensure_ascii=False, indent=1)
    # v5run: emit the v5 unified-QA fields the pipeline's normalizeExternalQa reads (status/hardFailures/softIssues/abstentions);
    # before, warnings and abstentions were dropped and an all-abstained run looked like a pass.
    hard = [f"{i['issue']}@{','.join(str(t) for t in i['times'][:4])}" for i in issues]
    soft = [f"{w['issue']}@{','.join(str(t) for t in w['times'][:4])}" for w in warnings]
    ratio = len(ABSTAINED) / CALLS[0] if CALLS[0] else 1.0
    status = 'fail' if issues else ('abstain' if (not CALLS[0] or ratio >= ABSTAIN_RATIO) else 'pass')
    abst = [{'source': 'qa2', 'reason': f"{len(ABSTAINED)}/{CALLS[0]} model calls gave no usable answer (>= {ABSTAIN_RATIO:.0%})"}] if status == 'abstain' else []
    print(json.dumps({'pass': not issues, 'status': status, 'score': score, 'issues': hard, 'hardFailures': hard, 'warnings': soft, 'softIssues': soft,
                      'abstentions': abst, 'abstainedCalls': len(ABSTAINED), 'modelCalls': CALLS[0]}, ensure_ascii=False))

if __name__ == '__main__':
    main()
