from repair_router import route_failures

def test_abstain_is_human_review_not_pass_or_retry():
    result = route_failures("abstain", [])
    assert result["requiresHuman"] is True
    assert result["automaticAttemptsRemaining"] == 0

def test_audio_language_does_not_force_video_regeneration():
    result = route_failures("fail", ["audio_language"])
    assert result["routes"][0]["stage"] == "audio_track_only_if_supported"

def test_identity_routes_to_reference_and_keyframe():
    result = route_failures("fail", ["identity"])
    assert result["routes"][0]["stage"] == "keyframe_and_video"

def test_edge_black_is_trimmed_before_any_reroll():
    from repair_router import plan_visual_repair
    decision = plan_visual_repair("black", [], spans=[{"start": 0, "end": 0.8, "code": "black"}], duration=10)
    assert decision["action"] == "trim"
    assert decision["head"] == 0.8
    assert decision["tail"] == 0

def test_middle_cut_patches_a_short_tail():
    from repair_router import plan_visual_repair
    decision = plan_visual_repair("cut", [], spans=[{"start": 4.0, "end": 4.0, "code": "cut"}], duration=10)
    assert decision["action"] == "patch"
    assert decision["at"] == 3.85
    assert decision["generateSeconds"] == 7

def test_same_problem_revises_then_rerolls_once_then_stops():
    from repair_router import plan_visual_repair
    history = []
    first = plan_visual_repair("hands", history, duration=0)
    assert first["action"] == "revise"
    history.append({"action": "revise", "issueKey": "hands"})
    second = plan_visual_repair("hands", history, duration=0)
    assert second["action"] == "reroll"
    history.append({"action": "reroll", "issueKey": "hands"})
    third = plan_visual_repair("hands", history, duration=0)
    assert third["action"] == "stop"
