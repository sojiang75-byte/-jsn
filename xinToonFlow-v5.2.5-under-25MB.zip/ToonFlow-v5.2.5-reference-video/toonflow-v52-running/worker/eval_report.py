import json,sys,itertools,collections
sys.path.insert(0,'/workspace/fx4'); from hands_eval import verdict
c=json.load(open('eval/hand_cache.json'))
models=sys.argv[1].split(','); root=sys.argv[2]; pos=sys.argv[3].split(','); neg=sys.argv[4].split(',')
per=collections.defaultdict(dict)
for k,v in c.items():
    m,p=k.split('|',1)
    if root not in p: continue
    shot=p.split(root+'/')[1].split('/')[0]; per[(m,shot)][p]=verdict(v)
def flags(ms,shot,minbad=1,agree=False):
    crops=set().union(*[per[(m,shot)].keys() for m in ms])
    if agree: bad=[p for p in crops if sum(per[(m,shot)].get(p)=='bad' for m in ms)>=2]
    else: bad=[p for p in crops if any(per[(m,shot)].get(p)=='bad' for m in ms)]
    return len(bad)
print('shot-level bad-crop counts')
print('model'.ljust(30),' '.join(s[-5:] for s in pos),'|',' '.join(s[-5:] for s in neg))
for r in range(1,len(models)+1):
  for ms in itertools.combinations(models,r):
    row=[flags(ms,s) for s in pos]; nrow=[flags(ms,s) for s in neg]
    print('+'.join(m.split('/')[-1][:10] for m in ms).ljust(30),' '.join(f'{x:5d}' for x in row),'|',' '.join(f'{x:5d}' for x in nrow))
for ms in [models]:
    print('agree>=2'.ljust(30),' '.join(f'{flags(ms,s,agree=True):5d}' for s in pos),'|',' '.join(f'{flags(ms,s,agree=True):5d}' for s in neg))
