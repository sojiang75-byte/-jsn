"""Anime hand detector (deepghs/anime_hand_detection v1.0_s, YOLOv8 ONNX) + crop helper."""
import numpy as np, onnxruntime as ort
from PIL import Image
_S = None
def _sess():
    global _S
    if _S is None:
        o = ort.SessionOptions(); o.intra_op_num_threads = 4
        _S = ort.InferenceSession('/workspace/fx4/models/hand.onnx', o, providers=['CPUExecutionProvider'])
    return _S
def _nms(boxes, scores, thr=0.5):
    order = scores.argsort()[::-1]; keep = []
    while order.size:
        i = order[0]; keep.append(i)
        xx1 = np.maximum(boxes[i,0], boxes[order[1:],0]); yy1 = np.maximum(boxes[i,1], boxes[order[1:],1])
        xx2 = np.minimum(boxes[i,2], boxes[order[1:],2]); yy2 = np.minimum(boxes[i,3], boxes[order[1:],3])
        inter = np.clip(xx2-xx1,0,None)*np.clip(yy2-yy1,0,None)
        a = (boxes[:,2]-boxes[:,0])*(boxes[:,3]-boxes[:,1])
        iou = inter/(a[i]+a[order[1:]]-inter+1e-9)
        order = order[1:][iou < thr]
    return keep
def detect(img: Image.Image, conf=0.3, size=640):
    img = img.convert('RGB'); w, h = img.size; r = size / max(w, h)
    nw, nh = int(round(w*r)), int(round(h*r))
    canvas = Image.new('RGB', (size, size), (114,114,114)); canvas.paste(img.resize((nw, nh), Image.BILINEAR), (0, 0))
    x = np.asarray(canvas, dtype=np.float32).transpose(2,0,1)[None] / 255.0
    out = _sess().run(None, {'images': x})[0][0]  # (4+nc, anchors)
    if out.shape[0] > out.shape[1]: out = out.T
    sc = out[4:].max(0); m = sc >= conf
    if not m.any(): return []
    b = out[:4, m].T; sc = sc[m]
    boxes = np.stack([b[:,0]-b[:,2]/2, b[:,1]-b[:,3]/2, b[:,0]+b[:,2]/2, b[:,1]+b[:,3]/2], 1) / r
    keep = _nms(boxes, sc)
    res = []
    for i in keep:
        x1,y1,x2,y2 = boxes[i]; res.append((max(0,x1),max(0,y1),min(w,x2),min(h,y2),float(sc[i])))
    return res
def crop(img: Image.Image, box, pad=0.45, minside=448):
    x1,y1,x2,y2 = box[:4]; bw, bh = x2-x1, y2-y1; s = max(bw, bh)*(1+2*pad)
    cx, cy = (x1+x2)/2, (y1+y2)/2
    c = img.crop((int(max(0,cx-s/2)), int(max(0,cy-s/2)), int(min(img.width,cx+s/2)), int(min(img.height,cy+s/2))))
    k = max(1.0, minside / max(c.size))
    return c.resize((int(c.width*k), int(c.height*k)), Image.LANCZOS)
