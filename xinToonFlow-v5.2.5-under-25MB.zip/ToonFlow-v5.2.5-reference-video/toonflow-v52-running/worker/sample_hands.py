"""Sample a video at 2 fps, detect hands, save upscaled crops + per-shot grid. usage: sample_hands.py video outdir [fps]"""
import sys, os, json, subprocess, glob
sys.path.insert(0, '/workspace/fx4'); from handdet import detect, crop
from PIL import Image, ImageDraw
video, out = sys.argv[1], sys.argv[2]; fps = float(sys.argv[3]) if len(sys.argv) > 3 else 2.0
os.makedirs(out + '/frames', exist_ok=True); os.makedirs(out + '/crops', exist_ok=True)
subprocess.run(['ffmpeg', '-v', 'error', '-y', '-i', video, '-vf', f'fps={fps}', '-q:v', '2', out + '/frames/f%04d.jpg'], check=True)
rows = []
for f in sorted(glob.glob(out + '/frames/*.jpg')):
    i = int(f[-8:-4]); t = (i - 1) / fps + 0.5 / fps
    im = Image.open(f)
    for k, b in enumerate(detect(im, conf=0.3)):
        if (b[2]-b[0]) < 14 or (b[3]-b[1]) < 14: continue
        p = f'{out}/crops/t{t:07.2f}_h{k}.jpg'; crop(im, b).save(p, quality=92)
        rows.append({'t': round(t, 2), 'frame': f, 'box': [float(x) for x in b[:4]], 'conf': b[4], 'crop': p})
json.dump(rows, open(out + '/hands.json', 'w'), indent=1)
print(len(rows), 'crops')
