"""laozhang-style prop assets: product-photo reference images (neutral grey surface, single side light) for each vehicle card.
Usage: python3 make_assets.py [ids...]   (keys from env only; never printed)"""
import json, sys, os, base64
sys.path.insert(0, "/workspace/fx4")
import auto_worker as W
SHOT = ("Product reference sheet of a single vehicle, isolated: the vehicle stands alone on a plain neutral grey studio floor in front of a plain neutral grey backdrop, "
        "one soft key light from screen-left, one clear shadow falling to screen-right, flat even exposure, no people, no other vehicles, no text, no logos, no watermark. "
        "Three-quarter front view from the driver's side at eye level, whole vehicle in frame with margin.")
INTERIOR = ("Product reference of the same vehicle's interior seen from the rear bench looking forward between the two front seats, empty seats, no people, "
            "neutral daylight from screen-left, no text.")
cards = {v["id"]: v for v in W.vehicle_cards()}
ids = sys.argv[1:] or list(cards)
os.makedirs("/workspace/fx4/assets", exist_ok=True)
for vid in ids:
    v = cards[vid]
    for view, extra in (("ext", SHOT), ("int", INTERIOR)):
        if view == "int" and vid != "van": continue
        for k in (1, 2):
            p = " ".join([W.style_line(), extra, v["en"], ("Never show: " + v["negative"] + ".") if v.get("negative") and view == "ext" else ""])
            job = {"id": f"asset_{vid}_{view}_{k}", "params": {"aspect_ratio": "16:9"}}
            W.OUT = "/workspace/fx4/assets"
            out = W.gen_image(job, p, [])
            print(vid, view, k, out, flush=True)
