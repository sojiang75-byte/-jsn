#!/usr/bin/env python3
"""Evaluate a human-labelled QA set without changing production thresholds.

Input JSON: [{"id":"...","truth":"pass|fail","prediction":"pass|fail|abstain","confidence":0.0,"category":"hands"}]
"""
import json, sys
from collections import defaultdict

def metrics(rows):
    tp = sum(r["truth"] == "fail" and r["prediction"] == "fail" for r in rows)
    fp = sum(r["truth"] == "pass" and r["prediction"] == "fail" for r in rows)
    tn = sum(r["truth"] == "pass" and r["prediction"] == "pass" for r in rows)
    fn = sum(r["truth"] == "fail" and r["prediction"] == "pass" for r in rows)
    abstain = sum(r["prediction"] == "abstain" for r in rows)
    div = lambda a, b: round(a / b, 4) if b else None
    return {"n": len(rows), "precision": div(tp, tp + fp), "recall": div(tp, tp + fn),
            "false_positive_rate": div(fp, fp + tn), "false_reject_rate": div(fp, fp + tn),
            "false_accept_rate": div(fn, fn + tp), "abstain_rate": div(abstain, len(rows)),
            "tp": tp, "fp": fp, "tn": tn, "fn": fn, "abstain": abstain}

def main(path):
    rows = json.load(open(path, encoding="utf-8"))
    valid = [r for r in rows if r.get("truth") in ("pass", "fail") and r.get("prediction") in ("pass", "fail", "abstain")]
    groups = defaultdict(list)
    for row in valid: groups[row.get("category", "overall")].append(row)
    report = {"overall": metrics(valid), "by_category": {k: metrics(v) for k, v in sorted(groups.items())},
              "excluded": len(rows) - len(valid), "thresholds_changed": False}
    print(json.dumps(report, ensure_ascii=False, indent=2))

if __name__ == "__main__":
    if len(sys.argv) != 2: raise SystemExit("usage: evaluate_qa_calibration.py labelled_qa.json")
    main(sys.argv[1])
