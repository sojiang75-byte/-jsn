"""Failure-code based repair routing. Routes are explicit so QA never blindly regenerates every asset."""
from typing import Any, Dict, Iterable, List

ROUTES = {
    "identity": ("keyframe_and_video", "补强角色锚点/多视角参考，重做首帧后再生成视频"),
    "cast": ("storyboard_and_keyframe", "修正出场人物清单与站位，再重做首帧和视频"),
    "vehicle": ("prop_reference_and_video", "修正车辆资产卡/车型参考图，只重做受影响镜头"),
    "style": ("style_anchor_and_video", "恢复项目画风锚点与负面约束，只重做受影响镜头"),
    "viewpoint": ("shot_contract_and_video", "按镜头视角合同修正 POV/过肩/俯视，再重做该镜"),
    "audio_language": ("audio_track_only_if_supported", "优先只重做配音/音轨；当前生成器不支持独立音轨时转人工，不重绘画面"),
    "dialogue_match": ("audio_track_only_if_supported", "只修正台词与音轨；画面无需重做，若无音轨接口则人工处理"),
    "hands": ("frame_review_or_local_repair", "先复核低置信度帧；只对确认的手部缺陷做局部修复"),
    "continuity": ("continuity_and_affected_shots", "修正跨镜状态与受影响镜头，不全片重生成"),
    "anatomy": ("keyframe_and_video", "修正角色肢体结构与参考图后重做受影响镜头"),
    "qa_abstain": ("recheck_or_manual_review", "补充证据或人工审核；不得将 abstain 自动当作通过或失败"),
}

def route_failures(status: str, failures: Iterable[Any]) -> Dict[str, Any]:
    if status == "pass":
        return {"status": "pass", "routes": [], "automaticAttemptsRemaining": 0, "requiresHuman": False}
    if status == "abstain":
        return {"status": "abstain", "routes": [{"code": "qa_abstain", "stage": ROUTES["qa_abstain"][0], "instruction": ROUTES["qa_abstain"][1]}], "automaticAttemptsRemaining": 0, "requiresHuman": True}
    routes: List[Dict[str, str]] = []
    seen = set()
    for failure in failures:
        code = failure.get("code") if isinstance(failure, dict) else str(failure)
        code = str(code).split(":", 1)[0].strip().lower()
        if code in ROUTES and code not in seen:
            stage, instruction = ROUTES[code]
            routes.append({"code": code, "stage": stage, "instruction": instruction})
            seen.add(code)
    manual = not bool(routes) or any(route["stage"] == "audio_track_only_if_supported" for route in routes)
    return {"status": "fail", "routes": routes, "automaticAttemptsRemaining": 0 if manual else 2, "requiresHuman": manual}
