#!/usr/bin/env python3
"""Auto-fulfil Toonflow grok-relay jobs through the official xAI API (v5 QA/repair worker, isolated from v4).
- v5: unified pass/fail/abstain arbiter, failure-code repair routing, two targeted automatic visual repairs; abstain/audio-only cases stop for manual review.
- v4: qa2.py strict multi-model QA (dense hand crops + finger counts, card traits, continuity, unexpected objects) on every
  video try and on keyframe stills; up to 5 video tries alternating grok-imagine-video-1.5 / grok-imagine-video; shot id from the
  【镜头ID】 prompt tag (stripped before translation); continuation reference images (previous-shot tail frames + anchors) are sent as
  reference_images on grok-imagine-video-1.5 next to the pinned first frame (dropped on grok-imagine-video, which cannot combine them).
- v3: per-character trait exclusivity block (e.g. only Lao Wu has tattoos), third-person/no-POV and spatial staging rules, no readable signs,
  Mandarin-only speech for every shot, QA flags trait_bleed / first_person_pov / spatial_problem / fingers / extra limbs;
  3 tries on grok-imagine-video-1.5, then up to 2 more on grok-imagine-video.
- Hardened English prompts: fixed outfits from the run's character cards, Mandarin dialogue block, 2D anime style, anatomy/text/cut negatives.
- Video QA after every generated clip (video_qa.py: Nemotron frame checks + faster-whisper Mandarin check);
  up to MAX_QA_TRIES generations per video job with targeted prompt changes / alternative model, then the best clip is delivered.
- Moderation fallback (softened prompt, implied action) kept.
State in /workspace/fx2/worker_state.json guarantees one result per job id. Keys come from the environment only and are never logged."""
import base64, glob, hashlib, io, json, os, re, shutil, subprocess, sys, threading, time, traceback, urllib.request, urllib.error
from concurrent.futures import ThreadPoolExecutor
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import video_qa
from repair_router import route_failures
from qa_contract import normalize_qa

RELAY = os.environ.get("RELAY_ROOT", "/workspace/relay")  # v5run: env-overridable (v5 run uses its own relay)
BASE = os.environ.get("WORKER_BASE", "/workspace/fx4")  # v5run: env-overridable so v5 never shares v4 worker state
RUN = f"{BASE}/run"
OUT = f"{BASE}/out"
QADIR = f"{BASE}/qa"
STATE = f"{BASE}/worker_state.json"
REPORT = f"{BASE}/qa_report.json"
API = "https://api.x.ai/v1"
KEY = os.environ.get("XAI_API_KEY", "").strip()
IMAGE_MODEL = "grok-imagine-image-2.0"
VIDEO_MODEL = "grok-imagine-video-1.5"
ALT_VIDEO_MODEL = "grok-imagine-video"
CHAT_MODEL = "grok-4.3"
CONCURRENCY = int(os.environ.get("WORKER_CONCURRENCY", "3"))
MAX_REFS = 5
MAX_QA_TRIES = 5  # alternating VIDEO_MODEL / ALT_VIDEO_MODEL
MAX_IMAGE_QA_TRIES = 3
QA2 = os.environ.get("WORKER_QA2", os.path.join(os.path.dirname(os.path.abspath(__file__)), "qa2.py"))
QA2_PY = os.environ.get("WORKER_QA2_PY", "/workspace/fx4/venv/bin/python")
STORYBOARD = os.environ.get("WORKER_STORYBOARD", f"{RUN}/一键成片/{os.environ.get('WORKER_RUN_ID', 'fx4-ch1')}/storyboard.json")
TAG_RE = re.compile(r"\n?【镜头ID】(\S+)")
LEGEND_RE = re.compile(r"【参考图说明】.*?(?:【画面】\n?|\Z)", re.S)
lock = threading.RLock()

DEFAULT_STYLE = "2D Japanese anime, cel-shaded, hand-drawn look, clean line art"
_style_cache = {}

def run_style():
    """Art style of the current run, so stills use the same style text Toonflow gives the video model:
    WORKER_STYLE, else the `style` of storyboard.json / cast.json in the run directory, else DEFAULT_STYLE."""
    env = os.environ.get("WORKER_STYLE", "").strip()
    if env: return env
    for path in (STORYBOARD, os.path.join(os.path.dirname(STORYBOARD), "cast.json")):
        try: mtime = os.path.getmtime(path)
        except OSError: continue
        hit = _style_cache.get(path)
        if not hit or hit[0] != mtime:
            try: hit = (mtime, str(json.load(open(path)).get("style") or "").strip())
            except Exception: hit = (mtime, "")
            _style_cache[path] = hit
        if hit[1]: return hit[1]
    return DEFAULT_STYLE

def style_line():
    style = run_style().rstrip(".。 ")
    guard = " Never photorealistic or 3D render." if re.search(r"anime|2D|cel-shad|动画|动漫|二次元|赛璐璐", style, re.I) else ""
    return style + "." + guard
NEG_VID = ("Exactly five fingers per hand, no extra hands or limbs, no disembodied hands entering the frame, no text, no subtitles, "
           "no license plate lettering, no readable signs, no jump cuts: one continuous shot, keep every character's face, hair and outfit identical to the first frame. "
           "Follow the shot's explicitly described camera viewpoint (third-person, first-person POV, over-shoulder or insert); do not change viewpoint mid-shot. Nobody stands or walks in a traffic lane in front of a moving vehicle. "
           "Any speech or exclamation is Mandarin Chinese only; never English words. "
           "Clean picture: no subtitles, captions, on-screen text or watermark anywhere. Sound: ambient sound effects only, no music.")
DIALOGUE_LOCK = ("Voice lock: the only audible human voice in the whole clip is the exact quoted line(s) above, nothing added: no extra words, "
                 "interjections, grunts or laughter; characters without a line make no vocal sound; any smile or laugh in the action is silent, facial only.")
SILENT_LOCK = "Voice lock: nobody speaks in this clip; no human voice at all, only ambient sound effects."
NEG_IMG = ("Exactly five fingers per hand, no extra hands or limbs, no text, no subtitles, no watermark, no license plate lettering, "
           "signboards blank or abstract with no readable characters. Follow the shot's explicitly described camera viewpoint; do not change viewpoint mid-shot. "
           "Every person's position is physically plausible (nobody standing in a traffic lane in front of a moving vehicle).")

def log(*a):
    with lock:
        print(time.strftime("[%Y-%m-%d %H:%M:%S]"), *a, flush=True)

def load_state():
    try: return json.load(open(STATE))
    except Exception: return {"since": time.time(), "jobs": {}, "outfits_en": {}}
state = load_state(); state.setdefault("outfits_en", {})
if len(sys.argv) > 2 and sys.argv[1] == "--since":
    state["since"] = float(sys.argv[2])
def save_state():
    with lock:
        tmp = STATE + ".tmp"
        json.dump(state, open(tmp, "w"), ensure_ascii=False, indent=1)
        os.replace(tmp, STATE)
def jstate(jid):
    with lock: return state["jobs"].setdefault(jid, {})

def write_report():
    with lock:
        rep = {jid: {k: st.get(k) for k in ("type", "status", "tries", "chosen", "qa_pass", "qa_status", "softened", "dialogue")}
               for jid, st in state["jobs"].items() if st.get("type") == "video"}
        tmp = REPORT + ".tmp"; json.dump(rep, open(tmp, "w"), ensure_ascii=False, indent=1); os.replace(tmp, REPORT)

class ApiError(Exception):
    def __init__(self, msg, status=0, moderation=False, transient=True):
        super().__init__(msg); self.status, self.moderation, self.transient = status, moderation, transient

MOD_RE = re.compile(r"moderat|content polic|safety|not allowed|violat|inappropriate|blocked|flagged", re.I)

def http(method, url, body=None, timeout=300):
    data = json.dumps(body).encode() if body is not None else None
    req = urllib.request.Request(url, data=data, method=method, headers={"Authorization": f"Bearer {KEY}", "Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return json.loads(r.read().decode() or "{}")
    except urllib.error.HTTPError as e:
        text = e.read().decode(errors="replace")[:600].replace(KEY, "***") if KEY else ""
        mod = bool(MOD_RE.search(text))
        raise ApiError(f"HTTP {e.code}: {text}", e.code, moderation=mod, transient=(e.code in (408, 409, 429) or e.code >= 500))
    except Exception as e:
        raise ApiError(f"{type(e).__name__}: {e}"[:300])

def data_uri(path, max_side=1536):
    from PIL import Image
    im = Image.open(path).convert("RGB")
    if max(im.size) > max_side:
        s = max_side / max(im.size); im = im.resize((round(im.width * s), round(im.height * s)), Image.LANCZOS)
    buf = io.BytesIO(); im.save(buf, "JPEG", quality=93)
    return "data:image/jpeg;base64," + base64.b64encode(buf.getvalue()).decode()

# ---------- character cards ----------
EN_NAMES = {"劫匪老大": "Lao Da", "老大": "Lao Da"}

def en_name(name):
    if name in EN_NAMES: return EN_NAMES[name]
    from pypinyin import lazy_pinyin
    py = lazy_pinyin(name)
    return " ".join(p.capitalize() for p in py) if len(py) <= 3 else name

def load_cards():
    cards = {}
    for path in glob.glob(f"{RUN}/角色/*/card.json"):
        try: card = json.load(open(path))
        except Exception: continue
        name = card.get("name") or os.path.basename(os.path.dirname(path))
        for outfit in card.get("outfits") or [{}]:
            txt = "，".join(outfit.get(k, "") for k in ("upper", "lower", "shoes", "accessories") if outfit.get(k))
            txt = re.sub(r"[，,、]?\s*手持[^，,。]*", "", txt)  # v4: props (pistol) are per-shot 持物, not outfit
            anchor = (outfit.get("views") or {}).get("anchor")
            cards.setdefault(name, []).append({"name": name, "en": en_name(name), "label": outfit.get("label", ""), "outfit": txt,
                                               "anchor": os.path.join(RUN, anchor) if anchor else None})
    return cards

def outfit_en(c):
    key = hashlib.sha1((c["name"] + "|" + c["outfit"]).encode()).hexdigest()[:16]
    with lock:
        if key in state["outfits_en"]: return state["outfits_en"][key]
    try:
        txt = chat("Translate this Chinese clothing description of an anime character into a short precise English outfit description (garments, colors, materials, collar/hood type, accessories). Output only the description, no preamble.", c["outfit"])
        txt = re.sub(r"\s+", " ", txt).strip().rstrip(".")
    except ApiError:
        return c["outfit"]
    with lock: state["outfits_en"][key] = txt
    save_state(); return txt

def chars_for(job, cards):
    zh = job.get("prompt", "")
    found = []
    def add(name, label=""):
        opts = cards.get(name)
        if not opts: return
        pick = next((o for o in opts if label and o["label"] and o["label"] in label), opts[0])
        if pick not in found: found.append(pick)
    if job["type"] == "video":
        m = re.search(r"出场[：:]([^。\n]*)", zh)
        for n in re.split(r"[、，,\s]+", m.group(1) if m else ""):
            add(n.strip())
    else:
        for name, label in re.findall(r"角色「([^」·]+)(?:·([^」]*))?」", zh):
            add(name, label)
        # v4: never add cast from the segment-level 站位 line (it names people who are not in this shot)
        m = re.search(r"人物[：:]([^\n]*)", zh)
        for name in cards:
            if m and re.search(r"图\d+的" + re.escape(name), m.group(1)): add(name)
    return found

def strip_blocking(zh, chars):
    """Drop the segment-level 站位 clause when it names a card character who is not in this shot."""
    present = {c["name"] for c in chars} if chars and isinstance(chars[0], dict) and "name" in chars[0] else set()
    def fix(m):
        txt = m.group(0)
        others = [n for n in load_cards() if n in txt and n not in present]
        return "" if others else txt
    return re.sub(r"站位[：:][^\n]*?。(?:。)?", fix, zh)

TRAIT_KINDS = [  # same kinds as Toonflow traits.ts
    ("tattoo", re.compile(r"纹身|花臂|刺青|tattoo", re.I), "tattoos", "clean bare arms and skin with no tattoos at all"),
    ("scar", re.compile(r"疤|scar", re.I), "scars", "no scars"),
    ("mole", re.compile(r"痣|mole", re.I), "a facial mole", "no facial mole"),
    ("glove", re.compile(r"手套|glove", re.I), "gloves", "bare hands, no gloves"),
    ("glasses", re.compile(r"眼镜|墨镜|glasses", re.I), "glasses", "no glasses"),
    ("earring", re.compile(r"耳环|耳钉|耳饰|earring", re.I), "earrings", "no earrings"),
    ("beard", re.compile(r"胡子|胡须|胡茬|络腮|beard|stubble", re.I), "a beard or stubble", "clean-shaven"),
]

def card_traits():
    """{name: set(kinds)} from every card (invariant + all outfits)."""
    out = {}
    for path in glob.glob(f"{RUN}/角色/*/card.json"):
        try: card = json.load(open(path))
        except Exception: continue
        inv = card.get("invariant") or {}
        texts = [str(inv.get(k, "")) for k in ("face", "hair", "body", "marks")]
        for o in card.get("outfits") or []:
            texts += [str(o.get(k, "")) for k in ("marks", "upper", "lower", "shoes", "accessories")]
        txt = "；".join(texts)
        out[card.get("name")] = {k for k, rx, _, _ in TRAIT_KINDS if rx.search(txt)}
    return out

def trait_block(chars):
    """English exclusivity rules, e.g. 'Only Lao Wu has tattoos; Xiao Feng has clean bare arms ...'. Cast-wide ownership."""
    if not chars: return ""
    owners_all = card_traits(); rules = []
    names = [c["name"] for c in chars]
    for key, _, en, bare in TRAIT_KINDS:
        owners = [n for n, ks in owners_all.items() if key in ks]
        if not owners: continue
        bare_here = [n for n in names if key not in owners_all.get(n, set())]
        if not bare_here: continue
        here = [n for n in names if n in owners]
        if here:
            rules.append(f"Only {' and '.join(en_name(n) for n in here)} {'have' if len(here) > 1 else 'has'} {en}; "
                         + "; ".join(f"{en_name(n)} ({n}) has {bare}" for n in bare_here))
        else:  # v4: never name an absent character (it made models add him)
            rules.append("; ".join(f"{en_name(n)} ({n}) has {bare}" for n in bare_here))
    if len(names) > 1:
        rules.append("Each character keeps only their own marks, clothing and accessories; never transfer a tattoo, scar, glove or garment from one character to another; arms of different people never merge")
    return ("Character traits (strict): " + ". ".join(rules) + ".") if rules else ""

def trait_text(chars):
    return trait_block(chars).replace("Character traits (strict): ", "")

def outfit_block(chars):
    if not chars: return ""
    parts = [f"{c['en']} ({c['name']}) wears {(lambda t: t[:1].lower() + t[1:])(outfit_en(c))}" for c in chars]
    return "Outfits, same outfit in every shot, exactly as in the reference/first frame: " + "; ".join(parts) + "."

# ---------- dialogue ----------
def parse_dialogue(zh):
    m = re.search(r"台词[：:](.*?)(?:。音效|。保持|\n|$)", zh, re.S)
    if not m: return []
    out = []
    for speaker, how, line in re.findall(r"([^\s：:；;“”（）。]{1,8})(?:（([^）]*)）)?(?:说|喊|道|问|吼|低语|旁白|画外音)[：:]“(.*?)”", m.group(1)):
        out.append({"speaker": speaker, "how": how, "line": line})
    if not out:
        out = [{"speaker": "", "how": "", "line": l} for l in re.findall(r"“(.*?)”", m.group(1))]
    return out

def short_sentences(line):
    parts = [p for p in re.split(r"(?<=[，。！？；—…,!?])", line.replace("——", "，")) if p.strip()]
    return " ".join(p.strip() for p in parts)

def dialogue_block(dlg, variant):
    if not dlg: return ""
    rows = []
    for d in dlg:
        who = f"{en_name(d['speaker'])} ({d['speaker']})" if d["speaker"] else "The character"
        line = short_sentences(d["line"]) if variant == "lang" else d["line"]
        rows.append(f'{who} speaks Mandarin Chinese (Putonghua) only, clear Mandarin voice, natural lip sync, says: "{line}"')
    head = "Dialogue, spoken in Mandarin Chinese only (no English, no Japanese): " if variant == "lang" else "Dialogue: "
    tail = " All speech is Mandarin Chinese (Putonghua) with lips moving in sync." if variant == "lang" else ""
    return head + " Then ".join(r + "." for r in rows) + tail

# ---------- translation ----------
SYS_IMG = """You convert Chinese storyboard prompts for an ANIME short film into one concise English prompt for the Grok Imagine image model.
Rules: output ONLY the prompt text, no preamble. Do not write any style sentence at the start (it is added separately). Never use photoreal/realistic/live-action/photo/3D wording (replace with anime equivalents).
Keep every concrete detail: framing, lens/angle, setting, time, mood, staging (who is left/right), each character's appearance, outfit (exactly as written, do not invent other clothing), pose, action, gaze, focus, props. Every character listed must be visibly in frame; nobody else.
Exception: for characters listed under "Fixed appearance", write only the name exactly as given there plus pose, action, gaze, expression and what this shot explicitly changes (mask on, jacket off, wounds, wet). Never restate or paraphrase their face, hair, body or regular clothing: one fixed wording per character is appended verbatim to every shot, and a second wording makes the character drift.
Reference images: refer to them ONLY with the tags given in the mapping (e.g. <IMAGE_1>), saying what to take from each (character identity/face/hair/outfit, or the scene layout and lighting without its people). Do not mention references that are not in the mapping.
State "no text, no subtitles, no watermark, no license plate lettering". End with an "Avoid:" list translated from 避免 plus: extra fingers, extra hands, photorealism, 3D render. Max ~220 words.
The 持物 (holding) line is authoritative: if it says a hand is empty (空), that hand holds nothing, even if a character description mentions a prop such as a pistol. Mention only the people listed under 人物 (people named only in a 站位 note are NOT in this shot).
Write it as a film still: every character is ALREADY in the middle of the action (e.g. "already mid-stride", "already pulling the door open"), not a sequence of steps.
Staging: positions only as screen-left / screen-center / screen-right, tied to one named anchor object in the scene with an approximate distance in meters and a facing direction (e.g. "screen-right, 1 m from the van's sliding door, facing the cash truck"); never vague words like "nearby" or "in the room". One light source with one shadow direction.
Drop any trait constraint (特征约束) sentence that names a character who is not in this shot; prefer positive wording (say what IS there).
Glossary: 面包车 = a white minivan / panel van (NEVER "bread van", no bread anywhere); 押运车 = armored cash-transport truck; 劫匪 = masked robbers; 老大 = the gang boss (Lao Da); 老五 = gang member Lao Wu; 萧枫 = Xiao Feng."""
SYS_VID = """You convert a Chinese shot description for an ANIME short film into concise English for the Grok Imagine image-to-video model (the first frame is given as an image).
Rules: output ONLY the prompt text. Do not write any style sentence (added separately). Never use photoreal/realistic/live-action/3D wording.
Include in order: camera move and framing; who is in the shot; the action beat by beat; sound effects; the end state of the shot.
Describe each beat as a state the character is already in ("already mid-swing", "already turning the wheel hard") rather than a chain of steps (reach, pull out, raise). Positions only as screen-left/right relative to a named anchor object.
A character who speaks must keep physically doing something while talking (driving, checking a weapon, glancing at the mirror); nobody stands still and talks for more than about 3 seconds.
Drop any trait constraint (特征约束) sentence that names a character who is not in this shot.
Do NOT write out any dialogue text: where a character speaks, write only "<Name> speaks his line (see Dialogue below)" with the delivery/emotion. Max ~130 words.
Glossary: 面包车 = a white minivan / panel van (NEVER "bread van"); 押运车 = armored cash-transport truck; 劫匪 = masked robbers; 老大 = the gang boss (Lao Da); 老五 = gang member Lao Wu; 萧枫 = Xiao Feng."""
SOFT = """
IMPORTANT: a previous version was rejected by content moderation. Keep the story beat faithful but tone it down: no blood, no gore, no visible wounds, no weapons pointed at anyone's head or stabbing contact; imply violence through reactions, motion blur, impact flashes, cutaway framing and aftermath; describe weapons neutrally (e.g. "a handgun held at his side") and threats as tense confrontation. Keep it stylized anime action."""
SOFT2 = """
STRONGER SOFTENING (second moderation rejection): show NO weapon contact, NO blood, NO body falling dead on screen. Convey the beat through suspense: a glint of light, a sudden bright white flash filling the frame, a startled reaction, the attacker's cool expression; any collapse happens off-frame or is only suggested by a shadow dropping out of frame. Keep it stylized anime."""

def chat(system, user):
    last = None
    for attempt in range(4):
        try:
            r = http("POST", f"{API}/chat/completions", {"model": CHAT_MODEL, "messages": [{"role": "system", "content": system}, {"role": "user", "content": user}], "max_tokens": 1500}, timeout=180)
            txt = (r["choices"][0]["message"].get("content") or "").strip()
            if txt: return txt
            last = "empty"
        except ApiError as e:
            last = str(e)
        time.sleep(5 * (attempt + 1))
    raise ApiError(f"translation failed: {last}")

def select_refs(job):
    refs = (job.get("references") or {}).get("images") or []
    desc = dict((int(n), d.strip()) for n, d in re.findall(r"^图(\d+)[：:](.*)$", job.get("prompt", ""), re.M))
    items = [(i, p, desc.get(i, "")) for i, p in enumerate(refs, 1) if "上一镜" not in desc.get(i, "")]
    if len(items) > MAX_REFS:
        def prio(it):
            # anchors first, then face close-ups; the scene goes first when over the limit (it is also described in text)
            d = it[2]; return 2 if d.startswith("场景") else (1 if "特写" in d else 0)
        keep = sorted(items, key=prio)[:MAX_REFS]
        items = [it for it in items if it in keep]
    return items

ASSETS = f"{BASE}/assets"
def vehicle_ref(job):
    """laozhang: props as product-photo assets used as reference images. Returns [(n, path, desc)] or []."""
    vs = vehicles_for(job)
    v = next((x for x in vs if x["id"] == "van"), None)
    if not v: return []
    sel = json.load(open(f"{ASSETS}/selected.json")) if os.path.exists(f"{ASSETS}/selected.json") else {}
    interior = any(k in job.get("prompt", "") for k in ("van_interior", "车内", "驾驶座", "方向盘", "副驾")) and not any(k in job.get("prompt", "") for k in ("下车", "驶入", "急刹", "车尾"))
    path = sel.get("van_int" if interior else "van_ext")
    if not path or not os.path.exists(path): return []
    return [(90, path, "道具「面包车」产品参考图（" + ("车内" if interior else "车外") + "）：只参考车型、颜色、车身标记与内饰，不参考背景、光线和构图")]

def add_vehicle_ref(job, refs):
    """xAI image edits take at most 5 images. Make room: if the characters are masked, drop a face close-up of a character that also has an
    outfit-variant full-body ref; otherwise drop the scene ref (the scene is also described in text); never drop an outfit ref."""
    vr = vehicle_ref(job)
    if not vr or any("道具「面包车」" in d for _, _, d in refs): return refs
    if len(refs) >= MAX_REFS:
        zh = job.get("prompt", ""); drop = None
        if "面具" in zh:
            variants = {re.sub(r"·.*", "", m) for m in re.findall(r"角色「([^」]*·[^」]*)」", " ".join(d for _, _, d in refs))}
            drop = next((it for it in refs if "特写" in it[2] and any(f"「{v}」" in it[2] for v in variants)), None)
        drop = drop or next((it for it in refs if it[2].startswith("场景")), None) or refs[-1]
        refs = [it for it in refs if it is not drop]
    return refs + vr

def translate(job, refs, soft):
    chars = chars_for(job, load_cards())
    zh = strip_blocking(job.get("prompt", ""), chars)
    if job["type"] == "image":
        body = re.sub(r"【参考图说明】.*?(?=【画面】|\Z)", "", zh, flags=re.S).strip()
        mapping = "\n".join(f"<IMAGE_{k}> = {d or '参考图'}" for k, (_, _, d) in enumerate(refs, 1)) or "(no reference images)"
        fixed = ", ".join(f"{c['en']} ({c['name']})" for c in chars) or "none"
        user = f"Reference mapping (Chinese 图N correspond as follows: {', '.join(f'图{i}-><IMAGE_{k}>' for k, (i, _, _) in enumerate(refs, 1)) or 'none'}):\n{mapping}\n\nFixed appearance: {fixed}\n\nChinese prompt:\n{body}"
        sysm = SYS_IMG
    else:
        user = f"Chinese shot description ({job['params'].get('seconds')} seconds):\n{zh}"
        sysm = SYS_VID
    if soft: sysm += SOFT
    if soft >= 2: sysm += SOFT2
    try:
        return chat(sysm, user)
    except ApiError as e:
        log(job["id"], "translation fallback:", e)
        return re.sub(r"“.*?”", "(line, see Dialogue)", zh)

# ---------- v4: fixed vehicle/prop card ----------
VEHICLES_FILE = f"{RUN}/道具/vehicles.json"
def vehicle_cards():
    try: return json.load(open(VEHICLES_FILE)).get("vehicles", [])
    except Exception: return []

def vehicles_for(job):
    zh = job.get("prompt", "")
    m = TAG_RE.search(zh); scene_id = ""; shot_txt = ""
    if m:
        try:
            b = json.load(open(STORYBOARD))
            for e in b.get("episodes", []):
                for sg in e.get("segments", []):
                    for sh in sg.get("shots", []):
                        if sh.get("id") == m.group(1):
                            scene_id = sg.get("sceneId", "")
                            shot_txt = json.dumps({k: sh.get(k) for k in ("firstFrame", "action", "description", "lastFrame") if sh.get(k)}, ensure_ascii=False)
        except Exception: pass
    txt = shot_txt or re.sub(r"站位[：:][^\n]*?。", "", zh)
    out = []
    for v in vehicle_cards():
        if scene_id in v.get("scenes", []) or "面包车与高桥" in zh and v["id"] == "van" or any(k in txt for k in v.get("match", [])):
            out.append(v)
    return out

def vehicle_block(job):
    vs = vehicles_for(job)
    if not vs: return ""
    neg = "; ".join(v["negative"] for v in vs if v.get("negative"))
    return "Vehicles (fixed props, identical in every shot): " + " ".join(v["en"] for v in vs) + (f" Never show: {neg}." if neg else "")

# ---------- root-cause fixes (QA calibration, see PROGRESS.md) ----------
def shot_dict(shot_id):
    try: b = json.load(open(STORYBOARD))
    except Exception: return {}
    for e in b.get("episodes", []):
        for sg in e.get("segments", []):
            for sh in sg.get("shots", []):
                if sh.get("id") == shot_id: return sh
    return {}

def glove_rule(chars):
    """Viewpoint-proof glove wording. v4 keyframes put 萧枫's glove on BOTH hands (E01-02-01 i1) or on the LEFT hand when he faces
    the camera (i2/i3: the model mirrors 'right hand' to screen-right)."""
    raw = card_raw(); out = []
    for c in chars:
        acc = json.dumps((raw.get(c["name"]) or {}).get("outfits", [{}])[:1], ensure_ascii=False)
        if "手套" not in acc: continue
        side = "RIGHT" if "右手" in acc else "LEFT" if "左手" in acc else None
        if not side: continue
        other = "LEFT" if side == "RIGHT" else "RIGHT"
        scr = "screen-LEFT" if side == "RIGHT" else "screen-RIGHT"
        out.append(f"{c['en']} wears exactly ONE black fingerless glove, on his own {side} hand only (when he faces the camera that is the hand on the {scr} side of the picture); his {other} hand is always bare skin; never gloves on both hands")
    return ("Glove rule: " + "; ".join(out) + ".") if out else ""

def no_glove_rule(chars, all_chars=None):
    raw = card_raw(); bare = [c["en"] for c in chars if "手套" not in json.dumps((raw.get(c["name"]) or {}).get("outfits", [{}])[:1], ensure_ascii=False)]
    return (", ".join(bare) + (" has" if len(bare) == 1 else " have") + " bare hands, no gloves.") if bare and len(chars) > 1 else ""

def hands_block(job, chars):
    """Per-shot hand contents from storyboard continuity. 老五's reference image holds a pistol, so without this he holds a gun even
    when the storyboard says his hands are empty (v3 E01-02-02, E01-03-02, E01-04-01 QA findings)."""
    sid = shot_for_image(job)
    cont = (shot_dict(sid) or {}).get("continuity") or {}
    ids = {c.get("id"): c for c in chars}; raw = card_raw(); lines = []
    for h in cont.get("hands") or []:
        c = next((x for x in chars if x.get("id") == h.get("id") or (raw.get(x["name"]) or {}).get("id") == h.get("id")), None)
        if not c: continue
        l, r = h.get("left") or "空", h.get("right") or "空"
        en = lambda v: "empty" if v in ("空", "", None) else ("a pistol" if "枪" in v else "the steering wheel" if "方向盘" in v else v)
        lines.append(f"{c['en']}: left hand {en(l)}, right hand {en(r)}" + (" (the pistol in his reference image is NOT held in this shot)" if "枪" not in l + r and "枪" in json.dumps(raw.get(c['name']) or {}, ensure_ascii=False) else ""))
    return ("Hands in this shot (storyboard continuity): " + "; ".join(lines) + ".") if lines else ""

SCENE_TERMS = [  # (trigger in the Chinese prompt, English clarification) — prompt wording only, chapter text untouched
    ("吊灯", "The 吊灯 is ONE plain industrial metal pendant lamp hanging on a chain; never a crystal chandelier, never several lamps."),
    ("警灯", "Police cars appear only behind/around the gang's white bread van; the van itself never has police livery or a light bar."),
]
def scene_terms(job):
    p = job.get("prompt", "")
    return " ".join(en for k, en in SCENE_TERMS if k in p)

def fix_block(job, chars):
    if os.environ.get("NO_RC_FIXES") == "1": return ""
    return " ".join(x for x in (glove_rule(chars), no_glove_rule(chars), hands_block(job, chars), scene_terms(job)) if x)

def compose(job, body, chars, dlg, variant="normal", fixes=""):
    if job["type"] == "image":
        return " ".join(x for x in (style_line(), body, outfit_block(chars), trait_block(chars), fix_block(job, chars), vehicle_block(job), NEG_IMG) if x)
    parts = [style_line(), body, outfit_block(chars), trait_block(chars), fix_block(job, chars), vehicle_block(job)]
    if fixes: parts.append("Avoid these problems seen in a previous attempt: " + fixes + ".")
    if variant == "lang":
        parts += [NEG_VID, dialogue_block(dlg, variant)]
    else:
        parts += [dialogue_block(dlg, variant), NEG_VID]
    parts.append(DIALOGUE_LOCK if dlg else SILENT_LOCK)
    return " ".join(p for p in parts if p)

# ---------- generation ----------
def gen_image(job, prompt, refs):
    p = job.get("params", {})
    body = {"model": IMAGE_MODEL, "prompt": prompt, "aspect_ratio": p.get("aspect_ratio") or "9:16", "resolution": "1.5k", "quality": "medium", "response_format": "b64_json", "n": 1}
    if refs:
        body["images"] = [{"url": data_uri(path), "type": "image_url"} for _, path, _ in refs]
        r = http("POST", f"{API}/images/edits", body, timeout=400)
    else:
        r = http("POST", f"{API}/images/generations", body, timeout=400)
    d = (r.get("data") or [{}])[0]
    if d.get("respect_moderation") is False or not d.get("b64_json"):
        raise ApiError(f"image filtered/empty: {json.dumps({k: v for k, v in d.items() if k != 'b64_json'})[:200]}", moderation=d.get("respect_moderation") is False, transient=d.get("respect_moderation") is not False)
    raw = base64.b64decode(d["b64_json"])
    ext = ".png" if raw[:8] == b"\x89PNG\r\n\x1a\n" else ".webp" if raw[8:12] == b"WEBP" else ".jpg"
    out = f"{OUT}/{job['id']}{ext}"
    open(out, "wb").write(raw)
    return out

def gen_video(job, cur, out, refs=()):
    """cur: {model, prompt, request_id?} persisted in state so a restart resumes polling."""
    p = job.get("params", {})
    ff = (job.get("references") or {}).get("first_frame")
    if not cur.get("request_id"):
        body = {"model": cur["model"], "prompt": cur["prompt"], "duration": int(p.get("seconds") or 8), "resolution": p.get("resolution") or "720p",
                "aspect_ratio": p.get("aspect_ratio") or "9:16", "generate_audio": p.get("generate_audio", True) is not False}
        if ff: body["image"] = {"url": data_uri(ff, 1920)}
        if refs and cur["model"] == VIDEO_MODEL:
            body["reference_images"] = [{"url": data_uri(path, 1280)} for _, path, _ in refs]
        r = http("POST", f"{API}/videos/generations", body, timeout=300)
        cur["request_id"] = r["request_id"]; save_state()
        log(job["id"], "video submitted", cur["model"], f"{body['duration']}s")
    rid, t0, errs = cur["request_id"], time.time(), 0
    while time.time() - t0 < 3600:
        time.sleep(10)
        try:
            r = http("GET", f"{API}/videos/{rid}", timeout=60); errs = 0
        except ApiError as e:
            if not e.transient or e.moderation:
                cur.pop("request_id", None); save_state(); raise
            errs += 1
            if errs > 20: cur.pop("request_id", None); save_state(); raise
            continue
        s = r.get("status")
        if s == "done":
            v = r.get("video") or {}
            if v.get("respect_moderation") is False or not v.get("url"):
                cur.pop("request_id", None); save_state()
                raise ApiError("video filtered by moderation", moderation=True, transient=False)
            urllib.request.urlretrieve(v["url"], out)
            return out
        if s in ("failed", "expired"):
            cur.pop("request_id", None); save_state()
            err = json.dumps(r.get("error") or r)[:400]
            raise ApiError(f"video {s}: {err}", moderation=bool(MOD_RE.search(err)), transient=not MOD_RE.search(err))
    cur.pop("request_id", None); save_state()
    raise ApiError("video poll timeout")

def finish(jid, out, st):
    res = subprocess.run(["python3", f"{RELAY}/finish.py", jid, out], capture_output=True, text=True)
    log(jid, "finish:", (res.stdout + res.stderr).strip()[:300])
    st["status"] = "done" if res.returncode == 0 else "finish_error"; st["file"] = out; save_state(); write_report()

def fail(jid, st, reason):
    res = subprocess.run(["python3", f"{RELAY}/fail.py", jid, reason[:300]], capture_output=True, text=True)
    log(jid, "FAILED ->", (res.stdout + res.stderr).strip()[:300])
    st["status"] = "failed"; st["reason"] = reason[:300]; save_state(); write_report()

def run_image(job, st):
    jid = job["id"]; refs = select_refs(job); chars = chars_for(job, load_cards())
    if os.environ.get("NO_VEHICLE_REF") != "1": refs = add_vehicle_ref(job, refs)
    soft = st.get("soft", 0); attempts = 0; last = ""
    while attempts < 4 and soft <= 3:
        attempts += 1
        try:
            if not st.get("prompt") or st.get("prompt_soft") != soft:
                st["prompt"] = compose(job, translate(job, refs, soft), chars, []); st["prompt_soft"] = soft; save_state()
            log(jid, f"try {attempts} soft={soft} refs={[i for i, _, _ in refs]} chars={[c['name'] for c in chars]} prompt: {st['prompt'][:300]!r}")
            return finish(jid, image_with_qa(job, st, refs, chars), st)
        except ApiError as e:
            last = str(e); log(jid, "error:", last[:400])
            if e.moderation:
                soft += 1; st["soft"] = soft; st["softened"] = True; save_state(); attempts -= 1 if soft <= 3 else 0; continue
            time.sleep(15 * attempts)
        except Exception as e:
            last = f"{type(e).__name__}: {e}"; log(jid, "exception:", traceback.format_exc()[-600:]); time.sleep(15 * attempts)
    fail(jid, st, ("moderation: " if soft > 3 else "") + last)

def image_with_qa(job, st, refs, chars):
    """v4: keyframe stills go through qa2 (hand crops + card traits); up to MAX_IMAGE_QA_TRIES, best kept."""
    jid = job["id"]
    if not chars:
        return gen_image(job, st["prompt"], refs)
    raw = card_raw(); ids = [raw[c["name"]]["id"] for c in chars if c["name"] in raw and raw[c["name"]].get("id")]
    tries = st.setdefault("img_tries", [])
    base_prompt = st["prompt"]
    while len(tries) < MAX_IMAGE_QA_TRIES:
        fixes = qa2_fixes(tries[-1]["issues_full"], chars) if tries else []
        prompt = " ".join(x for x in (base_prompt, look_block(chars), ("Avoid: " + "; ".join(fixes) + ".") if fixes else "") if x)
        out = gen_image(job, prompt, refs)
        k = len(tries) + 1; keep = f"{OUT}/{jid}_i{k}{os.path.splitext(out)[1]}"; shutil.copyfile(out, keep)
        wd = f"{QADIR}/{jid}_i{k}"; shutil.rmtree(wd, ignore_errors=True); os.makedirs(wd, exist_ok=True)
        sid = shot_for_image(job); si = shot_info(sid, wd) if sid else None
        if si:
            info = si[0]; d = si[1]; d["shot"] = dict(d["shot"], characters=[{"id": i} for i in ids] or d["shot"].get("characters", []))
            json.dump(d, open(info, "w"), ensure_ascii=False, indent=1)
        else:
            info = f"{wd}/info.json"; json.dump({"shot": {"characters": [{"id": i} for i in ids], "firstFrame": job.get("prompt", "")[-800:]}}, open(info, "w"), ensure_ascii=False)
        q2 = run_qa2(keep, info, wd, image=True)
        full = (q2.get("report") or {}).get("issues") or [{"issue": i} for i in q2.get("issues", [])]
        tries.append({"file": keep, "pass": bool(q2.get("pass")), "issues": q2.get("issues", []), "issues_full": full}); save_state()
        log(jid, f"image QA try {k}: pass={q2.get('pass')} issues={q2.get('issues')}")
        if q2.get("pass"): break
    best = max(range(len(tries)), key=lambda i: (tries[i]["pass"], -len(tries[i]["issues"]), -i))
    st["img_chosen"] = best + 1; final = f"{OUT}/{jid}{os.path.splitext(tries[best]['file'])[1]}"
    _sid = shot_for_image(job); _rep = {}
    try: _rep = json.load(open(f"{QADIR}/{jid}_i{best + 1}/qa2.json"))
    except Exception: pass
    log(jid, f"IMAGE_QA_FINAL shot={_sid} chosen={best + 1}/{len(tries)} pass={tries[best]['pass']} status={_rep.get('status', 'unknown')} issues={tries[best]['issues']}")
    shutil.copyfile(tries[best]["file"], final)
    return final

# ---------- v4: looks, shot info, qa2 ----------
def card_raw():
    out = {}
    for path in glob.glob(f"{RUN}/角色/*/card.json"):
        try: c = json.load(open(path)); out[c.get("name")] = c
        except Exception: pass
    return out

def look_block(chars):
    """Side-specific identity rules (hair colour, marks with side, glove hand) translated once per character and cached."""
    raw = card_raw(); lines = []
    for c in chars:
        card = raw.get(c["name"]) or {}; inv = card.get("invariant") or {}; outfits = card.get("outfits") or [{}]
        o = next((x for x in outfits if c.get("label") and x.get("label") == c["label"]), outfits[0])
        src = f"发型：{inv.get('hair','')}；标记：{inv.get('marks','') or '无'}；脸：{inv.get('face','')}；配饰：{o.get('accessories','')}；上衣：{o.get('upper','')}"
        key = "look|" + hashlib.sha1((c["name"] + src).encode()).hexdigest()[:16]
        with lock: txt = state["outfits_en"].get(key)
        if not txt:
            try:
                txt = chat("Translate this Chinese anime character identity description into one short precise English sentence fragment. Keep hair colour, every mark and its exact side (left/right as the character's own side), which hand wears a glove, tattoos or their absence. Output only the fragment.", src)
                txt = re.sub(r"\s+", " ", txt).strip().rstrip(".")
                with lock: state["outfits_en"][key] = txt
                save_state()
            except ApiError: txt = ""
        if txt: lines.append(f"{c['en']}: {txt}")
    return ("Identity (identical in every frame): " + "; ".join(lines) + ".") if lines else ""

def shot_for_image(job):
    """Keyframe jobs carry no shot tag: find the storyboard shot whose firstFrame text is in the prompt (so QA sees continuity/extras)."""
    m = TAG_RE.search(job.get("prompt", ""))
    if m: return m.group(1)
    try: b = json.load(open(STORYBOARD))
    except Exception: return None
    p = job.get("prompt", ""); best = None
    for e in b.get("episodes", []):
        for sg in e.get("segments", []):
            for sh in sg.get("shots", []):
                ff = (sh.get("firstFrame") or "").strip()
                if len(ff) >= 8 and ff[:24] in p and (best is None or len(ff) > best[1]): best = (sh["id"], len(ff))
    return best[0] if best else None

def shot_info(shot_id, wd):
    try: b = json.load(open(STORYBOARD))
    except Exception: return None
    prev = None
    for e in b.get("episodes", []):
        for sg in e.get("segments", []):
            sc = next((x for x in b.get("scenes", []) if x.get("id") == sg.get("sceneId")), {})
            for sh in sg.get("shots", []):
                if sh.get("id") == shot_id:
                    info = {"shotId": shot_id, "segmentId": sg["id"], "shot": sh, "prevShot": prev,
                            "scene": f"{sc.get('name','')}：{sc.get('description','')}；站位：{sg.get('blocking','')}"}
                    os.makedirs(wd, exist_ok=True); path = f"{wd}/info.json"
                    json.dump(info, open(path, "w"), ensure_ascii=False, indent=1); return path, info
                prev = sh.get("id")
    return None

def run_qa2(media, info_path, wd, prev=None, image=False):
    cmd = [QA2_PY, QA2, media, info_path, "--out", f"{wd}/qa2.json"]
    if prev and os.path.exists(prev): cmd += ["--prev", prev]
    if image: cmd.append("--image")
    env = dict(os.environ, QA_STORYBOARD=STORYBOARD)
    try:
        res = subprocess.run(cmd, capture_output=True, text=True, timeout=2400, env=env)
        line = next((l for l in reversed(res.stdout.strip().splitlines()) if l.strip().startswith("{")), None)
        out = json.loads(line) if line else {"pass": False, "score": 0, "issues": [f"qa2_error: {(res.stderr or '')[-200:]}"]}
    except Exception as e:
        out = {"pass": False, "score": 0, "issues": [f"qa2_error: {type(e).__name__}: {e}"[:200]]}
    try: out["report"] = json.load(open(f"{wd}/qa2.json"))
    except Exception: pass
    return out

def qa2_fixes(issues, chars):
    raw = card_raw(); fixes = []
    for it in issues:
        txt = it.get("issue", "") if isinstance(it, dict) else str(it)
        if txt.startswith("qa2_error"): continue
        if "手指" in txt: fixes.append("six fingers, an extra thumb or malformed hands (every hand has exactly five fingers: one thumb and four fingers)")
        elif "纹身" in txt: fixes.append("tattoos on the wrong character (only " + " and ".join(en_name(n) for n, c in raw.items() if re.search("纹身|花臂", json.dumps(c, ensure_ascii=False))) + " has tattoos; everyone else has bare clean forearms)")
        elif "手套" in txt: fixes.append("the glove on the wrong hand (" + "; ".join(f"{en_name(n)} wears it on the {'RIGHT' if '右手' in json.dumps(c, ensure_ascii=False) else 'LEFT'} hand only" for n, c in raw.items() if "手套" in json.dumps(c, ensure_ascii=False)) + ")")
        elif "黑痣" in txt: fixes.append("the black mole on Lao Da's LEFT cheek missing; it is always visible")
        elif "发色" in txt: fixes.append("a character's hair colour changing; keep each character's exact hair colour")
        elif "持枪手" in txt: fixes.append("the gun switching hands; the gun stays in the same hand for the whole shot as described")
        elif "前排" in txt: fixes.append("three people in the front row of the car; only the driver and one front passenger sit in front, anyone else sits in the back seat behind them")
        elif "不应出现" in txt: fixes.append("a character appearing who is not in this shot")
        elif "尸体" in txt: fixes.append("extra dead bodies that are not described")
        elif txt.startswith("异常物体"): fixes.append("unexpected element: " + txt.split("：", 1)[-1][:120])
    return list(dict.fromkeys(fixes))[:6]

def plan_next(st):
    """Variant/model/fixes for the next QA try based on previous results (v4: alternate models every try)."""
    tries = st.get("tries", []); n = len(tries)
    lang_fail = any(t.get("qa", {}).get("lang_fail") for t in tries)
    variant = "lang" if lang_fail else "normal"
    model = VIDEO_MODEL if n % 2 == 0 or st.get("seconds", 8) > 10 else ALT_VIDEO_MODEL
    fixes = []
    for t in tries[-1:]:
        qa = t.get("qa", {})
        for r in qa.get("reasons", []):
            if r.startswith("qa2:"): continue
            if r.startswith("not anime"): fixes.append("frames turning photorealistic or 3D CGI; the whole clip must stay flat 2D cel-shaded anime")
            elif r.startswith("outfit"): fixes.append("a character's clothing changing; keep the exact outfit described above")
            elif r == "bad_fingers": fixes.append("six or missing fingers")
            elif r == "extra_hands": fixes.append("an extra disembodied hand or arm entering the frame")
            elif r == "garbled_text": fixes.append("garbled text or license plate lettering")
            elif r == "unexpected_people": fixes.append("extra people not described")
            elif r == "jump_cut" or r.startswith("hard cut"): fixes.append("jump cuts or teleporting; one smooth continuous take")
            elif r == "trait_bleed": fixes.append("a character showing another character's tattoo, scar or clothing; follow the character trait rules exactly")
            elif r == "first_person_pov": fixes.append("camera viewpoint may not match the shot contract; follow the explicitly specified viewpoint and keep it consistent throughout the shot")
            elif r == "spatial_problem": fixes.append("implausible staging (people standing in front of a moving vehicle, tangled arms, characters in the wrong place); keep positions physically plausible and as described")
            elif r.startswith("non-Mandarin") or r.startswith("english words"): fixes.append("English words or exclamations in the audio; all voices must be Mandarin Chinese or wordless")
        fixes += qa2_fixes((qa.get("qa2") or {}).get("issues_full") or [], [])
    return variant, model, "; ".join(dict.fromkeys(fixes))

def ref_line(refs):
    """refs: [(n, path, desc)] continuation references; <IMAGE_0> is the pinned first frame."""
    if not refs: return ""
    parts = ["<IMAGE_0> is the exact first frame of this shot"]
    for k, (_, _, d) in enumerate(refs, 1):
        if "上一镜" in d or "结尾" in d:
            parts.append(f"<IMAGE_{k}> is an end frame of the PREVIOUS shot, use it only to keep lighting, character positions, wounds and which hand holds which object consistent (do not copy its framing)")
        else:
            nm = next((en_name(n) for n in card_raw() if n and n in d), None)
            parts.append(f"<IMAGE_{k}> is the identity reference of {nm}" if nm else f"<IMAGE_{k}> is a reference image")
    return "Reference images: " + "; ".join(parts) + "."

def video_refs(job, zh):
    imgs = (job.get("references") or {}).get("images") or []
    desc = dict((int(n), d.strip()) for n, d in re.findall(r"^图(\d+)[：:](.*)$", zh, re.M))
    return [(i, p, desc.get(i, "")) for i, p in enumerate(imgs, 1)][:6]

def run_video(job, st):
    jid = job["id"]; zh_raw = job.get("prompt", "")
    m = TAG_RE.search(zh_raw); shot_id = m.group(1) if m else None
    refs = video_refs(job, zh_raw)
    zh = LEGEND_RE.sub("", TAG_RE.sub("", zh_raw)).strip()
    vjob = dict(job, prompt=zh)
    chars = chars_for(vjob, load_cards()); dlg = parse_dialogue(zh)
    st["shot"] = shot_id; st["seconds"] = int((job.get("params") or {}).get("seconds") or 8)
    st["dialogue"] = [d["line"] for d in dlg]; st.setdefault("tries", [])
    soft = st.get("soft", 0); errors = 0; last = ""
    while len(st["tries"]) < MAX_QA_TRIES and soft <= 3 and errors < 4:
        cur = st.get("cur")
        try:
            if not cur or cur.get("soft") != soft:
                variant, model, fixes = plan_next(st)
                if not st.get("body") or st.get("body_soft") != soft:
                    st["body"] = translate(vjob, [], soft); st["body_soft"] = soft
                prompt = compose(vjob, st["body"], chars, dlg, variant, fixes)
                use_refs = model == VIDEO_MODEL and refs
                prompt = " ".join(x for x in (ref_line(refs) if use_refs else "", look_block(chars), prompt) if x)
                cur = st["cur"] = {"model": model, "variant": variant, "fixes": fixes, "soft": soft, "refs": bool(use_refs), "prompt": prompt}
                save_state()
            k = len(st["tries"]) + 1
            log(jid, f"try {k} shot={shot_id} model={cur['model']} refs={len(refs) if cur.get('refs') else 0} variant={cur['variant']} soft={soft} chars={[c['name'] for c in chars]} prompt: {cur['prompt'][:400]!r}")
            out = gen_video(job, cur, f"{OUT}/{jid}_t{k}.mp4", refs if cur.get("refs") else [])
            wd = f"{QADIR}/{jid}_t{k}"; shutil.rmtree(wd, ignore_errors=True); os.makedirs(wd, exist_ok=True)
            try:
                qa = video_qa.check(out, chars, zh, st["dialogue"], wd, trait_text(chars))
            except Exception as e:
                # QA transport/model failure is an abstention, never a silent pass.
                qa = {"pass": False, "score": 0.0, "reasons": [], "qa_error": f"{type(e).__name__}: {e}"[:200]}
            si = shot_info(shot_id, wd) if shot_id else None
            qa_primary = dict(qa)  # 保留主 QA 原始结论，避免后续合并结果污染来源归因
            if si:
                prev = f"{BASE}/qa2/final/{si[1]['prevShot']}.json" if si[1].get("prevShot") else None
                q2 = run_qa2(out, si[0], wd, prev)
                full = (q2.get("report") or {}).get("issues") or [{"issue": i} for i in q2.get("issues", [])]
                qa["qa2"] = {"pass": q2.get("pass"), "score": q2.get("score"), "issues": q2.get("issues", []), "issues_full": full}
                qa["reasons"] = list(qa.get("reasons", [])) + [f"qa2:{i}" for i in q2.get("issues", [])]
                qa["score"] = min(float(qa.get("score") or 0), float(q2.get("score") or 0))
                qa["unified"] = normalize_qa(qa_primary, q2, shot_id=shot_id or "")
            else:
                qa["unified"] = normalize_qa(qa_primary, {}, shot_id=shot_id or "")
            # Unified arbiter owns execution semantics: abstain is neither pass nor fail.
            qa["qa_status"] = qa["unified"]["status"]
            qa["pass"] = qa["qa_status"] == "pass"
            reason_text = " ".join(str(item).lower() for item in qa["unified"].get("hardFailures", []))
            failure_codes = []
            for code, terms in {
                "identity": ("identity", "face", "character mismatch", "串脸", "身份不一致"), "cast": ("unexpected_people", "extra people", "cast", "额外人物", "出场人物"),
                "vehicle": ("vehicle", "车型", "车辆", "car model"), "style": ("not anime", "style", "画风"),
                "viewpoint": ("first_person_pov", "viewpoint", "pov", "视角"), "audio_language": ("language", "non-mandarin", "english words", "语言错误", "非普通话"),
                "dialogue_match": ("transcript mismatch", "dialogue", "台词不匹配"), "hands": ("bad_fingers", "extra_hands", "finger", "手指", "手部"),
                "continuity": ("continuity", "hand swap", "position", "连续性", "换手"), "anatomy": ("anatomy", "limb", "肢体"),
            }.items():
                if any(term in reason_text for term in terms): failure_codes.append(code)
            qa["repairPlan"] = route_failures(qa["qa_status"], failure_codes)
            st["tries"].append({"file": out, "model": cur["model"], "refs": cur.get("refs"), "variant": cur["variant"], "soft": soft, "fixes": cur["fixes"], "qa": qa, "wd": wd})
            st.pop("cur", None); save_state(); write_report()
            log(jid, f"QA try {k}: pass={qa.get('pass')} score={qa.get('score')} reasons={qa.get('reasons')} audio={qa.get('audio')}")
            if qa.get("qa_status") in ("pass", "abstain"):
                if qa.get("qa_status") == "abstain":
                    log(jid, "QA abstain: stop automatic retries and require manual review / re-check")
                break
            if qa.get("repairPlan", {}).get("requiresHuman"):
                log(jid, "QA failure routes to manual/audio-only repair; stop video regeneration to avoid changing a correct picture")
                break
            prior_auto_failures = sum(1 for item in st["tries"] if item.get("qa", {}).get("qa_status") == "fail" and not item.get("qa", {}).get("repairPlan", {}).get("requiresHuman"))
            if prior_auto_failures >= 2:
                log(jid, "Reached the v5 limit of two targeted automatic repair attempts; manual review required")
                break
        except ApiError as e:
            last = str(e); log(jid, "error:", last[:400])
            if e.moderation:
                soft += 1; st["soft"] = soft; st["softened"] = True; st.pop("cur", None); save_state(); continue
            errors += 1; time.sleep(20 * errors)
        except Exception as e:
            last = f"{type(e).__name__}: {e}"; errors += 1
            log(jid, "exception:", traceback.format_exc()[-600:]); time.sleep(20 * errors)
    if st["tries"]:
        def rank(i):
            q = st["tries"][i]["qa"]
            status_rank = {"pass": 2, "abstain": 1, "fail": 0}.get(q.get("qa_status"), 0)
            return (status_rank, -len((q.get("qa2") or {}).get("issues") or []), float(q.get("score") or 0), -i)
        best = max(range(len(st["tries"])), key=rank)
        st["chosen"] = best + 1; st["qa_pass"] = bool(st["tries"][best]["qa"].get("pass")); st["qa_status"] = st["tries"][best]["qa"].get("qa_status", "abstain")
        log(jid, f"chosen try {best + 1}/{len(st['tries'])} qa_pass={st['qa_pass']}")
        dst = f"{OUT}/{jid}.mp4"; shutil.copyfile(st["tries"][best]["file"], dst)
        if shot_id and os.path.exists(f"{st['tries'][best]['wd']}/qa2.json"):
            os.makedirs(f"{BASE}/qa2/final", exist_ok=True)
            shutil.copyfile(f"{st['tries'][best]['wd']}/qa2.json", f"{BASE}/qa2/final/{shot_id}.json")
        return finish(jid, dst, st)
    fail(jid, st, ("moderation: " if soft > 3 else "") + last)

def run_job(job):
    st = jstate(job["id"]); st["type"] = job["type"]
    if job["type"] == "video" and os.environ.get("WORKER_IMAGE_ONLY") == "1":
        # v5run: video must go to ai& MiniMax H3, never xAI video; a video job here means a mis-configured videoModel
        return fail(job["id"], st, "v5run worker is image-only (WORKER_IMAGE_ONLY=1): videoModel must be aiand/minimaxai/minimax-h3, not grokRelay")
    (run_video if job["type"] == "video" else run_image)(job, st)

def main():
    if not KEY: sys.exit("XAI_API_KEY missing")
    if not os.environ.get("NEBIUS_API_KEY"): log("WARNING: NEBIUS_API_KEY missing, visual QA will error")
    for d in (OUT, QADIR): os.makedirs(d, exist_ok=True)
    save_state()
    log("art style:", style_line())
    log(f"worker v5run start (image_only={os.environ.get('WORKER_IMAGE_ONLY')}, base={BASE}, relay={RELAY}); jobs after {time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(state['since']))}; image={IMAGE_MODEL} video={VIDEO_MODEL}/{ALT_VIDEO_MODEL}; concurrency={CONCURRENCY}")
    threading.Thread(target=video_qa.whisper, daemon=True).start()  # preload whisper
    pool = ThreadPoolExecutor(CONCURRENCY); active = set()
    while True:
        try:
            for name in sorted(os.listdir(f"{RELAY}/queue")):
                if not name.endswith(".json") or name.count(".") != 1: continue
                jid = name[:-5]
                if jid in active or os.path.exists(f"{RELAY}/done/{name}"): continue
                try: job = json.load(open(f"{RELAY}/queue/{name}"))
                except Exception: continue
                if job.get("created_ts", 0) < state["since"]: continue
                if state["jobs"].get(jid, {}).get("status") in ("done", "failed", "finish_error"): continue
                active.add(jid)
                def wrap(j=job):
                    try: run_job(j)
                    except Exception: log(j["id"], "fatal:", traceback.format_exc()[-600:])
                    finally: active.discard(j["id"])
                pool.submit(wrap)
                log(jid, "picked", job["type"], json.dumps(job.get("params", {}), ensure_ascii=False))
        except Exception:
            log("loop error", traceback.format_exc()[-400:])
        time.sleep(5)

if __name__ == "__main__":
    main()
