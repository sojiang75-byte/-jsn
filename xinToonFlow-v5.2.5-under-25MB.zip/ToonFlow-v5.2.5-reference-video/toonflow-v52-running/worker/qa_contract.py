#!/usr/bin/env python3
"""Normalize legacy visual/video QA and qa2 results into one auditable contract.

This adapter deliberately distinguishes fail from abstain. A missing model reply,
transport error, or malformed payload is never treated as a pass.
"""
from typing import Any, Dict, List

CHECK_KEYS = ("identity", "cast", "vehicle", "style", "viewpoint", "continuity",
              "audio_language", "dialogue_match", "hands", "anatomy")

def _issues(value: Any) -> List[str]:
    if not isinstance(value, list):
        return []
    out = []
    for item in value:
        if isinstance(item, dict):
            item = item.get("issue") or item.get("reason") or item.get("message") or str(item)
        out.append(str(item)[:300])
    return out

def normalize_qa(video_qa: Dict[str, Any] | None, qa2: Dict[str, Any] | None,
                 *, shot_id: str = "", contract_version: str = "v5") -> Dict[str, Any]:
    video_qa = video_qa if isinstance(video_qa, dict) else {}
    qa2 = qa2 if isinstance(qa2, dict) else {}
    video_error = bool(video_qa.get("qa_error") or video_qa.get("visual_error") or
                       "visual_qa_error" in (video_qa.get("reasons") or []))
    qa2_error = any(str(x).startswith("qa2_error") for x in _issues(qa2.get("issues")))
    abstentions = []
    if video_error:
        abstentions.append({"source": "video_qa", "reason": str(video_qa.get("qa_error") or video_qa.get("visual_error") or "visual QA unavailable")[:300]})
    if qa2_error or not qa2:
        abstentions.append({"source": "qa2", "reason": "QA2 unavailable or returned an error"})
    if video_qa.get("hands_error") or video_qa.get("hands_grok_error"):
        abstentions.append({"source": "hands", "reason": str(video_qa.get("hands_error") or video_qa.get("hands_grok_error"))[:300]})
    if video_qa.get("audio_error") and video_qa.get("dialogue_expected"):
        abstentions.append({"source": "audio", "reason": str(video_qa.get("audio_error"))[:300]})
    video_failed = video_qa.get("pass") is False
    qa2_failed = qa2.get("pass") is False and not qa2_error
    hard = []
    if video_failed and not video_error:
        hard.extend(_issues(video_qa.get("reasons")))
    if qa2_failed:
        hard.extend(_issues(qa2.get("issues")))
    if hard:
        status = "fail"
    elif abstentions:
        status = "abstain"
    elif video_qa.get("pass") is True and qa2.get("pass") is True:
        status = "pass"
    else:
        status = "abstain"
        abstentions.append({"source": "arbiter", "reason": "Insufficient evidence to decide"})
    checks = {key: {"status": "not_checked"} for key in CHECK_KEYS}
    visual = video_qa.get("visual") if isinstance(video_qa.get("visual"), dict) else {}
    if "style" in visual:
        checks["style"] = {"status": "pass" if float(visual.get("style") or 0) >= 0.7 else "fail",
                           "confidence": float(visual.get("style") or 0)}
    if "first_person_pov" in visual:
        checks["viewpoint"] = {"status": "fail" if visual.get("first_person_pov") else "pass"}
    if "bad_fingers" in visual or "extra_hands" in visual:
        bad = bool(visual.get("bad_fingers") or visual.get("extra_hands"))
        checks["hands"] = {"status": "fail" if bad else "pass"}
    return {
        "shotId": shot_id,
        "contractVersion": contract_version,
        "status": status,
        "hardFailures": list(dict.fromkeys(hard)),
        "softIssues": [],
        "abstentions": abstentions,
        "checks": checks,
        "evidence": {"videoQa": video_qa, "qa2": qa2},
    }
