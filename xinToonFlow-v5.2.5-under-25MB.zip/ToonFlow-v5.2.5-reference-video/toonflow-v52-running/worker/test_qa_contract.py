import unittest
from qa_contract import normalize_qa

class UnifiedQATests(unittest.TestCase):
    def test_both_pass(self):
        result = normalize_qa({"pass": True, "score": .9}, {"pass": True, "score": .95}, shot_id="E01-01-01")
        self.assertEqual(result["status"], "pass")
    def test_visual_failure(self):
        result = normalize_qa({"pass": False, "reasons": ["style mismatch"]}, {"pass": True})
        self.assertEqual(result["status"], "fail")
        self.assertIn("style mismatch", result["hardFailures"])
    def test_empty_or_error_is_abstain_not_pass(self):
        result = normalize_qa({"pass": False, "qa_error": "timeout"}, {"pass": False, "issues": ["qa2_error: timeout"]})
        self.assertEqual(result["status"], "abstain")
        self.assertFalse(result["hardFailures"])
    def test_missing_qa2_is_abstain(self):
        result = normalize_qa({"pass": True}, {})
        self.assertEqual(result["status"], "abstain")

if __name__ == "__main__":
    unittest.main()

def test_both_qa_pass_is_required_for_pass():
    result = normalize_qa({"pass": True, "reasons": []}, {"pass": True, "issues": []})
    assert result["status"] == "pass"

def test_qa2_failure_is_hard_failure():
    result = normalize_qa({"pass": True, "reasons": []}, {"pass": False, "issues": ["vehicle mismatch"]})
    assert result["status"] == "fail"
    assert "vehicle mismatch" in result["hardFailures"]

def test_hand_model_error_causes_abstain_not_pass():
    result = normalize_qa({"pass": True, "reasons": [], "hands_error": "timeout"}, {"pass": True, "issues": []})
    assert result["status"] == "abstain"
    assert result["abstentions"][0]["source"] == "hands"
