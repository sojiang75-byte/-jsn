#!/usr/bin/env python3
"""Video QA for generated shots (v3, run fx3): Nemotron frame checks (style / outfit / hands / trait bleed / first-person POV /
spatial staging / text / people / cuts), a dedicated per-frame finger + extra-limb count, ffmpeg hard-cut check, and faster-whisper
speech-language check on EVERY shot (dialogue shots must match the Mandarin lines; no shot may contain English speech).
No keys are printed or logged."""
import base64, io, json, os, re, subprocess, tempfile, threading, time, urllib.request, urllib.error
import numpy as np

NEBIUS_URL = os.environ.get("NEBIUS_BASE_URL", "https://api.tokenfactory.nebius.com/v1").rstrip("/") + "/chat/completions"
NEBIUS_KEY = os.environ.get("NEBIUS_API_KEY", "").strip()
VL_MODEL = "nvidia/Nemotron-3.5-Super-VL"
WHISPER_MODEL = os.environ.get("QA_WHISPER_MODEL", "medium")
_whisper = None; _wlock = threading.RLock()

def run(cmd):
    return subprocess.run(cmd, capture_output=True, text=True)

def duration(path):
    r = run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "default=nw=1:nk=1", path])
    try: return float(r.stdout.strip())
    except Exception: return 0.0

def sample_times(d):
    ts = {0.15, d / 2, max(0.0, d - 0.15)}
    t = 2.0
    while t < d - 0.5:
        ts.add(t); t += 2.0
    out = []
    for x in sorted(ts):
        if not out or x - out[-1] >= 0.6 or x == max(ts): out.append(round(x, 2))
    if len(out) >= 2 and out[-1] - out[-2] < 0.6: out.pop(-2)
    return out

def extract_frames(path, outdir):
    d = duration(path); frames = []
    for i, t in enumerate(sample_times(d)):
        f = os.path.join(outdir, f"f{i:02d}_{t:05.2f}.jpg")
        run(["ffmpeg", "-nostdin", "-v", "error", "-y", "-ss", str(t), "-i", path, "-frames:v", "1", "-vf", "scale=-2:768", "-q:v", "3", f])
        if os.path.exists(f): frames.append((t, f))
    return d, frames

def scene_cuts(path, thr=0.45):
    """Hard cuts inside the clip (ffmpeg scene score), ignoring the first/last 0.3 s."""
    r = run(["ffmpeg", "-nostdin", "-v", "info", "-i", path, "-an", "-vf", f"select='gt(scene,{thr})',showinfo", "-f", "null", "-"])
    d = duration(path)
    ts = [float(x) for x in re.findall(r"pts_time:([\d.]+)", r.stderr)]
    return [t for t in ts if 0.3 < t < d - 0.3]

def b64img(path, max_side=768):
    from PIL import Image
    im = Image.open(path).convert("RGB")
    if max(im.size) > max_side:
        s = max_side / max(im.size); im = im.resize((round(im.width * s), round(im.height * s)))
    buf = io.BytesIO(); im.save(buf, "JPEG", quality=88)
    return "data:image/jpeg;base64," + base64.b64encode(buf.getvalue()).decode()

def tile(paths, h=640):
    from PIL import Image
    ims = [Image.open(p).convert("RGB") for p in paths]
    ims = [im.resize((round(im.width * h / im.height), h)) for im in ims]
    W = sum(im.width for im in ims) + 12 * (len(ims) - 1)
    canvas = Image.new("RGB", (W, h), (255, 255, 255)); x = 0
    for im in ims: canvas.paste(im, (x, 0)); x += im.width + 12
    buf = io.BytesIO(); canvas.save(buf, "JPEG", quality=88)
    return "data:image/jpeg;base64," + base64.b64encode(buf.getvalue()).decode()

def extract_json(text):
    m = re.search(r"```(?:json)?\s*(.*?)```", text, re.S); body = m.group(1) if m else text
    s = body.find("{"); depth = 0; ins = False; i = s
    while 0 <= i < len(body):
        c = body[i]
        if ins:
            if c == "\\": i += 1
            elif c == '"': ins = False
        elif c == '"': ins = True
        elif c == "{": depth += 1
        elif c == "}":
            depth -= 1
            if depth == 0: return json.loads(body[s:i + 1])
        i += 1
    raise ValueError("no json")

def nemotron(system, content, retries=3):
    last = None
    for a in range(retries):
        body = {"model": VL_MODEL, "messages": [{"role": "system", "content": system}, {"role": "user", "content": content}],
                "max_tokens": 1500, "temperature": 0, "reasoning_effort": "none", "response_format": {"type": "json_object"}}
        req = urllib.request.Request(NEBIUS_URL, data=json.dumps(body).encode(), method="POST",
                                     headers={"Authorization": f"Bearer {NEBIUS_KEY}", "Content-Type": "application/json"})
        try:
            with urllib.request.urlopen(req, timeout=240) as r:
                txt = json.loads(r.read().decode())["choices"][0]["message"].get("content") or ""
            return extract_json(txt)
        except urllib.error.HTTPError as e:
            last = f"HTTP {e.code}: {e.read().decode(errors='replace')[:200]}"
            if e.code == 400 and "response_format" in last and "response_format" in body: pass
        except Exception as e:
            last = f"{type(e).__name__}: {e}"[:200]
        time.sleep(5 * (a + 1))
    raise RuntimeError(f"nemotron failed: {last}")

VIS_SYS = """You are a strict QA reviewer for a 2D Japanese anime (cel-shaded, hand-drawn look) short film.
You get: character reference sheets (with the outfit each character must wear), then several frames sampled in order from ONE continuous generated video shot (labelled with their timestamps).
Check every frame carefully and report:
- style: 1.0 if ALL frames are 2D cel-shaded anime; lower it a lot if any frame looks photorealistic, live-action, or like a 3D CGI render (list those frame timestamps in photoreal_frames).
- outfit: for each named character visible, does the clothing (jacket/coat type, collar, hood, color, material) match the reference and the outfit text? A hoodie or leather jacket instead of a high-collar zip jacket is a mismatch (score <= 0.3). Use 1.0 if the character is not visible in any frame.
- hands: count fingers on every visible hand. Report six or more / fused / missing fingers in bad_fingers (true/false), and any extra hand or arm (e.g. a disembodied hand or a hand holding a gun entering from the frame edge that belongs to nobody in the shot) in extra_hands (true/false).
- text: garbled_text true if there is any visible pseudo-text, gibberish letters, license plate lettering or subtitles.
- trait_bleed: true if a character shows a mark/garment that belongs to ANOTHER character according to the trait rules given (e.g. the rules say only Lao Wu has tattoos and Xiao Feng has tattoos on his arms). Check bare arms and hands carefully.
- first_person_pov: true only if a first-person / point-of-view shot is NOT requested by the shot description. If the description explicitly requests POV/first-person, this is intentional and must be false. A hand/gun entering from the edge is not itself an error when the shot description calls for that POV. If intent is unclear, set false and explain uncertainty in issues rather than treating POV as a defect.
- spatial_problem: true if the staging is physically implausible or contradicts the described positions: people standing or walking in a traffic lane in front of a moving vehicle on a highway/overpass, characters floating, passing through objects, a character outside a vehicle when described inside it, or arms tangled/merged between two people.
- people: unexpected_people true only if a person who is not described in the shot appears (masked robbers/police/background crowd described in the shot are expected).
- continuity: jump_cut true if consecutive frames show an abrupt discontinuity of the same subject (a character teleports / pose or position jumps impossibly / a different camera setup) rather than smooth motion.
Output ONLY one JSON object: {"style":0-1,"photoreal_frames":[seconds],"outfit":{"<name>":0-1},"bad_fingers":bool,"extra_hands":bool,"trait_bleed":bool,"first_person_pov":bool,"spatial_problem":bool,"garbled_text":bool,"unexpected_people":bool,"jump_cut":bool,"issues":["short english description with timestamp"]}"""

HAND_SYS = """You are an anatomy checker for anime frames. For EACH image, find every visible human hand and count its fingers (thumb included) carefully, one by one.
Report a hand as bad if it has six or more fingers, fewer than five fingers when the whole hand is visible (not occluded), fused or melted fingers.
Also report extra limbs: more than two arms/hands for one person, a hand or arm that belongs to nobody (enters from the frame edge with no body), or arms of two people merged/tangled into one.
Output ONLY JSON: {"frames":[{"index":0,"hands":[{"fingers":5,"bad":false}],"extra_limbs":false,"note":""}],"bad_fingers":bool,"extra_hands":bool,"issues":["short english description with frame index"]}"""

XAI_KEY = os.environ.get("XAI_API_KEY", "").strip()
GROK_HAND_SYS = """Before answering, for each hand list every digit from one side to the other (thumb, index, middle, ring, little), noting that a thumb is short, thick and attached at the side/base of the palm, while the four long fingers start at the knuckle line. If you see five long fingers at the knuckle line (whether or not a thumb is visible), the hand has six digits and is bad.
You are an anatomy checker for anime frames. For every visible human hand, count the fingers including the thumb. A hand is bad if it has six or more fingers, fused/melted fingers, or fewer than five when fully visible. Also flag extra limbs (a hand/arm belonging to nobody, more than two arms for one person, two people's arms merged or tangled).
Output ONLY JSON: {"hands":[{"whose":"","digits":["thumb","index"],"long_fingers_at_knuckles":0,"fingers":0,"bad":false}],"bad_fingers":false,"extra_hands":false,"issues":[""]}"""

def grok_hand(path):
    body = {"model": "grok-4.3", "max_tokens": 1500, "messages": [{"role": "system", "content": GROK_HAND_SYS}, {"role": "user", "content": [
        {"type": "image_url", "image_url": {"url": b64img(path, 1024), "detail": "high"}}, {"type": "text", "text": "Check this frame."}]}]}
    last = None
    for a in range(3):
        req = urllib.request.Request("https://api.x.ai/v1/chat/completions", data=json.dumps(body).encode(), method="POST",
                                     headers={"Authorization": f"Bearer {XAI_KEY}", "Content-Type": "application/json"})
        try:
            with urllib.request.urlopen(req, timeout=180) as r:
                return extract_json(json.loads(r.read().decode())["choices"][0]["message"].get("content") or "")
        except urllib.error.HTTPError as e:
            last = f"HTTP {e.code}"
        except Exception as e:
            last = type(e).__name__
        time.sleep(5 * (a + 1))
    raise RuntimeError(f"grok hand check failed: {last}")

def grok_hands(frames):
    """Second opinion on fingers/limbs with grok-4.3 vision, one frame per call, about every second of the clip."""
    if not XAI_KEY or not frames: return {}
    from concurrent.futures import ThreadPoolExecutor
    with ThreadPoolExecutor(4) as pool:
        outs = list(pool.map(lambda f: (f[0], grok_hand(f[1])), frames))
    bad, extra, issues = False, False, []
    for t, o in outs:
        hands = [h for h in o.get("hands") or [] if isinstance(h, dict)]
        b = o.get("bad_fingers") is True or any(h.get("bad") is True or (isinstance(h.get("fingers"), (int, float)) and h["fingers"] > 5)
                                                or (isinstance(h.get("long_fingers_at_knuckles"), (int, float)) and h["long_fingers_at_knuckles"] > 4) for h in hands)
        e = o.get("extra_hands") is True
        if b or e: issues.append(f"{t:.1f}s: " + "; ".join(str(x) for x in (o.get("issues") or [])[:2]))
        bad, extra = bad or b, extra or e
    return {"bad_fingers": bad, "extra_hands": extra, "issues": issues[:4]}

def dense_frames(path, outdir, step=1.0):
    d = duration(path); out = []; t = 0.3
    while t < d - 0.1:
        f = os.path.join(outdir, f"h_{t:05.2f}.jpg")
        run(["ffmpeg", "-nostdin", "-v", "error", "-y", "-ss", str(t), "-i", path, "-frames:v", "1", "-vf", "scale=-2:1024", "-q:v", "2", f])
        if os.path.exists(f): out.append((t, f))
        t += step
    return out

def hands_check(frames):
    """Dedicated finger/limb count on up to 4 frames at higher resolution (one image per frame, no tiling)."""
    if not frames: return {"bad_fingers": False, "extra_hands": False}
    idx = sorted({0, len(frames) // 3, (2 * len(frames)) // 3, len(frames) - 1})
    content = []
    for k, i in enumerate(idx):
        content.append({"type": "text", "text": f"Image index {k} (t={frames[i][0]:.1f}s):"})
        content.append({"type": "image_url", "image_url": {"url": b64img(frames[i][1], 1024)}})
    content.append({"type": "text", "text": "Count the fingers now and return the JSON."})
    out = nemotron(HAND_SYS, content)
    bad = out.get("bad_fingers") is True or any(h.get("bad") is True or (isinstance(h.get("fingers"), (int, float)) and h["fingers"] > 5)
                                                for f in out.get("frames") or [] if isinstance(f, dict) for h in f.get("hands") or [] if isinstance(h, dict))
    extra = out.get("extra_hands") is True or any(isinstance(f, dict) and f.get("extra_limbs") is True for f in out.get("frames") or [])
    return {"bad_fingers": bool(bad), "extra_hands": bool(extra), "issues": (out.get("issues") or [])[:4]}

def visual_check(frames, chars, description, traits=""):
    content = [{"type": "text", "text": "Character references:"}]
    for c in chars:
        if c.get("anchor") and os.path.exists(c["anchor"]):
            content.append({"type": "text", "text": f"Reference for {c['name']} ({c.get('en','')}). Required outfit: {c.get('outfit_en') or c.get('outfit','')}"})
            content.append({"type": "image_url", "image_url": {"url": b64img(c["anchor"], 640)}})
    if traits: content.append({"type": "text", "text": f"Trait rules (each character keeps only their own marks): {traits}"})
    content.append({"type": "text", "text": f"Shot description (Chinese): {description[:1200]}\nFrames from the generated video follow."})
    nref = sum(1 for c in content if c["type"] == "image_url")
    budget = max(2, 8 - nref)
    group = 1
    while -(-len(frames) // group) > budget: group += 1
    for i in range(0, len(frames), group):
        chunk = frames[i:i + group]
        if len(chunk) == 1:
            content.append({"type": "text", "text": f"Frame at {chunk[0][0]:.1f}s:"})
            content.append({"type": "image_url", "image_url": {"url": b64img(chunk[0][1])}})
        else:
            content.append({"type": "text", "text": "Frames side by side, left to right at " + ", ".join(f"{t:.1f}s" for t, _ in chunk) + " (separate frames, not one picture):"})
            content.append({"type": "image_url", "image_url": {"url": tile([f for _, f in chunk])}})
    names = [c["name"] for c in chars]
    content.append({"type": "text", "text": f"Return the JSON now. outfit keys must be exactly: {names}"})
    return nemotron(VIS_SYS, content)

def whisper():
    global _whisper
    with _wlock:
        if _whisper is None:
            from faster_whisper import WhisperModel
            _whisper = WhisperModel(WHISPER_MODEL, device="cpu", compute_type="int8", cpu_threads=4)
    return _whisper

HALLUCINATION = re.compile(r"thank(s| you) for watching|please subscribe|subtitles? by|字幕|请不吝点赞|订阅|明镜|^\s*(thank you|thanks)[.!]?\s*$", re.I)

def audio_check(path):
    raw = run_bytes(["ffmpeg", "-nostdin", "-v", "error", "-i", path, "-vn", "-ac", "1", "-ar", "16000", "-f", "f32le", "-"])
    a = np.frombuffer(raw, np.float32)
    if a.size < 16000: return {"language": None, "prob": 0, "text": "", "note": "no audio"}
    with _wlock:
        m = whisper()
        segs, info = m.transcribe(a, beam_size=5, vad_filter=True)
        segs = [s for s in segs if s.no_speech_prob < 0.6]
        # 常见的静音幻觉（字幕组/感谢观看之类）不算台词
        text = "".join(s.text for s in segs if not HALLUCINATION.search(s.text)).strip()
    return {"language": info.language, "prob": round(float(info.language_probability), 3), "text": text}

def run_bytes(cmd):
    return subprocess.run(cmd, capture_output=True).stdout

def _py(s):
    from pypinyin import lazy_pinyin
    s = re.sub(r"[^\u4e00-\u9fff0-9A-Za-z]", "", s)
    return " ".join(lazy_pinyin(s))

def line_match(expected_lines, text):
    """Fuzzy match of the transcript against the intended lines, on toneless pinyin (robust to homophones / traditional chars)."""
    from rapidfuzz import fuzz
    exp = _py("".join(expected_lines)); got = _py(text)
    if not exp: return 1.0
    if not got: return 0.0
    return round(max(fuzz.partial_ratio(exp, got), fuzz.token_set_ratio(exp, got)) / 100, 3)

LATIN_WORD = re.compile(r"[A-Za-z]{2,}")

def check(video, chars, description, dialogue_lines, workdir, traits=""):
    """Return dict with pass flag, score (0-1, higher better) and reasons."""
    os.makedirs(workdir, exist_ok=True)
    d, frames = extract_frames(video, workdir)
    res = {"duration": round(d, 2), "frames": [t for t, _ in frames], "reasons": []}
    score = 1.0
    v = None
    for attempt in range(2):
        try:
            v = visual_check(frames, chars, description, traits); res["visual"] = v; res.pop("visual_error", None); break
        except Exception as e:
            res["visual_error"] = str(e)[:200]
    if v is None:
        res["reasons"].append("visual_qa_error"); score -= 0.3
    else:
        style = float(v.get("style", 1) or 0)
        if style < 0.7: res["reasons"].append(f"not anime style ({style}) frames {v.get('photoreal_frames')}"); score -= 0.35
        for n, s in (v.get("outfit") or {}).items():
            try: s = float(s)
            except Exception: continue
            if s < 0.6: res["reasons"].append(f"outfit mismatch {n} ({s})"); score -= 0.2
    try:
        h = hands_check(frames); res["hands"] = h
    except Exception as e:
        h = {}; res["hands_error"] = str(e)[:200]
    try:
        g = grok_hands(dense_frames(video, workdir, 1.0 if d <= 10 else 1.5)); res["hands_grok"] = g
        h = {"bad_fingers": h.get("bad_fingers") is True or g.get("bad_fingers") is True, "extra_hands": h.get("extra_hands") is True or g.get("extra_hands") is True,
             "issues": (h.get("issues") or [])[:2] + (g.get("issues") or [])[:3]}
    except Exception as e:
        res["hands_grok_error"] = str(e)[:200]
    v = v or {}
    flags = {"bad_fingers": v.get("bad_fingers") is True or h.get("bad_fingers") is True,
             "extra_hands": v.get("extra_hands") is True or h.get("extra_hands") is True}
    for k in ("trait_bleed", "first_person_pov", "spatial_problem", "garbled_text", "unexpected_people", "jump_cut"):
        flags[k] = v.get(k) is True
    # POV is evaluated against the shot contract, not a global third-person-only rule.
    requested_pov = bool(re.search(r"(第一人称|主观视角|POV|first[- ]person|subjective camera)", description, re.I)) and not bool(re.search(r"(禁止|不要|避免|不得).{0,10}(第一人称|主观视角|POV|first[- ]person)", description, re.I))
    if requested_pov:
        flags["first_person_pov"] = False
        v["first_person_pov"] = False
    for k, pen in (("bad_fingers", 0.3), ("extra_hands", 0.3), ("trait_bleed", 0.3), ("first_person_pov", 0.3), ("spatial_problem", 0.25),
                   ("garbled_text", 0.1), ("unexpected_people", 0.15), ("jump_cut", 0.15)):
        if flags[k]: res["reasons"].append(k); score -= pen
    issues = (v.get("issues") or [])[:6] + (h.get("issues") or [])[:3]
    if res["reasons"] and issues: res["issues"] = issues
    cuts = scene_cuts(video)
    if cuts:
        res["cuts"] = cuts; res["reasons"].append(f"hard cut at {cuts}"); score -= 0.15
    try:
        a = audio_check(video); res["audio"] = a
        latin = LATIN_WORD.findall(a.get("text") or "")
        if dialogue_lines:
            a["match"] = line_match(dialogue_lines, a["text"])
            if a["language"] != "zh":
                res["reasons"].append(f"language {a['language']} not zh"); res["lang_fail"] = True; score -= 0.5
            elif a["match"] < 0.45:
                res["reasons"].append(f"transcript mismatch ({a['match']}): {a['text'][:60]}"); res["lang_fail"] = True; score -= 0.3
            elif len(latin) >= 2:
                res["reasons"].append(f"english words in speech: {' '.join(latin[:6])}"); res["lang_fail"] = True; score -= 0.3
        elif a.get("text") and a["language"] not in (None, "zh") and a.get("prob", 0) >= 0.5 and len(latin) >= 2:
            # 无台词镜头也不能出现英文喊叫（如 “What the!”）
            res["reasons"].append(f"non-Mandarin speech ({a['language']}): {a['text'][:60]}"); res["lang_fail"] = True; score -= 0.4
    except Exception as e:
        res["audio_error"] = str(e)[:200]
    res["score"] = round(max(0.0, score), 3)
    res["pass"] = not res["reasons"]
    return res
