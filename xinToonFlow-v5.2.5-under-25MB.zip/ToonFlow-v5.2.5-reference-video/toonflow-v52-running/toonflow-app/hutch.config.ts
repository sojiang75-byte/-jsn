export default {
  packageManager: "bun",
};
