/**
 * 固定道具/车辆卡：同一辆车（类型、颜色、车型、标记）在所有镜头中保持一致。
 * 镜头文本命中关键词或场景属于该道具时，把道具卡描述注入首帧/视频/尾帧提示词，并把易混淆的其它车型写进负面提示。
 */
import type { Segment, Shot, Storyboard } from "./schema";

export type PropCard = NonNullable<Storyboard["props"]>[number];

/** 本镜涉及的道具卡（按卡片顺序）。站位（段级）文本不参与匹配：它可能描述本镜之外的时刻。 */
export function shotPropCards(props: PropCard[] | undefined, segment: Pick<Segment, "sceneId">, shot: Shot): PropCard[] {
  if (!props?.length) return [];
  const text = [shot.firstFrame, shot.action, shot.endFrame, ...(shot.props ?? [])].filter(Boolean).join(" ");
  return props.filter(card => (card.scenes ?? []).includes(segment.sceneId) || [card.name, ...(card.match ?? [])].some(word => word && text.includes(word)));
}

export function propLines(cards: PropCard[]) {
  return cards.map(card => `固定${card.kind === "vehicle" ? "车辆" : "道具"}「${card.name}」（每个镜头完全一致）：${card.description}`);
}

export function propNegatives(cards: PropCard[]) {
  return cards.map(card => card.negative?.trim()).filter((item): item is string => !!item);
}

/**
 * 道具/车辆产品照提示词（思路来自本地 H3 漫剧教程「道具拍成产品照」）：中性灰台面与背景、单一侧光、主体独立、3/4 前侧视角，
 * 不带人物与文字。生成的图作为参考图挂到命中该道具的镜头，用来锁定车型、颜色与标记（解决“面包车 / 警车”来回变的问题）。
 */
export function propProductPrompt(card: PropCard, style: string) {
  return [
    `${style}，道具参考图`,
    `${card.kind === "vehicle" ? "车辆" : "道具"}「${card.name}」单独摆放在中性灰色台面上，背后是纯中性灰背景`,
    "只有一个柔和的侧光从画面左侧打来，阴影统一落向画面右侧，曝光平整",
    card.kind === "vehicle" ? "车辆 3/4 前侧视角，平视，整车完整入画并留边" : "道具 3/4 视角，完整入画并留边",
    card.description,
    "画面中没有人物、没有其他车辆或物体、没有文字、标志和水印",
  ].join("。") + "。";
}

/** 本镜可挂载的道具参考图（只取已生成产品照的卡）。 */
export function shotPropImages(props: PropCard[] | undefined, segment: Pick<Segment, "sceneId">, shot: Shot) {
  return shotPropCards(props, segment, shot).filter(card => !!card.image).map(card => ({ path: card.image!, name: card.name }));
}
