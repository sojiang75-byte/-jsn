/**
 * 规划阶段：故事 → 剧本 → 角色卡/场景 → 分镜 JSON。每个 JSON 阶段都做 zod 结构校验与质量门检查，
 * 不通过时把错误列表回喂给模型修复（最多 repairAttempts 次）。
 */
import { z } from "zod";
import { characterCardSchema, type CharacterCard } from "@/utils/assets/characterCard";
import { extractJson } from "./scoring";
import type { TextModel } from "./llm";
import { iterateShots, parseStoryboard, sceneSchema, type Storyboard } from "./storyboard/schema";
import { applyContinuity, applyDeathEventsFromSource, continuityInstructions, continuityProblems, hasContinuity, propagateDeadStates } from "./storyboard/continuity";
import { cameraMoves, shotSizes, stabilities } from "./storyboard/vocab";
import { fillDurations, spokenUnits } from "./storyboard/timing";
import { gateFeedback, runGates, type GateContext, type GateResult } from "./storyboard/gates";
import { buildEpisodeMemoryPrompt, deriveCrossEpisodeMemory } from "./v5Continuity";
import { buildSourceLedger, hydrateStoryboardFromLedger, partitionSourceLedger, repairSourceLedgerAssignments, validateSourceLedger, type SourceLedger } from "./sourceLedger";

export const stageTag = (stage: "script" | "cast" | "storyboard") => `<!-- autoflow:${stage} -->`;

export interface PlanBrief {
  story: string;
  episodes: number;
  targetSeconds: number;
  aspectRatio: string;
  /** 单镜时长范围（来自分镜节奏参数）；缺省 2–10 秒 */
  shotSeconds?: { min: number; max: number };
  style?: string;
  language?: string;
  /** 提示词风格档追加的写作规则（如 H3 要求视觉字段用英文） */
  writingRule?: string;
  /** 原文保护模式：不允许编剧阶段改写章节，默认开启。 */
  preserveSourceText?: boolean;
  /** clip：1–4 秒镜头收成 5–15 秒素材。shot：一镜一次视频生成。 */
  rhythm?: "shot" | "clip";
}

/** 剧本模式的编剧要求。10 秒试拍和整集用同一套结构，字数按目标时长伸缩。 */
export function screenplayInstructions(brief: PlanBrief) {
  const seconds = brief.targetSeconds ?? 30;
  if (seconds <= 15) {
    return `${stageTag("script")}
你是短剧编剧。把故事改写成可拍摄的 ${seconds} 秒试拍剧本，不要逐字保留原文。
要求：一个主角、一个场景、一句短台词。开头就是冲突，不要风景和铺垫。心理活动全部改成看得见的动作，不要写「他想」。结尾停在一个还没做完的动作上。对白用「角色名：台词」。不要写镜头号。只输出剧本正文。`;
  }
  return `${stageTag("script")}
你是短剧编剧。把故事改写成可拍摄的分场剧本，不要逐字保留原文。
要求：共 ${brief.episodes} 集，每集约 ${seconds} 秒。台词合计 750–1000 字，口语短句。心理活动、内心独白全部改成可见动作，不要写「他想」。
开头 3 秒必须是冲突（动作或对白），不要风景铺垫。
结尾停在悬念：一个未回答的问题、一个未完成的动作，或下一集才会揭开的信息。
每场写明「场景名 / 时间 / 出场人物」，随后是动作与对白（角色名：台词）。人物 1–3 人。不要写镜头号。只输出剧本正文。`;
}

const withRule = (system: string, brief: PlanBrief) => brief.writingRule ? `${system}\n${brief.writingRule}` : system;

export async function writeScript(model: TextModel, brief: PlanBrief, signal?: AbortSignal) {
  // 小说/章节模式必须原样保留。分镜模型负责镜头创作，不负责改写源文本。
  if (brief.preserveSourceText !== false) {
    if (brief.story.trim().length < 2) throw new Error("原始章节为空");
    return brief.story;
  }
  const system = screenplayInstructions(brief);
  const text = await model.complete({ system, prompt: `故事：${brief.story}${brief.style ? `\n画风：${brief.style}` : ""}`, signal });
  if (text.trim().length < 20) throw new Error("模型返回的剧本为空");
  return text.trim();
}

const castSchema = z.strictObject({
  title: z.string().trim().min(1).max(120),
  logline: z.string().trim().max(500).optional(),
  style: z.string().trim().min(1).max(500),
  characters: z.array(characterCardSchema.omit({ version: true }).extend({ version: z.literal(1).default(1) })).min(1).max(12),
  scenes: z.array(sceneSchema.omit({ image: true })).min(1).max(50),
});
export type CastPlan = { title: string; logline?: string; style: string; characters: CharacterCard[]; scenes: z.infer<typeof castSchema>["scenes"] };

async function jsonStage<T>(model: TextModel, system: string, prompt: string, validate: (value: unknown) => { ok: true; data: T } | { ok: false; errors: string[] },
  repairAttempts: number, signal?: AbortSignal, log?: (message: string) => void,
  onAttempt?: (attempt: number, output: string, errors: string[]) => void | Promise<void>): Promise<T> {
  let lastErrors: string[] = [];
  let lastOutput = "";
  for (let attempt = 0; attempt <= repairAttempts; attempt++) {
    const request = attempt === 0 ? prompt
      : `${prompt}\n\n你上一次的输出没有通过校验。请输出完整 JSON，但只能修改错误明确涉及的字段；所有未被错误点名的字段、镜头顺序、角色、动作、原文 ID 分配和已正确的内容必须逐项保持不变。不得改写、删减、合并或翻译任何原文内容。不要省略未改动部分。\n错误：\n${lastErrors.join("\n")}\n\n上一次输出：\n${lastOutput.slice(0, 120000)}`;
    lastOutput = await model.complete({ system, prompt: request, signal, json: true });
    let value: unknown;
    try { value = extractJson(lastOutput); }
    catch (error) { lastErrors = [error instanceof Error ? error.message : String(error)]; await onAttempt?.(attempt + 1, lastOutput, lastErrors); log?.(`JSON 解析失败，第 ${attempt + 1} 次：${lastErrors[0]}`); continue; }
    const result = validate(value);
    if (result.ok) { await onAttempt?.(attempt + 1, lastOutput, []); return result.data; }
    lastErrors = result.errors;
    await onAttempt?.(attempt + 1, lastOutput, lastErrors);
    log?.(`校验未通过，第 ${attempt + 1} 次：${result.errors.slice(0, 3).join("；")}`);
  }
  throw Object.assign(new Error(`模型输出多次校验失败：${lastErrors.slice(0, 5).join("；")}`), { details: lastErrors });
}

export async function planCast(model: TextModel, brief: PlanBrief, script: string, options: { repairAttempts?: number; signal?: AbortSignal; log?: (message: string) => void } = {}): Promise<CastPlan> {
  const system = `${stageTag("cast")}
你是角色设定师。从剧本中提取角色卡与场景表，只输出 JSON：
{"title":"剧名","logline":"一句话梗概","style":"统一画风（如：日系动画赛璐璐，柔和光影）",
 "characters":[{"id":"英文或拼音小写id","name":"角色名","identity":{"gender":"female|male|other","age":整数},
   "invariant":{"face":"脸型五官与肤色，具体可视","hair":"发型发色","body":"身高体型","marks":"痣/疤等独特标记，可省略"},
   "identityInvariants":["绝不能改变的脸部/发型/体型特征"],"temporaryState":[],"voice":{"timbre":"音色描述","language":"普通话","speakingRate":1.0},
   "outfits":[{"id":"default","label":"日常装","upper":"上装颜色款式","lower":"下装","shoes":"鞋","accessories":"配饰"}],
   "negative":"可省略","seed":可省略}],
 "scenes":[{"id":"英文或拼音小写id","name":"场景名","description":"空间布局、主要陈设、光线与色调","layout":"固定平面布局与家具位置","lightingBaseline":"固定主光方向、色温与阴影","cameraViews":["正面","侧面"]}]}
规则：外观描述必须是可画出来的具体视觉特征，不写性格；同一个人换装是 outfits 里的新条目，不是新角色。`;
  return jsonStage(model, withRule(system, brief), `画风偏好：${brief.style ?? "由你决定，全片统一"}\n剧本：\n${script}`, value => {
    const parsed = castSchema.safeParse(value);
    if (!parsed.success) return { ok: false, errors: parsed.error.issues.slice(0, 30).map(issue => `${issue.path.join(".")}：${issue.message}`) };
    const ids = new Set<string>();
    for (const character of parsed.data.characters) {
      if (ids.has(character.id)) return { ok: false, errors: [`角色 id ${character.id} 重复`] };
      ids.add(character.id);
    }
    return { ok: true, data: parsed.data as CastPlan };
  }, options.repairAttempts ?? 2, options.signal, options.log);
}

export function storyboardInstructions(brief: PlanBrief) {
  return `${stageTag("storyboard")}
你是分镜导演。把剧本拆成分镜 JSON，只输出 JSON，结构：
{"version":1,"title":"","aspectRatio":"${brief.aspectRatio}","style":"","bible":{"projectId":"项目id","canon":["不可改变的世界观事实"],"threads":[{"id":"thread-1","description":"尚未解决的剧情线","status":"open","introducedEpisode":1}]},"characters":[{"id":"","name":""}],"scenes":[{"id":"","name":"","description":""}],
 "episodes":[{"ep":1,"title":"","targetSeconds":${brief.targetSeconds},"segments":[
   {"id":"E01-01","sceneId":"场景id","blocking":"开场站位：谁在画面左/右/前/后，朝向与距离","timeOfDay":"","mood":"",
    "shots":[{"id":"E01-01-01","size":"medium","camera":"Static Shot",
      "transition":"cut","cameraContract":{"viewpoint":"third_person","axisId":"dialogue-axis","axisSide":"A"},"extrasPolicy":{"mode":"forbidden"},"characters":[{"id":"角色id","outfit":"造型id","pose":"首帧位置与姿态"}],
      "dialogue":[],"quoteAssignments":[{"sourceId":"Q0001","kind":"dialogue","speaker":"角色id 或 narrator","emotion":"情绪；画外音写 画外"},{"sourceId":"Q0002","kind":"sfx"},{"sourceId":"Q0003","kind":"quoted_text"}],"sourceRefs":["SRC0001"],
      "firstFrame":"首帧静态画面","action":"本镜动作与表演","endFrame":"结束画面，可省略","spatialContract":{"positions":[{"characterId":"角色id","screenPosition":"left","facing":"right","eyelineTarget":"视线目标"}],"startState":"开始状态","endState":"结束状态","beat":"action"},"dialogueLanguage":"普通话中文","sfx":"音效，可省略",
      "lens":"如 35mm","cameraPosition":"机位高度与方位","composition":"构图","eyeline":"视线落点","focus":"焦点主体","stability":"stable",
      "continuity":{"dead":["已死亡角色id"],"hands":[{"id":"角色id","left":"左手所持物或 空","right":"右手所持物或 空"}],"extras":"画面中允许出现的非角色人物或尸体，没有写 无"}}]}]}]}
规则：
1. 段 = 同一场景内连续的一组镜头，id 为 E集-段 两位连号；镜 id 为 E集-段-镜 两位连号。
2. ${brief.rhythm === "clip"
    ? `镜头优先 ${brief.shotSeconds?.min ?? 1}–${brief.shotSeconds?.max ?? 4} 秒，单镜同框不超过 3 人。对白按每秒 4.1 个中文字估算，另加开口前约 1.5 秒和说完后的短停；装不下就加长，不超过 15 秒，不要加快语速。每个镜头只做一件事：一个动作，或一句台词。手碰到道具时写明哪只手靠近、碰到、施力，以及道具落到哪里。反应镜写一个触发、一个情绪、两处看得见的变化，并在 1.5 秒内定住。必须写 endFrame。firstFrame 只写起点，不画终点才出现的动作和道具；endFrame 只写终点。结束画面的左右手、站位和道具要能从 firstFrame 变过去，不新增人物和手。要看清的道具画到占满持有它的那只手。镜头内不切镜。同一段的下一镜 firstFrame 承接上一镜 endFrame。每镜单独生成一条视频。切到下一镜必须换信息，同一动作不在下一镜再做一次。`
    : `${brief.shotSeconds ? `每镜 ${brief.shotSeconds.min}–${brief.shotSeconds.max} 秒；可写整数 seconds 表示期望时长（动作、氛围镜头可以更长，台词不够的程序会自动补足），不写则按台词字数估算` : "每镜 2–10 秒，不写 seconds（程序按台词字数估算）"}；单镜同框不超过 3 人；镜头内不切镜。`}
3. 每镜 characters 必须列出画面中所有可见角色，只用给定角色 id 与造型 id；空镜给空数组。
4. 同段内动作直接延续上一镜（同机位/同动作）时 transition 写 continuous，否则 cut；段首镜必须是 cut。
5. firstFrame 只写静态画面（人物位置、姿态、表情、环境），action 只写动作；不要在这些字段里写镜头号、时间码或图片编号。
6. 镜头视角必须由 cameraContract 明确声明；third_person、first_person、over_shoulder、insert、subjective_camera、top_down 均可使用。第一人称/主观镜头必须指定 subjectCharacterId；不得与合同冲突，不得在单镜中无理由切换视角。
7. 空间调度必须物理合理：车辆行驶时人物只能在车内或路边安全位置，禁止让人物站在/走在行驶车辆前方的公路、高架或车道上；追车、行车镜头只拍车辆与车内人物。
8. 空间清楚：每段 blocking 写明谁在画面左/右/前/后、朝向和距离；同段镜头保持同一轴线，人物位置不跳变；每镜 composition 写明每个人物在画面中的位置（左/中/右、前景/背景）；人物进入或离开画面要在 action 中写明。
9. 画面中避免出现可读的招牌、标语、车牌等文字；每镜 dialogueLanguage 明确对白语言。原文对白、拟声词和引号内容必须使用 quoteAssignments 按原文顺序逐条分类：对白 kind=dialogue 并填写 speaker；拟声词/声音 kind=sfx；单纯被引用的人名/术语 kind=quoted_text。不得自行复制、改写、缩写、翻译或补写台词。程序会从原文账本自动回填原文。
10. 每镜写 continuity 做场记：dead 列出此前已死亡的角色（死亡后一直保持，死者出场只能写成尸体）；hands 写每个出场活人左右手各拿什么（同一把枪一直在同一只手，除非 action 明确写换手；不明时持枪写右手）；extras 只写剧本此刻确实存在的尸体/路人，没有写 无（不要凭空增加尸体或人群）。
11. 同框人数与座位物理合理：轿车前排最多两人（驾驶座 + 副驾），第三人坐后排；人物位置要与 blocking 一致。
12. 每镜必须提供 sourceRefs，引用本镜对应的原文片段 ID；所有 SRC ID 必须且只能分配一次，并保持原文顺序。每个 Q ID 必须且只能在 quoteAssignments 中分类一次，并按原文顺序排列；对白 kind=dialogue 且填写 speaker，拟声词/声音 kind=sfx，非对白引用文本 kind=quoted_text。每镜原则上只放一段独立对白（同一段长对白被账本切成连续 Q 片段时可分配到相邻镜头）；若多段独立对白合计估时超过 ${brief.shotSeconds?.max ?? 15} 秒，必须按完整 Q/group 边界拆到相邻镜头，禁止把多段对白硬塞进同一镜。程序从原文账本自动回填台词和 source，禁止模型改写。
13. 每集必须继承前集人物生死、伤情、服装、地点、关系、车辆/道具状态和未解决剧情线；只有本集明确动作才能改变状态。场景固定布局与灯光基线不得无故漂移。原文内容超过目标时长时允许延长目标时长，不得删减或压缩原文。
14. cameraContract 负责视角/轴线，spatialContract 负责人物画面左右、朝向、视线与镜头起止状态；extrasPolicy 明确是否允许额外人物。枚举字段只能选择单个合法值：size=${Object.keys(shotSizes).join("、")}；camera=${Object.keys(cameraMoves).join("、")}（POV 只能写入 cameraContract.viewpoint）；stability=${Object.keys(stabilities).join("、")}；transition=cut 或 continuous；screenPosition=far_left/left/center/right/far_right/foreground/background；facing=left/right/camera/away/profile。禁止把多个候选值用竖线拼成一个字段值。${brief.preserveSourceText === false ? `
15. 这是剧本模式，第 9、12、13 条里的原文逐字保留、SRC/Q 账本不适用。dialogue 直接写台词，不要编造 sourceRefs 或 quoteAssignments。第一段前 3 秒必须是冲突。每集最后一镜停在悬念。firstFrame 和 action 只写看得见的动作，禁止心理描写。` : ""}${brief.writingRule ? `\n${brief.writingRule}` : ""}`;
}

/** 修复模型常见的景别/运镜同义词；无法可靠转换的值保留给 Zod 质量门拒绝。 */
export function normalizeStoryboardEnums(value: unknown) {
  if (!value || typeof value !== "object" || Array.isArray(value)) return value;
  const copy = structuredClone(value) as Record<string, any>;
  const compact = (value: string) => value.toLowerCase().replace(/[\s_\-–—()（）]/g, "");
  const cameraAliases: Record<string, string> = {
    "静止镜头": "Static Shot", "固定镜头": "Static Shot", "固定机位": "Static Shot", "静态镜头": "Static Shot", "static": "Static Shot", "staticshot": "Static Shot", "fixedshot": "Static Shot", "lockedoff": "Static Shot",
    "推镜": "Push In", "推进": "Push In", "pushin": "Push In", "dollyin": "Push In", "拉镜": "Pull Out", "拉远": "Pull Out", "pullout": "Pull Out", "dollyout": "Pull Out",
    "zoomin": "Zoom In", "zoomout": "Zoom Out", "左摇": "Pan Left", "向左摇": "Pan Left", "panleft": "Pan Left", "右摇": "Pan Right", "向右摇": "Pan Right", "panright": "Pan Right",
    "左移": "Truck Left", "向左平移": "Truck Left", "truckleft": "Truck Left", "右移": "Truck Right", "向右平移": "Truck Right", "truckright": "Truck Right",
    "上摇": "Tilt Up", "向上仰摇": "Tilt Up", "tiltup": "Tilt Up", "下摇": "Tilt Down", "向下俯摇": "Tilt Down", "tiltdown": "Tilt Down",
    "升降": "Pedestal Up", "升起": "Pedestal Up", "pedestalup": "Pedestal Up", "下降": "Pedestal Down", "pedestaldown": "Pedestal Down",
    "环绕": "Arc Shot", "环绕镜头": "Arc Shot", "arcshot": "Arc Shot", "跟拍": "Tracking Shot", "跟踪": "Tracking Shot", "tracking": "Tracking Shot", "trackingshot": "Tracking Shot",
    "手持": "Shake Slightly", "轻微手持": "Shake Slightly", "轻微晃动": "Shake Slightly", "shakeslightly": "Shake Slightly",
  };
  const sizeAliases: Record<string, string> = {
    "大远景": "extreme-wide", "极远景": "extreme-wide", "extremewide": "extreme-wide", "extremewideshot": "extreme-wide",
    "远景": "wide", "全景": "wide", "wideshot": "wide", "全身景": "full", "全身": "full", "fullshot": "full",
    "中景": "medium", "mediumshot": "medium", "中近景": "medium-close", "近景": "medium-close", "mediumcloseup": "medium-close",
    "特写": "close", "近距离特写": "close", "closeup": "close", "大特写": "extreme-close", "极近特写": "extreme-close", "extremecloseup": "extreme-close",
  };
  const stabilityAliases: Record<string, string> = { "稳定": "stable", "画面稳定": "stable", "stable": "stable", "轻微晃动": "slight-shake", "slightshake": "slight-shake", "手持": "handheld", "手持感": "handheld", "handheld": "handheld" };
  const beatAliases: Record<string, string> = {
    "establish": "establishing", "establishingshot": "establishing", "setup": "establishing", "scenesetting": "establishing", "location": "establishing", "建立": "establishing", "建立空间": "establishing", "交代空间": "establishing", "开场建立": "establishing",
    "dialogue": "action", "activity": "action", "movement": "action", "combat": "action", "fight": "action", "explosion": "action", "impact": "action", "动作": "action", "活动": "action", "对白": "action", "台词": "action", "打斗": "action", "爆炸": "action",
    "tension": "reaction", "threat": "reaction", "suspense": "reaction", "response": "reaction", "emotionalreaction": "reaction", "紧张": "reaction", "威胁": "reaction", "反应": "reaction", "情绪反应": "reaction", "对峙": "reaction",
    "discovery": "reveal", "surprise": "reveal", "揭示": "reveal", "揭露": "reveal", "发现": "reveal",
    "detail": "insert", "insertshot": "insert", "closeupinsert": "insert", "细节": "insert", "插入": "insert",
    "bridge": "transition", "passage": "transition", "转场": "transition", "过渡": "transition",
  };
  const validBeats = new Set(["establishing", "action", "reaction", "reveal", "insert", "transition"]);
  const episodes = Array.isArray(copy.episodes) ? copy.episodes : [];
  for (const episode of episodes) for (const segment of Array.isArray(episode?.segments) ? episode.segments : []) for (const shot of Array.isArray(segment?.shots) ? segment.shots : []) {
    if (typeof shot.camera === "string") {
      const raw = shot.camera.trim();
      if (/^(?:pov|povshot|firstperson|firstpersonpov|主观视角|第一人称(?:视角|镜头)?)$/i.test(compact(raw))) {
        shot.camera = "Static Shot";
        const subject = shot.cameraContract?.subjectCharacterId ?? shot.characters?.[0]?.id;
        shot.cameraContract = subject ? { ...(shot.cameraContract ?? {}), viewpoint: "first_person", subjectCharacterId: subject } : { ...(shot.cameraContract ?? {}), viewpoint: "third_person" };
      } else {
        const choices = raw.split(/[|／/]/).map((item: string) => item.trim()).filter(Boolean);
        const candidate = choices.map((item: string) => cameraAliases[compact(item)] ?? item).find((item: string) => Object.hasOwn(cameraMoves, item));
        shot.camera = choices.length > 1 ? "Static Shot" : (candidate ?? (cameraAliases[compact(raw)] ?? raw));
      }
    }
    if (typeof shot.size === "string") {
      const choices = shot.size.split(/[|／/]/).map((item: string) => item.trim()).filter(Boolean);
      const candidate = choices.map((item: string) => sizeAliases[compact(item)] ?? item).find((item: string) => Object.hasOwn(shotSizes, item));
      shot.size = choices.length > 1 ? "medium" : (candidate ?? (sizeAliases[compact(shot.size)] ?? shot.size));
    }
    if (typeof shot.stability === "string") {
      const choices = shot.stability.split(/[|／/]/).map((item: string) => item.trim()).filter(Boolean);
      const candidate = choices.map((item: string) => stabilityAliases[compact(item)] ?? item).find((item: string) => Object.hasOwn(stabilities, item));
      shot.stability = choices.length > 1 ? "stable" : (candidate ?? (stabilityAliases[compact(shot.stability)] ?? shot.stability));
    }
    if (typeof shot.transition === "string") {
      const choices = shot.transition.split(/[|／/]/).map((item: string) => item.trim());
      shot.transition = choices.find((item: string) => ["cut", "continuous", "切镜", "连续"].includes(item)) ?? "cut";
      if (shot.transition === "切镜") shot.transition = "cut";
      if (shot.transition === "连续") shot.transition = "continuous";
    }
    if (typeof shot.spatialContract?.beat === "string") {
      const rawBeat = shot.spatialContract.beat.trim();
      const choices = rawBeat.split(/[|／/]/).map((item: string) => item.trim()).filter(Boolean);
      const mapped = choices.map((item: string) => beatAliases[compact(item)] ?? item).find((item: string) => validBeats.has(item));
      shot.spatialContract.beat = mapped ?? beatAliases[compact(rawBeat)] ?? rawBeat;
    }
    if (shot.cameraContract?.viewpoint?.includes?.("|")) shot.cameraContract.viewpoint = "third_person";
    if (shot.extrasPolicy?.mode?.includes?.("|")) shot.extrasPolicy.mode = "forbidden";
  }
  return copy;
}

/**
 * 模型常把造型写成标签（如“孵化”）或把角色写成名字：按角色卡把名字映射回 id、把造型标签映射回造型 id；
 * 造型仍对不上时退回该角色的第一套造型（只有一套时必然是它），避免为一个字段反复修复整集分镜。
 */
export function normalizeCastReferences(board: Storyboard, cast: Pick<CastPlan, "characters">) {
  const key = (text: string) => text.trim().toLowerCase().replace(/\s+/g, "");
  const byId = new Map(cast.characters.map(card => [card.id, card] as const));
  const byName = new Map(cast.characters.map(card => [key(card.name), card] as const));
  const resolve = (id: string) => byId.get(id) ?? byName.get(key(id));
  for (const episode of board.episodes) for (const segment of episode.segments) for (const shot of segment.shots) {
    for (const character of shot.characters) {
      const card = resolve(character.id);
      if (!card) continue;
      character.id = card.id;
      if (card.outfits.some(outfit => outfit.id === character.outfit)) continue;
      const wanted = key(character.outfit ?? "");
      const match = card.outfits.find(outfit => key(outfit.label ?? "") === wanted || key(outfit.id) === wanted)
        ?? card.outfits.find(outfit => wanted && (key(outfit.label ?? "").includes(wanted) || wanted.includes(key(outfit.label ?? "") || "\u0000")));
      character.outfit = (match ?? card.outfits[0])!.id;
    }
    for (const line of shot.dialogue ?? []) {
      if (line.speaker === "narrator") continue;
      const card = resolve(line.speaker);
      if (card) line.speaker = card.id;
    }
    for (const assignment of shot.quoteAssignments ?? []) {
      if (assignment.kind !== "dialogue" || !assignment.speaker || assignment.speaker === "narrator") continue;
      const card = resolve(assignment.speaker);
      if (card) assignment.speaker = card.id;
    }
  }
  return board;
}

export function fitEpisodeTargetsToActualDuration<T extends { episodes: Array<{ targetSeconds?: number; segments: Array<{ shots: Array<{ seconds?: number }> }> }> }>(board: T) {
  for (const episode of board.episodes) {
    const actual = episode.segments.reduce((sum, segment) => sum + segment.shots.reduce((inner, shot) => inner + (shot.seconds ?? 0), 0), 0);
    if (episode.targetSeconds && actual > episode.targetSeconds) episode.targetSeconds = Math.ceil(actual);
  }
  return board;
}

/**
 * 在原文账本回填前，按不可变 Q/group 边界把超时对白确定性拆到相邻镜头。
 * 仅移动 SRC/Q 引用，不生成或改写原文；拆分后会再次运行账本校验。
 */
export function splitOverlongDialogueShots<T extends Storyboard>(
  input: T,
  ledger: SourceLedger,
  params: { minShotSeconds?: number; maxShotSeconds?: number; charsPerSecond?: number; linePadding?: number } = {},
  allowedDurations?: number[],
): { storyboard: T; splitShots: number; createdShots: number; warnings: string[] } {
  const board = structuredClone(input) as T;
  const maxSeconds = params.maxShotSeconds ?? 15;
  const minSeconds = params.minShotSeconds ?? 2;
  const charsPerSecond = params.charsPerSecond ?? 4.5;
  const linePadding = params.linePadding ?? 0.4;
  const quoteById = new Map(ledger.quotes.map(quote => [quote.id, quote]));
  const chunkById = new Map(ledger.chunks.map(chunk => [chunk.id, chunk]));
  const warnings: string[] = [];
  let splitShots = 0;
  let createdShots = 0;

  const secondsFor = (text: string) => spokenUnits(text) / charsPerSecond + linePadding;
  const snapWithinLimit = (seconds: number) => {
    const wanted = Math.max(minSeconds, seconds);
    const choices = allowedDurations?.filter(value => value <= maxSeconds).sort((a, b) => a - b);
    if (choices?.length) return choices.find(value => value + 0.05 >= wanted) ?? Math.ceil(wanted);
    return Math.ceil(wanted * 10) / 10;
  };

  for (const episode of board.episodes) for (const segment of episode.segments) {
    const rebuilt: typeof segment.shots = [];
    for (const shot of segment.shots) {
      const assignments = shot.quoteAssignments ?? [];
      const dialogueAssignments = assignments.filter(item => item.kind === "dialogue" && quoteById.has(item.sourceId));
      if (dialogueAssignments.length < 2 || !shot.sourceRefs?.length) { rebuilt.push(shot); continue; }

      const groups = new Map<string, { quotes: SourceLedger["quotes"]; assignments: typeof dialogueAssignments; start: number; end: number; text: string; speaker: string; emotion?: string }>();
      for (const assignment of dialogueAssignments) {
        const quote = quoteById.get(assignment.sourceId)!;
        const current = groups.get(quote.groupId);
        if (current) {
          current.quotes.push(quote);
          current.assignments.push(assignment);
          current.end = Math.max(current.end, quote.end);
          current.text += quote.text;
          if (assignment.emotion) current.emotion = assignment.emotion;
        } else {
          groups.set(quote.groupId, { quotes: [quote], assignments: [assignment], start: quote.start, end: quote.end, text: quote.text,
            speaker: assignment.speaker ?? "narrator", ...(assignment.emotion ? { emotion: assignment.emotion } : {}) });
        }
      }
      const orderedGroups = [...groups.values()].sort((a, b) => a.start - b.start);
      const totalSeconds = orderedGroups.reduce((sum, group) => sum + secondsFor(group.text), 0);
      if (totalSeconds <= maxSeconds + 0.05) { rebuilt.push(shot); continue; }

      type Unit = { sourceIds: string[]; start: number; end: number; text: string; seconds: number; groupIndex: number };
      const units: Unit[] = [];
      let unsplittable = false;
      orderedGroups.forEach((group, groupIndex) => {
        const wholeSeconds = secondsFor(group.text);
        if (wholeSeconds <= maxSeconds + 0.05) {
          units.push({ sourceIds: group.assignments.map(item => item.sourceId), start: group.start, end: group.end, text: group.text, seconds: wholeSeconds, groupIndex });
          return;
        }
        // 超长单段对白由账本预先按连续 50 字 Q 片段切分；只在这些原文边界上拆。
        for (const quote of group.quotes) {
          const quoteSeconds = secondsFor(quote.text);
          if (quoteSeconds > maxSeconds + 0.05) { unsplittable = true; return; }
          units.push({ sourceIds: [quote.id], start: quote.start, end: quote.end, text: quote.text, seconds: quoteSeconds, groupIndex });
        }
      });
      if (unsplittable || units.length < 2) {
        warnings.push(`${shot.id} 的单个 Q 原文片段本身超过 ${maxSeconds} 秒，未自动拆分，交由质量门拦截`);
        rebuilt.push(shot);
        continue;
      }

      const packs: Unit[][] = [];
      let currentPack: Unit[] = [];
      let currentSeconds = 0;
      for (const unit of units) {
        if (currentPack.length && currentSeconds + unit.seconds > maxSeconds + 0.05) {
          packs.push(currentPack); currentPack = []; currentSeconds = 0;
        }
        currentPack.push(unit); currentSeconds += unit.seconds;
      }
      if (currentPack.length) packs.push(currentPack);
      if (packs.length < 2) { rebuilt.push(shot); continue; }

      const sourceIdToPack = new Map<string, number>();
      packs.forEach((pack, packIndex) => pack.forEach(unit => unit.sourceIds.forEach(id => sourceIdToPack.set(id, packIndex))));
      const groupToPack = new Map<number, number>();
      packs.forEach((pack, packIndex) => pack.forEach(unit => groupToPack.set(unit.groupIndex, packIndex)));
      const groupPosition = orderedGroups.map((group, index) => ({ index, start: group.start, end: group.end }));
      const nearestPackForPosition = (position: number) => {
        let best = 0; let distance = Number.POSITIVE_INFINITY;
        for (const group of groupPosition) {
          const d = position < group.start ? group.start - position : position > group.end ? position - group.end : 0;
          if (d < distance) { distance = d; best = groupToPack.get(group.index) ?? 0; }
        }
        return best;
      };

      const sourceIdsByPack = packs.map(() => [] as string[]);
      let sourceConflict = false;
      for (const sourceId of shot.sourceRefs) {
        const chunk = chunkById.get(sourceId);
        if (!chunk) { sourceConflict = true; break; }
        const contained = ledger.quotes.filter(quote => quote.start >= chunk.start && quote.start < chunk.end);
        const mapped = [...new Set(contained.map(quote => sourceIdToPack.get(quote.id) ?? nearestPackForPosition(quote.start)))];
        if (mapped.length > 1) { sourceConflict = true; break; }
        const owner = mapped[0] ?? nearestPackForPosition((chunk.start + chunk.end) / 2);
        sourceIdsByPack[owner]!.push(sourceId);
      }
      if (sourceConflict || sourceIdsByPack.some(items => !items.length)) {
        warnings.push(`${shot.id} 的 SRC 原文片段跨越多个对白边界，无法无损拆分；保留原镜并由质量门拦截`);
        rebuilt.push(shot);
        continue;
      }

      const assignmentsByPack = packs.map(() => [] as typeof assignments);
      for (const assignment of assignments) {
        const quote = quoteById.get(assignment.sourceId);
        if (!quote) { assignmentsByPack[0]!.push(assignment); continue; }
        let owner = sourceIdToPack.get(assignment.sourceId);
        if (owner === undefined) {
          const containingChunk = ledger.chunks.find(chunk => quote.start >= chunk.start && quote.start < chunk.end);
          owner = containingChunk ? sourceIdsByPack.findIndex(ids => ids.includes(containingChunk.id)) : -1;
        }
        if (owner === undefined || owner < 0) owner = nearestPackForPosition(quote.start);
        assignmentsByPack[owner]!.push(assignment);
      }

      packs.forEach((pack, packIndex) => {
        const clone = structuredClone(shot);
        clone.id = shot.id;
        clone.sourceRefs = sourceIdsByPack[packIndex]!.sort((a, b) => (chunkById.get(a)?.index ?? 0) - (chunkById.get(b)?.index ?? 0));
        clone.quoteAssignments = assignmentsByPack[packIndex]!.sort((a, b) => (quoteById.get(a.sourceId)?.index ?? 0) - (quoteById.get(b.sourceId)?.index ?? 0));
        clone.dialogue = [];
        delete clone.source;
        const packSeconds = pack.reduce((sum, unit) => sum + unit.seconds, 0);
        clone.seconds = snapWithinLimit(packSeconds);
        if (packIndex > 0) {
          clone.transition = "continuous";
          clone.firstFrame = `承接上一镜尾帧，保持同一场景、人物站位、服装、道具状态与摄影轴线，不新增人物。`;
          clone.action = `承接上一镜连续表演，保持当前人物动作与空间状态；本镜只呈现分配给本镜的原文对白。`;
        }
        if (packIndex < packs.length - 1) delete clone.endFrame;
        rebuilt.push(clone);
      });
      splitShots++;
      createdShots += packs.length - 1;
    }
    segment.shots = rebuilt;
    if (segment.shots.length > 40) warnings.push(`${segment.id} 拆镜后共 ${segment.shots.length} 镜，超过分段镜头上限 40`);
    segment.shots.forEach((shot, index) => { shot.id = `${segment.id}-${String(index + 1).padStart(2, "0")}`; });
  }
  return { storyboard: board, splitShots, createdShots, warnings };
}

export interface StoryboardPlanResult { storyboard: Storyboard; gates: GateResult[] }

export async function planStoryboard(model: TextModel, brief: PlanBrief, script: string, cast: CastPlan,
  options: { repairAttempts?: number; signal?: AbortSignal; log?: (message: string) => void; gateContext: GateContext; allowedDurations?: number[]; onAttempt?: (episode: number | undefined, attempt: number, output: string, errors: string[]) => void | Promise<void> }): Promise<StoryboardPlanResult> {
  const ledger = buildSourceLedger(script, cast.characters);
  const clip = brief.rhythm === "clip";
  const shotAllowed = clip ? undefined : options.allowedDurations;
  const ledgerPromptFor = (activeLedger: ReturnType<typeof buildSourceLedger>) => `\n\n【不可修改的原文账本】sourceHash=${activeLedger.sourceHash}\n本次规划只负责以下原文范围（每个 SRC 必须分配一次，严格保持顺序）：\n${JSON.stringify(activeLedger.chunks.map(({id,text})=>({id,text})), null, 2)}\n原文对白/音效/引用内容（每个 Q 必须恰好在 quoteAssignments 中分类一次，保持顺序）：\n${JSON.stringify(activeLedger.quotes.map(({id,text,kind,speakerHint})=>({id,text,suggestedKind:kind,speakerHint})), null, 2)}\n不得自行改写或复述以上原文。`;
  const castText = JSON.stringify({
    characters: cast.characters.map(card => ({ id: card.id, name: card.name, outfits: card.outfits.map(outfit => ({ id: outfit.id, label: outfit.label })) })),
    scenes: cast.scenes,
  });
  let gates: GateResult[] = [];
  const baseCore = `剧名：${cast.title}\n画风：${cast.style}\n可用角色与场景：${castText}`;
  const plan = (prompt: string, episode?: number, activeLedger: ReturnType<typeof buildSourceLedger> = ledger) => jsonStage(model, storyboardInstructions(brief), prompt, value => {
    // ACT: 角色表、场景表、标题与画风以角色阶段为准，覆盖模型重复输出的部分，避免两处不一致。
    let merged = value && typeof value === "object" && !Array.isArray(value) ? {
      ...value as Record<string, unknown>, version: 1, title: cast.title, style: cast.style, aspectRatio: brief.aspectRatio,
      characters: cast.characters.map(card => ({ id: card.id, name: card.name })), scenes: cast.scenes,
    } as Record<string, unknown> : value;
    if (episode !== undefined && merged && typeof merged === "object" && Array.isArray((merged as { episodes?: unknown }).episodes)) {
      // 分集规划：只取本集，集号以程序为准
      const list = (merged as { episodes: Record<string, unknown>[] }).episodes;
      const own = list.find(item => item?.ep === episode) ?? list[0];
      merged = { ...merged as Record<string, unknown>, episodes: own ? [{ ...own, ep: episode, targetSeconds: brief.targetSeconds }] : [] };
    }
    const normalized = normalizeStoryboardEnums(merged);
    const parsed = parseStoryboard(normalized);
    if (!parsed.ok) return parsed;
    normalizeCastReferences(parsed.data, cast);
    for (const { shot } of iterateShots(parsed.data)) {
      shot.cameraContract ??= { viewpoint: "third_person" };
      shot.extrasPolicy ??= { mode: "forbidden" };
    }
    if (brief.preserveSourceText !== false) {
      const repair = repairSourceLedgerAssignments(parsed.data as any, activeLedger);
      if (repair.autoAssignedChunks || repair.autoAssignedQuotes) options.log?.(`原文账本自动补齐 ${repair.autoAssignedChunks} 个原文片段、${repair.autoAssignedQuotes} 条引号（原文由程序恢复）`);
      if (repair.unresolvedSpeakers) options.log?.(`有 ${repair.unresolvedSpeakers} 条对白的说话人无法从上下文确定，暂标为旁白，请在分镜确认时核对`);
      const ledgerReport = validateSourceLedger(parsed.data as any, activeLedger);
      if (!ledgerReport.ok) return { ok: false, errors: ledgerReport.errors.slice(0, 40) };
      const split = splitOverlongDialogueShots(parsed.data, activeLedger, clip ? { ...options.gateContext.params, maxShotSeconds: 15 } : options.gateContext.params, shotAllowed);
      if (split.splitShots) options.log?.(`程序自动拆分 ${split.splitShots} 个超时对白镜头，新增 ${split.createdShots} 个相邻镜头（按 Q 原文边界，无改写）`);
      for (const warning of split.warnings) options.log?.(`自动拆镜警告：${warning}`);
      parsed.data = split.storyboard;
      const postSplitLedger = validateSourceLedger(parsed.data as any, activeLedger);
      if (!postSplitLedger.ok) return { ok: false, errors: [`自动拆镜后的原文账本校验失败：${postSplitLedger.errors.slice(0, 20).join("；")}`] };
      // Hydrate after deterministic splitting so exact source text and dialogue land on their final adjacent shots.
      hydrateStoryboardFromLedger(parsed.data as any, activeLedger, { preserveAssignments: true });
      parsed.data.sourceLedgerHash = ledger.sourceHash;
      applyDeathEventsFromSource(parsed.data as any, cast.characters);
    }
    propagateDeadStates(parsed.data);
    const filled = fitEpisodeTargetsToActualDuration(fillDurations(parsed.data, { params: options.gateContext.params, allowed: shotAllowed }));
    const report = runGates(filled, { ...options.gateContext, clipRhythm: clip, clipDurations: clip ? options.allowedDurations : undefined, requireAnchors: false, allowedDurations: shotAllowed, chapter: brief.preserveSourceText === false && episode === undefined ? script : undefined });
    gates = report.gates;
    if (!report.ok) {
      const errors = [gateFeedback(report.gates)];
      const dialogueGate = report.gates.find(gate => gate.id === "dialogueFit" && !gate.ok);
      if (dialogueGate) {
        for (const detail of dialogueGate.details) {
          const shotId = detail.match(/^(E\d{2}-\d{2}-\d{2})/)?.[1];
          const shot = shotId ? [...iterateShots(filled)].find(item => item.shot.id === shotId)?.shot : undefined;
          const qIds = (shot?.quoteAssignments ?? []).filter(item => item.kind === "dialogue").map(item => item.sourceId);
          const groups = [...new Set(qIds.map(id => activeLedger.quotes.find(quote => quote.id === id)?.groupId).filter(Boolean))];
          if (qIds.length > 1 && groups.length > 1) errors.push(`${shotId} 的独立对白 ${qIds.join("、")} 不得放在同一镜头；请按原文顺序拆到两个相邻镜头，第一个镜头只分配前一段 Q，紧邻下一镜只分配后一段 Q，原文逐字保留，不得合并或改写。`);
        }
      }
      return { ok: false, errors };
    }
    return { ok: true, data: filled };
  }, options.repairAttempts ?? 2, options.signal, options.log,
    options.onAttempt ? (attempt, output, errors) => options.onAttempt!(episode, attempt, output, errors) : undefined);
  if (brief.episodes <= 1) return { storyboard: await plan(`${baseCore}${brief.preserveSourceText !== false ? ledgerPromptFor(ledger) : ""}`), gates };
  // 多集：先按原文连续片段做确定性分配，每集只接收自己的 SRC/Q 范围，避免每集都重复认领整章。
  const episodeLedgers = brief.preserveSourceText !== false ? partitionSourceLedger(ledger, brief.episodes) : [];
  // 多集：逐集规划（单次输出更短，修复更可靠），再合并
  const parts: Storyboard[] = [];
  for (let episode = 1; episode <= brief.episodes; episode++) {
    const label = `E${String(episode).padStart(2, "0")}`;
    const mergedThreads = new Map<string, NonNullable<Storyboard["bible"]>["threads"][number]>();
    for (const part of parts) for (const thread of part.bible?.threads ?? []) mergedThreads.set(thread.id, thread);
    const previousBoard = parts.length ? { ...parts[0]!, bible: parts[0]!.bible ? { ...parts[0]!.bible, threads: [...mergedThreads.values()] } : undefined, episodes: parts.flatMap(part => part.episodes) } : undefined;
    const memory = previousBoard ? buildEpisodeMemoryPrompt(deriveCrossEpisodeMemory(previousBoard), episode) : "【跨集记忆】首集，建立人物、道具和世界观状态。";
    const activeLedger = brief.preserveSourceText !== false ? episodeLedgers[episode - 1]! : ledger;
    const activeBase = `${baseCore}${brief.preserveSourceText !== false ? ledgerPromptFor(activeLedger) : ""}`;
    let current = await plan(`${activeBase}\n\n${memory}\n\n本次只输出第 ${episode} 集（共 ${brief.episodes} 集）的分镜：episodes 数组里只放 ep=${episode} 这一集，约 ${brief.targetSeconds} 秒，段 id 与镜 id 以 ${label}- 开头。只能引用本集提供的 SRC/Q ID，不得引用其他集原文 ID。必须继承上集记忆，除非本集动作明确交代状态变化。`, episode, activeLedger);
    if (!hasContinuity(current)) {
      const episodeSource = brief.preserveSourceText !== false ? activeLedger.chunks.map(chunk => chunk.text).join("") : script;
      current = await annotateContinuity(model, current, `${episodeSource}\n\n${memory}`, { repairAttempts: options.repairAttempts, signal: options.signal, log: options.log });
      options.log?.(`第 ${episode} 集场记完成：跨集状态已结构化`);
    }
    parts.push(current);
    options.log?.(`第 ${episode}/${brief.episodes} 集分镜完成（已注入跨集记忆）`);
  }
  const mergedThreads = new Map<string, NonNullable<Storyboard["bible"]>["threads"][number]>();
  const mergedCanon = new Set<string>();
  for (const part of parts) {
    for (const thread of part.bible?.threads ?? []) mergedThreads.set(thread.id, thread);
    for (const fact of part.bible?.canon ?? []) mergedCanon.add(fact);
  }
  const storyboard: Storyboard = { ...parts[0]!, bible: parts[0]!.bible ? { ...parts[0]!.bible, canon: [...mergedCanon], threads: [...mergedThreads.values()] } : undefined, episodes: parts.flatMap(part => part.episodes) };
  propagateDeadStates(storyboard);
  if (brief.preserveSourceText !== false) {
    const repair = repairSourceLedgerAssignments(storyboard as any, ledger);
    if (repair.autoAssignedChunks) options.log?.(`合并分集后自动补齐 ${repair.autoAssignedChunks} 个原文片段`);
    if (repair.autoAssignedQuotes || repair.autoAssignedChunks) options.log?.(`合并分集后自动补齐 ${repair.autoAssignedChunks} 个原文片段、${repair.autoAssignedQuotes} 条引号`);
    if (repair.unresolvedSpeakers) options.log?.(`合并分集后仍有 ${repair.unresolvedSpeakers} 条对白说话人暂标为 narrator，请核对`);
    const ledgerReport = validateSourceLedger(storyboard as any, ledger);
    if (!ledgerReport.ok) throw Object.assign(new Error(`合并后的原文账本未通过：${ledgerReport.errors.slice(0, 20).join("；")}`), { details: ledgerReport.errors });
    hydrateStoryboardFromLedger(storyboard as any, ledger, { preserveAssignments: true });
    storyboard.sourceLedgerHash = ledger.sourceHash;
    applyDeathEventsFromSource(storyboard as any, cast.characters);
    propagateDeadStates(storyboard);
    const timed = fitEpisodeTargetsToActualDuration(fillDurations(storyboard, { params: options.gateContext.params, allowed: shotAllowed }));
    storyboard.episodes = timed.episodes;
  }
  const report = runGates(storyboard, { ...options.gateContext, clipRhythm: clip, clipDurations: clip ? options.allowedDurations : undefined, requireAnchors: false, allowedDurations: shotAllowed, chapter: brief.preserveSourceText === false ? script : undefined, coverageSeverity: "warning" });
  if (!report.ok) throw Object.assign(new Error(`合并后的分镜未通过质量门：${gateFeedback(report.gates)}`), { details: report.gates });
  return { storyboard, gates: report.gates };
}

/** 对已有分镜补注连续性（谁已死亡、左右手持物、允许出现的尸体/路人）；只写 continuity 字段，不改其他内容。 */
export async function annotateContinuity(model: TextModel, board: Storyboard, script: string, options: { repairAttempts?: number; signal?: AbortSignal; log?: (message: string) => void } = {}) {
  const shots = [...iterateShots(board)].map(({ segment, shot }) => ({ id: shot.id, segment: segment.id, characters: shot.characters.map(item => ({ id: item.id, pose: item.pose })),
    props: shot.props, firstFrame: shot.firstFrame, action: shot.action, endFrame: shot.endFrame }));
  const prompt = `角色：${JSON.stringify(board.characters)}\n剧本：\n${script}\n\n分镜：\n${JSON.stringify(shots)}`;
  return jsonStage(model, continuityInstructions(), prompt, value => {
    const copy = structuredClone(board);
    const missing = applyContinuity(copy, value);
    if (missing.length) return { ok: false, errors: [`缺少镜头：${missing.join("、")}`] };
    const problems = continuityProblems(copy);
    if (problems.length) return { ok: false, errors: problems };
    return { ok: true, data: copy };
  }, options.repairAttempts ?? 2, options.signal, options.log);
}
