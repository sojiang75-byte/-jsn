/** ToonFlow v5 project bible, cross-episode memory, asset state machines and fingerprint utilities. */
import { createHash } from "node:crypto";
import { readFile } from "node:fs/promises";
import { z } from "zod";

const id = z.string().trim().min(1).max(96);
export const projectBibleSchema = z.object({
  version: z.literal(1).default(1),
  projectId: id,
  title: z.string().trim().min(1).max(160),
  canon: z.array(z.string().trim().min(1).max(500)).default([]),
  threads: z.array(z.object({ id, description: z.string().max(500), status: z.enum(["open", "resolved", "abandoned"]).default("open"), introducedEpisode: z.number().int().positive(), resolvedEpisode: z.number().int().optional() })).default([]),
  style: z.object({ description: z.string().trim().min(1).max(1000), palette: z.array(z.string().max(80)).default([]), lineAndTexture: z.string().max(500).optional(), forbidden: z.array(z.string().max(120)).default([]) }).optional(),
  characters: z.array(z.object({ id, identityInvariants: z.array(z.string().max(300)).default([]), outfits: z.array(z.object({ id, description: z.string().max(500) })).default([]), temporaryState: z.array(z.string().max(300)).default([]), voice: z.object({ voiceId: z.string().max(120).optional(), timbre: z.string().max(300).optional(), language: z.string().max(80).optional(), speakingRate: z.number().min(0.5).max(2).optional() }).optional() })).default([]),
  scenes: z.array(z.object({ id, layout: z.string().max(800).optional(), lightingBaseline: z.string().max(500).optional(), cameraViews: z.array(z.string().max(200)).default([]) })).default([]),
  assets: z.array(z.object({ id, kind: z.enum(["character", "scene", "prop", "vehicle", "voice"]), version: z.string().max(80), contentHash: z.string().max(128).optional() })).default([]),
  createdAt: z.string().optional(), updatedAt: z.string().optional(),
}).strict();
export type ProjectBible = z.infer<typeof projectBibleSchema>;

export const crossEpisodeMemorySchema = z.object({
  version: z.literal(1).default(1), projectId: id, updatedAt: z.string(), lastEpisode: z.number().int().nonnegative(),
  canonFacts: z.array(z.object({ id, fact: z.string().max(500), introducedEpisode: z.number().int().positive(), sourceShot: z.string().optional(), confidence: z.number().min(0).max(1).default(1) })).default([]),
  characterStates: z.array(z.object({ characterId: id, alive: z.boolean().default(true), injuries: z.array(z.string().max(200)).default([]), outfitId: z.string().optional(), locationId: z.string().optional(), relationships: z.array(z.string().max(300)).default([]), lastSeenEpisode: z.number().int().nonnegative() })).default([]),
  propStates: z.array(z.object({ propId: id, stateId: id, description: z.string().max(300), lastChangedEpisode: z.number().int().nonnegative() })).default([]),
  unresolvedThreads: z.array(z.object({ id, description: z.string().max(500), status: z.enum(["open", "resolved", "abandoned"]), introducedEpisode: z.number().int().positive(), resolvedEpisode: z.number().int().optional() })).default([]),
  episodeSummaries: z.array(z.object({ episode: z.number().int().positive(), summary: z.string().max(2000), endingState: z.string().max(1000) })).default([]),
}).strict();
export type CrossEpisodeMemory = z.infer<typeof crossEpisodeMemorySchema>;

export const stateTransitionSchema = z.object({ from: id, to: id, trigger: z.string().trim().min(1).max(300) });
export const stateMachineSchema = z.object({ assetId: id, initialState: id, states: z.array(z.object({ id, description: z.string().max(300) })).min(1), transitions: z.array(stateTransitionSchema).default([]) }).strict();
export type AssetStateMachine = z.infer<typeof stateMachineSchema>;

export function validateStateTransition(machine: AssetStateMachine, from: string, to: string, action: string) {
  const edge = machine.transitions.find(item => item.from === from && item.to === to);
  if (!edge) return { ok: false, reason: `资产 ${machine.assetId} 不允许从 ${from} 转换到 ${to}` };
  const tokens = edge.trigger.split(/[，,、；;\s]+/).filter(word => word.length >= 2);
  if (!tokens.some(token => action.includes(token))) return { ok: false, reason: `状态转换 ${from}→${to} 缺少动作依据：${edge.trigger}` };
  return { ok: true as const };
}

export function stableHash(value: unknown) { return createHash("sha256").update(JSON.stringify(value) ?? "undefined").digest("hex"); }
export async function fileFingerprint(path: string) {
  const data = await readFile(path);
  return { path, size: data.byteLength, sha256: createHash("sha256").update(data).digest("hex") };
}
export function buildInputFingerprints(input: { bible?: unknown; shotContract: unknown; characterCards?: unknown[]; scene?: unknown; props?: unknown[]; references?: unknown[]; prompt: string; generatorConfig: unknown; qaPolicyVersion: string }) {
  return {
    projectBibleHash: stableHash(input.bible ?? null), shotContractHash: stableHash(input.shotContract),
    characterCardHashes: (input.characterCards ?? []).map(stableHash), sceneHash: stableHash(input.scene ?? null),
    propHashes: (input.props ?? []).map(stableHash), referenceManifestHash: stableHash(input.references ?? []),
    promptHash: stableHash(input.prompt), generatorConfigHash: stableHash(input.generatorConfig), qaPolicyVersion: input.qaPolicyVersion,
  };
}
export function compareFingerprints(expected: Record<string, unknown> | undefined, actual: Record<string, unknown>) {
  if (!expected) return { fresh: false, stale: ["missing_fingerprints"] };
  const stale = Object.keys(actual).filter(key => JSON.stringify(expected[key]) !== JSON.stringify(actual[key]));
  return { fresh: stale.length === 0, stale };
}

/** Compact carry-forward context for the next episode; memory is explicit and auditable, not free-form hidden prompt state. */
export function buildEpisodeMemoryPrompt(memory: CrossEpisodeMemory | undefined, nextEpisode: number) {
  if (!memory) return "【跨集记忆】这是项目首集，按项目 Bible 建立连续性。";
  const facts = memory.canonFacts.map(item => `- ${item.fact}`).join("\n");
  const characters = memory.characterStates.map(item => `- ${item.characterId}: ${item.alive ? "存活" : "死亡"}; 伤情=${item.injuries.join("、") || "无"}; 服装=${item.outfitId ?? "沿用设定"}; 位置=${item.locationId ?? "未知"}`).join("\n");
  const props = memory.propStates.map(item => `- ${item.propId}: ${item.stateId}（${item.description}）`).join("\n");
  const threads = memory.unresolvedThreads.filter(item => item.status === "open").map(item => `- ${item.description}`).join("\n");
  const summaries = memory.episodeSummaries.slice(-2).map(item => `- 第${item.episode}集：${item.summary}；结尾状态：${item.endingState}`).join("\n");
  return [`【跨集记忆｜第${nextEpisode}集必须继承】`,`前情摘要：\n${summaries || "无"}`,`已发生事实：\n${facts || "无"}`,`角色状态：\n${characters || "无"}`,`关键道具/车辆：\n${props || "无"}`,`未解决剧情线：\n${threads || "无"}`,"不得无解释复活、治愈伤势、换装、瞬移或重置道具状态；如剧情确需变化，必须在镜头动作中交代原因。"].join("\n\n");
}

export function deriveCrossEpisodeMemory(board: { title: string; bible?: { projectId: string; canon?: string[] }; episodes: Array<{ ep: number; segments: Array<{ sceneId: string; shots: Array<{ id: string; characters: Array<{ id: string; outfit?: string }>; continuity?: { dead?: string[]; injuries?: Array<{ id: string; note: string }>; props?: Array<{ name: string; state: string }> }; action: string }> }> }> }, throughEpisode?: number): CrossEpisodeMemory {
  const episodes = board.episodes.filter(item => item.ep <= (throughEpisode ?? Number.MAX_SAFE_INTEGER));
  const characters = new Map<string, { characterId: string; alive: boolean; injuries: string[]; outfitId?: string; locationId?: string; relationships: string[]; lastSeenEpisode: number }>();
  const props = new Map<string, { propId: string; stateId: string; description: string; lastChangedEpisode: number }>();
  const summaries: CrossEpisodeMemory["episodeSummaries"] = [];
  for (const episode of episodes) {
    const ending: string[] = [];
    const events: string[] = [];
    for (const segment of episode.segments) for (const shot of segment.shots) {
      if (shot.action?.trim()) events.push(shot.action.trim().slice(0, 180));
      for (const deadId of shot.continuity?.dead ?? []) {
        const oldDead = characters.get(deadId) ?? { characterId: deadId, alive: false, injuries: [], relationships: [], lastSeenEpisode: episode.ep };
        oldDead.alive = false; oldDead.lastSeenEpisode = episode.ep; characters.set(deadId, oldDead);
      }
      for (const character of shot.characters) {
        const old = characters.get(character.id) ?? { characterId: character.id, alive: true, injuries: [], relationships: [], lastSeenEpisode: episode.ep };
        old.alive = old.alive && !(shot.continuity?.dead ?? []).includes(character.id);
        const injuries = (shot.continuity?.injuries ?? []).filter(item => item.id === character.id).map(item => item.note);
        if (injuries.length) old.injuries = [...new Set(injuries)];
        if (character.outfit) old.outfitId = character.outfit;
        old.locationId = segment.sceneId; old.lastSeenEpisode = episode.ep; characters.set(character.id, old);
      }
      for (const prop of shot.continuity?.props ?? []) props.set(prop.name, { propId: prop.name, stateId: prop.state, description: prop.state, lastChangedEpisode: episode.ep });
      if (shot.continuity?.dead?.length) ending.push(`死亡角色：${shot.continuity.dead.join("、")}`);
      if (shot.continuity?.injuries?.length) ending.push(`伤情：${shot.continuity.injuries.map(item => `${item.id} ${item.note}`).join("、")}`);
      if (shot.continuity?.props?.length) ending.push(`道具状态：${shot.continuity.props.map(item => `${item.name} ${item.state}`).join("、")}`);
    }
    summaries.push({ episode: episode.ep, summary: events.slice(0, 12).join("；").slice(0, 2000) || `${board.title} 第${episode.ep}集分镜状态摘要`, endingState: [...new Set(ending)].slice(-12).join("；") || "角色状态按本集最后一次出场记录继承" });
  }
  return crossEpisodeMemorySchema.parse({ version: 1, projectId: board.bible?.projectId ?? board.title, updatedAt: new Date().toISOString(), lastEpisode: episodes.at(-1)?.ep ?? 0,
    canonFacts: (board.bible?.canon ?? []).map((fact, index) => ({ id: `canon-${index + 1}`, fact, introducedEpisode: 1 })), characterStates: [...characters.values()], propStates: [...props.values()], unresolvedThreads: (board.bible as { threads?: CrossEpisodeMemory["unresolvedThreads"] } | undefined)?.threads ?? [], episodeSummaries: summaries });
}
