/**
 * 逐角色特征行与“特征不可串用”约束（防止多角色同时挂参考图时，一个角色的纹身/疤痕/配饰被画到另一个角色身上）。
 * 全部由角色卡推导：姓名 + 服装 + 不变标记；某类标记只有部分出场角色拥有时，写明“只有 A 有…；B 没有…”。
 */
import { isCreature, outfitOf, type CharacterCard } from "@/utils/assets/characterCard";

export interface TraitKind { key: string; zh: string; en: string; pattern: RegExp; bareZh: string; bareEn: string }

/** 容易在角色之间串用的可见标记 */
export const traitKinds: TraitKind[] = [
  { key: "tattoo", zh: "纹身", en: "tattoos", pattern: /纹身|花臂|刺青|tattoo/i, bareZh: "手臂和皮肤干净、没有任何纹身", bareEn: "clean bare skin with no tattoos at all" },
  { key: "scar", zh: "疤痕", en: "scars", pattern: /疤|scar/i, bareZh: "没有疤痕", bareEn: "no scars" },
  { key: "mole", zh: "痣", en: "facial moles", pattern: /痣|mole/i, bareZh: "脸上没有痣", bareEn: "no facial mole" },
  { key: "glove", zh: "手套", en: "gloves", pattern: /手套|glove/i, bareZh: "不戴手套", bareEn: "bare hands, no gloves" },
  { key: "glasses", zh: "眼镜", en: "glasses", pattern: /眼镜|墨镜|glasses|sunglasses/i, bareZh: "不戴眼镜", bareEn: "no glasses" },
  { key: "earring", zh: "耳饰", en: "earrings", pattern: /耳环|耳钉|耳饰|earring/i, bareZh: "没有耳饰", bareEn: "no earrings" },
  { key: "beard", zh: "胡须", en: "beard or stubble", pattern: /胡子|胡须|胡茬|络腮|beard|mustache|stubble/i, bareZh: "没有胡须", bareEn: "clean-shaven" },
];

export interface ShotCharacterRef { id: string; outfit?: string }

function cardText(card: CharacterCard, outfitId?: string) {
  const outfit = outfitOf(card, outfitId) as Record<string, unknown>;
  const parts = [card.invariant.face, card.invariant.hair, card.invariant.body, card.invariant.marks, outfit.marks, outfit.upper, outfit.lower, outfit.shoes, outfit.accessories];
  return parts.filter((part): part is string => typeof part === "string").join("；");
}

/** 某角色（某造型）拥有的标记种类 */
export function characterTraitKinds(card: CharacterCard, outfitId?: string) {
  const text = cardText(card, outfitId);
  return traitKinds.filter(kind => kind.pattern.test(text)).map(kind => kind.key);
}

/** 逐人特征行：“萧枫：28岁男；黑色短碎发；服装：…；标记：…” */
export function characterTraitLine(card: CharacterCard, outfitId?: string) {
  const outfit = outfitOf(card, outfitId) as Record<string, unknown>;
  const clothes = (["upper", "lower", "shoes", "accessories"] as const).map(key => outfit[key]).filter((value): value is string => typeof value === "string" && !!value.trim()).join("，");
  const marks = [card.invariant.marks, typeof outfit.marks === "string" ? outfit.marks : undefined].filter(Boolean).join("；");
  if (isCreature(card)) return `${card.name}：${card.identity.species}；${card.invariant.body}${marks ? `；标记：${marks}` : ""}`;
  const gender = { female: "女", male: "男", other: "" }[card.identity.gender];
  return `${card.name}：${card.identity.age}岁${gender}；${card.invariant.face}；${card.invariant.hair}；服装：${clothes}${marks ? `；标记：${marks}` : ""}`;
}

export interface ShotTraits {
  /** 每个出场角色一行 */
  lines: string[];
  /** 不可串用约束（中文） */
  constraints: string[];
  /** 负面词（中文），如“萧枫身上的纹身” */
  negatives: string[];
  /** 英文版约束（H3 等英文提示词风格用） */
  constraintsEn: string[];
}

/**
 * 本镜逐角色特征与互斥约束。只有一个出场角色时也写“没有…”（该角色卡没有的标记若被同场其他角色锚点带入，会串到他身上）；
 * cast 给出全片角色时，按全片角色判断谁拥有该标记（如老五不在本镜，萧枫仍“没有纹身”）。
 */
export function shotTraits(characters: ShotCharacterRef[], cards: Map<string, CharacterCard>, cast?: Iterable<CharacterCard>): ShotTraits {
  const present = characters.map(character => ({ character, card: cards.get(character.id) })).filter((item): item is { character: ShotCharacterRef; card: CharacterCard } => !!item.card);
  const lines = present.map(({ card, character }) => characterTraitLine(card, character.outfit));
  const constraints: string[] = [];
  const negatives: string[] = [];
  const constraintsEn: string[] = [];
  const everyone = [...(cast ?? cards.values())];
  for (const kind of traitKinds) {
    const ownersInShot = present.filter(({ card, character }) => characterTraitKinds(card, character.outfit).includes(kind.key)).map(({ card }) => card.name);
    const ownersInCast = everyone.filter(card => card.outfits.some(outfit => characterTraitKinds(card, outfit.id).includes(kind.key))).map(card => card.name);
    if (!ownersInCast.length) continue;
    const bare = present.filter(({ card }) => !ownersInShot.includes(card.name)).map(({ card }) => card.name);
    if (!bare.length) continue;
    const owners = ownersInShot.length ? ownersInShot : ownersInCast;
    constraints.push(`只有${owners.join("、")}有${kind.zh}；${bare.map(name => `${name}${kind.bareZh}`).join("；")}`);
    negatives.push(...bare.map(name => `${name}身上的${kind.zh}`));
    constraintsEn.push(`Only ${owners.join(" and ")} ${owners.length > 1 ? "have" : "has"} ${kind.en}; ${bare.map(name => `${name} has ${kind.bareEn}`).join("; ")}.`);
  }
  if (present.length > 1) {
    constraints.push("每个角色只保留自己角色卡上的特征与服装，不得把一个角色的纹身、疤痕、配饰或服装画到另一个角色身上");
    constraintsEn.push("Each character keeps only their own marks, clothing and accessories; never transfer a tattoo, scar, accessory or garment from one character to another.");
  }
  return { lines, constraints, negatives, constraintsEn };
}
