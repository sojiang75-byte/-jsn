/**
 * MiniMax H3 角色设定表的视角枚举与朝向描述（Toonflow 原创文字，MIT）。
 *
 * 视角清单（13 个：6 头部 + 3 全身 + 2 服装 + 2 细节）与“用鼻尖指向画面哪一侧描述朝向”的做法，
 * 参考 H3-Character-Sheet-Designer（https://github.com/ukr8b3g-cmyk/H3-Character-Sheet-Designer，
 * Copyright (c) 2026 ukr8b3g-cmyk，MIT License；见仓库根目录 THIRD_PARTY_NOTICES.md）的 view catalog 设计。
 * 本文件的 id、措辞与布局算法均为独立编写，未复制其代码与美术资源。
 *
 * 约定：H3 社区工作流里的“left profile / 左侧面”指鼻尖朝向画面右侧（与角色解剖学左侧并不一致），
 * 因此这里的 id 直接写画面方向（NoseRight / NoseLeft），提示词也只写“鼻尖指向画面哪条边”，避免左右歧义。
 */

export const h3ViewIds = [
  "headFront", "headProfileNoseRight", "headProfileNoseLeft", "headThreeQuarterNoseRight", "headThreeQuarterNoseLeft", "headBack",
  "bodyFront", "bodyProfileNoseRight", "bodyBack",
  "outfitFront", "outfitBack",
  "hands", "feet",
] as const;
export type H3ViewId = (typeof h3ViewIds)[number];
export type H3ViewGroup = "head" | "body" | "outfit" | "detail";

export interface H3View {
  id: H3ViewId;
  group: H3ViewGroup;
  /** 中文名（含 H3 社区约定的左右叫法） */
  label: string;
  /** 取景范围 */
  framing: string;
  /** 朝向：只用画面方向描述 */
  orientation: string;
  /** 画格宽高比（宽/高），用于排版 */
  aspect: number;
}

const portrait = "head-and-shoulders portrait from the top of the hair down to the upper chest";
const fullBody = "full figure from the top of the hair to the soles of the footwear, with clear empty space above the head and below the feet";

export const h3Views: Record<H3ViewId, H3View> = {
  headFront: { id: "headFront", group: "head", label: "头部正面", framing: portrait, aspect: 0.8,
    orientation: "facing the camera squarely; the nose sits on the vertical center line of the face and both ears show equally" },
  headProfileNoseRight: { id: "headProfileNoseRight", group: "head", label: "头部侧面（H3 约定的左侧面：鼻尖朝画面右）", framing: portrait, aspect: 0.8,
    orientation: "exact 90-degree profile; the nose points to the RIGHT edge of the image; only one eye is visible and the far ear is hidden" },
  headProfileNoseLeft: { id: "headProfileNoseLeft", group: "head", label: "头部侧面（H3 约定的右侧面：鼻尖朝画面左）", framing: portrait, aspect: 0.8,
    orientation: "exact 90-degree profile; the nose points to the LEFT edge of the image; only one eye is visible and the far ear is hidden" },
  headThreeQuarterNoseRight: { id: "headThreeQuarterNoseRight", group: "head", label: "头部 3/4 侧（鼻尖朝画面右）", framing: portrait, aspect: 0.8,
    orientation: "turned 45 degrees so the nose points toward the RIGHT side of the image; both eyes stay visible and the eye farther from the camera is foreshortened" },
  headThreeQuarterNoseLeft: { id: "headThreeQuarterNoseLeft", group: "head", label: "头部 3/4 侧（鼻尖朝画面左）", framing: portrait, aspect: 0.8,
    orientation: "turned 45 degrees so the nose points toward the LEFT side of the image; both eyes stay visible and the eye farther from the camera is foreshortened" },
  headBack: { id: "headBack", group: "head", label: "头部背面", framing: portrait, aspect: 0.8,
    orientation: "seen from directly behind; no facial features are visible and the head is not turned toward the camera" },
  bodyFront: { id: "bodyFront", group: "body", label: "全身正面", framing: fullBody, aspect: 0.42,
    orientation: "standing in a neutral relaxed pose; shoulders, hips and feet square to the camera; the nose on the vertical center line" },
  bodyProfileNoseRight: { id: "bodyProfileNoseRight", group: "body", label: "全身侧面（鼻尖朝画面右）", framing: fullBody, aspect: 0.42,
    orientation: "strict 90-degree side view; the nose, chest and toes all point to the RIGHT edge of the image; not looking at the camera" },
  bodyBack: { id: "bodyBack", group: "body", label: "全身背面", framing: fullBody, aspect: 0.42,
    orientation: "seen from directly behind; no face visible; the head is not turned" },
  outfitFront: { id: "outfitFront", group: "outfit", label: "服装正面", aspect: 0.6,
    framing: "the complete outfit shown on its own as a ghost-mannequin presentation, collar to shoes, without the wearer's head, hands or skin",
    orientation: "front side of the garments, symmetrical and flat to the camera" },
  outfitBack: { id: "outfitBack", group: "outfit", label: "服装背面", aspect: 0.6,
    framing: "the complete outfit shown on its own as a ghost-mannequin presentation, collar to shoes, without the wearer's head, hands or skin",
    orientation: "back side of the garments, symmetrical and flat to the camera" },
  hands: { id: "hands", group: "detail", label: "双手细节", aspect: 1,
    framing: "close-up of both hands: one showing the palm, one showing the back of the hand, including rings, gloves, nail color, scars or other marks",
    orientation: "fingers pointing up, hands side by side" },
  feet: { id: "feet", group: "detail", label: "鞋履细节", aspect: 1,
    framing: "close-up of the footwear (or bare feet) as worn, one foot seen from the front and one from the outer side",
    orientation: "placed side by side on the same ground line" },
};

/** 设定表预设：full13 为完整 13 视角；turnaround5 为常用五视角转面。 */
export const h3SheetPresets = {
  full13: [...h3ViewIds],
  turnaround5: ["headFront", "headProfileNoseRight", "bodyFront", "bodyProfileNoseRight", "bodyBack"],
} satisfies Record<string, H3ViewId[]>;
export type H3SheetPreset = keyof typeof h3SheetPresets;

/** MiniMax H3 官方 API 可选的画幅（宽/高）。 */
export const h3ApiRatios: [string, number][] = [["21:9", 21 / 9], ["16:9", 16 / 9], ["4:3", 4 / 3], ["1:1", 1], ["3:4", 3 / 4], ["9:16", 9 / 16]];

export function closestH3Ratio(aspect: number) {
  return h3ApiRatios.reduce((best, item) => Math.abs(Math.log(item[1] / aspect)) < Math.abs(Math.log(best[1] / aspect)) ? item : best)[0];
}

export interface H3SheetPanel { index: number; view: H3View; column: number; row: number; rows: number }

/**
 * 设定表排版：全身与服装各占一整列；头部与细节视图两两上下叠放成一列。
 * 返回列序与整体宽高比（以画面高度为 1），供提示词描述“从左到右第几栏、上/下格”。
 */
export function layoutH3Sheet(viewIds: readonly H3ViewId[]) {
  const views = viewIds.map(id => h3Views[id]);
  const order: H3ViewGroup[] = ["head", "body", "outfit", "detail"];
  const panels: H3SheetPanel[] = [];
  let column = 0;
  let width = 0;
  let index = 0;
  for (const group of order) {
    const members = views.filter(view => view.group === group);
    const stacked = group === "head" || group === "detail";
    for (let start = 0; start < members.length; start += stacked ? 2 : 1) {
      const slice = members.slice(start, start + (stacked ? 2 : 1));
      column++;
      slice.forEach((view, row) => panels.push({ index: ++index, view, column, row, rows: slice.length }));
      // 叠放时每格高度为 1/2，宽度按格宽高比折算
      width += Math.max(...slice.map(view => view.aspect / slice.length));
    }
  }
  const aspect = width;
  return { panels, columns: column, aspect, ratio: closestH3Ratio(aspect) };
}
