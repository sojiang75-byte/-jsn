/** 通用提示词风格档：保持一键成片原有的中文分层提示词（适用于 Qwen-Image、Wan、Seedance 等通用模型）。 */
import { buildCharacterViewPrompt } from "@/utils/assets/characterCard";
import { buildShotPrompts } from "../storyboard/prompts";
import type { PromptStyle } from "./types";

export const genericPromptStyle: PromptStyle = {
  id: "generic",
  label: "通用（中文分层提示词）",
  hostReferenceLabels: true,
  characterAnchor(card, outfitId) {
    const view = buildCharacterViewPrompt(card, "anchor", outfitId);
    return { prompt: `${view.prompt}\nAvoid: ${view.negative}`, ratio: view.ratio, seed: view.seed };
  },
  characterFace(card, outfitId) {
    const view = buildCharacterViewPrompt(card, "face", outfitId);
    return { prompt: `${view.prompt}\nAvoid: ${view.negative}`, ratio: view.ratio, seed: view.seed };
  },
  scene(scene, style, aspectRatio) {
    return { prompt: `${style}。场景设定图：${scene.name}——${scene.description}。空镜，画面中没有任何人物，不出现文字。`, ratio: aspectRatio };
  },
  keyframe(context, plan) {
    const prompts = buildShotPrompts({ ...context, characterImageIndex: plan.characterImageIndex });
    return `${prompts.firstFrame}\n避免：${prompts.negative}`;
  },
  endFrame(context, plan) {
    const prompts = buildShotPrompts({ ...context, characterImageIndex: plan.characterImageIndex });
    return prompts.endFrame ? `${prompts.endFrame}\n避免：${prompts.negative}` : undefined;
  },
  video(context, input) {
    if (input.mode !== "reference" || !input.plan) return buildShotPrompts({ ...context, characterImageIndex: undefined }).video;
    // 参考模式：plan 第 1 张为本镜首帧，角色序号已整体后移
    const prompts = buildShotPrompts({ ...context, characterImageIndex: input.plan.characterImageIndex });
    return `${prompts.video}\n首帧画面：${context.shot.firstFrame}`;
  },
};
