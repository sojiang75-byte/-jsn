/*
 * 分镜质量门：程序化、确定性检查，不依赖模型自评。
 *
 * 门的划分（段号连号、镜头时长区间、段时长上限、台词装得下、同框人数、景别/运镜枚举、构图量化字段、
 * 每集时长容差、人物对账）参考 shuohao-skills `skills/novel-storyboard/scripts/novel-storyboard.mjs`
 * 的 gateReport（Copyright 2026 烁皓，Apache-2.0，见 THIRD_PARTY_NOTICES.md），按 Toonflow 的三层结构重写，
 * 并新增：角色卡存在性、锚点图就绪、参考图数量上限、台词说话人在场、连续镜头衔接合法性。
 */
import { defaultParams, compositionFields, type StoryboardParams } from "./vocab";
import { iterateShots, type Storyboard } from "./schema";
import { estimateDialogueSeconds } from "./timing";
import { packRenderClips } from "./clips";
import { continuityProblems, crossEpisodeContinuityProblems } from "./continuity";
import { characterReferenceImages, type CharacterCard } from "@/utils/assets/characterCard";
import { buildSourceLedger } from "../sourceLedger";

export type GateSeverity = "error" | "warning";
export interface GateResult {
  id: string;
  label: string;
  severity: GateSeverity;
  ok: boolean;
  details: string[];
}

export interface GateContext {
  params?: Partial<StoryboardParams>;
  /** 角色卡，按角色 id 索引 */
  cards?: Map<string, CharacterCard>;
  /** 为 true 时要求每个出场角色都已有锚点图（生成阶段前检查） */
  requireAnchors?: boolean;
  /** 单次生成可挂载的参考图上限 */
  maxReferenceImages?: number;
  /** 视频模型支持的时长档位 */
  allowedDurations?: number[];
  /** 镜头是 1–4 秒剪辑单位，视频按 2–4 镜合成 5–15 秒素材。此时不要求单镜对齐视频档位。 */
  clipRhythm?: boolean;
  /** 素材时长必须落入的视频档位；仅 clipRhythm 时检查 */
  clipDurations?: number[];
  /** 原文（章节）：给出时检查原文覆盖——每句引号台词逐字出现在某镜台词里，各镜 source 拼起来覆盖原文 */
  chapter?: string;
  /** 原文覆盖门的严重度，缺省 error（多集合并时可降为 warning） */
  coverageSeverity?: GateSeverity;
}

/** 原文覆盖检查（aid-studio 的 source-coverage 思路，独立实现）：返回缺失的台词与未被任何镜头 source 覆盖的原文段落。 */
export function sourceCoverage(board: Storyboard, chapter: string) {
  const shots = board.episodes.flatMap(episode => episode.segments.flatMap(segment => segment.shots));
  const spoken = shots.flatMap(shot => (shot.dialogue ?? []).map(line => line.text)).join("\n");
  const sounds = shots.map(shot => shot.sfx ?? "").join("\n");
  const ledger = buildSourceLedger(chapter, board.characters);
  let dialogueCursor = 0; let soundCursor = 0;
  const missingLines: string[] = [];
  for (const quote of ledger.quotes) {
    if (quote.kind === "quoted_text") continue;
    const text = quote.kind === "sfx" ? sounds : spoken;
    const cursor = quote.kind === "sfx" ? soundCursor : dialogueCursor;
    const at = text.indexOf(quote.text, cursor);
    if (at < 0) missingLines.push(quote.text);
    else if (quote.kind === "sfx") soundCursor = at + quote.text.length;
    else dialogueCursor = at + quote.text.length;
  }
  const body = chapter;
  const covered = new Uint8Array(body.length);
  let withSource = 0; let cursor = 0; let ordered = true;
  for (const shot of shots) {
    if (!shot.source) continue;
    withSource++;
    const at = body.indexOf(shot.source, cursor);
    if (at < 0) { ordered = false; continue; }
    covered.fill(1, at, at + shot.source.length);
    cursor = at + shot.source.length;
  }
  const gaps: string[] = [];
  let start = -1;
  for (let index = 0; index <= body.length; index++) {
    if (index < body.length && !covered[index]) { if (start < 0) start = index; continue; }
    if (start >= 0 && index - start >= 6) gaps.push(body.slice(start, index));
    start = -1;
  }
  const ratio = body.length ? covered.reduce((sum, value) => sum + value, 0) / body.length : 1;
  return { missingLines, gaps, ratio, withSource, shots: shots.length, ordered };
}

const round = (value: number) => Math.round(value * 10) / 10;

export function runGates(board: Storyboard, context: GateContext = {}): { ok: boolean; gates: GateResult[] } {
  const params = { ...defaultParams, ...context.params };
  const bad: Record<string, string[]> = {
    ids: [], shotLength: [], segmentCap: [], dialogueFit: [], crowd: [], cast: [], anchors: [], speakers: [],
    blocking: [], composition: [], scenes: [], duration: [], references: [], continuity: [], durations: [], clips: [], staging: [], director: [], story: [], crossEpisode: [], propStates: [], coverage: [], sourceSpan: [],
  };
  const castIds = new Set(board.characters.map(item => item.id));
  const sceneIds = new Set(board.scenes.map(item => item.id));
  const seenEpisodes = new Set<number>();

  for (const episode of board.episodes) {
    const label = `E${String(episode.ep).padStart(2, "0")}`;
    if (seenEpisodes.has(episode.ep)) bad.ids!.push(`集号 ${episode.ep} 重复`);
    seenEpisodes.add(episode.ep);
    let episodeSeconds = 0;
    episode.segments.forEach((segment, segmentIndex) => {
      const wantSegment = `${label}-${String(segmentIndex + 1).padStart(2, "0")}`;
      if (segment.id !== wantSegment) bad.ids!.push(`第 ${segmentIndex + 1} 段应为 ${wantSegment}，实际 ${segment.id}`);
      if (!sceneIds.has(segment.sceneId)) bad.scenes!.push(`${segment.id} 的场景 ${segment.sceneId} 未在 scenes 中定义`);
      if (segment.blocking.trim().length < 8) bad.blocking!.push(`${segment.id} 的开场站位过于简略`);
      let segmentSeconds = 0;
      segment.shots.forEach((shot, shotIndex) => {
        const wantShot = `${segment.id}-${String(shotIndex + 1).padStart(2, "0")}`;
        if (shot.id !== wantShot) bad.ids!.push(`${segment.id} 第 ${shotIndex + 1} 镜应为 ${wantShot}，实际 ${shot.id}`);
        const seconds = shot.seconds;
        if (seconds === undefined) bad.shotLength!.push(`${shot.id} 未设置时长（应先运行时长估算）`);
        else {
          segmentSeconds += seconds;
          const lengthMax = context.clipRhythm ? Math.max(params.maxShotSeconds, 15) : params.maxShotSeconds;
          if (seconds < params.minShotSeconds || seconds > lengthMax) bad.shotLength!.push(`${shot.id} ${seconds} 秒`);
          const need = estimateDialogueSeconds(shot, params);
          if (need > seconds + 0.05) bad.dialogueFit!.push(`${shot.id} 台词约需 ${round(need)} 秒，镜头只有 ${seconds} 秒`);
          if (!context.clipRhythm && context.allowedDurations?.length && !context.allowedDurations.includes(seconds)) {
            bad.durations!.push(`${shot.id} ${seconds} 秒不在模型档位 ${context.allowedDurations.join("/")} 内`);
          }
        }
        if (shot.characters.length > params.maxOnScreen) bad.crowd!.push(`${shot.id} 同框 ${shot.characters.length} 人`);
        const onScreen = new Set(shot.characters.map(item => item.id));
        if (onScreen.size !== shot.characters.length) bad.cast!.push(`${shot.id} 出场角色重复`);
        let referenceCount = 0;
        for (const character of shot.characters) {
          if (!castIds.has(character.id)) { bad.cast!.push(`${shot.id} 的角色 ${character.id} 未在 characters 中定义`); continue; }
          const card = context.cards?.get(character.id);
          if (context.cards && !card) { bad.cast!.push(`${shot.id} 的角色 ${character.id} 没有角色卡`); continue; }
          if (card && character.outfit && !card.outfits.some(item => item.id === character.outfit)) {
            bad.cast!.push(`${shot.id} 的角色 ${character.id} 没有造型 ${character.outfit}`);
            continue;
          }
          if (card) {
            const images = characterReferenceImages(card, character.outfit);
            if (context.requireAnchors && !images.length) bad.anchors!.push(`${shot.id} 的角色 ${card.name} 缺少锚点图`);
            referenceCount += Math.min(1, images.length);
          }
        }
        if (context.maxReferenceImages !== undefined && referenceCount > context.maxReferenceImages) {
          bad.references!.push(`${shot.id} 至少需要 ${referenceCount} 张角色参考图，超出模型上限 ${context.maxReferenceImages}`);
        }
        for (const line of shot.dialogue ?? []) {
          if (line.speaker !== "narrator" && !onScreen.has(line.speaker) && !/画外|V\.?O\.?|O\.?S\.?/i.test(line.emotion ?? "")) {
            bad.speakers!.push(`${shot.id} 的说话人 ${line.speaker} 不在画面中（画外音请在 emotion 写“画外”）`);
          }
        }
        if (shot.transition === "continuous" && shotIndex === 0) bad.continuity!.push(`${shot.id} 是段首镜，不能与上一段动作连续`);
        for (const problem of stagingProblems(shot)) bad.staging!.push(`${shot.id} ${problem}`);
        for (const problem of directorContractProblems(shot)) bad.director!.push(`${shot.id} ${problem}`);
        const missing = compositionFields.filter(field => !shot[field]?.trim());
        if (missing.length) bad.composition!.push(`${shot.id} 缺 ${missing.join("/")}`);
      });
      if (segmentSeconds > params.maxSegmentSeconds) bad.segmentCap!.push(`${segment.id} 共 ${round(segmentSeconds)} 秒`);
      if (context.clipRhythm) {
        for (const pack of packRenderClips(segment.shots, { allowedDurations: context.clipDurations, minClipSeconds: 5, maxClipSeconds: 15 })) {
          if (pack.seconds < 5 || pack.seconds > 15) bad.clips!.push(`${pack.id} 合成素材 ${pack.seconds} 秒，应在 5–15 秒`);
          if (context.clipDurations?.length && !context.clipDurations.includes(pack.seconds)) bad.clips!.push(`${pack.id} 合成素材 ${pack.seconds} 秒不在模型档位 ${context.clipDurations.join("/")} 内`);
          if (pack.shots.length > 4) bad.clips!.push(`${pack.id} 合成了 ${pack.shots.length} 个镜头，应是 2–4 个`);
        }
      }
      episodeSeconds += segmentSeconds;
    });
    if (episode.targetSeconds) {
      const low = episode.targetSeconds * (1 - params.tolerance);
      const high = episode.targetSeconds * (1 + params.tolerance);
      if (episodeSeconds < low || episodeSeconds > high) {
        bad.duration!.push(`${label} 共 ${round(episodeSeconds)} 秒，目标 ${episode.targetSeconds} 秒 ±${Math.round(params.tolerance * 100)}%`);
      }
    }
  }

  bad.story!.push(...continuityProblems(board));
  bad.crossEpisode!.push(...crossEpisodeContinuityProblems(board));
  for (const prop of board.props ?? []) if (prop.stateMachine) {
    const states = new Set(prop.stateMachine.states.map(state => state.id));
    if (!states.has(prop.stateMachine.initialState)) bad.propStates!.push(`${prop.name} 初始状态 ${prop.stateMachine.initialState} 未定义`);
    for (const transition of prop.stateMachine.transitions) if (!states.has(transition.from) || !states.has(transition.to)) bad.propStates!.push(`${prop.name} 状态转换 ${transition.from}→${transition.to} 引用了未定义状态`);
    let current = prop.stateMachine.initialState;
    for (const { shot } of iterateShots(board)) {
      const state = shot.continuity?.props?.find(item => item.name === prop.name)?.state;
      if (!state || state === current) continue;
      const transition = prop.stateMachine.transitions.find(item => item.from === current && item.to === state);
      if (!transition) bad.propStates!.push(`${shot.id} ${prop.name} 不允许从 ${current} 变为 ${state}`);
      else if (!transition.trigger.split(/[，,、；;\s]+/).filter(word => word.length >= 2).some(word => shot.action.includes(word))) bad.propStates!.push(`${shot.id} ${prop.name} 状态变化缺少动作依据（${transition.trigger}）`);
      current = state;
    }
  }
  if (context.chapter?.trim()) {
    const report = sourceCoverage(board, context.chapter);
    for (const line of report.missingLines) bad.coverage!.push(`原文台词「${line}」没有逐字出现在任何镜头的台词里`);
    if (!report.ordered) bad.sourceSpan!.push("各镜 source 的顺序与原文顺序不一致或存在重复片段");
    if (report.ratio < 1) bad.sourceSpan!.push(`各镜 source 只覆盖原文 ${Math.round(report.ratio * 100)}%，未覆盖：${report.gaps.slice(0, 5).map(gap => gap.slice(0, 30)).join("｜")}`);
  }
  const gates: GateResult[] = [];
  const add = (id: keyof typeof bad, label: string, severity: GateSeverity) => gates.push({ id, label, severity, ok: bad[id]!.length === 0, details: bad[id]! });
  add("ids", "集/段/镜编号格式正确且连号", "error");
  add("scenes", "每段的场景已定义", "error");
  add("cast", "每镜出场角色均有定义、角色卡与造型", "error");
  add("anchors", "出场角色已有锚点参考图", "error");
  add("shotLength", `每镜时长 ${params.minShotSeconds}–${params.maxShotSeconds} 秒`, "error");
  add("dialogueFit", "台词装得进镜头时长", "error");
  add("durations", "镜头时长对齐模型档位", "error");
  if (context.clipRhythm) add("clips", "2–4 个镜头合成一条 5–15 秒素材，并对齐模型档位", "error");
  add("references", "强制参考图数量不超过模型上限", "error");
  add("continuity", "连续镜头衔接合法", "error");
  add("blocking", "每段有开场站位", "error");
  add("story", "单集剧情连续性：死者不复活、持物不无故换手", "error");
  add("crossEpisode", "跨集连续性：死亡、伤情、道具状态持续继承", "error");
  add("propStates", "车辆/道具状态机：只允许合法状态转换", "error");
  add("staging", "空间调度合理（无人站在行驶车辆前方的车道上）", "error");
  add("director", "镜头视角、主体视点与轴线合同有效", "error");
  if (context.chapter?.trim()) {
    add("coverage", "原文覆盖：原文引号台词逐字保留在镜头台词里", context.coverageSeverity ?? "error");
    add("sourceSpan", "原文覆盖：各镜 source 逐字摘录、顺序一致且覆盖全章", context.coverageSeverity ?? "error");
  }
  add("segmentCap", `每段总时长 ≤ ${params.maxSegmentSeconds} 秒`, "warning");
  add("crowd", `单镜同框 ≤ ${params.maxOnScreen} 人`, "warning");
  add("speakers", "说话人在画面中或标注画外", "warning");
  add("composition", "构图量化字段齐全（焦距/机位/构图/视线/焦点）", "warning");
  add("duration", "每集总时长在目标容差内", "warning");
  return { ok: gates.every(gate => gate.ok || gate.severity === "warning"), gates };
}

const negatedPov = /(非|不(要|用|是|能|得)?|禁止|避免|没有|无)\s*(第一人称|主观(视角|镜头)|POV)|\b(no|not|non|avoid|never)[\s-]+(a\s+)?(first[\s-]person|POV|point[\s-]of[\s-]view)/gi;
const povPattern = /第一人称|主观(视角|镜头)|观众视角|玩家视角|\bPOV\b|first[\s-]person|point[\s-]of[\s-]view/i;
const roadway = /(车道|路中央|马路中间|公路上|高速上|高架(桥)?上|桥面上|路面上|highway|traffic lane|middle of the road)/i;
const onFoot = /(站|立|拦|挡|跑|走|跪|躺|趴)|\b(stand|stands|standing|blocking|walk|walks|walking|run|runs|running)\b/i;
const inVehicle = /(车内|车里|车厢|驾驶座|驾驶室|副驾|后排|车窗内|inside the (van|car|truck)|in the driver'?s seat)/i;
const moving = /(疾驰|飞驰|行驶|驶来|迎面|冲来|开来|逼近|追赶|高速|speeding|driving|oncoming|racing|approaching)/i;

/**
 * 分镜调度检查：禁止第一人称主观持枪/伸手镜头；禁止人物徒步站在行驶车辆前方的公路/高架车道上（车外的人只能在路边或车内）。
 * 只检查画面字段（首帧、动作、尾帧、机位、构图、站位姿态）。
 */
export function stagingProblems(shot: Pick<Storyboard["episodes"][number]["segments"][number]["shots"][number], "firstFrame" | "action" | "endFrame" | "cameraPosition" | "composition" | "characters">) {
  const problems: string[] = [];
  const fields = [shot.firstFrame, shot.action, shot.endFrame, shot.cameraPosition, shot.composition, ...shot.characters.map(item => item.pose)].filter((text): text is string => !!text);
  const text = fields.join("。");
  for (const sentence of text.split(/[。；;.!?！？\n]/)) {
    if (shot.characters.length && roadway.test(sentence) && onFoot.test(sentence) && moving.test(sentence) && !inVehicle.test(sentence)) {
      problems.push(`人物徒步出现在行驶车辆前方的车道上（“${sentence.trim().slice(0, 40)}”），请把人物放在车内或路边`);
      break;
    }
  }
  return problems;
}

/** 检查显式导演合同；未声明合同的旧 v4 镜头不阻断迁移。 */
export function directorContractProblems(shot: Pick<Storyboard["episodes"][number]["segments"][number]["shots"][number], "id" | "firstFrame" | "action" | "endFrame" | "cameraPosition" | "composition" | "characters" | "cameraContract" | "extrasPolicy" | "spatialContract">) {
  const problems: string[] = [];
  const contract = shot.cameraContract;
  const text = [shot.firstFrame, shot.action, shot.endFrame, shot.cameraPosition, shot.composition, ...shot.characters.map(item => item.pose)]
    .filter((value): value is string => !!value).join("。");
  const mentionsPov = povPattern.test(text.replace(negatedPov, ""));
  if (contract?.viewpoint === "third_person" && mentionsPov) {
    problems.push("合同指定第三人称，但画面描述出现第一人称/主观视角");
  }
  if (contract && ["first_person", "subjective_camera"].includes(contract.viewpoint) && !contract.subjectCharacterId) {
    problems.push("主观视角缺少 subjectCharacterId");
  }
  if (contract?.subjectCharacterId && !shot.characters.some(character => character.id === contract.subjectCharacterId)) {
    problems.push(`视点主体 ${contract.subjectCharacterId} 不在本镜角色清单中`);
  }
  const spatialIds = (shot.spatialContract?.positions ?? []).map(item => item.characterId);
  if (new Set(spatialIds).size !== spatialIds.length) problems.push("spatialContract 中同一角色重复定义画面位置");
  for (const id of spatialIds) if (!shot.characters.some(character => character.id === id)) problems.push(`空间合同角色 ${id} 不在本镜角色清单中`);
  if (contract?.axisSide && !contract.axisId) problems.push("指定 axisSide 时必须同时指定 axisId");
  if (shot.extrasPolicy?.mode === "listed_only" && !shot.extrasPolicy.allowedDescription?.trim()) {
    problems.push("extrasPolicy=listed_only 时必须填写 allowedDescription");
  }
  return problems;
}

/** 把未通过的门整理为可回喂给模型的修改意见。 */
export function gateFeedback(gates: GateResult[], includeWarnings = false) {
  return gates.filter(gate => !gate.ok && (includeWarnings || gate.severity === "error"))
    .map(gate => `【${gate.label}】${gate.details.slice(0, 20).join("；")}`).join("\n");
}

export function countShots(board: Storyboard) {
  let count = 0;
  for (const _ of iterateShots(board)) count++;
  return count;
}
