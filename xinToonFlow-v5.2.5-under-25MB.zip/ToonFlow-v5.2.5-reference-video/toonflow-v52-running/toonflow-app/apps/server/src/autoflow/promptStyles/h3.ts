/**
 * MiniMax H3 提示词风格档（Toonflow 原创实现，MIT）。
 *
 * 结构遵循 MiniMax 官方 H3 提示词指南（MiniMax-AI/MiniMax-H3 仓库 skills/h3-prompt-writing）：
 * - 参考生成（Ref2VA）六段：subject_definitions / summary / retention_analysis / detailed_description /
 *   overall_soundscape / non_diegetic_music；用 <Subject N>、<Picture N> 指代，summary 以 [reference generation] 等任务前缀开头。
 * - 文/首帧/首尾帧生成（T2VA/I2VA/FL2VA）：integrated_multimodal_description + overall_soundscape + non_diegetic_music，
 *   首帧/首尾帧模式第一行写图片与目标视频时间点的对齐说明，随后空一行。
 * - 正文用英文；台词保持原语言并写成 <d>[Language] text</d>，说话人用 (S1)(S2) 编号；画外音写明嘴唇不动。
 * - 运镜用官方词汇（Push In / Pan / Truck / Tilt / Pedestal / Arc / Tracking / Static …）写成自然句。
 *
 * 角色设定表的视角清单、参考图角色分工（同一角色 / 脸 / 头部 / 服装 / 手 / 鞋）与“锚点优先、静帧用短视频首帧”的流程，
 * 参考 H3-Character-Sheet-Designer（Copyright (c) 2026 ukr8b3g-cmyk，MIT；见 THIRD_PARTY_NOTICES.md），文字与代码独立编写。
 *
 * H3 官方 API 只有视频接口，没有 seed：静帧（锚点、正脸、设定表、场景、关键帧）以“画面从第一帧起完整呈现且全程不变”的
 * 提示词生成最短视频，再由流水线用 FFmpeg 取第 0 帧。
 */
import type { CharacterCard } from "@/utils/assets/characterCard";
import { shotTraits } from "../traits";
import { continuityLinesEn } from "../storyboard/continuity";
import { shotPropCards } from "../storyboard/propCards";
import { cameraMoves, shotSizes } from "../storyboard/vocab";
import type { ShotPromptContext } from "../storyboard/prompts";
import type { ReferenceEntry, ShotReferencePlan } from "../references";
import { h3SheetPresets, h3Views, layoutH3Sheet, type H3SheetPreset, type H3ViewId } from "./h3Views";
import type { PromptStyle, StillPrompt, VideoPromptInput } from "./types";

/** 官方 API 文本上限 7000 字符；留出余量。 */
export const h3PromptLimit = 6800;

/** 参考图角色：限定每张参考图只贡献哪些属性。 */
export const h3ReferenceRoles = {
  sameCharacter: "use it for the identity of {subject}: face, hairstyle, body proportions, outfit colors and materials. Re-pose and re-frame freely; do not copy its background, lighting, pose or framing",
  face: "use it only for the facial structure, eye shape, skin tone and facial marks of {subject}. Do not take hairstyle, clothing, pose or background from it",
  head: "use it only for the face and hairstyle of {subject}. Do not take clothing, pose or background from it",
  sheet: "it is a multi-view design sheet of {subject}; use it for how {subject} looks from the side, the back and in close details. Do not reproduce the sheet layout",
  clothing: "use it only for the garments of {subject}: cut, colors, materials and trims. Do not transfer the face, hair or body of anyone shown",
  clothingFront: "use it only for the front side of the garments of {subject}",
  clothingBack: "use it only for the back side of the garments of {subject}",
  hands: "use it only for the hands of {subject}: skin tone, nails, rings, gloves and marks",
  footwear: "use it only for the footwear of {subject}",
} as const;
export type H3ReferenceRole = keyof typeof h3ReferenceRoles;

const role = (name: H3ReferenceRole, subject: string) => h3ReferenceRoles[name].replaceAll("{subject}", subject);

const stillHold = "The completed image is fully present in the very first frame and stays exactly the same until the last frame: no movement, no camera motion, no zoom, no cuts, no transitions, no fades.";
const cleanFrame = "No on-screen text, subtitles, captions, logos or watermark.";
const silent = { soundscape: "N/A", music: "N/A" };

const clip = (text: string | undefined, max = 400) => {
  const value = (text ?? "").replace(/\s+/g, " ").trim();
  return value.length > max ? `${value.slice(0, max - 1)}…` : value;
};
const sentence = (text: string | undefined, max?: number) => {
  const value = clip(text, max);
  return value ? (/[.!?。！？]$/.test(value) ? value : `${value}.`) : "";
};
const compact = (parts: (string | false | undefined)[]) => parts.filter((part): part is string => !!part && !!part.trim()).join(" ");

function genderWord(card: CharacterCard) {
  const age = card.identity.age;
  if (card.identity.gender === "female") return age < 13 ? "girl" : age < 18 ? "teenage girl" : "woman";
  if (card.identity.gender === "male") return age < 13 ? "boy" : age < 18 ? "teenage boy" : "man";
  return age < 18 ? "child" : "person";
}

function outfitOf(card: CharacterCard, outfitId?: string) {
  return (outfitId ? card.outfits.find(item => item.id === outfitId) : undefined) ?? card.outfits[0]!;
}

const creaturePattern = /\b((?:praying |stag |dung |orb-weaver |garden |wolf )?(?:mantis|mantid|beetle|spider|ant|snail|slug|insect|nymph|larva|caterpillar|butterfly|moth|bee|wasp|fly|cricket|grasshopper|cicada|dragonfly|ladybug|ladybird|worm|scorpion|frog|toad|lizard|bird|sparrow|cat|dog|fox|rabbit|mouse|rat|fish))(?:es|s)?\b/i;

/** 非人类角色的物种：优先角色卡 identity.species，否则从身体 / 面部描述里认出常见动物词；人类返回 undefined。 */
export function creatureOf(card: CharacterCard): string | undefined {
  if (card.identity.species?.trim()) return card.identity.species.trim();
  for (const text of [card.invariant.body, card.invariant.face]) {
    const match = creaturePattern.exec(text);
    if (match) return match[1]!.toLowerCase();
  }
  return undefined;
}

/** 某造型下的标志性记号：造型 marks 优先，其次 invariant.marks；"none" 视为没有。 */
export function marksOf(card: CharacterCard, outfitId?: string) {
  const value = outfitOf(card, outfitId).marks ?? card.invariant.marks;
  return value && !/^none$/i.test(value.trim()) ? value.trim() : undefined;
}

/** 非人类角色的负向约束：真实物种解剖结构，画面里不得出现人脸 / 人体 / 人。 */
export function creatureGuard(card: CharacterCard, outfitId?: string) {
  const kind = creatureOf(card);
  if (!kind) return undefined;
  const outfit = outfitOf(card, outfitId);
  const wingless = /\b(wingless|no wings)\b/i.test([outfit.upper, outfit.lower].filter(Boolean).join(" "));
  return `${wingless ? `This stage of ${card.name} has NO wings at all, only tiny wing buds; the bare segmented abdomen is fully exposed and not covered by anything; do not draw any wings. ` : ""}`+`${card.name} is an anatomically accurate real ${kind} photographed as photoreal macro nature photography, with true ${kind} head, eyes, legs and body; no human face, no human skin, no human body parts, not a costume, and no humans anywhere in the image.`;
}

/** 视角措辞的物种化：把头发 / 鼻子 / 鞋等人体词换成昆虫等动物也成立的说法。 */
export function creatureView(text: string) {
  return text
    .replace("head-and-shoulders portrait from the top of the hair down to the upper chest", "macro close-up of the head and the front of the thorax")
    .replace("full figure from the top of the hair to the soles of the footwear, with clear empty space above the head and below the feet", "the whole animal from antenna tips to leg tips, with clear empty space around it")
    .replace("standing in a neutral relaxed pose; shoulders, hips and feet square to the camera; the nose on the vertical center line", "in its natural resting posture, body square to the camera, head on the vertical center line")
    .replace("the nose, chest and toes all point", "the head points")
    .replace("both ears show equally", "both sides of the head show equally")
    .replace("the far ear is hidden", "the far side is hidden")
    .replace(/no face visible; the head is not turned|no facial features are visible and the head is not turned toward the camera/, "the back of the body faces the camera")
    .replace(/\bthe nose\b/g, "the head").replace(/\bnose\b/g, "head");
}

/** 记号长在翅膀 / 背上的动物：锚点改为俯拍背面，让记号正对镜头（锚点是后续所有参考的源头）。 */
export function creatureAnchorOrientation(card: CharacterCard, outfitId?: string) {
  const marks = marksOf(card, outfitId);
  if (!creatureOf(card) || !marks || !/\b(wing|wings|forewing|wing bud|back|abdomen)\b/i.test(marks)) return undefined;
  return `top-down view from directly above the animal's back, head pointing to the TOP edge of the image, ${/wing bud/i.test(marks) ? "the wing buds on the thorax clearly visible" : "wings slightly spread"} so the mark (${clip(marks, 120)}) faces the camera and is sharp and obvious; the animal's own left side is on the LEFT side of the image`;
}

/** 角色身份描述（英文骨架，字段内容沿用角色卡原文）。 */
export function h3CharacterDescription(card: CharacterCard, outfitId?: string, detail: "full" | "brief" = "full") {
  const outfit = outfitOf(card, outfitId);
  const wearing = [outfit.upper, outfit.lower, outfit.shoes, outfit.accessories].filter(item => item && !/^none$/i.test(item.trim())).map(item => clip(item!, 160)).join("; ");
  const kind = creatureOf(card);
  if (kind) {
    // 非人类：不写年龄 / 男孩女孩 / 头发 / 服装，避免模型画成人类小孩（也避开内容审核误判）
    const sex = card.identity.gender === "other" ? "" : `${card.identity.gender} `;
    const base = `${card.name}, a real ${sex}${kind} (an animal, not a human)`;
    const marks = marksOf(card, outfitId);
    if (detail === "brief") return `${base} (${clip(card.invariant.body, 140)}${marks ? `; ${clip(marks, 100)}` : ""})`;
    return compact([
      `${base}.`,
      `Head: ${sentence(card.invariant.face, 240)}`,
      `Body: ${sentence(card.invariant.body, 200)}`,
      marks && `Distinctive marks (clearly visible): ${sentence(marks, 160)}`,
      wearing && `Look "${outfit.label}": ${sentence(wearing, 480)}`,
    ]);
  }
  const base = `${card.name}, a ${card.identity.age}-year-old ${genderWord(card)}`;
  if (detail === "brief") return `${base} (hair: ${clip(card.invariant.hair, 120)}; wearing ${clip(outfit.upper, 120)})`;
  return compact([
    `${base}.`,
    `Face: ${sentence(card.invariant.face, 240)}`,
    `Hair: ${sentence(card.invariant.hair, 160)}`,
    `Body: ${sentence(card.invariant.body, 160)}`,
    card.invariant.marks && `Distinctive marks: ${sentence(card.invariant.marks, 160)}`,
    `Outfit "${outfit.label}": ${sentence(wearing, 480)}`,
  ]);
}

/** 台词语言标签：官方格式 <d>[Language] text</d>。 */
export function dialogueLanguage(text: string) {
  if (/[\u3040-\u30ff]/.test(text)) return "Japanese";
  if (/[\uac00-\ud7af]/.test(text)) return "Korean";
  if (/[\u4e00-\u9fff]/.test(text)) return "Chinese";
  return "English";
}

/** 运镜：官方词汇写成自然句。 */
const cameraSentence: Record<keyof typeof cameraMoves, string> = {
  "Static Shot": "The camera remains static.",
  "Push In": "The camera slowly pushes in with small amplitude.",
  "Pull Out": "The camera slowly pulls out with small amplitude.",
  "Zoom In": "The lens slowly zooms in.",
  "Zoom Out": "The lens slowly zooms out.",
  "Pan Left": "The camera pans left at slow speed.",
  "Pan Right": "The camera pans right at slow speed.",
  "Truck Left": "The camera trucks left at slow speed.",
  "Truck Right": "The camera trucks right at slow speed.",
  "Tilt Up": "The camera tilts up at slow speed.",
  "Tilt Down": "The camera tilts down at slow speed.",
  "Pedestal Up": "The camera pedestals up at slow speed.",
  "Pedestal Down": "The camera pedestals down at slow speed.",
  "Arc Shot": "The camera arcs around the subject at slow speed.",
  "Tracking Shot": "The camera tracks the subject's movement, keeping a steady distance.",
  "Shake Slightly": "The camera shakes slightly with a handheld feel.",
};
const stabilitySentence = { stable: "", "slight-shake": "There is a slight handheld shake.", handheld: "The camera is handheld." } as const;

function sections(parts: [string, string][]) {
  return parts.map(([name, body]) => `${name}:\n${body.trim()}`).join("\n");
}

function inlineSections(parts: [string, string][]) {
  return parts.map(([name, body]) => `${name}: ${body.trim()}`).join("\n");
}

/** 超长时依次收紧可选内容，保证不超过官方 7000 字符。 */
function fit(build: (budget: number) => string) {
  for (const budget of [400, 220, 120, 60]) {
    const text = build(budget);
    if (text.length <= h3PromptLimit) return text;
  }
  const text = build(40);
  return text.length <= h3PromptLimit ? text : `${text.slice(0, h3PromptLimit - 1)}…`;
}

/** 根据参考图来源组织 <Subject N>：出场角色在前，场景在后；上一镜画面/首帧作为独立 <Picture N>。 */
function subjectsOf(context: ShotPromptContext, entries: ReferenceEntry[]) {
  const subjects: { key: string; label: string; characterId?: string; outfit?: string; pictures: { number: number; kind: ReferenceEntry["kind"] }[] }[] = [];
  const subjectFor = (key: string, create: () => (typeof subjects)[number]) => subjects.find(item => item.key === key) ?? (subjects.push(create()), subjects.at(-1)!);
  for (const character of context.shot.characters) {
    const card = context.cards.get(character.id);
    subjectFor(`c:${character.id}`, () => ({ key: `c:${character.id}`, label: "", characterId: character.id, outfit: character.outfit,
      pictures: [], ...(card ? {} : { label: character.id }) }));
  }
  const standalone: { number: number; kind: ReferenceEntry["kind"] }[] = [];
  entries.forEach((entry, index) => {
    const number = index + 1;
    if (entry.characterId) subjectFor(`c:${entry.characterId}`, () => ({ key: `c:${entry.characterId}`, label: entry.name ?? entry.characterId!, characterId: entry.characterId, pictures: [] })).pictures.push({ number, kind: entry.kind });
    else if (entry.kind === "scene") subjectFor("scene", () => ({ key: "scene", label: entry.name ?? "the location", pictures: [] })).pictures.push({ number, kind: entry.kind });
    else standalone.push({ number, kind: entry.kind });
  });
  return { subjects: subjects.map((subject, index) => ({ ...subject, tag: `<Subject ${index + 1}>` })), standalone };
}

function setting(context: ShotPromptContext, budget: number) {
  const scene = context.board.scenes.find(item => item.id === context.segment.sceneId);
  return compact([
    scene && `Location: ${scene.name} — ${sentence(scene.description, budget)}`,
    scene?.layout && `Fixed layout: ${sentence(scene.layout, 160)}`,
    scene?.lightingBaseline && `Lighting baseline: ${sentence(scene.lightingBaseline, 120)}`,
    context.board.bible?.canon?.length && `Project canon (must not contradict): ${context.board.bible.canon.map(item => sentence(item, 100)).join("; ")}`,
    context.segment.timeOfDay && `Time of day: ${sentence(context.segment.timeOfDay, 60)}`,
    context.segment.mood && `Mood: ${sentence(context.segment.mood, 120)}`,
  ]);
}

function framing(context: ShotPromptContext) {
  const { shot } = context;
  return compact([
    `${shotSizes[shot.size].en[0]!.toUpperCase()}${shotSizes[shot.size].en.slice(1)}${shot.lens ? `, ${clip(shot.lens, 40)} lens` : ""}.`,
    shot.cameraPosition && `Camera position: ${sentence(shot.cameraPosition, 120)}`,
    shot.composition && `Composition: ${sentence(shot.composition, 160)}`,
  ]);
}

type Subjects = ReturnType<typeof subjectsOf>["subjects"];
const tagOf = (subjects: Subjects, characterId: string) => subjects.find(item => item.characterId === characterId)?.tag;

function nameOf(context: ShotPromptContext, id: string) {
  return context.cards.get(id)?.name ?? context.board.characters.find(item => item.id === id)?.name ?? id;
}

function peopleLines(context: ShotPromptContext, subjects: Subjects | undefined, budget: number) {
  return context.shot.characters.map(character => {
    const tag = subjects ? tagOf(subjects, character.id) : undefined;
    const card = context.cards.get(character.id);
    const who = tag ? `${tag} (${nameOf(context, character.id)})` : card ? h3CharacterDescription(card, character.outfit, "brief") : nameOf(context, character.id);
    const state = card?.temporaryState?.length ? ` Temporary state: ${card.temporaryState.join("; ")}.` : "";
    const invariants = card?.identityInvariants?.length ? ` Identity invariants: ${card.identityInvariants.join("; ")}.` : "";
    return `${who}: ${sentence(character.pose || "present in the frame", budget)}.${invariants}${state}`;
  }).join(" ");
}

function subjectDefinitions(context: ShotPromptContext, subjects: Subjects, standalone: { number: number; kind: ReferenceEntry["kind"] }[], budget: number) {
  const lines = subjects.filter(subject => subject.pictures.length || subject.characterId).map(subject => {
    const pictures = subject.pictures.map(item => `<Picture ${item.number}>`).join(", ");
    if (subject.characterId) {
      const card = context.cards.get(subject.characterId);
      const description = card ? h3CharacterDescription(card, subject.outfit, budget < 200 ? "brief" : "full") : nameOf(context, subject.characterId);
      return `${subject.tag} is ${description}${pictures ? ` Shown in ${pictures}.` : ""}`;
    }
    return `${subject.tag} is the location "${subject.label}"${pictures ? `, shown in ${pictures}` : ""}.`;
  });
  for (const item of standalone) {
    if (item.kind === "previousFrame") lines.push(`<Picture ${item.number}> is the opening frame: positions, hands and props already in it stay. It does not show actions that have not happened.`);
    if (item.kind === "keyframe") lines.push(`<Picture ${item.number}> is the opening keyframe of [Shot 1]. It controls the opening composition only, not the ending action.`);
    if (item.kind === "prop") lines.push(`<Picture ${item.number}> is one prop's shape, color and material. It does not decide who holds it or whether it is open.`);
    if (item.kind === "tailFrame") lines.push(`<Picture ${item.number}> is from the last second of the previous clip, moments earlier in the same place. Which side of a door or wall each person is on, door and prop states, objects in hands, weather and lighting continue from it.`);
  }
  return lines.join("\n");
}

function retention(subjects: Subjects, standalone: { number: number; kind: ReferenceEntry["kind"] }[], keyframeFull: boolean, insectScenes = false) {
  const lines: string[] = [];
  for (const subject of subjects) {
    for (const picture of subject.pictures) {
      if (picture.kind === "anchor") lines.push(`${subject.tag} from <Picture ${picture.number}>: fully_preserved — ${role("sameCharacter", subject.tag)}.`);
      if (picture.kind === "face") lines.push(`${subject.tag} from <Picture ${picture.number}>: partially_preserved — ${role("face", subject.tag)}.`);
      if (picture.kind === "sheet") lines.push(`${subject.tag} from <Picture ${picture.number}>: partially_preserved — ${role("sheet", subject.tag)}.`);
      if (picture.kind === "scene") lines.push(insectScenes
        ? `${subject.tag} from <Picture ${picture.number}>: partially_preserved — keep the plants, ground textures, color palette and lighting of the location; the camera angle may change; ignore any people, animals or human-made objects in it.`
        : `${subject.tag} from <Picture ${picture.number}>: partially_preserved — keep the layout, furniture, color palette and lighting of the location; the camera angle may change; ignore any people in it.`);
    }
  }
  for (const item of standalone) {
    if (item.kind === "previousFrame") lines.push(`<Picture ${item.number}>: fully_preserved — positions, hands, props and lighting at the opening. Do not add a person, hand or prop that is not in it.`);
    if (item.kind === "keyframe") lines.push(`<Picture ${item.number}>: ${keyframeFull ? "fully_preserved — opening composition, hands and prop state at 0.00 seconds. It must not control actions that have not happened." : "partially_preserved — opening composition and lighting only. It must not control pose, identity or the ending."}`);
    if (item.kind === "prop") lines.push(`<Picture ${item.number}>: fully_preserved — shape, color and material of this prop. It must not control who holds it, whether it is open, or the camera.`);
    if (item.kind === "tailFrame") lines.push(`<Picture ${item.number}>: partially_preserved — continue its positions, inside/outside placement, prop states, set dressing, weather and lighting; identity comes from the character pictures; do not copy its defects.`);
  }
  return lines.join("\n") || "N/A";
}

/** 静帧（Ref2VA）：subject_definitions 六段格式；无参考图时退回 T2VA 单段格式。 */
function still(input: { task: string; summary: string; style: string; body: string; definitions?: string; retention?: string }) {
  const description = compact([sentence(input.style, 300), `[Shot 1] ${input.body}`, stillHold, cleanFrame]);
  if (!input.definitions) return inlineSections([["integrated_multimodal_description", description], ["overall_soundscape", silent.soundscape], ["non_diegetic_music", silent.music]]);
  return sections([
    ["subject_definitions", input.definitions],
    ["summary", `[${input.task}] ${input.summary}`],
    ["retention_analysis", input.retention ?? "N/A"],
    ["detailed_description", description],
    ["overall_soundscape", silent.soundscape],
    ["non_diegetic_music", silent.music],
  ]);
}

/** 角色设定表提示词（导出供测试与外部工具复用）。 */
export function buildH3CharacterSheet(card: CharacterCard, outfitId: string, options: { views?: readonly H3ViewId[]; face?: boolean; style?: string } = {}): StillPrompt & { views: H3ViewId[] } {
  const views = [...(options.views ?? h3SheetPresets.full13)];
  const layout = layoutH3Sheet(views);
  const counts = (["head", "body", "outfit", "detail"] as const).map(group => [group, layout.panels.filter(panel => panel.view.group === group).length] as const).filter(([, count]) => count);
  const manifest = counts.map(([group, count]) => `${count} ${{ head: "head", body: "full-body", outfit: "outfit", detail: "detail" }[group]} view${count > 1 ? "s" : ""}`).join(", ");
  const creature = !!creatureOf(card);
  const viewText = (text: string) => creature ? creatureView(text) : text;
  const panels = layout.panels.map(panel => `Panel ${panel.index} (column ${panel.column}${panel.rows > 1 ? panel.row === 0 ? ", top" : ", bottom" : ""}): ${viewText(panel.view.framing)}; ${viewText(panel.view.orientation)}.`).join(" ");
  const guard = creatureGuard(card, outfitId);
  const markText = marksOf(card, outfitId);
  const marks = markText ? `The distinctive mark (${clip(markText, 140)}) is clearly visible and identical in every panel where that side of the body faces the camera${creature && /wing/i.test(markText) && !/wing bud/i.test(markText) ? "; in the back view the wings are slightly spread so the wing edges show clearly" : ""}.` : "";
  const definitions = [`<Subject 1> is ${h3CharacterDescription(card, outfitId)} Shown in <Picture 1>${options.face ? " and <Picture 2>" : ""}.`].join("\n");
  const retentionLines = [`<Subject 1> from <Picture 1>: fully_preserved — ${role("sameCharacter", "<Subject 1>")}.`];
  if (options.face) retentionLines.push(`<Subject 1> from <Picture 2>: partially_preserved — ${role("face", "<Subject 1>")}.`);
  const prompt = fit(() => still({
    task: "reference generation",
    summary: `Create one completed static character design sheet of <Subject 1> with ${views.length} views (${manifest}) arranged in ${layout.columns} columns on a single canvas.`,
    style: `${options.style ?? card.style ?? "Clean character model sheet"}. Plain pure white background, the same soft even studio lighting in every panel, identical scale for all full-body views, thin even gutters between panels, no text labels or captions`,
    body: `Static character design sheet, ${layout.ratio} canvas, panels read left to right and may be stretched evenly to fill the width. ${panels} Every panel shows the same <Subject 1> with the same ${creature ? "look" : "outfit"}; nothing is mirrored except where a view requires it.${marks ? ` ${marks}` : ""}${guard ? ` ${guard}` : ""}`,
    definitions,
    retention: retentionLines.join("\n"),
  }));
  return { prompt, ratio: layout.ratio, seed: card.seed, views };
}

export interface H3StyleOptions {
  /** 场景尺度：insect 时场景图按昆虫视角微距拍空景，不出现家具、人造物、动物和文字 */
  sceneScale?: "human" | "insect";
  /** 设定表视角预设，none 表示不生成设定表；缺省 full13 */
  sheet?: H3SheetPreset | "none";
}

export function createH3PromptStyle(options: H3StyleOptions = {}): PromptStyle {
  const sheetViews = options.sheet === "none" ? undefined : h3SheetPresets[options.sheet ?? "full13"];
  const style: PromptStyle = {
    id: "h3",
    label: "MiniMax H3（官方提示词格式）",
    hostReferenceLabels: false,
    plannerRule: "【MiniMax H3 提示词规则】视觉描述字段（角色 invariant 与 outfits、scenes.description、style、blocking、pose、firstFrame、action、endFrame、sfx、lens、cameraPosition、composition、eyeline、focus、props）一律用英文书写，具体可视、不写比喻；左右方位按“画面左/右”写成 screen left / screen right；台词 dialogue.text 保持剧本原语言，不要翻译；emotion 可用英文。",
    characterAnchor(card, outfitId) {
      const view = h3Views.bodyFront;
      return {
        prompt: fit(budget => still({
          task: "reference generation", summary: "", style: card.style ?? "Clean character design reference",
          body: creatureOf(card)
            ? `Single full-body reference of ${budget < 200 ? h3CharacterDescription(card, outfitId, "brief") : h3CharacterDescription(card, outfitId)} Framing: ${creatureView(view.framing)}. Orientation: ${creatureAnchorOrientation(card, outfitId) ?? creatureView(view.orientation)}. Plain seamless pure white background, soft even studio light, only this one animal in the image, one single view. ${creatureGuard(card, outfitId)}`
            : `Single full-body character reference of ${budget < 200 ? h3CharacterDescription(card, outfitId, "brief") : h3CharacterDescription(card, outfitId)} Framing: ${view.framing}. Orientation: ${view.orientation}. Plain seamless pure white background, soft even studio light, only this one person in the image, one single view.`,
        })),
        ratio: "9:16", seed: card.seed,
      };
    },
    characterFace(card, outfitId) {
      const view = h3Views.headFront;
      return {
        prompt: fit(() => still({
          task: "reference generation",
          summary: "Create one static close-up portrait of <Subject 1> for facial reference.",
          style: card.style ?? "Clean character design reference",
          body: creatureOf(card)
            ? `Macro close-up of the head of <Subject 1>. Framing: ${creatureView(view.framing)}. Orientation: ${creatureView(view.orientation)}. Plain seamless pure white background, soft even studio light, sharp detail of the real ${creatureOf(card)} head. ${creatureGuard(card, outfitId)}`
            : `Close-up portrait of <Subject 1>. Framing: ${view.framing}. Orientation: ${view.orientation}. Plain seamless pure white background, soft even studio light, sharp facial detail.`,
          definitions: `<Subject 1> is ${h3CharacterDescription(card, outfitId)} Shown in <Picture 1>.`,
          retention: `<Subject 1> from <Picture 1>: fully_preserved — ${role("sameCharacter", "<Subject 1>")}.`,
        })),
        ratio: "3:4", seed: card.seed,
      };
    },
    characterSheet: sheetViews ? (card, outfitId, references) => buildH3CharacterSheet(card, outfitId, { views: sheetViews, face: references.face }) : undefined,
    scene(scene, styleText, aspectRatio) {
      if (options.sceneScale === "insect") return {
        prompt: fit(budget => still({
          task: "reference generation", summary: "", style: styleText,
          body: `Empty insect-scale macro environment for the location "${scene.name}": ${sentence(scene.description, budget * 2)} Macro nature photography at the scale of a small insect, showing only natural plant, bark, soil, water and light textures. Show only the empty setting: any creatures or characters mentioned above are absent. No furniture, no human-made objects, no buildings or rooms, no animals or insects of any kind, no people, no text, letters, signs or symbols.`,
        })),
        ratio: aspectRatio,
      };
      return {
        prompt: fit(budget => still({
          task: "reference generation", summary: "", style: styleText,
          body: `Empty establishing view of the location "${scene.name}": ${sentence(scene.description, budget * 2)} Wide shot at eye level showing the full spatial layout, main furniture and light sources. There are no people or animals anywhere in the frame.`,
        })),
        ratio: aspectRatio,
      };
    },
    keyframe(context, plan) {
      return keyframePrompt(context, plan, "first");
    },
    endFrame(context, plan) {
      return context.shot.endFrame || context.shot.action ? keyframePrompt(context, plan, "end") : undefined;
    },
    video(context, input) {
      return videoPrompt(context, input);
    },
  };
  return style;
}

function keyframePrompt(context: ShotPromptContext, plan: ShotReferencePlan, which: "first" | "end") {
  const { shot, board, segment } = context;
  const picture = which === "first" ? shot.firstFrame : (shot.endFrame || shot.action);
  const { subjects, standalone } = subjectsOf(context, plan.entries);
  const hasImages = plan.entries.length > 0;
  const cast = shot.characters.length ? `the on-screen characters ${shot.characters.map(item => tagOf(subjects, item.id) ?? nameOf(context, item.id)).join(" and ")}` : "the empty location (no people)";
  return fit(budget => {
    const body = compact([
      framing(context),
      setting(context, budget),
      segment.blocking && `Blocking: ${sentence(segment.blocking, budget)}`,
      shot.characters.length ? peopleLines(context, hasImages ? subjects : undefined, budget) : "There are no people in the frame.",
      `The frame shows: ${sentence(picture, budget * 2)}`,
      shot.eyeline && `Eyeline: ${sentence(shot.eyeline, 120)}`,
      shot.focus && `Focus: ${sentence(shot.focus, 80)}`,
      !!shot.props?.length && `Props: ${sentence(shot.props.join(", "), 200)}`,
      shot.characters.length > 0 && "No extra people beyond those listed.",
      viewpointDirective(context),
      ...traitConstraints(context),
      ...continuityLinesEn(context.shot, id => nameOf(context, id)),
      ...propSentences(context),
      shot.characters.length > 0 && !creatureShot(context) && `${viewpointDirective(context)} Clear spatial staging matching the blocking; every visible hand belongs to a listed person and has exactly five fingers. Do not add a hand, person, or prop the frame description does not name. A prop that must be read fills the hand holding it.`,
      which === "first"
        ? "This frame is the opening instant only. Do not draw an action, expression, or prop state that exists only at the end."
        : "This frame is the closing instant only. Remove any pose or prop state that exists only at the start.",
    ]);
    return still({
      task: standalone.some(item => item.kind === "previousFrame") ? "reference generation + keyframe completion" : "reference generation",
      summary: `Create one static ${which === "first" ? "opening" : "closing"} keyframe of shot ${shot.id} featuring ${cast}, ${board.aspectRatio} frame.`,
      style: `${board.style}. ${board.aspectRatio} cinematic frame`,
      body,
      definitions: hasImages ? subjectDefinitions(context, subjects, standalone, budget) : undefined,
      retention: hasImages ? retention(subjects, standalone, false, creatureShot(context)) : undefined,
    });
  });
}

function speakerIds(context: ShotPromptContext) {
  const ids = new Map<string, string>();
  for (const line of context.shot.dialogue ?? []) if (!ids.has(line.speaker)) ids.set(line.speaker, `S${ids.size + 1}`);
  return ids;
}

function dialogueSentences(context: ShotPromptContext, subjects: Subjects | undefined) {
  const ids = speakerIds(context);
  const lines = (context.shot.dialogue ?? []).map(line => {
    const id = ids.get(line.speaker)!;
    const text = clip(line.text, 300).replaceAll("<", "‹").replaceAll(">", "›");
    const quote = `<d>[${dialogueLanguage(text)}] ${text}</d>`;
    const offscreen = line.speaker === "narrator" || /画外|旁白|V\.?O\.?|O\.?S\.?|off-?screen|voice-?over/i.test(line.emotion ?? "");
    const emotion = line.emotion && !/^(画外|旁白)$/.test(line.emotion) ? ` (emotion: ${clip(line.emotion, 40)})` : "";
    if (line.speaker === "narrator") return `An off-screen narrator (${id}) says in an off-screen voiceover${emotion}: ${quote}`;
    const tag = subjects ? tagOf(subjects, line.speaker) : undefined;
    const who = `${tag ? `${tag} ` : ""}${nameOf(context, line.speaker)} (${id})`;
    return offscreen ? `${who} says in an off-screen voiceover${emotion}, while their lips remain completely closed: ${quote}` : `${who}, on screen, opens their mouth and says${emotion}: ${quote}`;
  });
  const speaking = new Set((context.shot.dialogue ?? []).filter(line => line.speaker !== "narrator" && !/画外|旁白|V\.?O\.?|O\.?S\.?|off-?screen|voice-?over/i.test(line.emotion ?? "")).map(line => line.speaker));
  const silent = context.shot.characters.filter(character => !speaking.has(character.id)).map(character => `${nameOf(context, character.id)} does not speak; their lips remain completely closed.`);
  return [...lines, ...silent];
}

/** 逐角色标记互斥约束（只有 A 有纹身；B 没有纹身），由角色卡推导 */
function traitConstraints(context: ShotPromptContext) {
  if (creatureShot(context) || !context.shot.characters.length) return [];
  return shotTraits(context.shot.characters, context.cards).constraintsEn;
}

function creatureShot(context: ShotPromptContext) {
  const cards = context.shot.characters.map(item => context.cards.get(item.id)).filter((card): card is CharacterCard => !!card);
  return cards.length > 0 && cards.every(card => !!creatureOf(card));
}

function viewpointDirective(context: ShotPromptContext) {
  const shot = context.shot;
  const contract = shot.cameraContract;
  const view = contract?.viewpoint ?? "third_person";
  const directives = {
    third_person: "Third-person objective camera outside the characters.",
    first_person: `First-person POV through ${contract?.subjectCharacterId ?? "the declared subject"}; foreground hands are allowed only when they belong to this POV.`,
    over_shoulder: "Over-the-shoulder view from behind the declared character; preserve the screen direction and eyeline.",
    insert: "Insert close-up of the specified object/action; do not imply an unrequested POV.",
    subjective_camera: `Subjective camera through ${contract?.subjectCharacterId ?? "the declared subject"}; viewpoint must match that character.`,
    top_down: "Objective overhead/top-down camera; preserve spatial layout.",
  } as const;
  const axis = contract?.axisId ? `Axis ${contract.axisId}, camera on ${contract.axisSide ?? "unspecified"} side; preserve screen direction.` : "";
  const positions = shot.spatialContract?.positions.map(item => `${nameOf(context, item.characterId)} at ${item.screenPosition}, facing ${item.facing}${item.eyelineTarget ? `, looking at ${item.eyelineTarget}` : ""}`).join("; ");
  return compact([directives[view], axis, positions, shot.spatialContract?.startState && `Shot start state: ${shot.spatialContract.startState}`, shot.spatialContract?.endState && `Shot end state: ${shot.spatialContract.endState}`, shot.spatialContract?.beat && `Narrative beat: ${shot.spatialContract.beat}`]);
}

function clipContinuity(context: ShotPromptContext, input?: VideoPromptInput) {
  if ((input?.internalCuts ?? 0) > 0) {
    return "Later beats belong in separate videos. This generation has no keyframe aligned to a cut, so hold one continuous shot and do not cut.";
  }
  return creatureShot(context)
    ? "One continuous shot with no cuts. Every character is a real animal exactly as in the references, with the same body shape, colors and marks throughout; no human faces, human body parts or humans appear."
    : "One continuous shot with no cuts. Faces, hairstyles and clothing stay identical to the references throughout; no new people appear. Keep only the hands and props visible in the first and last frames; do not grow an extra hand or replace a prop with a blank. Facing, turns and exits follow those frames. Spoken lines may begin after a short pause; do not add words to fill the pause.";
}

function videoBody(context: ShotPromptContext, subjects: Subjects | undefined, budget: number, input?: VideoPromptInput) {
  const { shot } = context;
  return compact([
    framing(context),
    cameraSentence[shot.camera],
    viewpointDirective(context),
    shot.stability ? stabilitySentence[shot.stability] : "",
    shot.characters.length ? peopleLines(context, subjects, Math.min(budget, 160)) : "There are no people in the frame.",
    `Action: ${sentence(shot.action, budget * 2)}`,
    "Perform one action only. If a hand meets a prop, that hand approaches, touches, applies force, and the prop lands in one place. The same hand does not do two conflicting tasks.",
    shot.spatialContract?.beat === "reaction" && "Reaction: one trigger, one named emotion, then two visible changes readable at this framing, held within 1.5 seconds.",
    ...dialogueSentences(context, subjects),
    shot.dialogueLanguage && `Dialogue language must be exactly ${shot.dialogueLanguage}; do not translate or add words.`,
    ...shot.characters.map(item => { const voice = context.cards.get(item.id)?.voice; return voice ? `${nameOf(context, item.id)} voice identity: ${[voice.voiceId, voice.timbre, voice.language, voice.speakingRate ? `rate ${voice.speakingRate}` : undefined].filter(Boolean).join(", ")}.` : undefined; }),
    shot.endFrame && `By the end of the shot: ${sentence(shot.endFrame, budget)}`,
    ...traitConstraints(context),
      ...continuityLinesEn(context.shot, id => nameOf(context, id)),
      ...propSentences(context),
    clipContinuity(context, input),
    input?.voiceReferences ? `Match the speaking voice to the ${input.voiceReferences} attached reference audio clip${input.voiceReferences > 1 ? "s" : ""}. Do not invent a different voice.` : "",
    cleanFrame,
  ]);
}

function soundscape(context: ShotPromptContext, input?: VideoPromptInput) {
  // 台词锁 / 无音乐（本地 H3 漫剧教程）：能听到的人声只有引号里的原话，不加词、语气词或笑声；没有台词的人不出声
  const parts = [context.shot.sfx && sentence(context.shot.sfx, 200), input?.voiceReferences ? `Voice identity comes from the ${input.voiceReferences} reference audio clip${input.voiceReferences > 1 ? "s" : ""}.` : "", context.shot.dialogue?.length
    ? "Dialogue is clear and close-miked. The only audible human voice is the exact quoted lines, with no added words, interjections or laughter; characters without a line make no vocal sound."
    : "Nobody speaks; no human voice.", "Ambient sound effects only, no music."];
  return compact(parts) || "Quiet natural ambience of the location.";
}

function drawnMedium(style: string) {
  if (/真人|实拍|photoreal|live-action|写实摄影/i.test(style)) return "";
  if (/动画|动漫|漫画|插画|赛璐璐|手绘|anime|illustration|comic|toon|cel/i.test(style)) return "Drawn animation, not live-action, not photographed, no real actors.";
  return "";
}

function videoPrompt(context: ShotPromptContext, input: VideoPromptInput) {
  const { board } = context;
  const seconds = Number.isFinite(input.seconds) ? Math.max(1, Math.round(input.seconds)) : 5;
  const look = compact([sentence(`${board.style}. ${board.aspectRatio} cinematic video`), drawnMedium(board.style)]);
  if (input.mode === "reference" && input.plan) {
    const plan = input.plan;
    const { subjects, standalone } = subjectsOf(context, plan.entries);
    return fit(budget => sections([
      ["subject_definitions", subjectDefinitions(context, subjects, standalone, budget)],
      ["summary", `[keyframe completion + reference generation] A ${seconds}-second single continuous shot ${context.shot.id} that starts exactly from <Picture 1> and performs one action. Do not cut.`],
      ["retention_analysis", retention(subjects, standalone, true, creatureShot(context))],
      ["detailed_description", compact([look, `[Shot 1] ${videoBody(context, subjects, budget, input)}`])],
      ["overall_soundscape", soundscape(context, input)],
      ["non_diegetic_music", "N/A"],
    ]));
  }
  const alignment = input.mode === "firstLast"
    ? `How the reference pictures align with the target video — Picture 1 (from Shot 1) aligns with the 0.00-second mark of the target video; Picture 2 (from Shot 1) aligns with the ${seconds.toFixed(2)}-second mark of the target video.`
    : "For the target video, at 0.00 seconds into the target video, <Picture 1> (from [Shot 1]) is fully referenced.";
  return fit(budget => `${alignment}\n\n${inlineSections([
    ["integrated_multimodal_description", compact([look, `[Shot 1] ${videoBody(context, undefined, budget, input)}`])],
    ["overall_soundscape", soundscape(context, input)],
    ["non_diegetic_music", "N/A"],
  ])}`);
}

export const h3PromptStyle = createH3PromptStyle();

/** 固定道具/车辆卡（英文句）：同一辆车在每个镜头一致，并排除易混淆车型 */
function propSentences(context: ShotPromptContext) {
  const board = context.board as ShotPromptContext["board"] & { props?: Parameters<typeof shotPropCards>[0] };
  return shotPropCards(board.props, context.segment, context.shot).map(card =>
    `Fixed ${card.kind === "vehicle" ? "vehicle" : "prop"} "${card.name}" (identical in every shot): ${card.description}${card.negative ? `. Never show instead: ${card.negative}` : ""}. This fixes shape, color and material only; whether it is open, lit, or in a hand comes from the first and last frames.`);
}
