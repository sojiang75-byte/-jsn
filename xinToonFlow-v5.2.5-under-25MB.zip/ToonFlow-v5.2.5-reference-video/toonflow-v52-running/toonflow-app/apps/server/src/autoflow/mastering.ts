/**
 * 成片母版（思路来自本地 H3 漫剧教程的剪辑与导出部分，FFmpeg 独立实现）：
 * 1. speechSafeEdges：每段首尾多剪一点（AI 视频开头结尾容易漂），但只剪静音部分，不剪到台词或音效起音；
 * 2. 空档铺底噪：一层很轻的环境底噪，用主音轨做侧链压缩，只在无声空档里听得见（手机上听不会像“断了”）；
 * 3. 响度：两遍 loudnorm，整体约 -15 LUFS（教程建议 -14～-16），真峰值不超过 -1.5 dBTP（峰值 ≤ -1 dB）；
 * 4. 导出：24/30 帧、1080×1920（竖屏）母版；手机压缩版另行转码。
 */
import { runProcess, systemFfmpeg, type FfmpegPaths } from "./media";

export interface MasterOptions {
  /** 目标整体响度（LUFS），缺省 -15 */
  targetLufs?: number;
  /** 真峰值上限（dBTP），缺省 -1.5 */
  truePeak?: number;
  /** 底噪电平（dBFS），缺省 -40；null 关闭底噪 */
  bedDb?: number | null;
  /** 底噪低通频率（Hz），缺省 500：只留低频环境感 */
  bedLowpass?: number;
}

export interface LoudnormMeasure { input_i: string; input_tp: string; input_lra: string; input_thresh: string; target_offset: string }

/** 解析 silencedetect 输出，求首尾可安全剪掉的秒数（各不超过 maxSeconds，并在声音起止前留 margin）。纯函数。 */
export function edgesFromSilence(stderr: string, duration: number, maxSeconds = 0.12, margin = 0.04) {
  const starts = [...stderr.matchAll(/silence_start: (-?[\d.]+)/g)].map(match => Math.max(0, Number(match[1])));
  const ends = [...stderr.matchAll(/silence_end: ([\d.]+)/g)].map(match => Number(match[1]));
  let head = 0;
  let tail = 0;
  // 开头静音：第一段 silence 从 0 开始
  if (starts.length && starts[0]! <= 0.01) head = Math.max(0, Math.min(maxSeconds, (ends[0] ?? duration) - margin));
  // 结尾静音：最后一段 silence 没有 end（持续到文件末尾）或 end≈duration
  const lastStart = starts[starts.length - 1];
  const lastEnd = ends[starts.length - 1];
  if (lastStart !== undefined && (lastEnd === undefined || lastEnd >= duration - 0.05)) tail = Math.max(0, Math.min(maxSeconds, duration - lastStart - margin));
  return { head: Number(head.toFixed(3)), tail: Number(tail.toFixed(3)) };
}

export async function speechSafeEdges(file: string, duration: number, maxSeconds = 0.12, paths: FfmpegPaths = systemFfmpeg, signal?: AbortSignal) {
  const result = await runProcess(paths.ffmpeg, ["-hide_banner", "-nostdin", "-i", file, "-vn", "-af", "silencedetect=noise=-35dB:d=0.05", "-f", "null", "-"], signal);
  // 没有音轨：只剪画面漂移，首尾各 maxSeconds/2
  if (!/Audio:/.test(result.stderr)) return { head: maxSeconds / 2, tail: maxSeconds / 2 };
  return edgesFromSilence(result.stderr, duration, maxSeconds);
}

/** 音频母版滤镜（纯函数）：底噪侧链 + loudnorm；measured 给出时为第二遍线性归一。输入 [0:a]，输出 [out]。 */
export function buildMasterAudioFilter(duration: number, options: MasterOptions = {}, measured?: LoudnormMeasure) {
  const lufs = options.targetLufs ?? -15;
  const tp = options.truePeak ?? -1.5;
  const bed = options.bedDb === undefined ? -40 : options.bedDb;
  const parts: string[] = [];
  let main = "[0:a]aresample=48000,aformat=sample_fmts=fltp:channel_layouts=stereo";
  if (bed !== null) {
    parts.push(`${main},asplit=2[main][sc]`);
    parts.push(`anoisesrc=color=brown:sample_rate=48000:amplitude=1:duration=${duration.toFixed(3)},lowpass=f=${options.bedLowpass ?? 500},` +
      `aformat=sample_fmts=fltp:channel_layouts=stereo,volume=${bed}dB[bed]`);
    // 主音轨有声时把底噪压下去（阈值约 -40 dBFS），空档时底噪恢复
    parts.push(`[bed][sc]sidechaincompress=threshold=0.01:ratio=20:attack=5:release=400:makeup=1[bedd]`);
    parts.push(`[main][bedd]amix=inputs=2:duration=first:normalize=0[mix]`);
    main = "[mix]";
  } else {
    parts.push(`${main}[mix]`);
    main = "[mix]";
  }
  const loud = `loudnorm=I=${lufs}:TP=${tp}:LRA=11` + (measured
    ? `:measured_I=${measured.input_i}:measured_TP=${measured.input_tp}:measured_LRA=${measured.input_lra}:measured_thresh=${measured.input_thresh}:offset=${measured.target_offset}:linear=true:print_format=summary`
    : ":print_format=json");
  parts.push(`${main}${loud},aresample=48000[out]`);
  return parts.join(";");
}

/** 从 loudnorm 第一遍的 stderr 解析测量值。 */
export function parseLoudnorm(stderr: string): LoudnormMeasure | undefined {
  const match = stderr.match(/\{\s*"input_i"[\s\S]*?\}/);
  if (!match) return undefined;
  try { return JSON.parse(match[0]) as LoudnormMeasure; } catch { return undefined; }
}

/** 母版：画面直接拷贝（已按母版分辨率/帧率拼接），音频做底噪 + 两遍响度归一。 */
export async function masterFilm(input: string, output: string, duration: number, options: MasterOptions = {}, paths: FfmpegPaths = systemFfmpeg, signal?: AbortSignal) {
  const first = await runProcess(paths.ffmpeg, ["-hide_banner", "-nostdin", "-i", input, "-filter_complex", buildMasterAudioFilter(duration, options), "-map", "[out]", "-f", "null", "-"], signal);
  const measured = parseLoudnorm(first.stderr);
  const result = await runProcess(paths.ffmpeg, ["-hide_banner", "-nostdin", "-y", "-i", input, "-filter_complex", buildMasterAudioFilter(duration, options, measured),
    "-map", "0:v:0", "-map", "[out]", "-c:v", "copy", "-c:a", "aac", "-b:a", "192k", "-ar", "48000", "-movflags", "+faststart", output], signal);
  if (result.code !== 0) throw new Error(`母版混音失败（${result.code}）：${result.stderr.trim().split("\n").slice(-4).join(" | ")}`);
  return { output, measured };
}
