/**
 * 分镜连续性状态：谁已死亡、每人左右手拿什么、画面里允许出现哪些非角色人物/尸体。
 * 文本模型在分镜阶段逐镜填写（或对已有分镜补注），程序据此：
 * 1. 写进首帧/视频提示词（“老五右手持枪，左手空；已死亡：老大，只作为倒地不动的尸体出现；画面中不得出现其他尸体”）；
 * 2. 做确定性门检查：死者复活、死亡状态回退、持物无故换手。
 */
import { iterateShots, type Shot, type Storyboard } from "./schema";

export type ShotContinuity = NonNullable<Shot["continuity"]>;
const empty = /^(空|无|没有|空手|none|empty|nothing|-)?$/i;
const weapon = /枪|刀|匕首|棍|棒|斧|弓|剑|gun|pistol|rifle|knife|blade|bat/i;
const corpse = /尸体|遗体|死者|尸身|横尸|毙命|断气|倒地不起|倒在地上|躺在地上|躺在血泊|一动不动|不再动弹|毫无生气|僵硬|corpse|motionless body|lifeless body|dead body/i;
const handSwitch = /换手|换到(左|右)手|交到(左|右)手|switch(es)? hands|to (his|her|the) (left|right) hand/i;

export function heldItem(value?: string) {
  const text = value?.trim() ?? "";
  return empty.test(text) ? undefined : text;
}

/** 提示词里的连续性约束行（中文）。nameOf 把角色 id 映射为名字。 */
export function continuityLines(shot: Shot, nameOf: (id: string) => string) {
  const state = shot.continuity;
  if (!state) return [];
  const lines: string[] = [];
  const onScreen = new Set(shot.characters.map(item => item.id));
  const hands = (state.hands ?? []).filter(item => onScreen.has(item.id) && !(state.dead ?? []).includes(item.id)).map(item => {
    const left = heldItem(item.left);
    const right = heldItem(item.right);
    return `${nameOf(item.id)}${right ? `右手持${right}` : "右手空"}，${left ? `左手持${left}` : "左手空"}`;
  });
  if (hands.length) lines.push(`持物（左右手不可互换）：${hands.join("；")}`);
  const dead = (state.dead ?? []).map(nameOf);
  if (dead.length) {
    const visibleDead = (state.dead ?? []).filter(id => onScreen.has(id)).map(nameOf);
    lines.push(`已死亡：${dead.join("、")}${visibleDead.length ? `（${visibleDead.join("、")}只作为倒地不动的尸体出现）` : "（不出现或只作为尸体出现）"}`);
  }
  const injuries = (state.injuries ?? []).filter(item => onScreen.has(item.id)).map(item => `${nameOf(item.id)}${item.note}`);
  if (injuries.length) lines.push(`伤情保持：${injuries.join("；")}`);
  const props = (state.props ?? []).map(item => `${item.name}：${item.state}`);
  if (props.length) lines.push(`道具状态：${props.join("；")}`);
  const extras = state.extras?.trim();
  lines.push(extras && !empty.test(extras) ? `画面中除出场角色外只允许：${extras}；不得出现其他人物或尸体` : "画面中除出场角色外没有其他人物，也没有尸体");
  return lines;
}

/** English variant for English-prompt styles. */
export function continuityLinesEn(shot: Shot, nameOf: (id: string) => string) {
  const state = shot.continuity;
  if (!state) return [];
  const lines: string[] = [];
  const onScreen = new Set(shot.characters.map(item => item.id));
  for (const item of state.hands ?? []) {
    if (!onScreen.has(item.id) || (state.dead ?? []).includes(item.id)) continue;
    const left = heldItem(item.left);
    const right = heldItem(item.right);
    lines.push(`${nameOf(item.id)} holds ${right ? right : "nothing"} in the RIGHT hand and ${left ? left : "nothing"} in the LEFT hand (never swap hands).`);
  }
  for (const item of state.injuries ?? []) if (onScreen.has(item.id)) lines.push(`${nameOf(item.id)} keeps the visible injury: ${item.note}.`);
  for (const item of state.props ?? []) lines.push(`Prop state: ${item.name} — ${item.state}.`);
  if (state.dead?.length) lines.push(`Already dead: ${state.dead.map(nameOf).join(", ")} — only ever shown as a motionless body.`);
  const extras = state.extras?.trim();
  lines.push(extras && !empty.test(extras) ? `Besides the listed characters only: ${extras}; no other people or bodies.` : "No other people and no dead bodies besides the listed characters.");
  return lines;
}

/** 确定性检查：死者复活、死亡状态回退、持武器无故换手。返回问题列表（形如 “E01-04-02 …”）。 */
export function continuityProblems(board: Storyboard) {
  const problems: string[] = [];
  for (const episode of board.episodes) {
    const deadSoFar = new Set<string>();
    const injuriesSoFar = new Map<string, string>();
    const propsSoFar = new Map<string, string>();
    let previous: Shot | undefined;
    let previousSegment: string | undefined;
    for (const segment of episode.segments) {
      for (const shot of segment.shots) {
        const state = shot.continuity;
        if (state) {
          const dead = new Set(state.dead ?? []);
          for (const id of deadSoFar) if (!dead.has(id)) problems.push(`${shot.id} 中 ${id} 此前已死亡，连续性状态却未列为死亡`);
          for (const character of shot.characters) {
            if (dead.has(character.id) && !corpse.test(`${character.pose ?? ""}${shot.firstFrame}${shot.action}`)) problems.push(`${shot.id} 中已死亡的 ${character.id} 出场但未写明是尸体`);
          }
          for (const item of state.hands ?? []) {
            if (dead.has(item.id)) continue;
            const before = previous?.continuity?.hands?.find(other => other.id === item.id);
            if (!before || previousSegment !== segment.id) continue;
            const was = { left: heldItem(before.left), right: heldItem(before.right) };
            const now = { left: heldItem(item.left), right: heldItem(item.right) };
            const swapped = (was.right && weapon.test(was.right) && !now.right && now.left && weapon.test(now.left))
              || (was.left && weapon.test(was.left) && !now.left && now.right && weapon.test(now.right));
            if (swapped && !handSwitch.test(`${previous!.action}${shot.action}`)) problems.push(`${shot.id} 中 ${item.id} 的武器从${was.right ? "右" : "左"}手换到${was.right ? "左" : "右"}手，动作里没有写换手`);
          }
          // 伤情：本集内出现过的伤不会消失（角色再次出场时仍需列出）
          const injured = new Set((state.injuries ?? []).map(item => item.id));
          for (const [who, note] of injuriesSoFar) if (shot.characters.some(item => item.id === who) && !dead.has(who) && !injured.has(who)) problems.push(`${shot.id} 中 ${who} 此前已有伤（${note}），本镜伤情未列出`);
          for (const item of state.injuries ?? []) injuriesSoFar.set(item.id, item.note);
          // 道具状态：变化必须在上一镜或本镜动作里写明原因（关键词出现在动作中）
          for (const item of state.props ?? []) {
            const was = propsSoFar.get(item.name);
            if (was && was !== item.state && !causeMentioned(item.state, `${previous?.action ?? ""}${shot.action}${shot.firstFrame}`)) problems.push(`${shot.id} 中 ${item.name} 状态从「${was}」变为「${item.state}」，动作里没有写原因`);
            propsSoFar.set(item.name, item.state);
          }
          for (const id of dead) deadSoFar.add(id);
        }
        previous = shot;
        previousSegment = segment.id;
      }
    }
  }
  return problems;
}

/** 新状态里的关键字（两字以上片段）是否在动作描述里出现，作为“有原因”的粗判。 */
function causeMentioned(state: string, action: string) {
  const words = state.split(/[，,、；;：:\s]+/).map(word => word.replace(/^(被|已|有|呈)/, "")).filter(word => word.length >= 2);
  return words.some(word => { for (let index = 0; index + 2 <= word.length; index++) if (action.includes(word.slice(index, index + 2))) return true; return false; });
}

/**
 * Infer explicit death events from immutable source spans and carry them forward.
 * This is deliberately conservative: only explicit death/corpse language is accepted;
 * threats, intentions and negated statements do not kill a character.
 */
export function applyDeathEventsFromSource(board: Storyboard, characters: Array<{ id: string; name: string }>) {
  const dead = new Set<string>();
  const escape = (value: string) => value.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  const hasCorpseMention = (text: string, name: string) => {
    const n = escape(name);
    // Death evidence must belong to the same clause as the character name.
    // In particular, never let a corpse mention cross a semicolon into the next subject:
    // "老二成为尸体；老五来不及呼叫" means 老二 is dead, not 老五.
    const clauses = text.split(/[。！？!?；;\n]+/).map(part => part.trim()).filter(Boolean);
    const pattern = new RegExp(`(?:${n}[^，,]{0,14}(?:尸体|遗体|尸身|尸首|已经死|死了|断气|毙命|身亡|丧命)|(?:尸体|遗体|尸身|尸首)[^，,]{0,14}${n})`);
    return clauses.some(clause => pattern.test(clause));
  };
  const hasDeathEvent = (text: string, name: string) => {
    const n = escape(name);
    const sentences = text.split(/[。！？!?；;\n]+/);
    return sentences.some(sentence => {
      const explicit = new RegExp(`(?:${n}[^，,。！？!?；;]{0,10}(?:被杀|被打死|被枪杀|中枪身亡|死了|死亡|毙命|断气|身亡|丧命|咽气|没气了)|(?:杀死|打死|枪杀|击毙|干掉|毙掉)(?:了)?[^，,。！？!?；;]{0,8}${n})`).test(sentence);
      if (!explicit) return false;
      return !/(?:要|想|准备|打算|计划|不想|不敢|没有|未能|不能|别|不要|不会|没打算)\s*(?:杀|打死|枪杀|击毙|干掉)|(?:没|未|不)\s*(?:死|死亡|断气|毙命)/.test(sentence);
    });
  };
  for (const episode of board.episodes) for (const segment of episode.segments) for (const shot of segment.shots) {
    const state = shot.continuity ?? (shot.continuity = { dead: [] });
    for (const id of state.dead ?? []) dead.add(id);
    const source = `${shot.source ?? ""}\n${shot.firstFrame}\n${shot.action}\n${shot.endFrame ?? ""}\n${shot.characters.map(character => character.pose ?? "").join("\n")}`;
    for (const character of characters) if (hasCorpseMention(source, character.name)) dead.add(character.id);
    state.dead = [...new Set([...(state.dead ?? []), ...dead])];
    // A narrated killing takes effect from the next shot; the current shot may still depict the action itself.
    for (const character of characters) if (hasDeathEvent(source, character.name)) dead.add(character.id);
  }
  return [...dead];
}

/** 结构化死亡状态账本：一旦某镜声明角色已死，后续镜头/集自动继承，避免模型漏填。 */
export function propagateDeadStates(board: Storyboard) {
  const dead = new Set<string>();
  for (const episode of board.episodes) for (const segment of episode.segments) for (const shot of segment.shots) {
    for (const id of shot.continuity?.dead ?? []) dead.add(id);
    if (shot.continuity || dead.size) {
      shot.continuity ??= { dead: [] };
      shot.continuity.dead = [...new Set([...(shot.continuity.dead ?? []), ...dead])];
    }
  }
  return board;
}

export function hasContinuity(board: Storyboard) {
  return [...iterateShots(board)].every(({ shot }) => !!shot.continuity
    && Array.isArray(shot.continuity.dead) && Array.isArray(shot.continuity.hands)
    && typeof shot.continuity.extras === "string");
}

/** 补注连续性状态的指令（对已有分镜，不改其他字段）。 */
export function continuityInstructions() {
  return `你是场记（script supervisor）。给定剧本与分镜 JSON，逐镜跟踪连续性，只输出 JSON：
{"shots":[{"id":"E01-01-01","dead":["已死亡角色id"],"hands":[{"id":"角色id","left":"左手所持物或 空","right":"右手所持物或 空"}],"extras":"画面中允许出现的非角色人物或尸体，没有写 无","injuries":[{"id":"角色id","note":"可见伤情"}],"props":[{"name":"道具/车辆","state":"当前状态"}]}]}
规则：
1. 按剧本时间顺序推进：角色在哪一镜死亡，从下一镜起列入 dead，之后一直保持；未死的人不要写成死亡。
2. hands 只写本镜画面中出场的活着的角色；手里的武器、物件要与剧本和上一镜一致——同一把枪一直在同一只手，除非剧本明确写了换手。惯用手不明时持枪写右手。
3. 手套、纹身等外观属于角色卡，不要写进 hands。
4. extras：只写剧本到此刻确实存在且画面可能拍到的尸体/路人（如“地上一具老大的尸体”）；剧本没有的尸体与人群一律不写，写 无。
5. injuries：角色受伤后在本集内每次出场都要列出同样的伤；props：关键道具与车辆（如面包车）的车型/损坏状态逐镜保持，只有剧本写明原因（撞、炸、打破）时才变化。
6. 每个镜头 id 都要输出，不得遗漏或新增。`;
}

/** 把模型补注结果合并进分镜（只写 continuity 字段）；返回缺失的镜头 id。 */
export function applyContinuity(board: Storyboard, value: unknown) {
  const list = (value && typeof value === "object" && Array.isArray((value as { shots?: unknown }).shots) ? (value as { shots: unknown[] }).shots : Array.isArray(value) ? value : []) as Record<string, unknown>[];
  const byId = new Map(list.filter(item => item && typeof item.id === "string").map(item => [item.id as string, item]));
  const ids = new Set(board.characters.map(item => item.id));
  const missing: string[] = [];
  for (const { shot } of iterateShots(board)) {
    const item = byId.get(shot.id);
    if (!item) { missing.push(shot.id); continue; }
    const text = (v: unknown, max: number) => typeof v === "string" && v.trim() ? v.trim().slice(0, max) : undefined;
    shot.continuity = {
      dead: Array.isArray(item.dead) ? [...new Set(item.dead.filter((id): id is string => typeof id === "string" && ids.has(id)))] : [],
      hands: Array.isArray(item.hands) ? item.hands.filter((hand): hand is Record<string, unknown> => !!hand && typeof hand === "object" && ids.has(String((hand as Record<string, unknown>).id)))
        .slice(0, 6).map(hand => ({ id: String(hand.id), left: text(hand.left, 40), right: text(hand.right, 40) })) : [],
      extras: text(item.extras, 200),
      injuries: Array.isArray(item.injuries) ? item.injuries.filter((v): v is Record<string, unknown> => !!v && typeof v === "object" && ids.has(String((v as Record<string, unknown>).id)) && !!text((v as Record<string, unknown>).note, 60))
        .slice(0, 12).map(v => ({ id: String(v.id), note: text(v.note, 60)! })) : undefined,
      props: Array.isArray(item.props) ? item.props.filter((v): v is Record<string, unknown> => !!v && typeof v === "object" && !!text((v as Record<string, unknown>).name, 40) && !!text((v as Record<string, unknown>).state, 80))
        .slice(0, 12).map(v => ({ name: text(v.name, 40)!, state: text(v.state, 80)! })) : undefined,
    };
  }
  return missing;
}


/** 跨集场记：死亡、伤情与道具状态不会在新一集自动重置。 */
export function crossEpisodeContinuityProblems(board: Storyboard) {
  const problems: string[] = [];
  const dead = new Set<string>();
  const injuries = new Map<string, string>();
  const props = new Map<string, string>();
  const outfits = new Map<string, string>();
  for (const episode of board.episodes) for (const segment of episode.segments) for (const shot of segment.shots) {
    const state = shot.continuity;
    for (const character of shot.characters) {
      const beforeOutfit = outfits.get(character.id);
      if (beforeOutfit && character.outfit && beforeOutfit !== character.outfit && !/(换装|换上|穿上|脱下|更换|换成|制服|衣服|外套|outfit|change clothes|put on|take off)/i.test(shot.action)) {
        problems.push(`${shot.id} 跨集连续性：${character.id} 造型从 ${beforeOutfit} 变为 ${character.outfit}，动作未交代换装`);
      }
      if (character.outfit) outfits.set(character.id, character.outfit);
    }
    if (!state) continue;
    const currentDead = new Set(state.dead ?? []);
    for (const id of dead) if (shot.characters.some(character => character.id === id)) {
      const corpseText = `${shot.firstFrame}${shot.action}${shot.endFrame ?? ""}`;
      if (!currentDead.has(id)) problems.push(`${shot.id} 跨集连续性：${id} 已在前集死亡，continuity.dead 必须继续列出`);
      if (!corpse.test(corpseText)) problems.push(`${shot.id} 跨集连续性：${id} 已死亡，只能以尸体状态出现`);
    }
    for (const [id, note] of injuries) if (shot.characters.some(character => character.id === id) && !currentDead.has(id) && !(state.injuries ?? []).some(item => item.id === id)) {
      problems.push(`${shot.id} 跨集连续性：${id} 上集伤情「${note}」未继承`);
    }
    for (const item of state.injuries ?? []) injuries.set(item.id, item.note);
    for (const item of state.props ?? []) {
      const before = props.get(item.name);
      if (before && before !== item.state && !/(修复|更换|恢复|清洗|补好|换新|repair|replace|restore)/i.test(shot.action)) problems.push(`${shot.id} 跨集连续性：${item.name} 状态由「${before}」变为「${item.state}」，未说明变化原因`);
      props.set(item.name, item.state);
    }
    for (const id of currentDead) dead.add(id);
  }
  return problems;
}
