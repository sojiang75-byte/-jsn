import { createHash } from "node:crypto";
export interface SourceChunk { id: string; index: number; start: number; end: number; text: string }
export interface SourceQuote { id: string; index: number; groupId: string; start: number; end: number; text: string; speakerHint?: string; kind: "dialogue" | "sfx" | "quoted_text" }
export interface SourceLedger { version: 1; sourceHash: string; chunks: SourceChunk[]; quotes: SourceQuote[] }
const soundOnly = /^(?:(?:吱|嘣|嘭|唰|噗通|扑通|砰|砰砰|轰|轰隆|轰隆隆|咔嚓|咔咔|啪|啪嗒|咚|哐|嗖|滴|叮|叮铃铃|铃铃|呼|嘶|嗡嗡|哒哒|噼里啪啦|咻|哗啦|吱呀|咯吱|滋啦|嘎吱|咔哒|轰轰)[—\-…～~!！。,.，、]*)+$/;
const quotePairs = [/“([^”]{1,20000})”/g, /「([^」]{1,20000})」/g, /『([^』]{1,20000})』/g, /"([^"]{1,20000})"/g, /‘([^’]{1,10000})’/g, /'([^']{1,10000})'/g];
function classifyQuote(value: string, source: string, start: number): SourceQuote["kind"] {
  const compact = value.trim().replace(/\s/g, "");
  if (soundOnly.test(compact)) return "sfx";
  const prefix = source.slice(Math.max(0, start - 64), start).replace(/[“「『"‘'：:，,。！？!?；;、\s]+$/g, "").trim();
  if (/(?:外号|绰号|代号|简称|又称|称为|被称为|名为|叫作|叫做|名字是|名字叫|被叫作|被叫做|这个词|这个名字|标题是|书名是|片名是|提到|说到|谈到|提及)$/.test(prefix)) return "quoted_text";
  return "dialogue";
}
function hashText(value: string) { return createHash("sha256").update(value, "utf8").digest("hex"); }
function splitChunks(source: string, quotes: SourceQuote[] = []): SourceChunk[] {
  const quoteEnds = new Set(quotes.map(quote => quote.end));
  const ranges: Array<[number, number]> = [];
  let start = 0;
  let quoteClose = "";
  let quoteCharacters = 0;
  const opens: Record<string, string> = { "“": "”", "「": "」", "『": "』", "‘": "’", "\"": "\"" };
  for (let i = 0; i < source.length; i++) {
    const char = source[i]!;
    if (quoteClose) {
      if (char === quoteClose) {
        quoteClose = "";
        let end = i + 1;
        while (end < source.length && /[，。！？!?；、\n]/.test(source[end]!)) end++;
        if (end > start) { ranges.push([start, end]); start = end; i = end - 1; }
      } else {
        quoteCharacters++;
        // Align source chunk boundaries with Q-segment boundaries so long dialogue can span shots.
        if (quoteCharacters % 50 === 0 && source[i + 1] !== quoteClose) { ranges.push([start, i + 1]); start = i + 1; }
      }
      continue;
    }
    if (opens[char]) { quoteClose = opens[char]!; quoteCharacters = 0; continue; }
    if (quoteEnds.has(i + 1) || /[。！？!?；\n]/.test(char)) { const end = i + 1; if (end > start) ranges.push([start, end]); start = end; }
  }
  if (start < source.length) ranges.push([start, source.length]);
  if (!ranges.length && source.length) ranges.push([0, source.length]);
  const final: Array<[number, number]> = [];
  for (const [a, b] of ranges) {
    if (b - a <= 1800) { final.push([a, b]); continue; }
    let at = a;
    while (at < b) { let next = Math.min(b, at + 1400); if (next < b) { const local = source.slice(at, next); const cut = Math.max(local.lastIndexOf("，"), local.lastIndexOf("、"), local.lastIndexOf("。"), local.lastIndexOf("；")); if (cut > 500) next = at + cut + 1; } final.push([at, next]); at = next; }
  }
  return final.map(([a, b], index) => ({ id: `SRC${String(index + 1).padStart(4, "0")}`, index, start: a, end: b, text: source.slice(a, b) }));
}
export function buildSourceLedger(source: string, characters: Array<{ id: string; name: string }> = []): SourceLedger {
  const matches: Array<{ start: number; end: number; text: string; speakerHint?: string }> = [];
  for (const regex of quotePairs) { regex.lastIndex = 0; for (const match of source.matchAll(regex)) { const inner = match[1]; if (!inner?.trim()) continue; const offset = match[0].indexOf(inner); matches.push({ start: match.index! + offset, end: match.index! + offset + inner.length, text: inner }); } }
  // Also capture unquoted screenplay-style lines (known cast names or role labels followed by a colon).
  const linePattern = /(?:^|[\r\n])[\t ]*([^：:\r\n]{1,8})[：:][\t ]*([^\r\n]+)/gm;
  for (const match of source.matchAll(linePattern)) {
    const speakerName = match[1]?.trim(); const text = match[2];
    if (!speakerName || !text?.trim() || /[“”「」『』"‘’]/.test(text)) continue;
    if (/^(?:时间|地点|场景|场次|镜头|画面|字幕|说明|备注|标题|章节|第[一二三四五六七八九十0-9]+[集章场])$/.test(speakerName)) continue;
    const offset = match[0].lastIndexOf(text); const start = match.index! + offset; const end = start + text.length;
    if (matches.some(item => start < item.end && end > item.start)) continue;
    const character = characters.find(item => item.name === speakerName || item.id === speakerName);
    matches.push({ start, end, text, speakerHint: character?.id ?? "narrator" });
  }
  matches.sort((a, b) => a.start - b.start || b.end - a.end);
  const quotes: SourceQuote[] = []; let lastEnd = -1; let groupNumber = 0;
  for (const item of matches) { if (item.start < lastEnd) continue; lastEnd = item.end; const groupId = `G${String(++groupNumber).padStart(4, "0")}`; const kind = item.speakerHint ? "dialogue" : classifyQuote(item.text, source, item.start); let offset = 0;
    while (offset < item.text.length) { const end = Math.min(item.text.length, offset + 50); const text = item.text.slice(offset, end); quotes.push({ id: `Q${String(quotes.length + 1).padStart(4, "0")}`, index: quotes.length, groupId, start: item.start + offset, end: item.start + end, text, ...(item.speakerHint ? { speakerHint: item.speakerHint } : {}), kind }); offset = end; }
  }
  return { version: 1, sourceHash: hashText(source), chunks: splitChunks(source, quotes), quotes };
}
/** Split immutable source into contiguous episode slices; a single quoted utterance is never split across episodes. */
export function partitionSourceLedger(ledger: SourceLedger, episodeCount: number): SourceLedger[] {
  if (!Number.isInteger(episodeCount) || episodeCount < 1) throw new Error("episodeCount 必须是正整数");
  if (episodeCount === 1) return [ledger];
  const quoteRanges = new Map<string, { first: number; last: number }>();
  for (const quote of ledger.quotes) {
    const first = ledger.chunks.findIndex(chunk => quote.start >= chunk.start && quote.start < chunk.end);
    const last = ledger.chunks.findIndex(chunk => quote.end - 1 >= chunk.start && quote.end - 1 < chunk.end);
    if (first < 0 || last < 0) continue;
    const range = quoteRanges.get(quote.groupId);
    quoteRanges.set(quote.groupId, { first: Math.min(range?.first ?? first, first), last: Math.max(range?.last ?? last, last) });
  }
  const units: SourceChunk[][] = [];
  let cursor = 0;
  while (cursor < ledger.chunks.length) {
    let end = cursor;
    for (const range of quoteRanges.values()) if (range.first <= cursor && range.last >= cursor) end = Math.max(end, range.last);
    units.push(ledger.chunks.slice(cursor, end + 1));
    cursor = end + 1;
  }
  if (units.length < episodeCount) throw new Error(`原文只有 ${units.length} 个完整剧情片段（不能拆开同一句对白），无法拆成 ${episodeCount} 集；请减少集数或提供更长章节`);
  const slices: SourceChunk[][] = []; let unitCursor = 0;
  for (let ep = 0; ep < episodeCount; ep++) {
    const remaining = episodeCount - ep;
    const target = units.slice(unitCursor).reduce((sum, unit) => sum + unit.reduce((n, item) => n + item.text.length, 0), 0) / remaining;
    const maxEnd = units.length - (remaining - 1); let end = unitCursor; let chars = 0;
    while (end < maxEnd) {
      const unit = units[end]!; const unitChars = unit.reduce((n, item) => n + item.text.length, 0);
      if (end > unitCursor && Math.abs(chars - target) <= Math.abs(chars + unitChars - target)) break;
      chars += unitChars; end++; if (chars >= target) break;
    }
    if (end === unitCursor) end++;
    slices.push(units.slice(unitCursor, end).flat()); unitCursor = end;
  }
  return slices.map(chunks => {
    const start = chunks[0]!.start; const end = chunks[chunks.length - 1]!.end;
    return { version: 1, sourceHash: ledger.sourceHash, chunks, quotes: ledger.quotes.filter(item => item.start >= start && item.start < end) };
  });
}

/** Repair omissions deterministically; the source text itself is never generated or rewritten. */
export function repairSourceLedgerAssignments<T extends { characters?: Array<{ id: string; name: string }>; episodes: Array<{ segments: Array<{ shots: Array<Record<string, any>> }> }> }>(board: T, ledger: SourceLedger) {
  const shots = board.episodes.flatMap(ep => ep.segments.flatMap(seg => seg.shots)); const chunkOwner = new Map<string, number>();
  for (let i = 0; i < shots.length; i++) {
    let refs = Array.isArray(shots[i]!.sourceRefs) ? shots[i]!.sourceRefs as string[] : [];
    refs = refs.filter(id => ledger.chunks.some(chunk => chunk.id === id));
    if (!refs.length && typeof shots[i]!.source === "string" && shots[i]!.source) {
      const wanted = shots[i]!.source as string;
      outer: for (let start = 0; start < ledger.chunks.length; start++) { let joined = ""; const candidate: string[] = []; for (let end = start; end < ledger.chunks.length && joined.length <= wanted.length; end++) { joined += ledger.chunks[end]!.text; candidate.push(ledger.chunks[end]!.id); if (joined === wanted) { refs = candidate; break outer; } if (!wanted.startsWith(joined)) break; } }
    }
    const unique = [...new Set(refs)].sort((a, b) => (ledger.chunks.find(x => x.id === a)?.index ?? 999999) - (ledger.chunks.find(x => x.id === b)?.index ?? 999999));
    shots[i]!.sourceRefs = unique; for (const id of unique) if (!chunkOwner.has(id)) chunkOwner.set(id, i);
  }
  let autoAssignedChunks = 0;
  for (const chunk of ledger.chunks) if (!chunkOwner.has(chunk.id)) {
    let best = -1; let distance = Infinity;
    for (const [id, shotIndex] of chunkOwner) { const other = ledger.chunks.find(item => item.id === id); if (!other) continue; const d = Math.abs(other.index - chunk.index); if (d < distance) { distance = d; best = shotIndex; } }
    if (best >= 0) { shots[best]!.sourceRefs = [...(shots[best]!.sourceRefs ?? []), chunk.id]; chunkOwner.set(chunk.id, best); autoAssignedChunks++; }
  }
  const seenChunks = new Set<string>();
  for (const shot of shots) shot.sourceRefs = (shot.sourceRefs ?? []).filter((id: string) => { if (seenChunks.has(id)) return false; seenChunks.add(id); return true; });

  const characters = board.characters ?? [];
  const inferSpeaker = (quote: SourceQuote) => {
    const prefix = ledger.chunks.filter(chunk => chunk.start < quote.start).map(chunk => chunk.text).join("").slice(-160)
      + (ledger.chunks.find(chunk => quote.start >= chunk.start && quote.start < chunk.end)?.text.slice(0, Math.max(0, quote.start - (ledger.chunks.find(chunk => quote.start >= chunk.start && quote.start < chunk.end)?.start ?? 0))) ?? "");
    const tail = prefix.slice(-160); const candidates = characters.filter(item => tail.includes(item.name));
    const likely = candidates.filter(item => { const escaped = item.name.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"); return new RegExp(`${escaped}[^。！？\\n]{0,16}(?:说|道|喊|骂|叫|吼|问|回答|嘀咕|低声|喝道|追问)`).test(tail); });
    return (likely.at(-1) ?? candidates.at(-1))?.id ?? "narrator";
  };
  const quoteById = new Map(ledger.quotes.map(item => [item.id, item])); const assigned = new Set<string>();
  for (const shot of shots) {
    const local = new Set<string>();
    shot.quoteAssignments = (shot.quoteAssignments ?? []).filter((item: any) => {
      const quote = quoteById.get(item.sourceId); if (!quote || local.has(item.sourceId) || assigned.has(item.sourceId)) return false;
      const ownerChunk = ledger.chunks.find(chunk => quote.start >= chunk.start && quote.start < chunk.end);
      if (!ownerChunk || chunkOwner.get(ownerChunk.id) !== shots.indexOf(shot)) return false;
      local.add(item.sourceId); assigned.add(item.sourceId); item.kind = quote.kind;
      if (quote.kind === "dialogue" && quote.speakerHint && quote.speakerHint !== "narrator") item.speaker = quote.speakerHint;
      else if (quote.kind === "dialogue" && typeof item.speaker === "string" && item.speaker !== "narrator") item.speaker = characters.find(c => c.id === item.speaker || c.name === item.speaker)?.id;
      if (quote.kind !== "dialogue") delete item.speaker;
      return true;
    });
  }
  const groupSpeakers = new Map<string, string>();
  for (const shot of shots) for (const item of shot.quoteAssignments ?? []) { const quote = quoteById.get(item.sourceId); if (quote?.kind === "dialogue" && item.speaker && item.speaker !== "narrator" && !groupSpeakers.has(quote.groupId)) groupSpeakers.set(quote.groupId, item.speaker); }
  let autoAssignedQuotes = 0; let unresolvedSpeakers = 0;
  for (const quote of ledger.quotes) {
    const chunk = ledger.chunks.find(item => quote.start >= item.start && quote.start < item.end); if (!chunk) continue;
    const owner = chunkOwner.get(chunk.id); if (owner === undefined) continue; const shot = shots[owner]!;
    const current = (shot.quoteAssignments ?? []).find((item: any) => item.sourceId === quote.id);
    if (current) {
      if (quote.kind === "dialogue") {
        if (quote.speakerHint && quote.speakerHint !== "narrator") current.speaker = quote.speakerHint;
        else current.speaker = groupSpeakers.get(quote.groupId) ?? (current.speaker && current.speaker !== "narrator" ? current.speaker : inferSpeaker(quote));
        if (current.speaker && current.speaker !== "narrator" && !groupSpeakers.has(quote.groupId)) groupSpeakers.set(quote.groupId, current.speaker);
        if (current.speaker === "narrator") unresolvedSpeakers++;
      }
      continue;
    }
    const assignment: any = { sourceId: quote.id, kind: quote.kind };
    if (quote.kind === "dialogue") { assignment.speaker = quote.speakerHint && quote.speakerHint !== "narrator" ? quote.speakerHint : groupSpeakers.get(quote.groupId) ?? inferSpeaker(quote); groupSpeakers.set(quote.groupId, assignment.speaker); if (assignment.speaker === "narrator") unresolvedSpeakers++; }
    shot.quoteAssignments = [...(shot.quoteAssignments ?? []), assignment]; autoAssignedQuotes++;
  }
  for (const shot of shots) if (Array.isArray(shot.quoteAssignments)) shot.quoteAssignments.sort((a: any, b: any) => (quoteById.get(a.sourceId)?.index ?? 999999) - (quoteById.get(b.sourceId)?.index ?? 999999));
  return { autoAssignedQuotes, autoAssignedChunks, unresolvedSpeakers, sourceChunks: ledger.chunks.length, shots: shots.length };
}

export function hydrateStoryboardFromLedger<T extends { episodes: Array<{ segments: Array<{ shots: Array<Record<string, any>> }> }> }>(board: T, ledger: SourceLedger, options: { preserveAssignments?: boolean } = {}): T {
  const chunks = new Map(ledger.chunks.map(item => [item.id, item])); const quotes = new Map(ledger.quotes.map(item => [item.id, item]));
  for (const episode of board.episodes) for (const segment of episode.segments) for (const shot of segment.shots) {
    const refs = Array.isArray(shot.sourceRefs) ? shot.sourceRefs as string[] : [];
    if (refs.length) shot.source = refs.map(id => chunks.get(id)?.text ?? "").join("");
    const assignments = Array.isArray(shot.quoteAssignments) ? shot.quoteAssignments as Array<{ sourceId: string; kind: string; speaker?: string; emotion?: string }> : [];
    if (assignments.length) {
      const groups = new Map<string, { kind: string; text: string; speaker: string; emotion?: string; index: number }>();
      for (const ref of assignments) {
        const quote = quotes.get(ref.sourceId); if (!quote) continue; const current = groups.get(quote.groupId);
        if (current) { current.text += quote.text; if (ref.emotion) current.emotion = ref.emotion; }
        else groups.set(quote.groupId, { kind: quote.kind, text: quote.text, speaker: ref.speaker || "narrator", emotion: ref.emotion, index: quote.index });
      }
      const ordered = [...groups.values()].sort((a, b) => a.index - b.index);
      shot.dialogue = ordered.filter(item => item.kind === "dialogue").flatMap(item => {
        const lines: Array<{ speaker: string; text: string; emotion?: string }> = [];
        for (let at = 0; at < item.text.length; at += 450) lines.push({ speaker: item.speaker, text: item.text.slice(at, at + 450), ...(item.emotion ? { emotion: item.emotion } : {}) });
        return lines;
      });
      const sounds = ordered.filter(item => item.kind === "sfx").map(item => item.text); if (sounds.length) shot.sfx = sounds.join("、");
    }
    if (!options.preserveAssignments) { delete shot.sourceRefs; delete shot.dialogueRefs; delete shot.quoteAssignments; delete shot.sfxRefs; delete shot.quoteRefs; }
  }
  return board;
}

export function validateSourceLedger(board: { characters?: Array<{ id: string; name: string }>; episodes: Array<{ segments: Array<{ shots: Array<Record<string, any>> }> }> }, ledger: SourceLedger) {
  const chunkUses = new Map<string, string[]>(); const quoteUses = new Map<string, string[]>(); const quoteOrder: string[] = []; const chunkOrder: number[] = []; const errors: string[] = []; const chunkOwner = new Map<string, string>();
  for (const episode of board.episodes) for (const segment of episode.segments) for (const shot of segment.shots) {
    const shotId = String(shot.id ?? "unknown"); const refs = Array.isArray(shot.sourceRefs) ? shot.sourceRefs as string[] : [];
    const localIndices = refs.map(id => ledger.chunks.find(item => item.id === id)?.index).filter((value): value is number => value !== undefined);
    if (localIndices.some((value, index) => index > 0 && value !== localIndices[index - 1]! + 1)) errors.push(`${shotId} 的 sourceRefs 必须是连续原文片段，不能跨段拼接`);
    for (const id of refs) { chunkUses.set(id, [...(chunkUses.get(id) ?? []), shotId]); if (!chunkOwner.has(id)) chunkOwner.set(id, shotId); const chunk = ledger.chunks.find(item => item.id === id); if (chunk) chunkOrder.push(chunk.index); }
    const assignments = Array.isArray(shot.quoteAssignments) ? shot.quoteAssignments as Array<{ sourceId: string; kind: string; speaker?: string }> : [];
    for (const item of assignments) {
      quoteUses.set(item.sourceId, [...(quoteUses.get(item.sourceId) ?? []), item.kind]); quoteOrder.push(item.sourceId);
      const quote = ledger.quotes.find(value => value.id === item.sourceId);
      if (quote) { const sourceChunk = ledger.chunks.find(chunk => quote.start >= chunk.start && quote.start < chunk.end); if (sourceChunk && chunkOwner.get(sourceChunk.id) !== shotId) errors.push(`${shotId} 的 ${quote.id} 被分配到错误镜头，应归属 ${chunkOwner.get(sourceChunk.id) ?? "未分配"}`); }
      if (quote?.kind === "dialogue" && (!item.speaker || (item.speaker !== "narrator" && !(board.characters ?? []).some(character => character.id === item.speaker)))) errors.push(`${shotId} 的 ${item.sourceId} 对白缺少有效说话人 ID`);
    }
    if (!assignments.length) {
      for (const item of (shot.dialogueRefs ?? []) as Array<{ sourceId: string }>) { quoteUses.set(item.sourceId, [...(quoteUses.get(item.sourceId) ?? []), "dialogue"]); quoteOrder.push(item.sourceId); }
      for (const id of (shot.sfxRefs ?? []) as string[]) { quoteUses.set(id, [...(quoteUses.get(id) ?? []), "sfx"]); quoteOrder.push(id); }
      for (const id of (shot.quoteRefs ?? []) as string[]) { quoteUses.set(id, [...(quoteUses.get(id) ?? []), "quoted_text"]); quoteOrder.push(id); }
    }
  }
  for (const chunk of ledger.chunks) { const count = (chunkUses.get(chunk.id) ?? []).length; if (count !== 1) errors.push(`${chunk.id} 原文片段应且只能归属一个镜头，当前 ${count} 次`); }
  for (const id of chunkUses.keys()) if (!ledger.chunks.some(item => item.id === id)) errors.push(`引用了不存在的原文片段 ${id}`);
  for (const quote of ledger.quotes) { const uses = quoteUses.get(quote.id) ?? []; if (uses.length !== 1) errors.push(`${quote.id}「${quote.text}」应且只能分类一次，当前 ${uses.length} 次`); else if (uses[0] !== quote.kind) errors.push(`${quote.id}「${quote.text}」类型应为 ${quote.kind}，实际 ${uses[0]}`); }
  for (const id of quoteUses.keys()) if (!ledger.quotes.some(item => item.id === id)) errors.push(`引用了不存在的引号原文 ${id}`);
  const expectedQuoteOrder = ledger.quotes.map(item => item.id);
  if (quoteOrder.length === expectedQuoteOrder.length && quoteOrder.some((id, index) => id !== expectedQuoteOrder[index])) errors.push("引号原文的分配顺序与章节顺序不一致");
  if (chunkOrder.some((value, index) => index > 0 && value < chunkOrder[index - 1]!)) errors.push("原文片段顺序与章节顺序不一致");
  return { ok: errors.length === 0, errors, chunkCount: ledger.chunks.length, quoteCount: ledger.quotes.length };
}
