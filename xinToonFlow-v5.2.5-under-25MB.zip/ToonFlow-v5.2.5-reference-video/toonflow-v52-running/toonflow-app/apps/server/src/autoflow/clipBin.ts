/**
 * Clip Bin：每镜的版本化归档（思路移植自 ComfyUI-MiniMaxH3-PrefixStream 的 engine/clip_bin_manager.py：
 * clip 包 = 预览 + 元数据 + 血缘 parent_clip_id，项目级 JSON 索引原子写入；这里存的是成片视频而不是 latent）。
 * - 镜头/<id>/版本/v<N>/：video.mp4、首帧.jpg、尾帧.jpg、预览.jpg（首尾帧拼图）、clip.json（提示词、种子、评分、质检、模型、父镜头）；
 * - 一键成片/<runId>/clipbin.json：所有 clip 的索引与每镜当前版本，写临时文件后 rename，保证原子；
 * - redo：只重做指定镜头——先把当前版本归档，再清空该镜状态；旧版本目录永不改写；
 * - pick：把某镜切回任一历史版本。
 */
import { copyFile, mkdir, readFile, rename, writeFile, stat } from "node:fs/promises";
import { posix } from "node:path";
import { extractFrame, probeMedia, runProcess, systemFfmpeg, type FfmpegPaths } from "./media";

export interface ClipRecord {
  clipId: string;
  shotId: string;
  version: number;
  /** 同一镜的上一版本（被本版本替代） */
  supersedes?: string;
  /** 续接来源：上一镜当时的 clipId */
  parentClipId?: string;
  createdAt: string;
  dir: string;
  video: string;
  preview?: string;
  prompt?: string;
  firstFramePrompt?: string;
  seed?: number;
  model?: string;
  score?: number;
  checks?: Record<string, number>;
  qa?: { pass: boolean; score?: number; issues?: string[] };
  warnings?: string[];
  /** v5 输入依赖指纹；缺省表示旧 v4 clip，兼容读取但不能声称已验证新鲜度 */
  inputFingerprints?: {
    projectBibleHash?: string;
    shotContractHash?: string;
    characterCardHashes?: string[];
    sceneHash?: string;
    propHashes?: string[];
    referenceManifestHash?: string;
    promptHash?: string;
    generatorConfigHash?: string;
    qaPolicyVersion?: string;
    referenceFiles?: { path: string; size: number; sha256: string }[];
  };
  note?: string;
}

export interface ClipBinIndex {
  version: 1;
  clips: ClipRecord[];
  /** shotId → 当前采用的 clipId */
  current: Record<string, string>;
}

export interface ClipSource {
  video?: string;
  keyframe?: string;
  seed?: number;
  prompts?: { firstFrame: string; video: string };
  score?: { score: number; checks?: object };
  qa?: { pass: boolean; score?: number; issues?: string[] };
  warnings?: string[];
  clipId?: string;
  inputFingerprints?: ClipRecord["inputFingerprints"];
}

export class ClipBin {
  constructor(readonly root: string, readonly abs: (path: string) => string, readonly ffmpeg: FfmpegPaths = systemFfmpeg, readonly signal?: AbortSignal) {}
  get indexPath() { return posix.join(this.root, "clipbin.json"); }

  async load(): Promise<ClipBinIndex> {
    try { return JSON.parse(await readFile(this.abs(this.indexPath), "utf8")) as ClipBinIndex; }
    catch { return { version: 1, clips: [], current: {} }; }
  }

  async save(index: ClipBinIndex) {
    const file = this.abs(this.indexPath);
    const temp = `${file}.${process.pid}.${Date.now()}.tmp`;
    await writeFile(temp, JSON.stringify(index, null, 2));
    await rename(temp, file);
  }

  /** 串行化对索引的读改写（同一进程内并行镜头共用一个 ClipBin 实例）。 */
  #queue: Promise<unknown> = Promise.resolve();
  update<T>(mutate: (index: ClipBinIndex) => Promise<T> | T): Promise<T> {
    const next = this.#queue.then(async () => { const index = await this.load(); const result = await mutate(index); await this.save(index); return result; });
    this.#queue = next.catch(() => undefined);
    return next;
  }

  versionsOf(index: ClipBinIndex, shotId: string) { return index.clips.filter(clip => clip.shotId === shotId).sort((a, b) => a.version - b.version); }

  /** 归档一镜的当前视频为新版本（同一视频文件已归档过则直接返回已有记录）。 */
  archive(shotId: string, shotDirectory: string, source: ClipSource, meta: { model?: string; parentClipId?: string; note?: string } = {}) {
    return this.update(async index => {
      if (!source.video) throw new Error(`${shotId} 没有视频，无法归档`);
      const size = (await stat(this.abs(source.video))).size;
      // 已归档过的视频（同一源文件，或本身就是某个版本目录里的视频，如 pick 切回的旧版本）不重复归档
      const existing = this.versionsOf(index, shotId).find(clip => clip.video === source.video || clip.note?.includes(`src=${source.video}|${size}`));
      if (existing) { index.current[shotId] = existing.clipId; return existing; }
      const version = (this.versionsOf(index, shotId).at(-1)?.version ?? 0) + 1;
      const dir = posix.join(shotDirectory, "版本", `v${version}`);
      await mkdir(this.abs(dir), { recursive: true });
      const video = posix.join(dir, "video.mp4");
      await copyFile(this.abs(source.video), this.abs(video));
      const first = posix.join(dir, "首帧.jpg");
      const tail = posix.join(dir, "尾帧.jpg");
      const preview = posix.join(dir, "预览.jpg");
      try {
        const probe = await probeMedia(this.abs(video), this.ffmpeg, this.signal);
        await extractFrame(this.abs(video), 0, this.abs(first), this.ffmpeg, this.signal);
        await extractFrame(this.abs(video), Math.max(0, probe.duration - 0.12), this.abs(tail), this.ffmpeg, this.signal);
        await runProcess(this.ffmpeg.ffmpeg, ["-hide_banner", "-nostdin", "-y", "-i", this.abs(first), "-i", this.abs(tail),
          "-filter_complex", "[0:v]scale=-2:360[a];[1:v]scale=-2:360[b];[a][b]hstack=inputs=2", "-q:v", "3", this.abs(preview)], this.signal);
      } catch { /* 预览失败不影响归档 */ }
      const previous = index.current[shotId];
      const record: ClipRecord = {
        clipId: `${shotId}@v${version}`, shotId, version, supersedes: previous, parentClipId: meta.parentClipId,
        createdAt: new Date().toISOString(), dir, video, preview,
        prompt: source.prompts?.video, firstFramePrompt: source.prompts?.firstFrame, seed: source.seed, model: meta.model,
        score: source.score?.score, checks: source.score?.checks as Record<string, number> | undefined, qa: source.qa, warnings: source.warnings?.slice(-12),
        inputFingerprints: source.inputFingerprints,
        note: `${meta.note ? `${meta.note} ` : ""}src=${source.video}|${size}`,
      };
      await writeFile(this.abs(posix.join(dir, "clip.json")), JSON.stringify(record, null, 2));
      index.clips.push(record);
      index.current[shotId] = record.clipId;
      return record;
    });
  }

  /** 记录质检结果到当前版本（clip.json 与索引同步更新）。 */
  annotate(shotId: string, patch: Partial<Pick<ClipRecord, "qa" | "note">>) {
    return this.update(async index => {
      const record = index.clips.find(clip => clip.clipId === index.current[shotId]);
      if (!record) return undefined;
      Object.assign(record, patch);
      await writeFile(this.abs(posix.join(record.dir, "clip.json")), JSON.stringify(record, null, 2));
      return record;
    });
  }

  async get(clipId: string) { return (await this.load()).clips.find(clip => clip.clipId === clipId); }
}

/** 解析 --redo / --pick 参数：逗号分隔，pick 形如 E01-02-03@v1。 */
export function parseShotList(value?: string | string[]) {
  const list = (Array.isArray(value) ? value : value ? [value] : []).flatMap(item => item.split(/[,，\s]+/)).map(item => item.trim()).filter(Boolean);
  const bad = list.filter(item => !/^E\d{2}-\d{2}-\d{2}(@v\d+)?$/.test(item));
  if (bad.length) throw new Error(`无法识别的镜头 ID：${bad.join("、")}（应形如 E01-02-03 或 E01-02-03@v1）`);
  return [...new Set(list)];
}

/** 重做时需要清空的镜头状态字段（保留 attempts / warnings 作为历史） */
export const shotOutputFields = ["keyframe", "endKeyframe", "video", "lastFrame", "contactSheet", "score", "review", "keyframeHandsOk", "lastFrameHandsOk",
  "lastFrameTraitsOk", "chainable", "chainedFrom", "needsRedo", "rejectedKeyframe", "qa", "continuation", "clipId", "seed"] as const;
