/**
 * Mock 依赖：不调用任何外部/付费接口，用 FFmpeg 生成占位图片与视频，用固定 JSON 模拟语言模型。
 * 用于单元测试、冒烟测试和“一键成片”流程演示。
 */
import { join, posix } from "node:path";
import type { GeneratedMedia, MediaGenerationRequest } from "@toonflow/tools-scaffold/runtime";
import type { TextModel } from "./llm";
import { makePanClip, makeSolidImage, systemFfmpeg, type FfmpegPaths } from "./media";
import type { ConsistencyScorer } from "./scoring";

const palette = ["0x6b8cce", "0xce6b8c", "0x8cce6b", "0xcea76b", "0x6bcec3", "0x9b6bce", "0xce6b6b", "0x6bce8c"];

function hash(text: string) {
  let value = 0;
  for (const char of text) value = (value * 31 + char.codePointAt(0)!) >>> 0;
  return value;
}

export function mockCast(title: string) {
  return {
    title, logline: "雨夜便利店里，两位陌生人因一把伞结缘。", style: "日系动画赛璐璐风格，柔和霓虹光影，电影感",
    characters: [
      { id: "linxia", name: "林夏", identity: { gender: "female", age: 24 },
        invariant: { face: "鹅蛋脸，杏眼，左眼角一颗泪痣，肤色白皙", hair: "黑色齐肩短发，空气刘海", body: "身高 165cm，纤细" },
        outfits: [{ id: "default", label: "便利店制服", upper: "浅蓝色便利店工作马甲配白衬衫", lower: "深灰直筒裤", shoes: "白色帆布鞋", accessories: "胸前名牌" }] },
      { id: "chenmo", name: "陈默", identity: { gender: "male", age: 27 },
        invariant: { face: "瘦长脸，单眼皮，下颌线清晰", hair: "深棕色微卷短发", body: "身高 180cm，偏瘦", marks: "右手背一道浅疤" },
        outfits: [{ id: "default", label: "雨夜外套", upper: "被雨打湿的黑色风衣", lower: "黑色长裤", shoes: "黑色短靴" }] },
    ],
    scenes: [{ id: "store", name: "深夜便利店", description: "狭长店面，左侧货架，右侧收银台，落地玻璃门外是下雨的街道，冷白灯光混合门外霓虹" }],
  };
}

export function mockStoryboard(broken: boolean) {
  const shot = (id: string, extra: Record<string, unknown>) => ({
    id, size: "medium", camera: "Static Shot", transition: "cut", lens: "35mm", cameraPosition: "平视，收银台正面", composition: "三分法",
    eyeline: "看向对方", focus: "说话人", stability: "stable", ...extra,
  });
  return {
    episodes: [{ ep: 1, title: "雨伞", targetSeconds: 14, segments: [
      { id: "E01-01", sceneId: "store", blocking: "林夏站在画面右侧收银台后，陈默从左侧玻璃门推门进入，两人相距约三米，面对面", timeOfDay: "深夜", mood: "安静、潮湿",
        shots: [
          shot(broken ? "E01-01-1" : "E01-01-01", { size: "wide", characters: [{ id: "linxia", pose: "收银台后低头整理小票" }, { id: "chenmo", pose: "推门而入，浑身湿透" }],
            firstFrame: "玻璃门被推开，雨水溅进门口，收银台后的店员抬起头", action: "陈默推门进来抖落身上的雨水，林夏抬头看向门口" }),
          shot("E01-01-02", { size: "medium-close", camera: "Push In", characters: [{ id: "linxia", pose: "双手撑在收银台上" }],
            dialogue: [{ speaker: "linxia", text: "外面雨这么大，你没带伞吗？", emotion: "关切" }],
            firstFrame: "林夏在收银台后微微前倾", action: "林夏关切地开口询问，镜头缓慢推近" }),
          shot("E01-01-03", { transition: "continuous", size: "medium-close", characters: [{ id: "linxia", pose: "转身弯腰" }],
            firstFrame: "林夏转身弯腰", action: "林夏从柜台下拿出一把透明雨伞递向前方" }),
        ] },
      { id: "E01-02", sceneId: "store", blocking: "门口近景：陈默站在画面左侧玻璃门前，林夏在右侧递伞，两人侧对镜头", timeOfDay: "深夜", mood: "温暖",
        shots: [
          shot("E01-02-01", { size: "close", camera: "Truck Right", characters: [{ id: "chenmo", pose: "伸手接伞" }, { id: "linxia", pose: "递伞" }],
            dialogue: [{ speaker: "chenmo", text: "谢谢，我明天还你。", emotion: "腼腆" }],
            firstFrame: "两只手在透明雨伞的伞柄处交汇，背景是雨夜街道的霓虹", action: "陈默接过雨伞，轻声道谢", sfx: "雨声" }),
        ] },
    ] }],
  };
}

/** 语言模型 mock：按系统提示词中的阶段标记返回固定输出；brokenFirstStoryboard 用于覆盖“校验失败 → 回喂修复”路径。 */
export function createMockTextModel(options: { brokenFirstStoryboard?: boolean } = {}): TextModel & { calls: string[] } {
  let storyboardCalls = 0;
  const calls: string[] = [];
  return {
    calls,
    async complete({ system, prompt }) {
      const stage = system.match(/<!-- autoflow:(\w+) -->/)?.[1] ?? (system.includes("一致性审查") ? "score" : "unknown");
      calls.push(stage);
      if (stage === "script") return `# 雨伞\n\n## 第1场 深夜便利店 / 夜 / 林夏、陈默\n\n陈默浑身湿透推门而入。\n林夏：外面雨这么大，你没带伞吗？\n林夏从柜台下拿出一把透明雨伞。\n陈默：谢谢，我明天还你。\n\n（故事：${prompt.slice(3, 40)}）`;
      if (stage === "cast") return "```json\n" + JSON.stringify(mockCast("雨伞")) + "\n```";
      if (stage === "storyboard") return JSON.stringify(mockStoryboard(!!options.brokenFirstStoryboard && storyboardCalls++ === 0));
      if (stage === "score") return JSON.stringify({ characters: {}, artifacts: 1, reasons: [] });
      throw new Error(`mock 文本模型收到未知阶段：${stage}`);
    },
  };
}

/** 媒体生成 mock：图片为按提示词/种子着色的纯色图，视频为首帧缓慢平移的短片。 */
export function createMockGenerator(cwd: string, paths: FfmpegPaths = systemFfmpeg) {
  const requests: { mediaType: "image" | "video"; request: MediaGenerationRequest }[] = [];
  let counter = 0;
  return {
    requests,
    async generate(mediaType: "image" | "video", request: MediaGenerationRequest): Promise<GeneratedMedia[]> {
      requests.push({ mediaType, request: structuredClone(request) });
      const directory = request.outputDirectory ?? "assets/generated";
      const name = `mock-${mediaType}-${String(++counter).padStart(3, "0")}`;
      if (mediaType === "image") {
        const [width, height] = request.ratio === "2:3" ? [256, 384] : request.ratio === "4:5" ? [320, 400] : request.ratio === "9:16" ? [288, 512] : [512, 288];
        const file = posix.join(directory, `${name}.png`);
        await makeSolidImage(join(cwd, file), { width, height, color: palette[hash(request.prompt + (request.seed ?? 0)) % palette.length]! }, paths);
        return [{ path: file, mimeType: "image/png", mediaType: "image" }];
      }
      const source = request.firstFrame?.path ?? request.images?.[0]?.path;
      const file = posix.join(directory, `${name}.mp4`);
      let image = source ? join(cwd, source) : join(cwd, directory, `${name}-src.png`);
      if (!source) await makeSolidImage(image, { width: 512, height: 288, color: "0x444444" }, paths);
      await makePanClip(image, join(cwd, file), { seconds: Math.max(1, request.duration ?? 3), width: 512, height: 288, audio: !!request.generateAudio }, paths);
      return [{ path: file, mimeType: "video/mp4", mediaType: "video" }];
    },
  };
}

/** 一致性评分 mock：指定的候选（按调用序号）给低分，其余高分，用于覆盖换种子重试路径。 */
export function createMockScorer(lowScoreCalls: number[] = [1]): ConsistencyScorer & { calls: number } {
  const scorer = {
    id: "mock",
    calls: 0,
    async score(input: { references: { name: string; role: string }[] }) {
      scorer.calls++;
      const value = lowScoreCalls.includes(scorer.calls) ? 0.35 : 0.92;
      const perCharacter = Object.fromEntries(input.references.filter(item => item.role === "character").map(item => [item.name, value]));
      return { score: value, perCharacter, reasons: value < 0.5 ? ["mock：发型与参考不一致"] : [], scorer: "mock" };
    },
  };
  return scorer;
}
