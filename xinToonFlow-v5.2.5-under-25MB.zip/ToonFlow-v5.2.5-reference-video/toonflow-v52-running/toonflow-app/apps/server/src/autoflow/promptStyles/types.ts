/** 提示词风格档：同一条一键成片流水线可切换不同模型家族的提示词写法。 */
import type { CharacterCard } from "@/utils/assets/characterCard";
import type { ShotPromptContext } from "../storyboard/prompts";
import type { ShotReferencePlan } from "../references";

export const promptStyleIds = ["h3", "generic", "grokH3"] as const;
export type PromptStyleId = (typeof promptStyleIds)[number];

export interface StillPrompt {
  prompt: string;
  /** 画幅；H3 风格只会返回官方 API 支持的画幅 */
  ratio: string;
  seed?: number;
}

export interface VideoPromptInput {
  /** firstFrame：首帧驱动；firstLast：首尾帧驱动；reference：参考图驱动（plan 第 1 张为本镜首帧） */
  mode: "firstFrame" | "firstLast" | "reference";
  seconds: number;
  plan?: ShotReferencePlan;
  /** 同一条视频里计划好的切点数。缺省或 0 表示镜头内不切。 */
  internalCuts?: number;
  /** 跟在开场镜头后面的切镜，按时间顺序 */
  followingShots?: { seconds?: number; action: string; dialogue?: { speaker: string; text: string }[] }[];
  /** 已挂上的参考音频条数，最多 3 */
  voiceReferences?: number;
}

export interface PromptStyle {
  id: PromptStyleId;
  label: string;
  /** 是否让宿主按 referenceLabels 在提示词前追加「图N：用途」声明（H3 风格在提示词内自带 <Picture N> 定义，不需要） */
  hostReferenceLabels: boolean;
  /** 追加给编剧/角色/分镜阶段语言模型的写作规则 */
  plannerRule?: string;
  /** 正面全身锚点：纯文本生成 */
  characterAnchor(card: CharacterCard, outfitId: string): StillPrompt;
  /** 正脸特写：第 1 张参考图为锚点 */
  characterFace(card: CharacterCard, outfitId: string): StillPrompt;
  /** 多视角设定表：第 1 张参考图为锚点、第 2 张（可选）为正脸；不支持的风格返回 undefined */
  characterSheet?(card: CharacterCard, outfitId: string, references: { face: boolean }): StillPrompt;
  scene(scene: { name: string; description: string }, style: string, aspectRatio: string): StillPrompt;
  keyframe(context: ShotPromptContext, plan: ShotReferencePlan): string;
  endFrame(context: ShotPromptContext, plan: ShotReferencePlan): string | undefined;
  video(context: ShotPromptContext, input: VideoPromptInput): string;
}
