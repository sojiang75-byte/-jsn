/**
 * 一键成片用到的 FFmpeg 操作：尾帧提取、黑场/冻结/切镜检测、联系表、拼接，以及 mock 素材生成。
 * 全部以参数数组调用本机 ffmpeg/ffprobe（不经 shell）；黑场/冻结/切镜检测的思路参考 ArcReel（AGPL，仅借鉴思路，代码独立编写）。
 */
import { spawn } from "node:child_process";
import { mkdir } from "node:fs/promises";
import { dirname } from "node:path";

export interface FfmpegPaths { ffmpeg: string; ffprobe: string }
export const systemFfmpeg: FfmpegPaths = { ffmpeg: "ffmpeg", ffprobe: "ffprobe" };

export function runProcess(command: string, args: string[], signal?: AbortSignal) {
  return new Promise<{ code: number; stdout: string; stderr: string }>((resolve, reject) => {
    const child = spawn(command, args, { stdio: ["ignore", "pipe", "pipe"], signal });
    let stdout = "";
    let stderr = "";
    child.stdout.on("data", chunk => { if (stdout.length < 4_000_000) stdout += chunk; });
    child.stderr.on("data", chunk => { if (stderr.length < 8_000_000) stderr += chunk; });
    child.once("error", reject);
    child.once("close", code => resolve({ code: code ?? -1, stdout, stderr }));
  });
}

async function ffmpeg(paths: FfmpegPaths, args: string[], signal?: AbortSignal) {
  const result = await runProcess(paths.ffmpeg, ["-hide_banner", "-nostdin", ...args], signal);
  if (result.code !== 0) throw new Error(`FFmpeg 执行失败（${result.code}）：${result.stderr.trim().split("\n").slice(-4).join(" | ")}`);
  return result;
}

export interface MediaProbe { duration: number; width?: number; height?: number; hasAudio: boolean; hasVideo: boolean }

export async function probeMedia(file: string, paths: FfmpegPaths = systemFfmpeg, signal?: AbortSignal): Promise<MediaProbe> {
  const result = await runProcess(paths.ffprobe, ["-v", "error", "-print_format", "json", "-show_format", "-show_streams", file], signal);
  if (result.code !== 0) throw new Error(`无法读取媒体信息：${result.stderr.trim()}`);
  const data = JSON.parse(result.stdout) as { format?: { duration?: string }; streams?: { codec_type?: string; width?: number; height?: number; duration?: string }[] };
  const video = data.streams?.find(stream => stream.codec_type === "video");
  return {
    duration: Number(data.format?.duration ?? video?.duration ?? 0) || 0,
    width: video?.width, height: video?.height,
    hasVideo: !!video,
    hasAudio: !!data.streams?.some(stream => stream.codec_type === "audio"),
  };
}

/** 提取视频最后一帧为图片（用于下一镜首帧）。-sseof 回退 1 秒后逐帧覆盖写出，最终文件即末帧。 */
export async function extractLastFrame(video: string, output: string, paths: FfmpegPaths = systemFfmpeg, signal?: AbortSignal) {
  await mkdir(dirname(output), { recursive: true });
  await ffmpeg(paths, ["-y", "-sseof", "-1", "-i", video, "-an", "-update", "1", "-q:v", "2", output], signal);
  return output;
}

/** 提取指定时刻的单帧。 */
export async function extractFrame(video: string, seconds: number, output: string, paths: FfmpegPaths = systemFfmpeg, signal?: AbortSignal) {
  await mkdir(dirname(output), { recursive: true });
  await ffmpeg(paths, ["-y", "-ss", String(Math.max(0, seconds)), "-i", video, "-frames:v", "1", "-q:v", "2", output], signal);
  return output;
}

export interface TimeRange { start: number; end: number; duration: number }
export interface VideoSignals {
  duration: number;
  black: TimeRange[];
  freeze: TimeRange[];
  /** 检测到的切镜时刻（秒） */
  sceneCuts: number[];
  hasAudio: boolean;
}

export interface DetectOptions {
  /** 黑场最短时长（秒） */
  blackMinSeconds?: number;
  /** 像素亮度阈值（0–1） */
  blackPixelThreshold?: number;
  /** 冻结最短时长（秒） */
  freezeMinSeconds?: number;
  /** 冻结噪声阈值（dB） */
  freezeNoiseDb?: number;
  /** 切镜场景分数阈值（0–1） */
  sceneThreshold?: number;
}

export function parseSignals(log: string, duration: number): Omit<VideoSignals, "hasAudio"> {
  const black: TimeRange[] = [];
  for (const match of log.matchAll(/black_start:\s*([\d.]+)\s+black_end:\s*([\d.]+)\s+black_duration:\s*([\d.]+)/g)) {
    black.push({ start: Number(match[1]), end: Number(match[2]), duration: Number(match[3]) });
  }
  const freeze: TimeRange[] = [];
  let freezeStart: number | undefined;
  for (const match of log.matchAll(/lavfi\.freezedetect\.freeze_(start|end):\s*([\d.]+)/g)) {
    const value = Number(match[2]);
    if (match[1] === "start") freezeStart = value;
    else if (freezeStart !== undefined) { freeze.push({ start: freezeStart, end: value, duration: value - freezeStart }); freezeStart = undefined; }
  }
  // 冻结持续到片尾时 ffmpeg 不输出 freeze_end
  if (freezeStart !== undefined) freeze.push({ start: freezeStart, end: duration, duration: Math.max(0, duration - freezeStart) });
  const sceneCuts: number[] = [];
  for (const match of log.matchAll(/pts_time:([\d.]+)[^\n]*\n[^\n]*lavfi\.scene_score=([\d.]+)/g)) sceneCuts.push(Number(match[1]));
  return { duration, black, freeze, sceneCuts };
}

/** 单次解码同时跑 blackdetect、freezedetect 与场景切换检测。 */
export async function detectVideoSignals(video: string, options: DetectOptions = {}, paths: FfmpegPaths = systemFfmpeg, signal?: AbortSignal): Promise<VideoSignals> {
  const probe = await probeMedia(video, paths, signal);
  if (!probe.hasVideo) throw new Error("文件中没有视频流");
  const filter = [
    `blackdetect=d=${options.blackMinSeconds ?? 0.3}:pix_th=${options.blackPixelThreshold ?? 0.1}`,
    `freezedetect=n=${options.freezeNoiseDb ?? -60}dB:d=${options.freezeMinSeconds ?? 1}`,
    `select='gt(scene,${options.sceneThreshold ?? 0.4})'`,
    "metadata=print:key=lavfi.scene_score",
  ].join(",");
  const result = await ffmpeg(paths, ["-i", video, "-map", "0:v:0", "-vf", filter, "-an", "-f", "null", "-"], signal);
  return { ...parseSignals(result.stderr, probe.duration), hasAudio: probe.hasAudio };
}

/** 均匀抽帧拼成联系表，便于人工或视觉模型快速审片。 */
export async function contactSheet(video: string, output: string, options: { columns?: number; rows?: number; width?: number } = {},
  paths: FfmpegPaths = systemFfmpeg, signal?: AbortSignal) {
  const columns = options.columns ?? 4;
  const rows = options.rows ?? 2;
  const probe = await probeMedia(video, paths, signal);
  const rate = (columns * rows) / Math.max(0.5, probe.duration);
  await mkdir(dirname(output), { recursive: true });
  await ffmpeg(paths, ["-y", "-i", video, "-vf", `fps=${rate.toFixed(4)},scale=${options.width ?? 320}:-2,tile=${columns}x${rows}`,
    "-frames:v", "1", "-q:v", "3", output], signal);
  return output;
}

/** 统一分辨率/帧率后拼接；无音轨的片段补静音，保证拼接后音画同步。 */
export async function concatVideos(inputs: string[], output: string, options: { width?: number; height?: number; fps?: number } = {},
  paths: FfmpegPaths = systemFfmpeg, signal?: AbortSignal) {
  if (!inputs.length) throw new Error("没有可拼接的视频");
  const probes = [];
  for (const input of inputs) probes.push(await probeMedia(input, paths, signal));
  const width = options.width ?? probes[0]!.width ?? 1280;
  const height = options.height ?? probes[0]!.height ?? 720;
  const fps = options.fps ?? 24;
  const args: string[] = ["-y"];
  inputs.forEach(input => args.push("-i", input));
  const filters: string[] = [];
  const pairs: string[] = [];
  probes.forEach((probe, index) => {
    filters.push(`[${index}:v:0]scale=${width}:${height}:force_original_aspect_ratio=decrease,pad=${width}:${height}:(ow-iw)/2:(oh-ih)/2,setsar=1,fps=${fps},format=yuv420p[v${index}]`);
    if (probe.hasAudio) filters.push(`[${index}:a:0]aresample=44100,aformat=channel_layouts=stereo[a${index}]`);
    else filters.push(`anullsrc=r=44100:cl=stereo,atrim=duration=${probe.duration.toFixed(3)}[a${index}]`);
    pairs.push(`[v${index}][a${index}]`);
  });
  filters.push(`${pairs.join("")}concat=n=${inputs.length}:v=1:a=1[v][a]`);
  await mkdir(dirname(output), { recursive: true });
  await ffmpeg(paths, [...args, "-filter_complex", filters.join(";"), "-map", "[v]", "-map", "[a]",
    "-c:v", "libx264", "-preset", "veryfast", "-crf", "20", "-c:a", "aac", "-b:a", "160k", "-movflags", "+faststart", output], signal);
  return output;
}

/** mock：纯色静帧图片。 */
export async function makeSolidImage(output: string, options: { width: number; height: number; color: string }, paths: FfmpegPaths = systemFfmpeg, signal?: AbortSignal) {
  await mkdir(dirname(output), { recursive: true });
  await ffmpeg(paths, ["-y", "-f", "lavfi", "-i", `color=c=${options.color}:s=${options.width}x${options.height}`, "-frames:v", "1", output], signal);
  return output;
}

/** mock：以首帧图做缓慢平移生成有运动的短片（避免误触冻结检测），可附正弦音轨。 */
export async function makePanClip(image: string, output: string, options: { seconds: number; width: number; height: number; audio?: boolean },
  paths: FfmpegPaths = systemFfmpeg, signal?: AbortSignal) {
  const { seconds, width, height } = options;
  const scaledWidth = Math.ceil(width * 1.25 / 2) * 2;
  const scaledHeight = Math.ceil(height * 1.25 / 2) * 2;
  const args = ["-y", "-loop", "1", "-framerate", "24", "-t", String(seconds), "-i", image];
  if (options.audio) args.push("-f", "lavfi", "-t", String(seconds), "-i", "sine=frequency=440:sample_rate=44100");
  args.push("-vf", `scale=${scaledWidth}:${scaledHeight},crop=${width}:${height}:x='(iw-ow)*t/${seconds}':y='(ih-oh)/2',noise=alls=8:allf=t,format=yuv420p`,
    "-c:v", "libx264", "-preset", "ultrafast", "-pix_fmt", "yuv420p");
  if (options.audio) args.push("-c:a", "aac", "-shortest");
  await mkdir(dirname(output), { recursive: true });
  await ffmpeg(paths, [...args, output], signal);
  return output;
}
