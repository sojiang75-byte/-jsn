/** 一键成片服务层：参数校验、依赖装配（真实模型或 mock）、后台运行注册表。 */
import { z } from "zod";
import { readFile } from "node:fs/promises";
import { join, posix } from "node:path";
import { runAutoflow, type AutoflowDeps, type AutoflowOptions, type RunState } from "./pipeline";
import { createConfiguredTextModel, createOpenAICompatibleTextModel, nebiusDefaults, resolveNebiusCredentials, type TextModel } from "./llm";
import { createMockGenerator, createMockScorer, createMockTextModel } from "./mock";
import { createHttpScorer, createModelScorer, passThroughScorer, type ConsistencyScorer } from "./scoring";
import { systemFfmpeg, type FfmpegPaths } from "./media";

const model = z.strictObject({ providerId: z.string().regex(/^[a-zA-Z][a-zA-Z0-9_-]{0,95}$/), modelId: z.string().trim().min(1).max(256) });
const relativeDirectory = z.string().min(1).max(1024).refine(path => !/^[\\/]|[:\u0000-\u001f]/.test(path) && path.split(/[\\/]/).every(part => part && part !== "." && part !== ".."), "必须是工作区内的相对路径");

export const autoflowRequestSchema = z.strictObject({
  story: z.string().min(2).max(200000),
  /** 默认 true：章节原文只读，不调用编剧模型改写。 */
  preserveSourceText: z.boolean().optional().default(true),
  runId: z.string().regex(/^[A-Za-z0-9_-]{1,64}$/).optional(),
  /** 不调用任何外部接口，使用 FFmpeg 占位素材演示完整流程 */
  mock: z.boolean().optional(),
  episodes: z.number().int().min(1).max(20).optional(),
  targetSeconds: z.number().int().min(5).max(1800).optional(),
  aspectRatio: z.enum(["16:9", "9:16", "1:1", "4:3", "3:4", "21:9"]).optional(),
  style: z.string().trim().max(500).optional(),
  /** providerId 为 nebius 时直连 Nebius Token Factory（Key 取设置页语言模型 nebius 的配置或环境变量 NEBIUS_API_KEY） */
  textModel: model.extend({ reasoningEffort: z.enum(["none", "low", "medium", "high"]).optional() }).optional(),
  imageModel: model.extend({
    size: z.string().trim().max(64).optional(),
    maxReferenceImages: z.number().int().min(0).max(64).optional(),
    /** 用视频模型出静帧（MiniMax H3）；缺省时若所选“图片模型”实际是视频模型则自动开启 */
    stillFromVideo: z.strictObject({ duration: z.number().int().min(1).max(30), resolution: z.string().trim().max(64).optional() }).optional(),
  }).optional(),
  /** 提示词风格档：h3（默认，MiniMax H3 官方格式）/ generic（原通用中文提示词） */
  promptStyle: z.enum(["h3", "generic", "grokH3"]).optional(),
  h3: z.strictObject({ sheet: z.enum(["full13", "turnaround5", "none"]).optional(), sceneScale: z.enum(["human", "insect"]).optional() }).optional(),
  videoModel: model.extend({
    durations: z.array(z.number().positive().max(120)).max(64).optional(),
    resolution: z.string().trim().max(64).optional(),
    generateAudio: z.boolean().optional(),
    input: z.enum(["firstFrame", "reference", "directReference"]).optional(),
    useEndFrame: z.boolean().optional(),
    maxReferenceImages: z.number().int().min(0).max(64).optional(),
    /** 首尾帧能否和参考图放进同一个请求（缺省：ai& 为 false，其他供应商为 true） */
    framesWithReferences: z.boolean().optional(),
  }).optional(),
  scorer: z.union([
    z.strictObject({ type: z.literal("none") }),
    /** 看图评分。providerId 为 nebius 时走 Nebius 客户端（image_url data URI、reasoning_effort 缺省 none、严格 JSON）；
     *  modelId 缺省 nvidia/Nemotron-3.5-Super-VL，也可用 deepseek-ai/DeepSeek-V4.1-Flash-1017 */
    z.strictObject({ type: z.literal("model"), providerId: model.shape.providerId, modelId: model.shape.modelId.optional(),
      reasoningEffort: z.enum(["none", "low", "medium", "high"]).optional() }),
    z.strictObject({ type: z.literal("http"), endpoint: z.url() }),
  ]).optional(),
  scoreThreshold: z.number().min(0).max(1).optional(),
  maxAttempts: z.number().int().min(1).max(8).optional(),
  /** 关键帧评分重试上限（缺省 max(5, maxAttempts)） */
  keyframeMaxAttempts: z.number().int().min(1).max(12).optional(),
  /** 严格关键帧（缺省 true）：重试用完仍低于阈值则镜头标记需重做，不静默接受 */
  strictKeyframes: z.boolean().optional(),
  /** 连续镜头用上一镜尾帧作首帧。clip 节奏缺省开启；显式 false 才每镜重画首帧。 */
  chainContinuous: z.boolean().optional(),
  /** 上一镜画面作参考图：qa（缺省，仅通过手/肢体检查的帧）/ always / never */
  previousFrameReference: z.enum(["qa", "always", "never"]).optional(),
  /** 相邻两段是同一场景时跨段接力（段落改为串行），缺省 false */
  chainAcrossSegments: z.boolean().optional(),
  /** 接力镜头的视频输入：firstFrame（缺省，上一镜尾帧作为真首帧提交）/ follow（沿用 videoModel.input） */
  chainedVideoInput: z.enum(["firstFrame", "follow"]).optional(),
  /** 下一镜要接力时，要求本镜结尾停在主角清楚可见的画面上，缺省 true */
  endOnSubject: z.boolean().optional(),
  repairAttempts: z.number().int().min(0).max(5).optional(),
  seed: z.number().int().min(0).max(2 ** 32 - 1).optional(),
  characterDirectory: relativeDirectory.optional(),
  /** storyboard = 只做免费规划；characters = 再出角色卡与场景图，人工确认后去掉 stopAfter 用同一 runId 续跑 */
  stopAfter: z.enum(["storyboard", "characters", "keyframes", "videos"]).optional(),
  /** clip：每个镜头单独成片，一条视频不内切；短于 5 秒由程序补足。缺省 shot。 */
  rhythm: z.enum(["shot", "clip"]).optional(),
  /** report：不跑外部硬质检、不挡成片。block：未通过则禁止导出。缺省 report。 */
  qaGate: z.enum(["report", "block"]).optional(),
  /** 先出有限条预览。seconds 为单条请求时长（H3 最短 5 秒），resolution 如 640P。 */
  preview: z.strictObject({
    maxClips: z.number().int().min(1).max(20).optional(),
    seconds: z.number().int().min(5).max(15).optional(),
    resolution: z.string().trim().max(64).optional(),
  }).optional(),
  /** 参考人声，最多 3 段 */
  voiceReferences: z.array(z.strictObject({
    path: relativeDirectory,
    mimeType: z.string().regex(/^audio\/[a-z0-9.+-]+$/i).optional(),
  })).max(3).optional(),
  /** 分镜节奏参数：单镜时长上下限、语速等（缺省 2–10 秒；长镜头视频模型如 Grok 可设 4–15） */
  params: z.strictObject({
    minShotSeconds: z.number().positive().max(60).optional(),
    maxShotSeconds: z.number().positive().max(60).optional(),
    maxSegmentSeconds: z.number().positive().max(600).optional(),
    maxOnScreen: z.number().int().min(1).max(10).optional(),
    tolerance: z.number().min(0).max(1).optional(),
    charsPerSecond: z.number().positive().max(20).optional(),
    linePadding: z.number().min(0).max(5).optional(),
  }).optional(),
  /** 有问题的场景 id：视频与关键帧不再用它的场景图作参考，并在提示词的场景描述后追加昆虫尺度约束（无家具、无人造物、无其他动物） */
  problemScenes: z.array(z.string().trim().min(1).max(64)).max(200).optional(),
  /** 同时生成的角色/场景/段落数（段内镜头按顺序接力），缺省 1；ai& 返回 429 时自动退避 */
  concurrency: z.number().int().min(1).max(16).optional(),
  /** 花费：缺省不限额，只记录花费；maxUsd 为正数时每次付费生成前按报价检查，超出即中止；pricePerSecond 覆盖内置单价（如非 ai& 供应商） */
  /** 续接：同段上一镜通过检查时，把其结尾帧作为本镜视频参考图 */
  continuation: z.strictObject({ mode: z.enum(["never", "qa", "always"]).optional(), frames: z.number().int().min(1).max(6).optional(), spanSeconds: z.number().min(0).max(5).optional(),
    handsGate: z.enum(["block", "warn"]).optional() }).optional(),
  continuationAnchors: z.boolean().optional(),
  /** 只重做这些镜头（旧版本归档进 Clip Bin） */
  redo: z.array(z.string().regex(/^E\d{2}-\d{2}-\d{2}$/)).max(500).optional(),
  redoKeepKeyframe: z.array(z.string().regex(/^E\d{2}-\d{2}-\d{2}$/)).max(500).optional(),
  /** 切回历史版本，如 E01-02-03@v1 */
  pick: z.array(z.string().regex(/^E\d{2}-\d{2}-\d{2}@v\d+$/)).max(500).optional(),
  clipBin: z.boolean().optional(),
  stitch: z.union([z.literal(false), z.strictObject({
    luminanceMatch: z.boolean().optional(), maxGainPercent: z.number().min(0).max(25).optional(), fadeFrames: z.number().int().min(1).max(96).optional(),
    crossfadeMs: z.number().min(0).max(500).optional(), declickMs: z.number().min(0).max(50).optional(), analysisFrames: z.number().int().min(1).max(24).optional(),
    fps: z.number().int().min(12).max(60).optional(), crf: z.number().int().min(10).max(40).optional(),
  })]).optional(),
  /** 外部逐镜质检命令（仅命令行可用：需环境变量 TOONFLOW_ALLOW_SHOT_QA=1） */
  shotQa: z.strictObject({ command: z.array(z.string().min(1).max(4096)).min(1).max(32), timeoutMs: z.number().int().min(1000).max(7200000).optional() }).optional(),
  annotateContinuity: z.boolean().optional(),
  shotTagInPrompt: z.boolean().optional(),
  budget: z.strictObject({
    /** 缺省、0、空字符串或 null = 不限制 */
    maxUsd: z.preprocess(value => (value === "" || value === null ? undefined : value), z.number().min(0).max(10000000).optional()),
    pricePerSecond: z.number().min(0).max(100).optional(),
    preflight: z.boolean().optional(),
  }).optional(),
});
export type AutoflowRequest = z.infer<typeof autoflowRequestSchema>;

interface ActiveRun { controller: AbortController; state?: RunState; promise: Promise<unknown>; cwd: string }
const active = new Map<string, ActiveRun>();

/** 从已安装媒体模型的声明中补全时长档位与参考图上限。 */
async function modelHints(request: AutoflowRequest) {
  const { listMediaModels } = await import("@/utils/media/generation");
  const models = await listMediaModels().catch(() => []);
  const find = (selection?: { providerId: string; modelId: string }) => models.find(item => item.providerId === selection?.providerId && item.modelId === selection?.modelId);
  const referenceLimit = (mode: unknown) => {
    const entries = Array.isArray(mode) ? mode.flat() : [];
    const limits = entries.map(item => String(item).match(/^imageReference:(\d+)$/)?.[1]).filter(Boolean).map(Number);
    return limits.length ? Math.max(...limits) : undefined;
  };
  const video = find(request.videoModel);
  const image = find(request.imageModel);
  const durations = (video?.durationResolutionMap as { duration: number[] }[] | undefined)?.flatMap(item => item.duration);
  const imageDurations = (image?.durationResolutionMap as { duration: number[]; resolution: string[] }[] | undefined) ?? [];
  return {
    durations: durations?.length ? [...new Set(durations)].sort((a, b) => a - b) : undefined,
    videoReferences: referenceLimit(video?.mode),
    imageReferences: referenceLimit(image?.mode),
    /** 所选“图片模型”其实是视频模型（如 MiniMax H3）：用最短时长出视频再取首帧 */
    stillFromVideo: image?.type === "video" ? {
      duration: Math.min(...imageDurations.flatMap(item => item.duration).filter(Number.isFinite), 30) || 5,
      resolution: imageDurations[0]?.resolution?.[0],
    } : undefined,
  };
}

/** nebius 直连 Nebius Token Factory（OpenAI 兼容），其余走设置页里配置的语言模型。 */
export async function createTextModel(selection: { providerId: string; modelId?: string; reasoningEffort?: string }, purpose: "text" | "vision" = "text"): Promise<TextModel> {
  if (selection.providerId.toLowerCase() !== nebiusDefaults.providerId) {
    if (!selection.modelId) throw Object.assign(new Error("请填写模型 modelId"), { status: 400 });
    return createConfiguredTextModel({ providerId: selection.providerId, modelId: selection.modelId });
  }
  const { default: conf } = await import("@/utils/conf");
  const providers = (conf.get("settings", {}) as { customProviders?: unknown }).customProviders;
  const saved = Array.isArray(providers)
    ? providers.find(item => typeof item?.id === "string" && item.id.toLowerCase() === nebiusDefaults.providerId) as { apiKey?: unknown; apiUrl?: unknown } | undefined
    : undefined;
  const credentials = resolveNebiusCredentials(saved ?? {});
  if (purpose === "vision") {
    // 看图评分：所有请求都带 reasoning_effort（缺省 none）。默认思考会把 max_tokens 用完，content 返回 null。
    return createOpenAICompatibleTextModel({ ...credentials, model: selection.modelId || nebiusDefaults.scorerModel,
      reasoningEffort: selection.reasoningEffort ?? "none", jsonReasoningEffort: selection.reasoningEffort ?? "none", maxTokens: 2000 });
  }
  return createOpenAICompatibleTextModel({ ...credentials, model: selection.modelId || nebiusDefaults.model, jsonReasoningEffort: selection.reasoningEffort ?? "none" });
}

/**
 * 缺省模型组合：文本（编剧/角色卡/分镜）= Nebius Kimi-K3，看图评分 = Nebius Nemotron-3.5-Super-VL。
 * 每次实际运行将所选模型写入 effective_models.json，监控报告不得硬编码模型名称。
 */
export function defaultModelSelections(request: Pick<AutoflowRequest, "textModel" | "scorer">) {
  const text = request.textModel ?? { providerId: nebiusDefaults.providerId, modelId: nebiusDefaults.model };
  const scorer: AutoflowRequest["scorer"] = request.scorer
    ?? (text.providerId.toLowerCase() === nebiusDefaults.providerId ? { type: "model", providerId: nebiusDefaults.providerId, modelId: nebiusDefaults.scorerModel } : undefined);
  return { text, scorer };
}

export async function buildDeps(cwd: string, request: AutoflowRequest, signal: AbortSignal): Promise<{ deps: AutoflowDeps; options: AutoflowOptions }> {
  const options: AutoflowOptions = {
    story: request.story, preserveSourceText: request.preserveSourceText, episodes: request.episodes, targetSeconds: request.targetSeconds, aspectRatio: request.aspectRatio, style: request.style,
    imageModel: request.imageModel ?? { providerId: "mock", modelId: "mock-image" },
    videoModel: request.videoModel ?? (request.mock ? { providerId: "mock", modelId: "mock-video", generateAudio: true } : undefined),
    scoreThreshold: request.scoreThreshold, maxAttempts: request.maxAttempts, repairAttempts: request.repairAttempts, seed: request.seed,
    keyframeMaxAttempts: request.keyframeMaxAttempts, strictKeyframes: request.strictKeyframes, chainContinuous: request.chainContinuous, previousFrameReference: request.previousFrameReference,
    chainAcrossSegments: request.chainAcrossSegments, chainedVideoInput: request.chainedVideoInput, endOnSubject: request.endOnSubject,
    characterDirectory: request.characterDirectory, stopAfter: request.stopAfter, concurrency: request.concurrency, problemScenes: request.problemScenes, promptStyle: request.promptStyle, h3: request.h3,
    outputDirectory: request.runId ? posix.join("一键成片", request.runId) : undefined, budget: request.budget, params: request.params,
    continuation: request.continuation, continuationAnchors: request.continuationAnchors, redo: request.redo, redoKeepKeyframe: request.redoKeepKeyframe, pick: request.pick,
    clipBin: request.clipBin, stitch: request.stitch, annotateContinuity: request.annotateContinuity, shotTagInPrompt: request.shotTagInPrompt,
    shotQa: request.shotQa && process.env.TOONFLOW_ALLOW_SHOT_QA === "1" ? request.shotQa : undefined,
    qaGate: request.qaGate, rhythm: request.rhythm, preview: request.preview, voiceReferences: request.voiceReferences,
  };
  if (request.shotQa && !options.shotQa) throw new Error("shotQa 外部质检命令只允许在命令行模式使用（TOONFLOW_ALLOW_SHOT_QA=1）");
  if (request.mock) {
    options.runtimeModels = { text: { providerId: "mock", modelId: "mock-text" }, image: options.imageModel, video: options.videoModel };
    const generator = createMockGenerator(cwd, systemFfmpeg);
    return { options, deps: { cwd, text: createMockTextModel({ brokenFirstStoryboard: true }), generate: generator.generate, scorer: createMockScorer([1]), ffmpeg: systemFfmpeg, signal, retryDelayMs: 0 } };
  }
  // 缺省使用 Nebius 文本模型与 Nemotron VL；若用户显式选择其他文本模型，以实际选择为准。
  const { text: textSelection, scorer: scorerSelection } = defaultModelSelections(request);
  if (!request.imageModel) throw Object.assign(new Error("请选择图片模型 imageModel"), { status: 400 });
  const hints = await modelHints(request);
  // 本地 ComfyUI 内置 Qwen-Image-Edit-2509 工作流最多 3 张参考图
  const comfyDefault = request.imageModel.providerId === "comfyui" ? 3 : undefined;
  options.imageModel = { ...request.imageModel, maxReferenceImages: request.imageModel.maxReferenceImages ?? hints.imageReferences ?? comfyDefault,
    stillFromVideo: request.imageModel.stillFromVideo ?? hints.stillFromVideo };
  if (options.videoModel) options.videoModel = { ...options.videoModel, durations: options.videoModel.durations ?? hints.durations,
    maxReferenceImages: options.videoModel.maxReferenceImages ?? hints.videoReferences };
  options.runtimeModels = { text: { providerId: textSelection.providerId, modelId: textSelection.modelId ?? nebiusDefaults.model }, image: options.imageModel,
    video: options.videoModel, scorer: scorerSelection?.type === "model" ? { providerId: scorerSelection.providerId, modelId: scorerSelection.modelId ?? nebiusDefaults.scorerModel } : undefined };
  const text = await createTextModel(textSelection);
  let scorer: ConsistencyScorer = passThroughScorer;
  if (scorerSelection?.type === "model") {
    const vision = await createTextModel(scorerSelection, "vision");
    scorer = createModelScorer(input => vision.complete(input));
  } else if (request.scorer?.type === "http") scorer = createHttpScorer(request.scorer.endpoint);
  const [{ generateMedia }, schemas, ffmpegModule] = await Promise.all([import("@/utils/media/generation"), import("@/utils/media/schemas"), import("@/utils/ffmpeg")]);
  const ffmpeg: FfmpegPaths = await ffmpegModule.prepareWorkspaceFfmpeg(signal);
  return { options, deps: {
    cwd, text, scorer, ffmpeg, signal,
    // ACT: 与 /api/ai/media/generate 使用同一套参数校验，再调用用户配置的媒体供应商。
    generate: async (mediaType, mediaRequest, generateSignal) => {
      const schema = mediaType === "image" ? schemas.imageGenerationSchema : schemas.videoGenerationSchema;
      const parsed = schema.parse(mediaRequest);
      // 已拿到任务 id 的请求在重试 / 续跑时只恢复轮询，绝不重复提交（收费任务不能取消）
      const { withTaskLedger } = await import("./taskLedger");
      return withTaskLedger(cwd, mediaType, parsed, task => generateMedia(cwd, mediaType, parsed, generateSignal, task));
    },
  } };
}

export async function startAutoflow(cwd: string, input: unknown) {
  const request = autoflowRequestSchema.parse(input);
  const runId = request.runId ?? crypto.randomUUID();
  if (active.has(runId)) throw Object.assign(new Error("该任务正在运行"), { status: 409 });
  const controller = new AbortController();
  const { deps, options } = await buildDeps(cwd, { ...request, runId }, controller.signal);
  const entry: ActiveRun = { controller, cwd, promise: Promise.resolve() };
  deps.onUpdate = state => { entry.state = state; };
  entry.promise = runAutoflow(options, deps, runId).catch(error => { console.error("[autoflow]", error instanceof Error ? error.message : error); })
    .finally(() => active.delete(runId));
  active.set(runId, entry);
  return { runId, outputDirectory: posix.join("一键成片", runId) };
}

export async function autoflowStatus(cwd: string, runId: string) {
  const entry = active.get(runId);
  if (entry?.state && entry.cwd === cwd) return { running: true, state: entry.state };
  const state = await readFile(join(cwd, "一键成片", runId, "run.json"), "utf8").then(text => JSON.parse(text) as RunState, () => undefined);
  if (!state) throw Object.assign(new Error("没有找到该一键成片任务"), { status: 404 });
  return { running: !!entry, state };
}

export function stopAutoflow(runId: string) {
  const entry = active.get(runId);
  if (!entry) return false;
  entry.controller.abort(new Error("用户已停止"));
  return true;
}

export function waitAutoflow(runId: string) {
  return active.get(runId)?.promise ?? Promise.resolve();
}
