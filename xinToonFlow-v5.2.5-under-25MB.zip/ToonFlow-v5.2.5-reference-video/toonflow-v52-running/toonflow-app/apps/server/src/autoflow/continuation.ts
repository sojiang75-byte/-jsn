/**
 * 镜头续接（思路移植自 ComfyUI-MiniMaxH3-PrefixStream 的 Prefix Continuation：把上一段的尾部作为下一段的上下文）。
 * H3 原版把上一段尾部的 latent 帧拼在下一段 latent 前面并在解码后裁掉；托管视频 API 拿不到 latent，
 * 这里在像素层做等价的弱版本：上一镜通过手/肢体/特征检查后，取其结尾 N 帧作为下一镜的参考图（与首帧、角色锚点一起提交），
 * 让模型延续光线、站位与动作；角色外观始终以原始角色锚点为准（与原项目“每轮都带原始身份参考、不把生成误差往下传”一致）。
 * 未通过检查的镜头一律不作为续接上下文，避免六指、纹身串用等错误沿镜头链传播。
 */
import { posix } from "node:path";
import { extractFrame, probeMedia, systemFfmpeg, type FfmpegPaths } from "./media";
import type { ReferenceLabel } from "@/utils/media/referenceLabels";

export interface ContinuationOptions {
  /** never：不续接；qa（缺省）：上一镜通过检查才续接；always：总是续接 */
  mode?: "never" | "qa" | "always";
  /** 取上一镜结尾几帧，缺省 3 */
  frames?: number;
  /** 这几帧分布在结尾多少秒内，缺省 1.2 */
  spanSeconds?: number;
  /**
   * v5.2.5：手指/肢体检查对接力的影响。warn（缺省）：只记警告，不断链；block：未通过就不续接、不接力（v5.2.4 及以前的行为）。
   * v4 实测静帧 0/22、有角色视频 0/6 通过手指检查，block 等于每镜都断链重画，所以缺省改为 warn。
   * 人物明显变样（chainable=false）和角色特征串用（lastFrameTraitsOk=false）仍然断链。
   */
  handsGate?: "block" | "warn";
}

/** 手指/肢体检查是否挡接力（缺省不挡） */
export function handsBlockChain(options: Pick<ContinuationOptions, "handsGate"> | undefined) {
  return options?.handsGate === "block";
}

export interface ContinuationSource {
  video?: string;
  lastFrameHandsOk?: boolean;
  lastFrameTraitsOk?: boolean;
  chainable?: boolean;
  qa?: { pass: boolean };
  needsRedo?: boolean;
}

/** 能否用上一镜结尾作为续接上下文；返回原因便于写日志。 */
export function continuationGate(previous: ContinuationSource | undefined, sameSegment: boolean, options: ContinuationOptions = {}): { ok: boolean; reason: string } {
  const mode = options.mode ?? "qa";
  if (mode === "never") return { ok: false, reason: "未开启续接" };
  if (!previous?.video) return { ok: false, reason: "没有上一镜视频" };
  if (!sameSegment) return { ok: false, reason: "跨段（换场景）不续接" };
  if (mode === "always") return { ok: true, reason: "总是续接" };
  if (previous.needsRedo) return { ok: false, reason: "上一镜待重做" };
  if (previous.qa && !previous.qa.pass) return { ok: false, reason: "上一镜未通过逐帧质检" };
  if (previous.lastFrameTraitsOk === false) return { ok: false, reason: "上一镜尾帧角色特征串用" };
  if (previous.chainable === false) return { ok: false, reason: "上一镜尾帧角色漂移" };
  if (previous.lastFrameHandsOk !== true) {
    if (handsBlockChain(options)) return { ok: false, reason: "上一镜尾帧未通过手指/肢体检查" };
    return { ok: true, reason: previous.lastFrameHandsOk === false ? "上一镜尾帧手指/肢体有瑕疵（只记录，不断链）" : "上一镜尾帧未做手指/肢体检查（只记录，不断链）" };
  }
  return { ok: true, reason: "上一镜通过检查" };
}

/** 结尾 N 帧的时间点（秒）：均匀分布在 [duration - span, duration - 0.12] 内，按时间升序。 */
export function tailFrameTimes(duration: number, frames = 3, spanSeconds = 1.2) {
  const count = Math.max(1, Math.round(frames));
  const end = Math.max(0, duration - 0.12);
  const start = Math.max(0, end - Math.max(0, spanSeconds));
  if (count === 1) return [Number(end.toFixed(3))];
  return Array.from({ length: count }, (_, index) => Number((start + (end - start) * index / (count - 1)).toFixed(3)));
}

export function tailFrameLabels(count: number): ReferenceLabel[] {
  return Array.from({ length: count }, (_, index) => ({
    role: "other" as const, name: `上一镜结尾第${index + 1}/${count}帧`,
    note: "只用于延续光线、色调、人物站位与动作；人物外观以角色参考图为准，不得照搬此图中的瑕疵",
  }));
}

/** 抽取上一镜结尾帧到 outputDirectory（工作区相对路径），返回相对路径列表。abs 把相对路径转为绝对路径。 */
export async function extractTailFrames(video: string, outputDirectory: string, abs: (path: string) => string, options: ContinuationOptions = {},
  paths: FfmpegPaths = systemFfmpeg, signal?: AbortSignal) {
  const probe = await probeMedia(abs(video), paths, signal);
  const times = tailFrameTimes(probe.duration, options.frames ?? 3, options.spanSeconds ?? 1.2);
  const files: string[] = [];
  for (const [index, time] of times.entries()) {
    const file = posix.join(outputDirectory, `续接参考${index + 1}.jpg`);
    await extractFrame(abs(video), time, abs(file), paths, signal);
    files.push(file);
  }
  return files;
}
