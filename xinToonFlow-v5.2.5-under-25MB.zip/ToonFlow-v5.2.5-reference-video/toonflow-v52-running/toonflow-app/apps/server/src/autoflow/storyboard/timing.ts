/** 按台词字数估算镜头时长，并对齐到视频模型支持的时长档位。 */
import { defaultParams, type StoryboardParams } from "./vocab";
import type { Shot, Storyboard } from "./schema";

/** 计算朗读字数：中日韩字符按 1 计，拉丁单词按 1.6 字计，标点不计。 */
export function spokenUnits(text: string) {
  const cjk = text.match(/[\u3400-\u9fff\u3040-\u30ff\uac00-\ud7af]/g)?.length ?? 0;
  const words = text.replace(/[\u3400-\u9fff\u3040-\u30ff\uac00-\ud7af]/g, " ").match(/[A-Za-z0-9']+/g)?.length ?? 0;
  return cjk + words * 1.6;
}

export function estimateDialogueSeconds(shot: Pick<Shot, "dialogue">, params: Partial<StoryboardParams> = {}) {
  const { charsPerSecond, linePadding, speechLeadSeconds, speechTailSeconds } = { ...defaultParams, ...params };
  const spoken = (shot.dialogue ?? []).reduce((sum, line) => sum + spokenUnits(line.text) / charsPerSecond + linePadding, 0);
  if (spoken <= 0) return 0;
  return spoken + speechLeadSeconds + speechTailSeconds;
}

/** 估算镜头时长：台词时长 + 动作基础时长（按动作描述长度 1.5–3 秒），并夹在上下限内。反应镜头在下限允许 1 秒时取 1 秒。 */
export function estimateShotSeconds(shot: Pick<Shot, "dialogue" | "action"> & { spatialContract?: { beat?: string } }, params: Partial<StoryboardParams> = {}) {
  const merged = { ...defaultParams, ...params };
  if (shot.spatialContract?.beat === "reaction" && merged.minShotSeconds <= 1 && !(shot.dialogue?.length)) return 1;
  const dialogue = estimateDialogueSeconds(shot, merged);
  const actionBase = Math.min(3, Math.max(1.5, spokenUnits(shot.action) / 30));
  const raw = dialogue > 0 ? (merged.speechLeadSeconds > 0 ? dialogue : dialogue + 0.6) : actionBase + 1;
  const max = dialogue > 0 && merged.speechLeadSeconds > 0 ? Math.max(merged.maxShotSeconds, 15) : merged.maxShotSeconds;
  return Math.min(max, Math.max(merged.minShotSeconds, Math.round(raw * 10) / 10));
}

/** 取不小于 seconds 的最短档位；没有档位时向上取整。 */
export function snapDuration(seconds: number, allowed?: number[]) {
  if (!allowed?.length) return Math.ceil(seconds);
  const sorted = [...allowed].sort((a, b) => a - b);
  return sorted.find(value => value >= seconds) ?? sorted[sorted.length - 1]!;
}

/** 为缺省时长的镜头填估算值，并把全部时长对齐到模型档位；返回新对象，不修改入参。 */
export function fillDurations(board: Storyboard, options: { params?: Partial<StoryboardParams>; allowed?: number[] } = {}): Storyboard {
  const copy = structuredClone(board);
  for (const episode of copy.episodes) for (const segment of episode.segments) for (const shot of segment.shots) {
    const wanted = shot.seconds ?? estimateShotSeconds(shot, options.params);
    shot.seconds = snapDuration(Math.max(wanted, estimateDialogueSeconds(shot, options.params)), options.allowed);
  }
  return copy;
}
