/*
 * 分镜词表与默认节奏参数。
 *
 * 部分内容移植自 shuohao-skills（https://github.com/eternityspring/shuohao-skills 中 skills/novel-storyboard），
 * Copyright 2026 烁皓，Apache License 2.0；见仓库根目录 THIRD_PARTY_NOTICES.md。
 * 修改：改写为 TypeScript；镜头时长上下限改为可配置并按“每镜一次视频生成”调整默认值；运镜增加中文提示词短语。
 */

/** 景别：key 为枚举值，zh 为写入提示词的中文景别词。 */
export const shotSizes = {
  "extreme-wide": { zh: "大远景", en: "extreme wide shot" },
  wide: { zh: "全景", en: "wide shot" },
  full: { zh: "全身景", en: "full shot" },
  medium: { zh: "中景", en: "medium shot" },
  "medium-close": { zh: "近景", en: "medium close-up" },
  close: { zh: "特写", en: "close-up" },
  "extreme-close": { zh: "大特写", en: "extreme close-up" },
} as const;

/** 运镜：key 采用通用英文术语，zh 为写入视频提示词的中文短语。 */
export const cameraMoves = {
  "Static Shot": "固定机位",
  "Push In": "镜头缓慢推近",
  "Pull Out": "镜头缓慢拉远",
  "Zoom In": "变焦推近",
  "Zoom Out": "变焦拉远",
  "Pan Left": "镜头向左摇",
  "Pan Right": "镜头向右摇",
  "Truck Left": "镜头向左平移",
  "Truck Right": "镜头向右平移",
  "Tilt Up": "镜头向上仰摇",
  "Tilt Down": "镜头向下俯摇",
  "Pedestal Up": "镜头垂直升起",
  "Pedestal Down": "镜头垂直下降",
  "Arc Shot": "镜头环绕主体",
  "Tracking Shot": "镜头跟随主体移动",
  "Shake Slightly": "轻微手持晃动",
} as const;

export const stabilities = { stable: "画面稳定", "slight-shake": "轻微晃动", handheld: "手持感" } as const;

/** 每镜构图量化字段；缺失时质量门给出警告。 */
export const compositionFields = ["lens", "cameraPosition", "composition", "eyeline", "focus"] as const;

export type ShotSize = keyof typeof shotSizes;
export type CameraMove = keyof typeof cameraMoves;

/** 节奏默认值：每镜对应一次视频生成，默认允许 2–10 秒；段为同一场景内的一组镜头。 */
export const defaultParams = {
  minShotSeconds: 2,
  maxShotSeconds: 10,
  maxSegmentSeconds: 60,
  maxOnScreen: 3,
  /** 每集时长相对 targetSeconds 的容差。 */
  tolerance: 0.2,
  /** 中文台词语速（字/秒），用于估算时长。 */
  charsPerSecond: 4.5,
  /** 每句台词前后的呼吸留白（秒）。 */
  linePadding: 0.4,
  /** 首帧模式开口前的等待。缺省 0，clip 节奏按 H3 实测约 1.8 秒。 */
  speechLeadSeconds: 0,
  /** 说完后留在终点的短停。缺省 0，clip 节奏约 0.5 秒。 */
  speechTailSeconds: 0,
};
export type StoryboardParams = typeof defaultParams;
