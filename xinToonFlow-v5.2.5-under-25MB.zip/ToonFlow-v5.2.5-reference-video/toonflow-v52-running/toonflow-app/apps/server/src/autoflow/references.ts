/**
 * 按镜头的出场角色强制挂载参考图，并生成与之等长同序的 referenceLabels（宿主据此写入「图N：用途」说明）。
 * 优先级：每个出场角色的锚点 → 场景图 → 上一镜画面 → 各角色正脸特写 →（H3 风格）各角色多视角设定表；超出模型上限时按优先级截断并给出警告。
 */
import type { MediaReference } from "@toonflow/tools-scaffold/runtime";
import type { ReferenceLabel } from "@/utils/media/referenceLabels";
import { characterReferenceImages, characterSheetImage, type CharacterCard } from "@/utils/assets/characterCard";
import type { Shot } from "./storyboard/schema";

export interface ShotReferenceInput {
  shot: Pick<Shot, "id" | "characters">;
  cards: Map<string, CharacterCard>;
  sceneImage?: { path: string; name: string };
  /** 道具/车辆产品照（固定车辆卡），与场景图同级优先 */
  propImages?: { path: string; name: string }[];
  previousFrame?: string;
  /** v5.2.5：上一镜结尾几帧（续接上下文），带道具状态、门内门外、天气与光线；与上一镜画面同级优先 */
  tailFrames?: { path: string; label: ReferenceLabel }[];
  /** 模型单次可接收的参考图上限，缺省 8 */
  maxImages?: number;
  /** 同时挂载角色多视角设定表（H3 风格），优先级最低 */
  includeSheet?: boolean;
}

/** 每张参考图的来源，供 H3 风格写 <Subject N>/<Picture N> 定义。 */
export interface ReferenceEntry {
  kind: "anchor" | "face" | "sheet" | "scene" | "prop" | "previousFrame" | "keyframe" | "tailFrame";
  characterId?: string;
  name?: string;
}

export interface ShotReferencePlan {
  images: MediaReference[];
  referenceLabels: ReferenceLabel[];
  /** 角色 id → 其锚点在 images 中的序号（从 1 开始），用于提示词中“图N”指代 */
  characterImageIndex: Map<string, number>;
  warnings: string[];
  /** 出场但没有任何参考图的角色 */
  missing: string[];
  /** 与 images 等长同序的来源说明 */
  entries: ReferenceEntry[];
  /** 最终实际发送给媒体模型的参考图清单；序号从 1 开始 */
  manifest: ReferenceManifestEntry[];
  /** 被模型上限裁掉的候选，便于审计 */
  dropped: ReferenceManifestEntry[];
}

export interface ReferenceManifestEntry {
  index: number;
  path: string;
  kind: ReferenceEntry["kind"];
  characterId?: string;
  name?: string;
  label: string;
}

export function imageMimeType(path: string) {
  const extension = path.toLowerCase().split(".").pop();
  return extension === "jpg" || extension === "jpeg" ? "image/jpeg" : extension === "webp" ? "image/webp" : extension === "gif" ? "image/gif" : "image/png";
}

export function resolveShotReferences(input: ShotReferenceInput): ShotReferencePlan {
  const limit = input.maxImages ?? 8;
  type Candidate = { path: string; label: ReferenceLabel; priority: number; characterId?: string; entry: ReferenceEntry };
  const candidates: Candidate[] = [];
  const missing: string[] = [];
  const warnings: string[] = [];
  for (const character of input.shot.characters) {
    const card = input.cards.get(character.id);
    if (!card) { missing.push(character.id); continue; }
    const [anchor, face] = characterReferenceImages(card, character.outfit);
    if (!anchor) { missing.push(character.id); continue; }
    const outfit = character.outfit ? card.outfits.find(item => item.id === character.outfit)?.label : undefined;
    candidates.push({ path: anchor, priority: 0, characterId: character.id, entry: { kind: "anchor", characterId: character.id, name: card.name },
      label: { role: "character", name: outfit ? `${card.name}·${outfit}` : card.name } });
    if (face && face !== anchor) candidates.push({ path: face, priority: 3, entry: { kind: "face", characterId: character.id, name: card.name },
      label: { role: "character", name: card.name, note: "正脸特写：五官细节以此为准" } });
    const sheet = input.includeSheet ? characterSheetImage(card, character.outfit) : undefined;
    if (sheet && sheet !== anchor) candidates.push({ path: sheet, priority: 4, entry: { kind: "sheet", characterId: character.id, name: card.name },
      label: { role: "character", name: card.name, note: "多视角设定表：侧面、背面与细节以此为准" } });
  }
  if (input.sceneImage) candidates.push({ path: input.sceneImage.path, priority: 1, entry: { kind: "scene", name: input.sceneImage.name }, label: { role: "scene", name: input.sceneImage.name } });
  for (const prop of input.propImages ?? []) candidates.push({ path: prop.path, priority: 1, entry: { kind: "prop", name: prop.name },
    label: { role: "prop", name: prop.name, note: "产品参考图：只参考车型/外形、颜色与标记，不参考背景、光线和构图" } });
  if (input.previousFrame) candidates.push({ path: input.previousFrame, priority: 2, entry: { kind: "previousFrame" }, label: { role: "previousFrame" } });
  for (const frame of input.tailFrames ?? []) candidates.push({ path: frame.path, priority: 2, entry: { kind: "tailFrame" }, label: frame.label });

  const seen = new Set<string>();
  const unique = candidates.filter(item => !seen.has(item.path) && seen.add(item.path));
  // 稳定排序：同优先级保持出场顺序
  const ordered = unique.map((item, order) => ({ item, order })).sort((a, b) => a.item.priority - b.item.priority || a.order - b.order).map(entry => entry.item);
  const kept = ordered.slice(0, limit);
  // 正脸特写、上一镜画面属于“锦上添花”，被截断属预期；只有角色锚点或场景图被截断才告警
  for (const dropped of ordered.slice(limit).filter(item => item.priority <= 1)) {
    warnings.push(`${input.shot.id} 参考图超出上限 ${limit}，已舍弃：${dropped.label.name ?? dropped.label.role}(${dropped.path})`);
  }
  if (missing.length) warnings.push(`${input.shot.id} 角色 ${missing.join("、")} 没有锚点图，无法强制挂载参考`);
  const characterImageIndex = new Map<string, number>();
  kept.forEach((item, index) => {
    if (item.characterId && item.priority === 0) characterImageIndex.set(item.characterId, index + 1);
  });
  const toManifest = (item: Candidate, index: number): ReferenceManifestEntry => ({
    index,
    path: item.path,
    kind: item.entry.kind,
    ...(item.entry.characterId ? { characterId: item.entry.characterId } : {}),
    ...(item.entry.name ? { name: item.entry.name } : {}),
    label: [item.label.role, item.label.name, item.label.note].filter(Boolean).join(" / "),
  });
  const manifest = kept.map((item, index) => toManifest(item, index + 1));
  const dropped = ordered.slice(limit).map((item, index) => toManifest(item, limit + index + 1));
  return {
    images: kept.map(item => ({ path: item.path, mimeType: imageMimeType(item.path) })),
    referenceLabels: kept.map(item => item.label),
    characterImageIndex,
    warnings,
    missing,
    entries: kept.map(item => item.entry),
    manifest,
    dropped,
  };
}

/** 在参考图最前面插入一张图（如视频参考模式的本镜首帧），其余序号整体后移。 */
export function prependReference(plan: ShotReferencePlan, path: string, label: ReferenceLabel, entry: ReferenceEntry): ShotReferencePlan {
  return {
    ...plan,
    images: [{ path, mimeType: imageMimeType(path) }, ...plan.images],
    referenceLabels: [label, ...plan.referenceLabels],
    entries: [entry, ...plan.entries],
    manifest: [{ index: 1, path, kind: entry.kind, ...(entry.characterId ? { characterId: entry.characterId } : {}), ...(entry.name ? { name: entry.name } : {}), label: [label.role, label.name, label.note].filter(Boolean).join(" / ") },
      ...plan.manifest.map(item => ({ ...item, index: item.index + 1 }))],
    characterImageIndex: new Map([...plan.characterImageIndex].map(([id, index]) => [id, index + 1])),
  };
}
