export type QaStatus = "pass" | "fail" | "abstain";
export interface UnifiedQaResult {
  status: QaStatus;
  hardFailures: string[];
  softIssues: string[];
  abstentions: { source: string; reason: string }[];
  checks: Record<string, { status: "pass" | "fail" | "not_checked"; confidence?: number }>;
  evidence: unknown;
}

/** Normalize plugin/worker QA output. Missing or malformed evidence is abstain, never pass. */
export function normalizeExternalQa(value: unknown): UnifiedQaResult {
  if (!value || typeof value !== "object") return { status: "abstain", hardFailures: [], softIssues: [], abstentions: [{ source: "external_qa", reason: "No structured QA response" }], checks: {}, evidence: value ?? null };
  const data = value as Record<string, unknown>;
  const hardFailures = Array.isArray(data.hardFailures) ? data.hardFailures.map(String) : Array.isArray(data.issues) && data.pass === false ? data.issues.map(String) : [];
  const softIssues = Array.isArray(data.softIssues) ? data.softIssues.map(String) : [];
  const abstentions = Array.isArray(data.abstentions) ? data.abstentions.filter((item): item is { source: string; reason: string } => !!item && typeof item === "object" && typeof (item as any).source === "string" && typeof (item as any).reason === "string") : [];
  let status: QaStatus;
  if (data.status === "pass" || data.status === "fail" || data.status === "abstain") status = data.status;
  else if (data.pass === true) status = "pass";
  else if (data.pass === false && hardFailures.length) status = "fail";
  else status = "abstain";
  if (status === "pass" && abstentions.length) status = "abstain";
  if (status === "fail" && !hardFailures.length) abstentions.push({ source: "arbiter", reason: "Failure status has no auditable failure code" });
  return { status, hardFailures, softIssues, abstentions, checks: data.checks && typeof data.checks === "object" ? data.checks as UnifiedQaResult["checks"] : {}, evidence: data.evidence ?? data };
}

export function routeQaFailure(result: UnifiedQaResult) {
  if (result.status === "pass") return { action: "accept" as const, automaticAttempts: 0, requiresHuman: false };
  if (result.status === "abstain") return { action: "recheck_or_manual_review" as const, automaticAttempts: 0, requiresHuman: true };
  const text = result.hardFailures.join(" ").toLowerCase();
  if (/language|dialogue|transcript|英文|语言/.test(text)) return { action: "audio_track_only_if_supported" as const, automaticAttempts: 0, requiresHuman: true };
  if (/hand|finger|手指|手部/.test(text)) return { action: "frame_review_or_local_repair" as const, automaticAttempts: 2, requiresHuman: false };
  if (/vehicle|车型|车辆/.test(text)) return { action: "prop_reference_and_video" as const, automaticAttempts: 2, requiresHuman: false };
  if (/style|画风/.test(text)) return { action: "style_anchor_and_video" as const, automaticAttempts: 2, requiresHuman: false };
  if (/viewpoint|pov|视角/.test(text)) return { action: "shot_contract_and_video" as const, automaticAttempts: 2, requiresHuman: false };
  if (/identity|face|角色|人物/.test(text)) return { action: "identity_reference_and_keyframe" as const, automaticAttempts: 2, requiresHuman: false };
  return { action: "manual_review" as const, automaticAttempts: 0, requiresHuman: true };
}
