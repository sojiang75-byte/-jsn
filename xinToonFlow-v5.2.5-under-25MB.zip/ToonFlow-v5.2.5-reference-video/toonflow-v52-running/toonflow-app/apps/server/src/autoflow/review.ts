/** 成片程序化审片：基于 FFmpeg 检测信号判定黑场、冻结、镜头内切镜与时长偏差。 */
import type { VideoSignals } from "./media";

export interface ReviewIssue { code: "empty" | "duration" | "black" | "freeze" | "cut" | "audio"; severity: "error" | "warning"; message: string }
export interface ReviewResult { ok: boolean; issues: ReviewIssue[] }

export interface ReviewExpectation {
  /** 期望时长（秒） */
  seconds?: number;
  /** 是否期望音轨（有台词且模型生成音频时） */
  expectAudio?: boolean;
  /** 允许镜头内切镜数量，默认 0 */
  allowedCuts?: number;
}

const sum = (ranges: { duration: number }[]) => ranges.reduce((total, range) => total + range.duration, 0);
const fixed = (value: number) => value.toFixed(1);

export function reviewVideoSignals(signals: VideoSignals, expectation: ReviewExpectation = {}): ReviewResult {
  const issues: ReviewIssue[] = [];
  const duration = signals.duration;
  if (!(duration > 0.5)) {
    issues.push({ code: "empty", severity: "error", message: `视频时长异常（${fixed(duration)} 秒）` });
    return { ok: false, issues };
  }
  if (expectation.seconds) {
    const tolerance = Math.max(1, expectation.seconds * 0.25);
    if (Math.abs(duration - expectation.seconds) > tolerance) {
      issues.push({ code: "duration", severity: "warning", message: `时长 ${fixed(duration)} 秒，期望 ${expectation.seconds} 秒` });
    }
  }
  const black = sum(signals.black);
  if (black > 0) {
    const severe = black > 0.5 || black / duration > 0.2;
    issues.push({ code: "black", severity: severe ? "error" : "warning",
      message: `黑场共 ${fixed(black)} 秒（${signals.black.map(range => `${fixed(range.start)}–${fixed(range.end)}s`).join("、")}）` });
  }
  const freeze = sum(signals.freeze);
  if (freeze / duration > 0.5) issues.push({ code: "freeze", severity: "error", message: `画面冻结 ${fixed(freeze)} 秒，超过时长一半` });
  else if (freeze > 1.5) issues.push({ code: "freeze", severity: "warning", message: `画面冻结 ${fixed(freeze)} 秒` });
  // 黑场边界本身会触发场景分数，排除紧邻黑场起止的切点
  const cuts = signals.sceneCuts.filter(time => time > 0.15 && time < duration - 0.15
    && !signals.black.some(range => Math.abs(time - range.start) < 0.1 || Math.abs(time - range.end) < 0.1));
  const allowed = expectation.allowedCuts ?? 0;
  if (cuts.length > allowed) {
    issues.push({ code: "cut", severity: cuts.length - allowed >= 2 ? "error" : "warning",
      message: `镜头内检测到 ${cuts.length} 处切镜（${cuts.map(fixed).join("s、")}s），可能破坏连续性` });
  }
  if (expectation.expectAudio && !signals.hasAudio) issues.push({ code: "audio", severity: "warning", message: "有台词但视频没有音轨" });
  return { ok: !issues.some(issue => issue.severity === "error"), issues };
}
