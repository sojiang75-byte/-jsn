/**
 * 可插拔的一致性评分器。生成的关键帧/视频截帧与角色锚点图比对，得分低于阈值时由流水线换种子重试。
 * - createModelScorer：默认实现，调用用户已配置的（多模态）语言模型逐角色打分；
 * - createHttpScorer：接入本地人脸相似度服务（如自建 InsightFace/ArcFace 服务）的钩子，只应指向本机或内网地址；
 * - passThroughScorer：不评分（总是通过），用于未配置视觉模型时。
 */
import { readFile } from "node:fs/promises";
import { imageMimeType } from "./references";

export interface ScoreReference { path: string; name: string; role: "character" | "scene" | "previousFrame"; /** 角色卡规定的服装文字，用于服装连续性检查 */ outfit?: string }
export interface ScoreInput {
  /** 待评图片（绝对路径） */
  candidate: string;
  /** 参考图（绝对路径） */
  references: ScoreReference[];
  /** 本镜文字描述，供模型判断画面是否符合 */
  description: string;
  /** 逐角色特征行与“特征不可串用”约束（由角色卡推导），用于串特征检查 */
  traits?: string[];
  /** 站位/构图要求，用于空间位置检查 */
  staging?: string;
  signal?: AbortSignal;
}
/** 结构化检查项（0–1，1 表示无问题） */
export interface ScoreChecks {
  /** 每只可见的手正好五根手指 */
  fingers: number;
  /** 没有多余的手/手臂/肢体（含无主之手） */
  limbs: number;
  /** 没有角色之间串特征（纹身、疤痕、服装、配饰） */
  traitBleed: number;
  /** 不是第一人称视角（前景伸出持枪的手等） */
  pov: number;
  /** 空间位置与站位描述一致、合理 */
  spatial: number;
  /** 其它崩坏（画风、脸部、乱码文字、多余人物） */
  artifacts: number;
}
export interface ScoreResult {
  /** 0–1，取各角色最低分与各检查项最低分 */
  score: number;
  perCharacter: Record<string, number>;
  reasons: string[];
  scorer: string;
  checks?: ScoreChecks;
}

/** 手与肢体检查是否通过（没有结构化检查时以总分为准） */
export function handsPass(result: Pick<ScoreResult, "score" | "checks"> | undefined, threshold: number) {
  if (!result) return false;
  if (!result.checks) return result.score >= threshold;
  return Math.min(result.checks.fingers, result.checks.limbs) >= threshold;
}
export interface ConsistencyScorer {
  id: string;
  score(input: ScoreInput): Promise<ScoreResult>;
}

export const passThroughScorer: ConsistencyScorer = {
  id: "none",
  async score() { return { score: 1, perCharacter: {}, reasons: ["未启用一致性评分"], scorer: "none" }; },
};

/** 视觉问答接口：给定图片与文字，返回模型文本输出。 */
export type VisionComplete = (input: { system: string; prompt: string; images: { data: string; mimeType: string }[]; signal?: AbortSignal; json?: boolean }) => Promise<string>;

export async function imagePart(path: string) {
  return { data: (await readFile(path)).toString("base64"), mimeType: imageMimeType(path) };
}

/** 从模型输出中取第一个 JSON 对象/数组（容忍 ```json 包裹与前后说明文字）。 */
export function extractJson(text: string): unknown {
  const fenced = text.match(/```(?:json)?\s*([\s\S]*?)```/);
  const body = fenced ? fenced[1]! : text;
  const start = body.search(/[[{]/);
  if (start < 0) throw new Error("模型输出中没有 JSON");
  const open = body[start]!;
  const close = open === "{" ? "}" : "]";
  let depth = 0;
  let inString = false;
  for (let index = start; index < body.length; index++) {
    const char = body[index]!;
    if (inString) {
      if (char === "\\") index++;
      else if (char === "\"") inString = false;
      continue;
    }
    if (char === "\"") inString = true;
    else if (char === open) depth++;
    else if (char === close && --depth === 0) return JSON.parse(body.slice(start, index + 1));
  }
  throw new Error("模型输出的 JSON 不完整");
}

const scoringSystem = `你是日式2D动画分镜的质检员。前面的图片是角色参考图（附角色卡规定服装），最后一张是待审画面。本镜没有角色参考时只有待审画面。
1. 逐个角色判断待审画面中该角色的脸型五官、发型发色是否与参考图为同一人。
2. 服装连续性：该角色的服装（外套款式、领型、颜色、材质、帽衫/夹克/皮衣之别）必须与角色卡服装文字和参考图一致；换了外套或款式不同，该角色分数不得高于 0.4。
3. fingers：逐只手数手指，每只可见的手必须正好五根手指；任何一只手六指、缺指、手指粘连，fingers 不得高于 0.3。
4. limbs：多余的手或手臂（含从画外伸入、找不到主人的手）、一人多于两只手臂、肢体缠绕错乱，limbs 不得高于 0.3。
5. traitsClean（特征干净度，1=没有串用）：按给出的逐角色特征与约束检查，某个角色身上出现了属于另一个角色的纹身/疤痕/配饰/服装（例如约束写“只有老五有纹身，萧枫没有纹身”而萧枫手臂上有纹身），traitsClean 不得高于 0.2；没有串用时给 1。
6. viewpointMatch（镜头视角合同匹配度）：必须根据画面描述中的 cameraContract 判断是否匹配。第一人称/主观/过肩/插入/顶视只要是合同明确要求就不是缺陷；只有实际视角与合同不符才低分。没有声明合同则不因 POV 单独扣分。
7. spatial：人物的空间位置、朝向与站位描述一致且物理上合理（例如人站在高速行驶车辆正前方的车道上、人物漂浮或穿模），不合理时 spatial 不得高于 0.3。
8. 画风：必须是2D日式动画赛璐璐风格；照片写实或3D渲染质感 artifacts 不得高于 0.3。其它崩坏（脸部扭曲、乱码文字/招牌/车牌字样、多余人物）酌情降低 artifacts。
只输出一个 JSON 对象，不要任何其它文字：{"characters":{"角色名":0到1的小数},"outfit":{"角色名":0到1的小数},"fingers":0到1,"limbs":0到1,"traitsClean":0到1,"viewpointMatch":0到1,"thirdPerson":0到1（仅兼容旧数据）,"spatial":0到1,"artifacts":0到1,"reasons":["简短问题"]}
characters 与 outfit 的键必须与给出的角色名完全一致；所有检查项都是“越高越好”：1 表示没有问题，0 表示问题严重；不要把“问题程度”填进去。`;

/** 把 0–1、"0.8"、"80%"、80（百分制）、8（十分制）统一成 0–1；无法识别返回 undefined。 */
export function normalizeScore(value: unknown): number | undefined {
  if (value && typeof value === "object" && "score" in value) return normalizeScore((value as { score: unknown }).score);
  const text = typeof value === "string" ? value.trim() : value;
  const percent = typeof text === "string" && text.endsWith("%");
  const number = Number(percent ? (text as string).slice(0, -1) : text);
  if (text === "" || text === null || text === undefined || typeof text === "boolean" || !Number.isFinite(number)) return undefined;
  const scaled = percent || number > 10 ? number / 100 : number > 1 ? number / 10 : number;
  return Math.min(1, Math.max(0, scaled));
}

/**
 * 宽松解析评分 JSON：characters 可以是 {名字:分数} / {名字:{score}} / [{name,score}]；名字忽略首尾空白与大小写；
 * 只有一个角色且只返回一个分数时直接采用；也接受顶层 score / consistency 作为该角色分数。
 */
/** 去掉“无/未见/没有…”之类的否定短语后，理由里是否仍提到该类问题 */
function mentionsProblem(reasons: string[], problem: RegExp) {
  return reasons.some(reason => problem.test(reason.replace(/(无|未见|未出现|未发现|没有|不存在|并无|非|不是|no |not |without )[^，；。,;]*/gi, "")));
}

export function parseScoreOutput(text: string, names: string[]) {
  const parsed = extractJson(text) as Record<string, unknown>;
  if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) throw new Error("评分输出不是 JSON 对象");
  const raw = parsed.characters ?? parsed.scores ?? parsed.perCharacter;
  const entries: [string, unknown][] = Array.isArray(raw)
    ? raw.map(item => [String((item as { name?: unknown })?.name ?? ""), item])
    : raw && typeof raw === "object" ? Object.entries(raw as Record<string, unknown>) : [];
  const key = (name: string) => name.trim().toLowerCase();
  const perCharacter: Record<string, number> = {};
  for (const name of names) {
    const found = entries.find(([entry]) => key(entry) === key(name))
      ?? (names.length === 1 && entries.length === 1 ? entries[0] : undefined);
    const fallback = names.length === 1 ? parsed.score ?? parsed.consistency : undefined;
    perCharacter[name] = normalizeScore(found?.[1] ?? fallback) ?? 0;
  }
  // 服装连续性（可选字段）并入该角色分数；手指/肢体（可选字段）并入崩坏分
  const outfit = parsed.outfit && typeof parsed.outfit === "object" && !Array.isArray(parsed.outfit) ? parsed.outfit as Record<string, unknown> : {};
  for (const name of names) {
    const entry = Object.entries(outfit).find(([entry]) => key(entry) === key(name));
    const value = entry ? normalizeScore(entry[1]) : undefined;
    if (value !== undefined) perCharacter[name] = Math.min(perCharacter[name]!, value);
  }
  const check = (...keys: string[]) => {
    for (const name of keys) { const value = normalizeScore(parsed[name]); if (value !== undefined) return value; }
    return 1;
  };
  const reasonList = (Array.isArray(parsed.reasons) ? parsed.reasons : typeof parsed.reasons === "string" ? [parsed.reasons] : []).map(String);
  // 名字像“问题程度”的旧键（traitBleed / pov）模型常按“0=没有问题”填写：低分但理由里没有对应问题时视为反向，按 1 处理
  const ambiguous = (keys: string[], problem: RegExp) => {
    for (const name of keys) {
      const value = normalizeScore(parsed[name]);
      if (value === undefined) continue;
      return value < 0.5 && !mentionsProblem(reasonList, problem) ? 1 : value;
    }
    return undefined;
  };
  const checks: ScoreChecks = {
    fingers: check("fingers", "hands"),
    limbs: check("limbs", "extraLimbs", "extra_hands"),
    traitBleed: normalizeScore(parsed.traitsClean) ?? ambiguous(["traitBleed", "trait_bleed", "traits"], /纹身|刺青|疤|痣|串用|串了|属于|他人|另一|别人|tattoo|scar|bleed/i) ?? 1,
    pov: normalizeScore(parsed.viewpointMatch) ?? normalizeScore(parsed.thirdPerson) ?? ambiguous(["pov"], /第一人称|主观|POV|first.?person/i) ?? 1,
    spatial: check("spatial", "staging"),
    artifacts: check("artifacts"),
  };
  const artifacts = Math.min(...Object.values(checks));
  const reasons = (Array.isArray(parsed.reasons) ? parsed.reasons : typeof parsed.reasons === "string" ? [parsed.reasons] : []).map(String).slice(0, 10);
  const labels: Record<keyof ScoreChecks, string> = { fingers: "手指数不对", limbs: "多余的手/肢体", traitBleed: "角色特征串用", pov: "视角合同不匹配", spatial: "空间位置不合理", artifacts: "画面崩坏" };
  for (const [name, value] of Object.entries(checks) as [keyof ScoreChecks, number][]) {
    if (value < 0.5 && !reasons.some(reason => reason.includes(labels[name]))) reasons.push(`${labels[name]}（${value.toFixed(2)}）`);
  }
  // 模型只给了 artifacts（旧格式）时不附 checks，handsPass 回退到总分
  const detailed = ["fingers", "hands", "limbs", "extraLimbs", "extra_hands", "traitsClean", "traitBleed", "trait_bleed", "traits", "pov", "viewpointMatch", "thirdPerson", "spatial", "staging"].some(name => parsed[name] !== undefined);
  return detailed ? { perCharacter, artifacts, reasons, checks } : { perCharacter, artifacts, reasons };
}

/**
 * options.checkEmptyShots：本镜没有角色参考时仍让模型检查手指/肢体/视角/空间/崩坏（缺省 true）；false 时空镜直接给 1 分。
 */
export function createModelScorer(complete: VisionComplete, options: { checkEmptyShots?: boolean } = {}): ConsistencyScorer {
  return {
    id: "model",
    async score(input) {
      const characters = input.references.filter(reference => reference.role === "character");
      if (!characters.length && options.checkEmptyShots === false) return { score: 1, perCharacter: {}, reasons: ["本镜无角色参考"], scorer: "model" };
      const images = [];
      for (const reference of characters) images.push(await imagePart(reference.path));
      images.push(await imagePart(input.candidate));
      const legend = characters.map((reference, index) => `图${index + 1}：${reference.name}${reference.outfit ? `（角色卡服装：${reference.outfit}）` : ""}`).join("；");
      const extra = [
        input.traits?.length ? `逐角色特征与约束：${input.traits.join("；")}` : "",
        input.staging ? `站位与构图要求：${input.staging}` : "",
      ].filter(Boolean).join("\n");
      const prompt = `${legend ? `${legend}；` : "本镜没有角色参考；"}图${characters.length + 1}：待审画面。画面描述：${input.description}${extra ? `\n${extra}` : ""}`;
      const names = characters.map(reference => reference.name);
      let text = await complete({ system: scoringSystem, prompt, images, signal: input.signal, json: true });
      let result: ReturnType<typeof parseScoreOutput>;
      try { result = parseScoreOutput(text, names); }
      catch (error) {
        // 输出不是合法 JSON 时只重试一次，要求严格 JSON
        text = await complete({ system: scoringSystem, images, signal: input.signal, json: true,
          prompt: `${prompt}\n\n上一次输出无法解析（${error instanceof Error ? error.message : String(error)}）。只输出一个合法 JSON 对象。` });
        result = parseScoreOutput(text, names);
      }
      return { score: Math.min(result.artifacts, ...Object.values(result.perCharacter)), perCharacter: result.perCharacter, reasons: result.reasons, scorer: "model", checks: result.checks };
    },
  };
}

/**
 * 本地人脸相似度服务钩子。约定：POST JSON {candidate:{data,mimeType}, references:[{name,data,mimeType}]}，
 * 返回 {scores:{name:0..1}}。默认拒绝非本机/内网地址，避免把角色图发往公网。
 */
export function createHttpScorer(endpoint: string, fetchImpl: typeof fetch = fetch): ConsistencyScorer {
  const url = new URL(endpoint);
  if (!/^(localhost|127\.\d+\.\d+\.\d+|\[::1\]|10\.\d+\.\d+\.\d+|192\.168\.\d+\.\d+|172\.(1[6-9]|2\d|3[01])\.\d+\.\d+)$/.test(url.hostname)) {
    throw new Error("人脸相似度服务只允许本机或内网地址");
  }
  return {
    id: "http",
    async score(input) {
      const characters = input.references.filter(reference => reference.role === "character");
      if (!characters.length) return { score: 1, perCharacter: {}, reasons: ["本镜无角色参考"], scorer: "http" };
      const references = [];
      for (const reference of characters) references.push({ name: reference.name, ...(await imagePart(reference.path)) });
      const response = await fetchImpl(url, { method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ candidate: await imagePart(input.candidate), references }), signal: input.signal });
      if (!response.ok) throw new Error(`人脸相似度服务返回 HTTP ${response.status}`);
      const data = await response.json() as { scores?: Record<string, number> };
      const perCharacter: Record<string, number> = {};
      for (const reference of characters) perCharacter[reference.name] = Math.min(1, Math.max(0, Number(data.scores?.[reference.name]) || 0));
      return { score: Math.min(...Object.values(perCharacter)), perCharacter, reasons: [], scorer: "http" };
    },
  };
}

/** 换种子：确定性递增，避免重复命中同一坏种子。 */
export function nextSeed(seed: number | undefined, attempt: number) {
  const base = seed ?? 20260101;
  return (base + attempt * 7919) % 4294967296;
}
