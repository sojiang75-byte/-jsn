/**
 * 成片拼接的接缝处理（思路移植自 ComfyUI-MiniMaxH3-PrefixStream 的 seam_protector / Long Video Stitcher，
 * 原实现在 latent / torch 张量上做；这里在像素与波形层面用 FFmpeg 重写，代码独立编写）：
 * 1. 裁掉重叠开头：续写片段（例如视频延长接口返回的“上一段尾部 + 新内容”）开头与上一镜重复的帧按 trimHeadFrames 丢弃；
 * 2. 亮度匹配：同一段内的切镜，测上一镜末尾几帧与下一镜开头几帧的平均亮度，算一个保守增益（±maxGainPercent），
 *    只施加在下一镜开头 fadeFrames 帧内并按余弦曲线回到原亮度，避免硬切时的明暗跳变；
 * 3. 音频：有重叠时用被裁掉的那段音频与上一镜结尾做互补余弦交叉淡化（sin² + cos² = 1，同源声音不会被抬高 3dB），
 *    总时长与画面保持一致；没有重叠的硬切只做几毫秒的去爆音淡入淡出，不改变时长，因而不会累积音画漂移。
 */
import { mkdir } from "node:fs/promises";
import { dirname } from "node:path";
import { probeMedia, runProcess, systemFfmpeg, type FfmpegPaths, type MediaProbe } from "./media";

export interface StitchClip {
  file: string;
  /** 开头与上一镜重叠、需要丢弃的帧数（按输出帧率计） */
  trimHeadFrames?: number;
  /** 所属段；只在同段相邻镜之间做亮度匹配（跨场景的明暗变化是有意为之） */
  segmentId?: string;
  /** 首尾各多剪掉的秒数（AI 视频开头结尾容易漂；由 speechSafeEdges 按静音测出，不会剪到台词） */
  edgeHeadSeconds?: number;
  edgeTailSeconds?: number;
}

export interface StitchOptions {
  width: number;
  height: number;
  fps?: number;
  /** 亮度匹配：缺省开 */
  luminanceMatch?: boolean;
  /** 亮度增益上限（百分比），缺省 8 */
  maxGainPercent?: number;
  /** 增益回落的帧数，缺省 16 */
  fadeFrames?: number;
  /** 有重叠时的音频交叉淡化毫秒数，缺省 40 */
  crossfadeMs?: number;
  /** 硬切去爆音淡入淡出毫秒数，缺省 6 */
  declickMs?: number;
  /** 测亮度用的帧数，缺省 6 */
  analysisFrames?: number;
  crf?: number;
}

export interface SeamPlan {
  index: number;
  trimHeadFrames: number;
  /** 本镜开头施加的亮度增益（1 = 不变） */
  gain: number;
  /** 本镜开头与上一镜之间的音频交叉淡化秒数（0 = 硬切去爆音） */
  audioCrossfade: number;
  /** 首尾额外剪掉的秒数（有重叠裁头时不再剪头） */
  edgeHead?: number;
  edgeTail?: number;
}

/** 由两侧平均亮度算保守增益（与 seam_protector.estimate_luminance_gain 同一思路：比值取中位数并限幅）。 */
export function luminanceGain(previousTail: number[], nextHead: number[], maxGainPercent = 8) {
  const pairs = Math.min(previousTail.length, nextHead.length);
  const ratios: number[] = [];
  for (let index = 0; index < pairs; index++) {
    const a = previousTail[previousTail.length - pairs + index]!;
    const b = nextHead[index]!;
    // 过暗/过曝帧不参与（与原实现的 0.04–0.96 有效区间一致，这里是 0–255 的 Y 均值）
    if (a < 10 || a > 245 || b < 10 || b > 245) continue;
    ratios.push(a / b);
  }
  if (!ratios.length) return 1;
  ratios.sort((x, y) => x - y);
  const middle = ratios.length >> 1;
  const median = ratios.length % 2 ? ratios[middle]! : (ratios[middle - 1]! + ratios[middle]!) / 2;
  const limit = Math.max(0, maxGainPercent) / 100;
  return Math.min(1 + limit, Math.max(1 - limit, median));
}

/** 只依赖探测结果与亮度测量的纯函数：决定每个接缝怎么处理。 */
export function planSeams(clips: StitchClip[], luma: { head: number[]; tail: number[] }[], options: Pick<StitchOptions, "luminanceMatch" | "maxGainPercent" | "crossfadeMs" | "fps">): SeamPlan[] {
  const fps = options.fps ?? 24;
  return clips.map((clip, index) => {
    const trimHeadFrames = index === 0 ? 0 : Math.max(0, Math.round(clip.trimHeadFrames ?? 0));
    const previous = clips[index - 1];
    const sameSegment = !!previous && !!clip.segmentId && previous.segmentId === clip.segmentId;
    const gain = index > 0 && sameSegment && options.luminanceMatch !== false
      ? luminanceGain(luma[index - 1]!.tail, luma[index]!.head, options.maxGainPercent ?? 8) : 1;
    const overlapSeconds = trimHeadFrames / fps;
    const audioCrossfade = index > 0 && trimHeadFrames > 0 ? Math.min(overlapSeconds, (options.crossfadeMs ?? 40) / 1000) : 0;
    const edgeHead = trimHeadFrames > 0 ? 0 : Math.max(0, clip.edgeHeadSeconds ?? 0);
    const edgeTail = Math.max(0, clip.edgeTailSeconds ?? 0);
    return { index, trimHeadFrames, gain: Math.abs(gain - 1) < 0.005 ? 1 : gain, audioCrossfade, ...(edgeHead ? { edgeHead } : {}), ...(edgeTail ? { edgeTail } : {}) };
  });
}

/** 测一段视频开头或结尾若干帧的平均亮度（Y 均值，0–255）。 */
export async function measureLuma(file: string, where: "head" | "tail", frames: number, duration: number, paths: FfmpegPaths = systemFfmpeg, signal?: AbortSignal, skipFrames = 0, fps = 24) {
  const seek = where === "head" ? skipFrames / fps : Math.max(0, duration - (frames + 1) / fps);
  const result = await runProcess(paths.ffmpeg, ["-hide_banner", "-nostdin", "-ss", seek.toFixed(3), "-i", file, "-an",
    "-vf", `fps=${fps},scale=160:-2,signalstats,metadata=print:key=lavfi.signalstats.YAVG`, "-frames:v", String(frames), "-f", "null", "-"], signal);
  const values = [...result.stderr.matchAll(/lavfi\.signalstats\.YAVG=([\d.]+)/g)].map(match => Number(match[1]));
  return values;
}

/** 生成 filter_complex（纯函数，便于测试）。 */
export function buildStitchFilter(probes: MediaProbe[], plans: SeamPlan[], options: StitchOptions) {
  const fps = options.fps ?? 24;
  const { width, height } = options;
  const fade = Math.max(1, options.fadeFrames ?? 16);
  const declick = Math.max(0, (options.declickMs ?? 6) / 1000);
  const filters: string[] = [];
  const videoLabels: string[] = [];
  let audioChain = "";
  probes.forEach((probe, index) => {
    const plan = plans[index]!;
    const start = plan.trimHeadFrames / fps + (plan.edgeHead ?? 0);
    const body = Math.max(0.04, probe.duration - start - (plan.edgeTail ?? 0));
    let video = `[${index}:v:0]scale=${width}:${height}:force_original_aspect_ratio=decrease,pad=${width}:${height}:(ow-iw)/2:(oh-ih)/2,setsar=1,fps=${fps}`;
    video += start > 0 || plan.edgeTail ? `,trim=start=${start.toFixed(4)}:duration=${body.toFixed(4)},setpts=PTS-STARTPTS` : "";
    video += ",format=yuv420p";
    if (plan.gain !== 1) {
      // 增益只作用于亮度平面，按余弦曲线在 fade 帧内回到 1（apply_luminance_gain_fade 的像素层等价物）
      const g = plan.gain.toFixed(4);
      video += `,geq=lum='clip(lum(X,Y)*(1+(${g}-1)*if(lt(N,${fade}),0.5+0.5*cos(PI*N/${fade}),0)),0,255)':cb='cb(X,Y)':cr='cr(X,Y)'`;
    }
    filters.push(`${video}[v${index}]`);
    videoLabels.push(`[v${index}]`);
    // 音频：重叠时从（裁切点 - 交叉淡化时长）开始取，交叉淡化后总长 = 画面长
    const audioStart = Math.max(0, start - plan.audioCrossfade);
    const audioSource = probe.hasAudio
      ? `[${index}:a:0]aresample=44100,aformat=sample_fmts=fltp:channel_layouts=stereo,atrim=start=${audioStart.toFixed(4)},asetpts=PTS-STARTPTS`
      : `anullsrc=r=44100:cl=stereo,atrim=duration=${(body + plan.audioCrossfade).toFixed(4)}`;
    const length = body + plan.audioCrossfade;
    let audio = `${audioSource},apad=whole_dur=${length.toFixed(4)},atrim=duration=${length.toFixed(4)}`;
    const nextPlan = plans[index + 1];
    if (declick > 0) {
      if (plan.audioCrossfade === 0) audio += `,afade=t=in:d=${declick}:curve=hsin`;
      if (!nextPlan || nextPlan.audioCrossfade === 0) audio += `,afade=t=out:st=${Math.max(0, length - declick).toFixed(4)}:d=${declick}:curve=hsin`;
    }
    filters.push(`${audio}[a${index}]`);
    if (index === 0) audioChain = `[a0]`;
    else if (plan.audioCrossfade > 0) {
      // hsin = sin²：互补增益（淡出 cos²），同源重叠不升高音量
      filters.push(`${audioChain}[a${index}]acrossfade=d=${plan.audioCrossfade.toFixed(4)}:c1=hsin:c2=hsin[ax${index}]`);
      audioChain = `[ax${index}]`;
    } else {
      filters.push(`${audioChain}[a${index}]concat=n=2:v=0:a=1[ax${index}]`);
      audioChain = `[ax${index}]`;
    }
  });
  filters.push(`${videoLabels.join("")}concat=n=${probes.length}:v=1:a=0[v]`);
  return { filter: filters.join(";"), audioLabel: audioChain };
}

/** 按接缝计划拼接成片。 */
export async function stitchVideos(clips: StitchClip[], output: string, options: StitchOptions, paths: FfmpegPaths = systemFfmpeg, signal?: AbortSignal) {
  if (!clips.length) throw new Error("没有可拼接的视频");
  const fps = options.fps ?? 24;
  const probes: MediaProbe[] = [];
  for (const clip of clips) probes.push(await probeMedia(clip.file, paths, signal));
  const frames = options.analysisFrames ?? 6;
  const luma: { head: number[]; tail: number[] }[] = [];
  for (const [index, clip] of clips.entries()) {
    const need = options.luminanceMatch !== false;
    luma.push(need ? {
      head: await measureLuma(clip.file, "head", frames, probes[index]!.duration, paths, signal, index ? Math.round(clip.trimHeadFrames ?? 0) : 0, fps),
      tail: await measureLuma(clip.file, "tail", frames, probes[index]!.duration, paths, signal, 0, fps),
    } : { head: [], tail: [] });
  }
  const plans = planSeams(clips, luma, { ...options, fps });
  const { filter, audioLabel } = buildStitchFilter(probes, plans, options);
  const args = ["-hide_banner", "-nostdin", "-y"];
  for (const clip of clips) args.push("-i", clip.file);
  await mkdir(dirname(output), { recursive: true });
  const result = await runProcess(paths.ffmpeg, [...args, "-filter_complex", filter, "-map", "[v]", "-map", audioLabel,
    "-c:v", "libx264", "-preset", "veryfast", "-crf", String(options.crf ?? 20), "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "160k", "-movflags", "+faststart", output], signal);
  if (result.code !== 0) throw new Error(`FFmpeg 拼接失败（${result.code}）：${result.stderr.trim().split("\n").slice(-4).join(" | ")}`);
  return { output, plans };
}
