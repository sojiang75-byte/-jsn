/**
 * 花费估算与预算守卫。
 * - 按“请求秒数 × 每秒单价”报价（ai& 的 MiniMax H3：$0.055/秒，按请求秒数报价、仅成功完成时扣费）。
 * - 缺省不限制金额（maxUsd 缺省、0 或空 = 不限制），但始终记录花费并写进报告。
 * - 设了上限时，每次付费生成前检查：已花费 + 不确定 + 本次报价 > 上限 → 直接中止（不提交，也就不会产生无法取消的任务）。
 * - 结算：成功记为 charged；明确失败（4xx 拒绝、任务 failed）记为 free；超时/断线等无法确认的记为 uncertain，按已花费计入，宁可保守。
 */

/** 内置单价（美元/秒），键为 `${providerId}/${modelId}`。 */
export const knownVideoPrices: Record<string, number> = {
  /** ai& MiniMax H3，按请求秒数。640P 预览仍走这条报价；RunningHub 量化档不在这个客户端里。 */
  "aiand/minimaxai/minimax-h3": 0.055,
  /** 本机 Grok Imagine 中继：不收费，花费记录显示 $0 */
  "grokRelay/grok-imagine-video": 0,
};

export function videoPricePerSecond(providerId: string, modelId: string, override?: number) {
  if (override !== undefined) return override;
  return knownVideoPrices[`${providerId}/${modelId}`];
}

/** 单次视频报价（美元，保留 4 位小数）。 */
export function estimateVideoCost(seconds: number, pricePerSecond: number) {
  return Math.round(Math.max(0, Math.round(seconds)) * pricePerSecond * 10000) / 10000;
}

export interface SpendEntry { label: string; seconds: number; usd: number; status: "reserved" | "charged" | "uncertain" | "free"; at: string; error?: string }
export interface SpendState { usd: number; entries: SpendEntry[] }
export interface BudgetOptions { /** 花费上限（美元）；缺省、0、空或非正数 = 不限制 */ maxUsd?: number | null; pricePerSecond?: number; preflight?: boolean }

/** 有效上限：只有正数才算上限，其余（undefined / null / 0 / NaN）都表示不限制。 */
export function budgetCap(options: BudgetOptions | undefined): number | undefined {
  const value = options?.maxUsd;
  return typeof value === "number" && Number.isFinite(value) && value > 0 ? value : undefined;
}

export class BudgetExceededError extends Error {
  readonly status = 402;
  readonly code = "BUDGET_EXCEEDED";
  constructor(message: string) { super(message); this.name = "BudgetExceededError"; }
}

export const round = (value: number) => Math.round(value * 10000) / 10000;

/** 已计入的花费（charged + uncertain + 尚未结算的 reserved）。 */
export function committedSpend(spend: SpendState) {
  return round(spend.entries.filter(entry => entry.status !== "free").reduce((sum, entry) => sum + entry.usd, 0));
}

export class BudgetGuard {
  constructor(readonly options: BudgetOptions | undefined, readonly spend: SpendState) {}

  /** 有效上限；undefined 表示不限制（只记录花费） */
  get cap() { return budgetCap(this.options); }

  /** 付费请求前调用：超预算抛 BudgetExceededError，否则登记 reserved 并返回条目。 */
  reserve(label: string, seconds: number, usd: number): SpendEntry {
    const committed = committedSpend(this.spend);
    const cap = this.cap;
    if (cap !== undefined && committed + usd > cap + 1e-9) {
      throw new BudgetExceededError(`预算不足：已花费 $${committed.toFixed(3)}，本次 ${label} 报价 $${usd.toFixed(3)}，上限 $${cap.toFixed(3)}，已在提交前中止`);
    }
    const entry: SpendEntry = { label, seconds, usd, status: "reserved", at: new Date().toISOString() };
    this.spend.entries.push(entry);
    this.spend.usd = committedSpend(this.spend);
    return entry;
  }

  settle(entry: SpendEntry, outcome: "charged" | "uncertain" | "free", error?: string) {
    entry.status = outcome;
    if (error) entry.error = error.slice(0, 300);
    this.spend.usd = committedSpend(this.spend);
  }

  /** 预检：剩余步骤的估算花费 + 已花费超过上限时中止。 */
  preflight(stage: string, estimateUsd: number) {
    const cap = this.cap;
    if (cap === undefined || this.options?.preflight === false) return;
    const committed = committedSpend(this.spend);
    if (committed + estimateUsd > cap + 1e-9) {
      throw new BudgetExceededError(`预算预检未通过（${stage}）：已花费 $${committed.toFixed(3)} + 预计 $${estimateUsd.toFixed(3)} > 上限 $${cap.toFixed(3)}。可提高 budget.maxUsd、减少镜头/角色，或设 budget.preflight=false 改为逐次检查`);
    }
  }
}

/** 根据错误判断这次付费请求是否可能已扣费。 */
export function outcomeOfError(error: unknown): "free" | "uncertain" {
  const status = (error as { status?: number }).status;
  const code = (error as { code?: string }).code;
  if (code === "MEDIA_TASK_FAILED" || code === "BUDGET_EXCEEDED") return "free";
  if (status !== undefined && status >= 400 && status < 500) return "free";
  return "uncertain";
}
