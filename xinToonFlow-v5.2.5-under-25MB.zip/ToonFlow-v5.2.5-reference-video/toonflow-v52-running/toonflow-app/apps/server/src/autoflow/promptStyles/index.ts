import { buildCharacterViewPrompt } from "@/utils/assets/characterCard";
import { genericPromptStyle } from "./generic";
import { createH3PromptStyle, type H3StyleOptions } from "./h3";
import type { PromptStyle, PromptStyleId } from "./types";

/**
 * v5run hybrid: stills (anchors, faces, scenes, first/end frames) use the generic Chinese prompts, which the grokRelay
 * worker translates for xAI grok-imagine-image; videos use the MiniMax H3 official format for ai& H3 (first-frame I2VA,
 * dialogue as <d>[Language] text</d>, voice lock). No H3 planner rule, so the storyboard stays Chinese for the worker/QA keywords.
 */
function createGrokH3PromptStyle(h3?: H3StyleOptions): PromptStyle {
  const video = createH3PromptStyle(h3);
  return {
    ...genericPromptStyle, id: "grokH3", label: "图片 xAI（通用中文）+ 视频 MiniMax H3 官方格式", video: video.video,
    characterSheet(card, outfitId) {
      const view = buildCharacterViewPrompt(card, "sheet", outfitId);
      return { prompt: `${view.prompt}\nAvoid: ${view.negative}`, ratio: view.ratio, seed: view.seed };
    },
  };
}

export * from "./types";
export { h3Views, h3ViewIds, h3SheetPresets, layoutH3Sheet, closestH3Ratio } from "./h3Views";
export { buildH3CharacterSheet, h3ReferenceRoles, dialogueLanguage, h3CharacterDescription } from "./h3";

/** 取提示词风格档；缺省为 MiniMax H3。 */
export function getPromptStyle(id: PromptStyleId = "h3", options: { h3?: H3StyleOptions } = {}): PromptStyle {
  if (id === "grokH3") return createGrokH3PromptStyle(options.h3);
  return id === "generic" ? genericPromptStyle : createH3PromptStyle(options.h3);
}
