/**
 * 由分镜字段程序化拼装三层提示词（首帧图 / 视频 / 尾帧图），不让模型自由发挥整段提示词。
 * 三层拆分思路参考 moyin-creator 的 first/video/end 三层提示词（AGPL，仅借鉴思路，代码独立编写）。
 */
import { continuityLines } from "./continuity";
import { propLines, propNegatives, shotPropCards } from "./propCards";
import { cameraMoves, shotSizes, stabilities } from "./vocab";
import type { Segment, Shot, Storyboard } from "./schema";
import { characterBrief, isCreature, type CharacterCard } from "@/utils/assets/characterCard";
import { shotTraits } from "../traits";

export interface ShotPromptContext {
  board: Pick<Storyboard, "style" | "aspectRatio" | "scenes" | "characters" | "bible"> & Partial<Pick<Storyboard, "props">>;
  segment: Pick<Segment, "sceneId" | "blocking" | "timeOfDay" | "mood">;
  shot: Shot;
  cards: Map<string, CharacterCard>;
  /** 角色 id → 参考图序号（图N）；缺省则不写图号 */
  characterImageIndex?: Map<string, number>;
}

export interface ShotPrompts {
  firstFrame: string;
  video: string;
  endFrame?: string;
  negative: string;
}

const join = (parts: (string | undefined | false)[], separator = "，") => parts.filter((part): part is string => !!part && !!part.trim()).join(separator);

function nameOf(context: ShotPromptContext, id: string, withImage: boolean) {
  const card = context.cards.get(id);
  const name = card?.name ?? context.board.characters.find(item => item.id === id)?.name ?? id;
  const index = context.characterImageIndex?.get(id);
  return withImage && index ? `${name}（图${index}）` : name;
}

function people(context: ShotPromptContext) {
  return context.shot.characters.map(character => {
    const card = context.cards.get(character.id);
    const index = context.characterImageIndex?.get(character.id);
    const who = card ? characterBrief(card, character.outfit) : nameOf(context, character.id, false);
    return join([index ? `图${index}的${who}` : who, character.pose, card?.temporaryState?.length ? `当前临时状态：${card.temporaryState.join("；")}` : undefined]);
  }).join("；");
}

export function buildShotPrompts(context: ShotPromptContext): ShotPrompts {
  const { board, segment, shot } = context;
  const scene = board.scenes.find(item => item.id === segment.sceneId);
  const size = shotSizes[shot.size].zh;
  const framing = join([size, shot.lens, shot.cameraPosition, shot.composition]);
  const canon = board.bible?.canon?.length ? `项目 Bible 不可违背事实：${board.bible.canon.join("；")}` : undefined;
  const setting = scene ? join([`场景：${scene.name}——${scene.description}`, scene.layout ? `固定空间布局：${scene.layout}` : undefined, scene.lightingBaseline ? `固定灯光基线：${scene.lightingBaseline}` : undefined, canon, segment.timeOfDay, segment.mood]) : join([canon, segment.timeOfDay, segment.mood]);
  // 非人类角色（如昆虫）不写手指/发型/服装，改写肢体数量与体色标记
  const creatures = [...context.cards.values()].some(card => isCreature(card));
  const cast = shot.characters.length ? `${creatures ? "角色" : "人物"}：${people(context)}` : creatures ? "空镜，画面中没有主要角色" : "空镜，画面中没有人物";
  const negativeParts = creatures ? ["文字", "字幕", "水印", "人类", "人手", "卡通", "多腿或缺腿", "角色串脸"] : ["文字", "字幕", "水印", "多余人物", "畸形手指", "面部变形", "角色串脸"];
  for (const character of shot.characters) {
    const negative = context.cards.get(character.id)?.negative;
    if (negative) negativeParts.push(negative);
  }
  // 逐角色特征行 + 不可串用约束（由角色卡推导），防止多张锚点同时参考时特征串到别人身上
  const traits = creatures ? undefined : shotTraits(shot.characters, context.cards);
  const traitText = traits?.lines.length ? `逐角色特征（各自独立，不可串用）：${traits.lines.join(" ｜ ")}` : undefined;
  const constraintText = traits?.constraints.length ? `特征约束：${traits.constraints.join("；")}` : undefined;
  if (traits) negativeParts.push(...traits.negatives);
  // 镜头视角由本镜导演合同决定；不再把 POV 作为全局负面词。
  const viewpoint = shot.cameraContract?.viewpoint ?? "third_person";
  const cameraDirective = ({
    third_person: "第三人称客观机位，摄影机在角色之外观察，不出现观众身体或无主前景手",
    first_person: `第一人称主观视角，视点主体为${shot.cameraContract?.subjectCharacterId ?? "指定角色"}，摄影机代表该角色的眼睛；允许符合动作的前景手部`,
    over_shoulder: "过肩镜头，从指定角色肩后观察对方，保持肩部前景与视线方向连续",
    insert: "局部插入特写，只表现指定动作或物件，不擅自切换为人物主观视角",
    subjective_camera: `主观镜头，视点主体为${shot.cameraContract?.subjectCharacterId ?? "指定角色"}，镜头运动与视点主体一致`,
    top_down: "俯视/顶视客观机位，保持空间关系可辨",
  } as const)[viewpoint];
  if (!creatures) {
    if (viewpoint === "third_person") negativeParts.push("第一人称视角", "从画面边缘伸入的无主之手或枪");
    negativeParts.push("多余的手臂", "六指");
  }
  // 固定道具/车辆卡：命中本镜的卡注入描述，并负面约束易混淆的其它车型
  const propCards = shotPropCards(board.props, segment, shot);
  const propText = propCards.length ? propLines(propCards).join("。") : undefined;
  negativeParts.push(...propNegatives(propCards));
  const extras = shot.extrasPolicy?.mode === "forbidden" ? "除明确列出的角色外，不出现任何其他人物"
    : shot.extrasPolicy?.mode === "listed_only" ? `只允许以下额外人物：${shot.extrasPolicy.allowedDescription ?? "未指定"}`
    : shot.extrasPolicy?.mode === "background_allowed" ? `允许背景人物，但不得抢占主体或改变人数设定${shot.extrasPolicy.allowedDescription ? `；限制：${shot.extrasPolicy.allowedDescription}` : ""}`
    : undefined;
  const axis = shot.cameraContract?.axisId
    ? `轴线合同：${shot.cameraContract.axisId}，机位位于${shot.cameraContract.axisSide ?? "未指定"}侧；保持人物屏幕方向与视线轴线连续`
    : undefined;
  const spatial = shot.spatialContract?.positions?.map(item => `${nameOf(context, item.characterId, false)}位于画面${({ far_left: "最左", left: "左侧", center: "中央", right: "右侧", far_right: "最右", foreground: "前景", background: "背景" } as const)[item.screenPosition]}，朝向${({ left: "画面左侧", right: "画面右侧", camera: "镜头", away: "背离镜头", profile: "侧面" } as const)[item.facing]}${item.eyelineTarget ? `，视线落在${item.eyelineTarget}` : ""}`).join("；");
  const beat = shot.spatialContract?.beat ? `镜头叙事功能：${({ establishing: "建立空间", action: "动作", reaction: "反应", reveal: "揭示", insert: "插入细节", transition: "转场" } as const)[shot.spatialContract.beat]}` : undefined;
  const staging = creatures ? undefined : `${cameraDirective}；人物空间位置清楚、符合站位描述，每只可见的手正好五根手指`;

  const firstFrame = join([
    `${board.style}，${board.aspectRatio} 画幅，${framing}`,
    setting,
    propText,
    `站位：${segment.blocking}`,
    spatial,
    shot.spatialContract?.startState ? `镜头开始状态：${shot.spatialContract.startState}` : undefined,
    beat,
    cameraDirective,
    axis,
    extras,
    cast,
    traitText,
    constraintText,
    `画面：${shot.firstFrame}`,
    "这一格只画起点，不画终点才出现的动作、表情和道具状态",
    staging,
    shot.eyeline && `视线：${shot.eyeline}`,
    shot.focus && `焦点：${shot.focus}`,
    shot.props?.length ? `道具：${shot.props.join("、")}` : undefined,
    ...continuityLines(shot, id => nameOf(context, id, false)),
  ], "。") + "。";

  const lines = (shot.dialogue ?? []).map(line => {
    const speaker = line.speaker === "narrator" ? "旁白" : nameOf(context, line.speaker, true);
    return `${speaker}${line.emotion ? `（${line.emotion}）` : ""}说：“${line.text}”`;
  });
  const video = join([
    join([size, cameraMoves[shot.camera], shot.stability ? stabilities[shot.stability] : undefined, cameraDirective, axis, extras]),
    shot.characters.length ? `出场：${shot.characters.map(item => nameOf(context, item.id, true)).join("、")}` : "空镜",
    `动作：${shot.action}`,
    "只做这一个动作。手碰到道具时，写明哪只手靠近、碰到、施力，以及道具落在哪里；同一只手不做两件相反的事",
    shot.spatialContract?.beat === "reaction" ? "反应：一个触发、一个情绪、两处在这个景别里看得见的变化，1.5 秒内定住" : undefined,
    lines.length ? `台词（必须逐字输出，不得翻译/改写）：${lines.join("；")}` : undefined,
    shot.characters.filter(item => !(shot.dialogue ?? []).some(line => line.speaker === item.id && !/画外|旁白/.test(line.emotion ?? ""))).map(item => `${nameOf(context, item.id, false)}不出声，嘴唇闭上`).join("；") || undefined,
    shot.dialogueLanguage ? `对白语言锁定：${shot.dialogueLanguage}，禁止混入其他语言` : undefined,
    ...shot.characters.map(item => { const voice = context.cards.get(item.id)?.voice; return voice ? `${nameOf(context, item.id, false)}声音设定：${[voice.timbre, voice.language, voice.voiceId ? `voice_id=${voice.voiceId}` : undefined, voice.speakingRate ? `语速${voice.speakingRate}` : undefined].filter(Boolean).join("，")}` : undefined; }),
    // 台词锁 + 无字幕锁 + 不要音乐（音乐后期再加）
    lines.length ? "台词锁：整段能听到的人声只有引号里的原话，不加任何词、语气词或笑声；没有台词的人完全不出声；说话的人边说边做事，不静止念台词超过 3 秒"
      : "本镜没有人说话，没有任何人声",
    "只有环境音效，不要音乐",
    shot.sfx && `音效：${shot.sfx}`,
    shot.endFrame && `结束时画面：${shot.endFrame}`,
    shot.spatialContract?.endState ? `镜头结束状态：${shot.spatialContract.endState}` : undefined,
    propText,
    ...continuityLines(shot, id => nameOf(context, id, false)),
    constraintText,
    creatures ? "保持每个角色的物种、体型、体色与标记与首帧及参考图完全一致，解剖结构正确、腿的数量符合物种，镜头内不切镜，不新增角色，不出现人类、字幕和文字"
      : "保持人物外观、发型、服装与首帧和尾帧完全一致，镜头内不切镜，不新增人物或手，不把已有道具换成空白，朝向和出画只跟首尾帧，道具图只锁定形状颜色和材质，不出现字幕和文字",
  ], "。") + "。";

  const closing = shot.endFrame || shot.action;
  const endFrame = closing ? join([
    `${board.style}，${board.aspectRatio} 画幅，${framing}`,
    setting,
    propText,
    cameraDirective,
    axis,
    extras,
    cast,
    traitText,
    constraintText,
    `画面：${closing}`,
    staging,
    "这一格只画终点，删掉起点才有、终点已经消失的姿态和道具",
    "不新增画面描述里没有的手、人或道具；要看清的道具占满握住它的那只手",
  ], "。") + "。" : undefined;

  return { firstFrame, video, endFrame, negative: [...new Set(negativeParts)].join("，") };
}
