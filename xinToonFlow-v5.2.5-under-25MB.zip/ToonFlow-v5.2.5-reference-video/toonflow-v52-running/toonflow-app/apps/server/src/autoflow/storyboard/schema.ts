/**
 * 一键成片的分镜 JSON：集（episode）→ 段（segment，同一场景的连续镜头，带开场站位）→ 镜（shot，一次视频生成）。
 * 每镜显式列出出场角色，供程序强制挂载角色锚点参考图；提示词由程序按“首帧 / 视频 / 尾帧”三层从字段拼装。
 */
import { z } from "zod";
import { cameraMoves, shotSizes, stabilities, type CameraMove, type ShotSize } from "./vocab";

const text = (max: number) => z.string().trim().min(1).max(max);
const id = z.string().trim().regex(/^[A-Za-z0-9_\-\u4e00-\u9fff]{1,64}$/, "ID 只能包含字母、数字、下划线、连字符或中文");

export const shotCharacterSchema = z.strictObject({
  /** 对应角色卡 id */
  id,
  /** 造型 id；缺省用角色卡第一套造型 */
  outfit: id.optional(),
  /** 该角色在本镜中的位置与动作（首帧静态） */
  pose: z.string().trim().max(300).optional(),
});

export const dialogueLineSchema = z.strictObject({
  /** 角色 id；旁白写 "narrator" */
  speaker: id,
  text: z.string().min(1).max(450),
  emotion: z.string().trim().max(60).optional(),
});

/** 连续性状态（分镜阶段由文本模型逐镜跟踪）：谁活着/已死、每人左右手各拿什么、画面里还有哪些非角色人物或尸体 */
export const shotContinuitySchema = z.strictObject({
  /** 本镜开始时已死亡（或失去行动能力）的角色 id：只能作为不动的尸体出现 */
  dead: z.array(id).max(20).optional(),
  /** 每个出场角色左右手所持之物；空手写 "空"，不在画面中不写 */
  hands: z.array(z.strictObject({ id, left: z.string().trim().max(40).optional(), right: z.string().trim().max(40).optional() })).max(6).optional(),
  /** 画面中允许出现的非角色人物或尸体，如“地上一具老大的尸体”；没有写 "无" */
  extras: z.string().trim().max(200).optional(),
  /** 本镜可见的伤情（一旦出现，本集内持续，不会凭空消失） */
  injuries: z.array(z.strictObject({ id, note: z.string().trim().max(60) })).max(12).optional(),
  /** 道具/车辆当前状态（如 面包车：左后门被撞凹）；状态只能在动作写明原因时变化 */
  props: z.array(z.strictObject({ name: z.string().trim().max(40), state: z.string().trim().max(80) })).max(12).optional(),
});

/** 镜头级导演合同：视角、轴线和空间关系由分镜明确表达，避免全局提示词把 POV 一概判错。 */
export const shotCameraContractSchema = z.strictObject({
  viewpoint: z.enum(["third_person", "first_person", "over_shoulder", "insert", "subjective_camera", "top_down"]).default("third_person"),
  angle: z.enum(["eye_level", "high_angle", "low_angle", "dutch", "overhead", "ground_level"]).optional(),
  axisId: id.optional(),
  axisSide: z.enum(["A", "B", "on_axis", "not_applicable"]).optional(),
  movement: z.enum(["static", "pan", "tilt", "dolly", "tracking", "handheld", "zoom", "crane"]).optional(),
  /** 主观镜头的主体/视点角色；非主观镜头可省略 */
  subjectCharacterId: id.optional(),
}).superRefine((value, ctx) => {
  if (["first_person", "subjective_camera"].includes(value.viewpoint) && !value.subjectCharacterId) {
    ctx.addIssue({ code: "custom", message: "第一人称/主观视角必须指定 subjectCharacterId", path: ["subjectCharacterId"] });
  }
});

/** 画面中非主要角色的策略，明确区分空镜、允许群众和禁止额外人物。 */
export const extrasPolicySchema = z.strictObject({
  mode: z.enum(["forbidden", "listed_only", "background_allowed"]).default("forbidden"),
  allowedDescription: z.string().trim().max(200).optional(),
});

export const shotSchema = z.strictObject({
  /** 形如 E01-01-01（集-段-镜） */
  id: z.string().regex(/^E\d{2}-\d{2}-\d{2}$/, "镜头 ID 必须形如 E01-01-01"),
  /** 时长（秒）；缺省由程序按台词字数估算 */
  seconds: z.number().positive().max(60).optional(),
  size: z.enum(Object.keys(shotSizes) as [ShotSize, ...ShotSize[]]),
  camera: z.enum(Object.keys(cameraMoves) as [CameraMove, ...CameraMove[]]),
  /** v5 导演合同；旧 v4 分镜可缺省，normalize 时按第三人称兼容 */
  cameraContract: shotCameraContractSchema.optional(),
  extrasPolicy: extrasPolicySchema.optional(),
  /** 与上一镜的衔接：continuous = 动作连续，直接用上一镜尾帧作首帧；cut = 切镜，新出关键帧 */
  transition: z.enum(["continuous", "cut"]).default("cut"),
  characters: z.array(shotCharacterSchema).max(6),
  props: z.array(text(80)).max(12).optional(),
  dialogue: z.array(dialogueLineSchema).max(200).optional(),
  /** 首帧（静态画面）：人物位置、姿态、表情、环境与光线 */
  firstFrame: text(1500),
  /** 视频：本镜内发生的动作与表演 */
  action: text(1500),
  /** 尾帧（可选）：镜头结束时的静态画面 */
  endFrame: z.string().trim().max(1500).optional(),
  sfx: z.string().max(5000).optional(),
  lens: z.string().trim().max(60).optional(),
  cameraPosition: z.string().trim().max(120).optional(),
  composition: z.string().trim().max(200).optional(),
  eyeline: z.string().trim().max(200).optional(),
  focus: z.string().trim().max(120).optional(),
  stability: z.enum(Object.keys(stabilities) as [keyof typeof stabilities, ...(keyof typeof stabilities)[]]).optional(),
  continuity: shotContinuitySchema.optional(),
  /** v5 空间合同：人物画面位置、朝向、视线、镜头起止状态 */
  spatialContract: z.object({ positions: z.array(z.object({ characterId: id, screenPosition: z.enum(["far_left", "left", "center", "right", "far_right", "foreground", "background"]), facing: z.enum(["left", "right", "camera", "away", "profile"]), eyelineTarget: z.string().max(120).optional() })).max(6).default([]), startState: z.string().max(500).optional(), endState: z.string().max(500).optional(), beat: z.enum(["establishing", "action", "reaction", "reveal", "insert", "transition"]).optional() }).optional(),
  /** 本镜对白的目标语言；禁止模型擅自翻译或混用语言 */
  dialogueLanguage: z.string().trim().max(40).optional(),
  /** 原文账本引用：模型只分配 ID，实际原文由程序回填 */
  sourceRefs: z.array(id).max(200).optional(),
  dialogueRefs: z.array(z.strictObject({ sourceId: id, speaker: id, emotion: z.string().trim().max(60).optional() })).max(30).optional(),
  /** 按原文顺序排列的全部引号片段分类；程序据此回填对白/音效 */
  quoteAssignments: z.array(z.strictObject({ sourceId: id, kind: z.enum(["dialogue", "sfx", "quoted_text"]), speaker: id.optional(), emotion: z.string().trim().max(60).optional() })).max(200).optional(),
  sfxRefs: z.array(id).max(60).optional(),
  quoteRefs: z.array(id).max(60).optional(),
  /** 本镜对应的原文片段（由程序按 sourceRefs 回填，不接受模型改写） */
  source: z.string().max(200000).optional(),
});

export const segmentSchema = z.strictObject({
  /** 形如 E01-01 */
  id: z.string().regex(/^E\d{2}-\d{2}$/, "段 ID 必须形如 E01-01"),
  sceneId: id,
  /** 开场站位：人物相对位置、朝向与空间关系，是本段所有镜头的空间地基 */
  blocking: text(800),
  timeOfDay: z.string().trim().max(40).optional(),
  mood: z.string().trim().max(120).optional(),
  shots: z.array(shotSchema).min(1).max(40),
});

export const episodeSchema = z.strictObject({
  ep: z.number().int().min(1).max(999),
  title: z.string().trim().max(120).optional(),
  targetSeconds: z.number().positive().max(3600).optional(),
  segments: z.array(segmentSchema).min(1).max(100),
});

export const sceneSchema = z.strictObject({
  id,
  name: text(80),
  description: text(1000),
  /** 场景参考图（工作区相对路径），生成后填入 */
  image: z.string().trim().max(2048).optional(),
  /** v5 场景连续性基线 */
  layout: z.string().trim().max(800).optional(),
  lightingBaseline: z.string().trim().max(500).optional(),
  cameraViews: z.array(z.string().trim().max(200)).max(20).optional(),
});

/** 固定道具卡（车辆等）：同一道具在所有镜头中外观一致；镜头文本命中 match 关键词或处于 scenes 场景时注入提示词，并对 negative 中的其它车型做负面约束 */
export const propCardSchema = z.strictObject({
  id,
  /** 中文名，如 面包车 */
  name: text(40),
  kind: z.enum(["vehicle", "prop"]).default("vehicle"),
  /** 类型、颜色、品牌/车型、显著标记（中文或英文均可） */
  description: text(800),
  /** 命中这些词（镜头首帧/动作/尾帧/道具）即视为本镜出现该道具；缺省用 name */
  match: z.array(text(20)).max(20).optional(),
  /** 整个场景都在该道具内或旁（如车内场景） */
  scenes: z.array(id).max(20).optional(),
  /** 负面提示：与之混淆的其它类型 */
  negative: z.string().trim().max(400).optional(),
  /** 产品照式参考图（中性灰台面、单一侧光、主体独立），由流水线生成后回填 */
  image: z.string().trim().max(400).optional(),
  /** v5：资产状态机，状态变化必须命中合法转换 */
  stateMachine: z.object({ initialState: id, states: z.array(z.object({ id, description: text(300) })).min(1), transitions: z.array(z.object({ from: id, to: id, trigger: text(300) })).default([]) }).optional(),
});

export const storyboardCharacterSchema = z.strictObject({
  id,
  name: text(64),
  /** 角色卡路径（工作区相对路径），如 角色/林夏/card.json */
  card: z.string().trim().max(2048).optional(),
});

export const storyboardSchema = z.strictObject({
  version: z.literal(1),
  /** 绑定本次不可修改的原文账本，防止跨 run 复用旧分镜。 */
  sourceLedgerHash: z.string().length(64).optional(),
  title: text(120),
  logline: z.string().trim().max(500).optional(),
  aspectRatio: z.enum(["16:9", "9:16", "1:1", "4:3", "3:4", "21:9"]).default("16:9"),
  /** 全片统一画风描述 */
  style: text(500),
  characters: z.array(storyboardCharacterSchema).max(50),
  scenes: z.array(sceneSchema).min(1).max(200),
  /** 固定道具/车辆卡（可选） */
  props: z.array(propCardSchema).max(30).optional(),
  /** v5 Project Bible：项目级唯一设定源，旧 v4 项目可缺省 */
  bible: z.object({ projectId: id, canon: z.array(text(500)).default([]), threads: z.array(z.object({ id, description: text(500), status: z.enum(["open", "resolved", "abandoned"]).default("open"), introducedEpisode: z.number().int().positive(), resolvedEpisode: z.number().int().optional() })).default([]), style: z.object({ description: text(1000), palette: z.array(text(80)).default([]), forbidden: z.array(text(120)).default([]) }).optional() }).optional(),
  episodes: z.array(episodeSchema).min(1).max(100),
});

export type Storyboard = z.infer<typeof storyboardSchema>;
export type StoryboardInput = z.input<typeof storyboardSchema>;
export type Episode = Storyboard["episodes"][number];
export type Segment = Episode["segments"][number];
export type Shot = Segment["shots"][number];

/** 结构校验：返回解析后的分镜或可读的错误列表（可直接回喂给模型修复）。 */
export function parseStoryboard(value: unknown): { ok: true; data: Storyboard } | { ok: false; errors: string[] } {
  const result = storyboardSchema.safeParse(value);
  if (result.success) return { ok: true, data: result.data };
  return { ok: false, errors: result.error.issues.slice(0, 50).map(issue => `${issue.path.join(".") || "(根)"}：${issue.message}`) };
}

export function* iterateShots(board: Storyboard) {
  for (const episode of board.episodes) {
    for (const segment of episode.segments) {
      for (const [index, shot] of segment.shots.entries()) yield { episode, segment, shot, index };
    }
  }
}
