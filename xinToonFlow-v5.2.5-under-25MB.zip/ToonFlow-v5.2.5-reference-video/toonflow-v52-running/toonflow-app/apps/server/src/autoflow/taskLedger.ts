import { createHash } from "node:crypto";
import { mkdir, readFile, rename, unlink, writeFile } from "node:fs/promises";
import { join } from "node:path";
import type { MediaGenerationCheckpoint } from "@/utils/media/generation";

/**
 * 一键成片的“已提交任务台账”：每个生成请求（按供应商、模型、提示词、种子、时长、参考图等算指纹）
 * 在 <工作区>/.autoflow-tasks/<指纹>.json 里记下供应商任务 id。同一请求再次调用（重试、进程重启续跑）时，
 * 只要已有任务 id 就恢复轮询原任务、绝不重新提交，避免收费任务被提交两次。
 * 仅在确定任务没有建成（提交阶段被拒）或任务本身失败（不计费）时清掉记录，允许重新提交。
 */
export type LedgerGenerate<R> = (task: { taskId: string; resume: boolean; checkpoint: MediaGenerationCheckpoint; save: (patch: Partial<MediaGenerationCheckpoint>) => Promise<void> }) => Promise<R>;

export function requestFingerprint(mediaType: string, request: unknown) {
  return createHash("sha256").update(mediaType).update("\0").update(JSON.stringify(request)).digest("hex").slice(0, 32);
}

function videoIdOf(checkpoint: MediaGenerationCheckpoint) {
  const data = checkpoint.providerData as { videoId?: unknown; taskId?: unknown; id?: unknown } | undefined;
  const id = data?.videoId ?? data?.taskId ?? data?.id;
  return typeof id === "string" && id ? id : undefined;
}

export async function withTaskLedger<R>(cwd: string, mediaType: string, request: unknown, run: LedgerGenerate<R>): Promise<R> {
  const directory = join(cwd, ".autoflow-tasks");
  await mkdir(directory, { recursive: true });
  const key = requestFingerprint(mediaType, request);
  const file = join(directory, `${key}.json`);
  const stored = await readFile(file, "utf8").then(text => JSON.parse(text) as { taskId: string; checkpoint: MediaGenerationCheckpoint }, () => undefined);
  const taskId = stored?.taskId ?? crypto.randomUUID();
  let checkpoint: MediaGenerationCheckpoint = stored?.checkpoint ?? {};
  const persist = async () => {
    await writeFile(`${file}.tmp`, JSON.stringify({ taskId, mediaType, checkpoint }, null, 2));
    await rename(`${file}.tmp`, file);
  };
  const save = async (patch: Partial<MediaGenerationCheckpoint>) => { checkpoint = { ...checkpoint, ...patch }; await persist(); };
  // 已有任务 id（或已落盘结果）：恢复，不重新提交
  const resume = !!(videoIdOf(checkpoint) || checkpoint.assets?.length || checkpoint.files?.length);
  if (stored?.checkpoint.providerData && !resume) {
    // 上次提交时没拿到任务 id（提交中断且没找回）：无法确认是否已建任务，宁可报错也不重复提交
    throw Object.assign(new Error(`上次提交没有拿到任务 id，为避免重复扣费不自动重提；确认供应商控制台后删除 ${file} 再重试`), { code: "TASK_SUBMIT_UNCERTAIN" });
  }
  try {
    return await run({ taskId, resume, checkpoint, save });
  } catch (error) {
    const status = (error as { status?: number }).status;
    const code = (error as { code?: string }).code;
    // 任务失败（不计费），或任务 id 还没拿到时提交被明确拒绝（4xx/5xx/429）：允许下次重新提交
    if (code === "MEDIA_TASK_FAILED" || (!videoIdOf(checkpoint) && status !== undefined)) await unlink(file).catch(() => {});
    throw error;
  }
}
