/**
 * 每个镜头单独成一条视频。H3 不执行素材内部的计划切点，只会在结尾硬跳。
 * 模型最短约 5 秒，短镜头向上取整；切镜发生在两条成片之间。
 */
export interface RenderClip<T> {
  id: string;
  shots: T[];
  /** 对齐到模型档位后的请求时长 */
  seconds: number;
  /** 素材内部计划切点数，等于镜头数减 1 */
  plannedCuts: number;
}

export interface ClipPackOptions {
  minClipSeconds?: number;
  maxClipSeconds?: number;
  minShots?: number;
  maxShots?: number;
  allowedDurations?: number[];
}

export function packRenderClips<T extends { id: string; seconds?: number }>(shots: readonly T[], options: ClipPackOptions = {}): RenderClip<T>[] {
  const minClip = options.minClipSeconds ?? 5;
  const maxClip = options.maxClipSeconds ?? 15;
  const minShots = options.minShots ?? 1;
  const maxShots = options.maxShots ?? 1;
  const allowed = (options.allowedDurations ?? []).filter(value => value >= minClip - 0.05 && value <= maxClip + 0.05).sort((a, b) => a - b);
  const packs: RenderClip<T>[] = [];
  let index = 0;
  while (index < shots.length) {
    const group: T[] = [];
    let sum = 0;
    while (index < shots.length && group.length < maxShots) {
      const next = shots[index]!.seconds ?? 2;
      const wouldPassCap = sum + next > maxClip + 0.05;
      if (wouldPassCap && group.length >= minShots) break;
      if (wouldPassCap && group.length > 0) break;
      group.push(shots[index]!);
      sum += next;
      index++;
    }
    const snapped = allowed.find(value => value + 0.05 >= sum) ?? Math.min(maxClip, Math.max(minClip, Math.ceil(sum)));
    packs.push({ id: group[0]!.id, shots: group, seconds: snapped, plannedCuts: Math.max(0, group.length - 1) });
  }
  return packs;
}

export function packContaining<T extends { id: string; seconds?: number }>(shots: readonly T[], shotId: string, options: ClipPackOptions = {}) {
  return packRenderClips(shots, options).find(pack => pack.shots.some(shot => shot.id === shotId));
}
