/**
 * 一键成片编排：故事 → 剧本 → 角色卡（先锚点后派生）→ 场景图 → 分镜 JSON（校验 + 质量门）
 * → 逐镜关键帧（强制角色参考 + 种子 + 一致性评分重试）→ 视频（首帧/尾帧接力 + FFmpeg 审片重试）→ 拼接导出。
 *
 * 所有外部能力通过 AutoflowDeps 注入：服务端使用用户配置的模型，测试与演示使用 mock，不调用付费接口。
 * 运行状态与产物写在工作区 <outputDirectory>/run.json，重复执行同一 runId 时跳过已完成的步骤。
 */
import { copyFile, mkdir, readFile, rename, stat, writeFile } from "node:fs/promises";
import { createHash } from "node:crypto";
import { buildInputFingerprints, compareFingerprints, deriveCrossEpisodeMemory, fileFingerprint, projectBibleSchema, stableHash } from "./v5Continuity";
import { normalizeExternalQa, routeQaFailure, type UnifiedQaResult } from "./qaContract";
import { dirname, join, posix } from "node:path";
import type { GeneratedMedia, MediaGenerationRequest } from "@toonflow/tools-scaffold/runtime";
import { characterCardSchema, characterOutfitText, characterReferenceImages, type CharacterCard } from "@/utils/assets/characterCard";
import type { ReferenceLabel } from "@/utils/media/referenceLabels";
import type { TextModel } from "./llm";
import { annotateContinuity, normalizeStoryboardEnums, planCast, planStoryboard, writeScript, type CastPlan, type PlanBrief } from "./planner";
import { applyDeathEventsFromSource, propagateDeadStates } from "./storyboard/continuity";
import { buildSourceLedger, validateSourceLedger } from "./sourceLedger";
import { hasContinuity } from "./storyboard/continuity";
import { propProductPrompt, shotPropImages } from "./storyboard/propCards";
import { continuationGate, extractTailFrames, handsBlockChain, tailFrameLabels, type ContinuationOptions } from "./continuation";
import { ClipBin, shotOutputFields } from "./clipBin";
import { stitchVideos, type StitchOptions } from "./stitch";
import { masterFilm, speechSafeEdges, type MasterOptions } from "./mastering";
import { runProcess } from "./media";
import { resolveShotReferences, imageMimeType, prependReference, type ReferenceManifestEntry } from "./references";
import { getPromptStyle, type PromptStyle, type PromptStyleId } from "./promptStyles";
import type { H3StyleOptions } from "./promptStyles/h3";
import { iterateShots, parseStoryboard, type Storyboard } from "./storyboard/schema";
import { runGates, sourceCoverage, type GateResult } from "./storyboard/gates";
import { concatVideos, contactSheet, detectVideoSignals, extractFrame, extractLastFrame, probeMedia, systemFfmpeg, type FfmpegPaths } from "./media";
import { reviewVideoSignals, type ReviewResult } from "./review";
import { handsPass, nextSeed, passThroughScorer, type ConsistencyScorer, type ScoreResult } from "./scoring";
import { shotTraits } from "./traits";
import { defaultParams, type StoryboardParams } from "./storyboard/vocab";
import { packContaining, packRenderClips, type ClipPackOptions } from "./storyboard/clips";
import { BudgetGuard, estimateVideoCost, outcomeOfError, round, videoPricePerSecond, type BudgetOptions, type SpendState } from "./budget";

export interface MediaModelOptions {
  providerId: string;
  modelId: string;
  /** 单次生成可接收的参考图上限（缺省 图片 8 / 视频 4） */
  maxReferenceImages?: number;
}
export interface VideoModelOptions extends MediaModelOptions {
  /** 模型支持的时长档位，如 [5, 10]；缺省按秒取整 */
  durations?: number[];
  resolution?: string;
  generateAudio?: boolean;
  /**
   * firstFrame：首帧（可选尾帧）驱动；reference：本镜关键帧 + 角色参考图驱动（需模型支持 imageReference 模式）；
   * directReference：不单独出关键帧，直接把角色锚点/设定表/场景图作为参考图驱动视频（省掉每镜一次静帧费用），
   * 连续镜头仍以上一镜尾帧作首帧接力。
   */
  input?: "firstFrame" | "reference" | "directReference";
  /** 有 endFrame 描述时额外生成尾帧图并走首尾帧模式 */
  useEndFrame?: boolean;
  /** 首尾帧能否和参考图放进同一个请求。缺省：ai& 为 false（网关不允许混用），其他供应商为 true */
  framesWithReferences?: boolean;
}

export interface AutoflowOptions {
  story: string;
  /** 默认 true：将输入章节作为只读原文，不经过编剧模型改写。 */
  preserveSourceText?: boolean;
  /** 实际模型配置快照，写入 effective_models.json 供失败报告读取。 */
  runtimeModels?: { text?: { providerId: string; modelId: string }; image?: { providerId: string; modelId: string }; video?: { providerId: string; modelId: string }; scorer?: { providerId: string; modelId: string } };
  episodes?: number;
  targetSeconds?: number;
  aspectRatio?: "16:9" | "9:16" | "1:1" | "4:3" | "3:4" | "21:9";
  style?: string;
  imageModel: MediaModelOptions & {
    size?: string;
    /**
     * 用视频模型出静帧（MiniMax H3 只有视频接口）：生成最短视频并取第 0 帧。
     * duration 为请求时长（H3 最短 4 秒，H3-Max 5 秒），resolution 如 768P / 2K。
     */
    stillFromVideo?: { duration: number; resolution?: string };
  };
  videoModel?: VideoModelOptions;
  /** 角色卡与锚点图存放的工作区目录，缺省 角色；同名角色卡已存在时复用，保证跨集一致 */
  characterDirectory?: string;
  outputDirectory?: string;
  /** 一致性评分阈值（0–1），缺省 0.7 */
  scoreThreshold?: number;
  /** 每个生成步骤的最大尝试次数（含换种子重试），缺省 3 */
  maxAttempts?: number;
  /** 关键帧（首帧）评分重试次数上限，缺省 max(5, maxAttempts) */
  keyframeMaxAttempts?: number;
  /**
   * 严格关键帧（缺省 true）：重试用完仍低于 scoreThreshold 时不接受该帧，镜头标记为 failed + needsRedo，
   * 不生成视频、不导出成片（用同一 runId 续跑会换新种子重做）。false 时保留旧行为：取最高分一张并记警告。
   */
  strictKeyframes?: boolean;
  /**
   * 连续镜头是否直接用上一镜尾帧作为首帧（缺省 false）：缺省每镜都用角色锚点 + 场景重新出首帧，避免上一镜的崩坏（六指、串纹身）传下去。
   * true 时也只在上一镜尾帧通过手/肢体检查且角色一致时才接力。
   */
  chainContinuous?: boolean;
  /**
   * 上一镜画面作为参考图：qa（缺省）/ always / never。
   * qa：continuation.handsGate 为 block 时只挂通过手/肢体检查的帧；缺省 warn 时只要人物没变样、特征没串用就挂。
   */
  previousFrameReference?: "qa" | "always" | "never";
  /** v5.2.5：相邻两段是同一场景时，下一段第一镜也承接上一段最后一镜（段落改为串行生成）。缺省 false。 */
  chainAcrossSegments?: boolean;
  /** v5.2.5：接力镜头的视频输入。firstFrame（缺省）：上一镜尾帧作为真正的首帧提交；follow：沿用 videoModel.input */
  chainedVideoInput?: "firstFrame" | "follow";
  /** v5.2.5：下一镜要接力时，提示词要求本镜最后一秒停在主角清楚可见的画面上，并写明从上一镜带过来的状态。缺省 true。 */
  endOnSubject?: boolean;
  repairAttempts?: number;
  /** 基础种子；缺省按角色名/镜头 id 派生 */
  seed?: number;
  params?: Partial<StoryboardParams>;
  /**
   * 停在某个阶段：storyboard = 只做免费的剧本/角色/分镜规划；characters = 再出角色卡与场景图（先人工检查设定表）；
   * keyframes / videos 同前。用同一 runId 去掉 stopAfter 即可续跑。
   */
  stopAfter?: "storyboard" | "characters" | "keyframes" | "videos";
  /** 并行度：同时生成的角色数 / 场景图数 / 段落数（段内镜头仍按顺序接力），缺省 1。遇到 429 会退避等待。 */
  concurrency?: number;
  /** 有问题的场景 id：不用其场景图作参考，并在场景描述后追加昆虫尺度约束 */
  problemScenes?: string[];
  /** 直接使用已有分镜（跳过剧本/分镜规划），需同时存在角色卡 */
  storyboard?: unknown;
  /** 提示词风格档：h3（默认，MiniMax H3 官方格式）或 generic（原通用中文提示词） */
  promptStyle?: PromptStyleId;
  /** H3 风格选项：设定表视角预设 full13（默认）/ turnaround5 / none */
  h3?: H3StyleOptions;
  /** 花费：缺省不限制金额、只记录；maxUsd 为正数时付费视频（含“视频取首帧”的静帧）每次提交前按报价检查，超出即中止 */
  budget?: BudgetOptions;
  /**
   * 续接（H3 Prefix Continuation 的像素层移植）：同段内上一镜通过检查时，把其结尾 N 帧作为本镜视频的参考图（首帧模式下与首帧一起提交）。
   * 缺省关闭；{ mode: "qa", frames: 3 } 为推荐值。
   */
  continuation?: ContinuationOptions;
  /** 视频续接时同时挂载出场角色锚点（缺省 true；只在 continuation 生效时有意义） */
  continuationAnchors?: boolean;
  /** 只重做这些镜头（如 ["E01-02-03"]）：当前版本先归档进 Clip Bin，旧版本目录不改动 */
  redo?: string[];
  /** 重做时保留已通过的关键帧，只重出视频 */
  redoKeepKeyframe?: string[];
  /** 把镜头切回历史版本，如 ["E01-02-03@v1"] */
  pick?: string[];
  /** Clip Bin 版本归档（缺省开启） */
  clipBin?: boolean;
  /** 拼接接缝处理：亮度匹配、重叠裁切、音频互补交叉淡化；false 用旧的直接拼接 */
  stitch?: false | Partial<Omit<StitchOptions, "width" | "height">>;
  /**
   * 成片母版：每段首尾按静音多剪一点、空档铺轻底噪、两遍响度归一（约 -15 LUFS，真峰值 ≤ -1.5 dBTP），
   * 按 width×height（缺省竖屏 1080×1920）与 fps（缺省 24）导出。缺省关闭。
   */
  master?: false | (MasterOptions & { width?: number; height?: number; fps?: number; edgeTrimSeconds?: number });
  /**
   * 外部逐镜质检命令：完成一镜后执行 command + [视频绝对路径, 镜头信息 JSON 绝对路径]，stdout 输出 {"pass":bool,"score"?:number,"issues"?:string[]}。
   * 结果写入镜头状态与 Clip Bin，并决定该镜能否作为下一镜的续接上下文。
   */
  shotQa?: { command: string[]; timeoutMs?: number };
  /**
   * report：不跑外部硬质检，质检结果不挡成片。block：运行 shotQa，未通过则禁止导出。
   * 缺省 report。v4 严格质检通过率接近 0，第一轮出片先放宽。
   */
  qaGate?: "report" | "block";
  /** clip：1–4 秒镜头合成 5–15 秒素材。shot：一镜一次视频。 */
  rhythm?: "shot" | "clip";
  /** 先出有限条短预览。seconds 最短 5 秒，resolution 如 640P。 */
  preview?: { maxClips?: number; seconds?: number; resolution?: string };
  /** 参考人声，最多 3 段，随视频请求的 audios 提交 */
  voiceReferences?: { path: string; mimeType?: string }[];
  /** 已有分镜缺少连续性标注（死亡/左右手持物/允许出现的尸体）时，用文本模型补注（缺省 false） */
  annotateContinuity?: boolean;
  /** 为固定道具/车辆卡生成产品照并作为参考图挂到命中的镜头，缺省开 */
  propImages?: boolean;
  /** 在视频提示词末尾附加 【镜头ID】E01-01-01 标记（供外部中转/质检识别镜头） */
  shotTagInPrompt?: boolean;
}

export interface AutoflowDeps {
  /** 工作区绝对路径 */
  cwd: string;
  text: TextModel;
  /** 生成媒体，返回工作区相对路径 */
  generate(mediaType: "image" | "video", request: MediaGenerationRequest, signal?: AbortSignal): Promise<GeneratedMedia[]>;
  scorer?: ConsistencyScorer;
  ffmpeg?: FfmpegPaths;
  onUpdate?(state: RunState): void;
  signal?: AbortSignal;
  /** 重试等待（毫秒），测试可设为 0 */
  retryDelayMs?: number;
  /** 429 限流退避的基础等待（毫秒，逐次加长，上限 120 秒），缺省 20000；测试可设为 0 */
  throttleDelayMs?: number;
  /** 429 最多等待几次（不计入 maxAttempts），缺省 60 */
  maxThrottleWaits?: number;
}

function contentHash(value: unknown) {
  return createHash("sha256").update(JSON.stringify(value)).digest("hex");
}

function audioMime(path: string) {
  const ext = path.split(".").pop()?.toLowerCase();
  if (ext === "mp3") return "audio/mpeg";
  if (ext === "wav") return "audio/wav";
  if (ext === "m4a" || ext === "mp4" || ext === "aac") return "audio/mp4";
  if (ext === "ogg") return "audio/ogg";
  if (ext === "flac") return "audio/flac";
  return "audio/wav";
}

export interface ShotState {
  status: "pending" | "keyframe" | "video" | "done" | "failed";
  keyframe?: string;
  endKeyframe?: string;
  video?: string;
  lastFrame?: string;
  contactSheet?: string;
  seed?: number;
  attempts: { stage: "keyframe" | "video"; seed: number; file?: string; score?: number; review?: ReviewResult; error?: string }[];
  score?: ScoreResult;
  review?: ReviewResult;
  /** 连续镜头：首帧取自哪一镜的尾帧 */
  chainedFrom?: string;
  /** 尾帧漂移时为 false，下一镜不接力 */
  chainable?: boolean;
  /** 尾帧 / 首帧是否通过手指与肢体检查（决定能否作为下一镜参考） */
  lastFrameHandsOk?: boolean;
  keyframeHandsOk?: boolean;
  /** 计划尾帧静帧是否通过手指与肢体检查；false 时不提交视频 */
  endKeyframeHandsOk?: boolean;
  /** 严格关键帧：重试用完仍低于阈值，需要重做（不生成视频） */
  needsRedo?: boolean;
  /** 被拒绝的最好一张关键帧（仅供人工查看，不参与后续生成） */
  rejectedKeyframe?: string;
  /** 尾帧是否通过“角色特征不串用”检查 */
  lastFrameTraitsOk?: boolean;
  /** 外部逐镜质检结果 */
  qa?: { pass: boolean; score?: number; issues?: string[] };
  /** v5 统一 QA：pass/fail/abstain 与修复路由 */
  qaResult?: UnifiedQaResult;
  repairPlan?: ReturnType<typeof routeQaFailure>;
  /** v5：记录关键帧、尾帧和视频请求实际采用的参考图清单 */
  referenceManifests?: { keyframe?: ReferenceManifestEntry[]; endFrame?: ReferenceManifestEntry[]; video?: ReferenceManifestEntry[]; fileMetadata?: (ReferenceManifestEntry & { size: number; sha256: string; source: "local_file" })[] };
  /** v5：当前提示词与参考图清单的输入指纹（旧 v4 状态可缺省） */
  inputFingerprints?: Partial<ReturnType<typeof buildInputFingerprints>> & { referenceFiles?: Awaited<ReturnType<typeof fileFingerprint>>[] };
  /** 续接：用了哪一镜的结尾帧 */
  continuation?: { from: string; frames: string[]; parentClipId?: string };
  /** Clip Bin 中的当前版本 */
  clipId?: string;
  /** 拼接时开头需丢弃的重叠帧数 */
  trimHeadFrames?: number;
  /** 重做时被替换（已归档）的版本 */
  redoOf?: string;
  warnings: string[];
  prompts?: { firstFrame: string; video: string; endFrame?: string };
}

/** 段内/跨段接力时的“上一镜” */
type SegmentCarry = { segmentId: string; shotId: string; state: ShotState };

export interface RunState {
  runId: string;
  status: "running" | "done" | "failed" | "stopped";
  stage: string;
  startedAt: string;
  updatedAt: string;
  error?: string;
  outputDirectory: string;
  log: string[];
  artifacts: {
    script?: string;
    cast?: string;
    cards: Record<string, string>;
    scenes: Record<string, string>;
    /** 道具/车辆产品照 */
    props?: Record<string, string>;
    storyboard?: string;
    final?: string;
    finalContactSheet?: string;
    report?: string;
  };
  gates?: GateResult[];
  projectBible?: unknown;
  crossEpisodeMemory?: unknown;
  shots: Record<string, ShotState>;
  /** 花费记录（美元，按报价估算；续跑时累计） */
  spend?: SpendState;
}

const ratioSize: Record<string, [number, number]> = {
  "16:9": [1280, 720], "9:16": [720, 1280], "1:1": [1024, 1024], "4:3": [1024, 768], "3:4": [768, 1024], "21:9": [1344, 576],
};

function hashSeed(text: string) {
  let hash = 2166136261;
  for (const char of text) { hash ^= char.codePointAt(0)!; hash = Math.imul(hash, 16777619) >>> 0; }
  return hash;
}

const safeName = (name: string) => name.replace(/[\\/:*?"<>|\u0000-\u001f]/g, "_").slice(0, 64) || "未命名";

/** 以并行度 limit 处理 items（保持各自内部顺序）；任一失败时等其余进行中的任务结束后抛出第一个错误。 */
export async function runPool<T>(items: readonly T[], limit: number, worker: (item: T, index: number) => Promise<void>) {
  let next = 0;
  let failure: { error: unknown } | undefined;
  const lane = async () => {
    while (!failure && next < items.length) {
      const index = next++;
      try { await worker(items[index]!, index); }
      catch (error) { failure ??= { error }; }
    }
  };
  await Promise.all(Array.from({ length: Math.max(1, Math.min(limit, items.length)) }, lane));
  if (failure) throw failure.error;
}

async function exists(path: string) {
  return stat(path).then(() => true, () => false);
}

class Run {
  state: RunState;
  constructor(readonly options: AutoflowOptions, readonly deps: AutoflowDeps, runId: string, existing?: RunState) {
    const now = new Date().toISOString();
    this.state = existing ? { ...existing, status: "running", error: undefined } : {
      runId, status: "running", stage: "start", startedAt: now, updatedAt: now,
      outputDirectory: options.outputDirectory ?? posix.join("一键成片", runId), log: [], artifacts: { cards: {}, scenes: {} }, shots: {},
    };
  }
  get out() { return this.state.outputDirectory; }
  abs(relative: string) { return join(this.deps.cwd, relative); }
  get ffmpeg() { return this.deps.ffmpeg ?? systemFfmpeg; }
  get scorer() { return this.deps.scorer ?? passThroughScorer; }
  get maxAttempts() { return Math.max(1, this.options.maxAttempts ?? 3); }
  get keyframeAttempts() { return Math.max(1, this.options.keyframeMaxAttempts ?? Math.max(5, this.maxAttempts)); }
  get strictKeyframes() { return this.options.strictKeyframes !== false; }
  get threshold() { return this.options.scoreThreshold ?? 0.7; }
  get maxThrottleWaits() { return this.deps.maxThrottleWaits ?? 60; }
  #budget?: BudgetGuard;
  get budget() { return this.#budget ??= new BudgetGuard(this.options.budget, this.state.spend ??= { usd: 0, entries: [] }); }
  /** 视频请求报价（美元）；未知单价返回 undefined（不计费也不拦截，除非配置了 budget.pricePerSecond）。 */
  quote(request: MediaGenerationRequest) {
    const price = videoPricePerSecond(request.providerId, request.modelId, this.options.budget?.pricePerSecond);
    if (price === undefined) return undefined;
    const seconds = Math.max(4, Math.round(request.duration ?? 4));
    return { seconds, usd: estimateVideoCost(seconds, price) };
  }
  stillCost() {
    const still = this.options.imageModel.stillFromVideo;
    if (!still) return 0;
    return this.quote({ providerId: this.options.imageModel.providerId, modelId: this.options.imageModel.modelId, prompt: "x", duration: still.duration } as MediaGenerationRequest)?.usd ?? 0;
  }
  #style?: PromptStyle;
  get style() { return this.#style ??= getPromptStyle(this.options.promptStyle ?? "h3", { h3: this.options.h3 }); }
  /** H3 风格把参考图定义写在提示词里，不再让宿主追加「图N：用途」。 */
  labels<T>(labels: T) { return this.style.hostReferenceLabels ? labels : undefined; }

  log(message: string) {
    const line = `[${new Date().toLocaleString("sv-SE")}] ${message}`;
    this.state.log.push(line);
    if (this.state.log.length > 2000) this.state.log.splice(0, this.state.log.length - 2000);
  }
  #saving: Promise<void> = Promise.resolve();
  /** 并行生成时串行写 run.json，避免并发写坏文件。 */
  async save(stage?: string) {
    if (stage) this.state.stage = stage;
    const write = async () => {
      this.state.updatedAt = new Date().toISOString();
      await mkdir(this.abs(this.out), { recursive: true });
      const path = this.abs(posix.join(this.out, "run.json"));
      await writeFile(`${path}.tmp`, JSON.stringify(this.state, null, 2));
      await rename(`${path}.tmp`, path);
      this.deps.onUpdate?.(this.state);
    };
    const next = this.#saving.then(write, write);
    this.#saving = next.catch(() => {});
    return next;
  }
  get concurrency() { return Math.max(1, Math.min(16, Math.floor(this.options.concurrency ?? 1))); }
  async writeText(relative: string, content: string) {
    await mkdir(dirname(this.abs(relative)), { recursive: true });
    await writeFile(this.abs(relative), content);
    return relative;
  }
  async readJson<T>(relative: string): Promise<T> { return JSON.parse(await readFile(this.abs(relative), "utf8")) as T; }

  /** 调用生成接口；抛错时指数退避重试，参数/鉴权类错误不重试。 */
  async generate(mediaType: "image" | "video", request: MediaGenerationRequest) {
    let lastError: unknown;
    let throttled = 0;
    for (let attempt = 1; attempt <= this.maxAttempts; attempt++) {
      this.deps.signal?.throwIfAborted();
      const quote = mediaType === "video" ? this.quote(request) : undefined;
      // 预算守卫：提交前检查（任务一旦提交无法取消）
      const entry = quote ? this.budget.reserve(`${request.outputDirectory ?? "video"} ${quote.seconds}s`, quote.seconds, quote.usd) : undefined;
      try {
        const files = await this.deps.generate(mediaType, request, this.deps.signal);
        if (!files.length) throw new Error("生成结果为空");
        if (entry) { this.budget.settle(entry, "charged"); this.log(`花费 +$${entry.usd.toFixed(3)}（累计 $${this.state.spend!.usd.toFixed(3)}${this.budget.cap !== undefined ? ` / 上限 $${this.budget.cap}` : "，不限额"}）`); await this.save(); }
        return files[0]!.path;
      } catch (error) {
        if (entry) { this.budget.settle(entry, outcomeOfError(error), error instanceof Error ? error.message : String(error)); await this.save().catch(() => {}); }
        lastError = error;
        const status = (error as { status?: number }).status;
        const code = (error as { code?: string }).code;
        // 429（并发渲染数或每分钟提交数到上限）：任务没有提交、不扣费，退避等待后重提，不占用重试次数
        if (status === 429 && !this.deps.signal?.aborted && throttled < this.maxThrottleWaits) {
          throttled++;
          attempt--;
          const delay = Math.min(120_000, (this.deps.throttleDelayMs ?? 20_000) * Math.min(throttled, 6)) * (0.75 + Math.random() * 0.5);
          if (throttled === 1 || throttled % 5 === 0) this.log(`${mediaType} 提交被限流（${code ?? "429"}），${Math.round(delay / 1000)} 秒后重试（第 ${throttled} 次等待）`);
          await new Promise(resolve => setTimeout(resolve, delay));
          continue;
        }
        // 402 余额不足、422 内容审核不通过：重试同一请求没有意义
        if (this.deps.signal?.aborted || code === "FFMPEG_REQUIRED" || (status !== undefined && [400, 401, 402, 403, 404, 422, 424].includes(status))) throw error;
        this.log(`${mediaType} 生成失败（第 ${attempt}/${this.maxAttempts} 次）：${error instanceof Error ? error.message : String(error)}`);
        if (attempt < this.maxAttempts) await new Promise(resolve => setTimeout(resolve, (this.deps.retryDelayMs ?? 3000) * attempt));
      }
    }
    throw lastError;
  }

  /**
   * 生成静帧。图片模型直接出图；配置了 stillFromVideo（如 MiniMax H3）时生成最短视频并取第 0 帧，
   * 提示词已要求“画面从第一帧起完整呈现且全程不变”。
   */
  async generateStill(request: MediaGenerationRequest) {
    const still = this.options.imageModel.stillFromVideo;
    if (!still) return this.generate("image", request);
    const { size: _size, ...rest } = request;
    const images = request.images ?? [];
    const video = await this.generate("video", {
      ...rest, duration: still.duration, resolution: still.resolution, generateAudio: false,
      mode: images.length ? [`imageReference:${images.length}`] : "text",
    });
    const output = video.replace(/\.[^./\\]+$/, "") + "-frame0.png";
    await extractFrame(this.abs(video), 0, this.abs(output), this.ffmpeg, this.deps.signal);
    return output;
  }

  get clipRhythm() { return this.options.rhythm === "clip"; }

  rhythmParams(): Partial<StoryboardParams> {
    return { ...(this.clipRhythm ? { minShotSeconds: 1, maxShotSeconds: 4, charsPerSecond: 4.1, speechLeadSeconds: 1.8, speechTailSeconds: 0.5 } : {}), ...this.options.params };
  }

  clipPackOptions(): ClipPackOptions {
    const durations = (this.options.videoModel?.durations ?? []).filter(value => value >= 5 && value <= 15);
    return { allowedDurations: durations.length ? durations : undefined, minClipSeconds: 5, maxClipSeconds: 15 };
  }

  voiceAudios() {
    return (this.options.voiceReferences ?? []).slice(0, 3).map(item => ({
      path: item.path,
      mimeType: item.mimeType ?? audioMime(item.path),
    }));
  }

  brief(): PlanBrief {
    const params = this.rhythmParams();
    const ranged = this.clipRhythm || this.options.params?.maxShotSeconds || this.options.params?.minShotSeconds;
    return { story: this.options.story, episodes: this.options.episodes ?? 1, targetSeconds: this.options.targetSeconds ?? 30,
      aspectRatio: this.options.aspectRatio ?? "16:9", style: this.options.style, writingRule: this.style.plannerRule,
      preserveSourceText: this.options.preserveSourceText !== false, rhythm: this.options.rhythm,
      shotSeconds: ranged ? { min: params.minShotSeconds ?? defaultParams.minShotSeconds, max: params.maxShotSeconds ?? defaultParams.maxShotSeconds } : undefined };
  }

  async script() {
    await this.writeText(posix.join(this.out, "effective_models.json"), JSON.stringify(this.options.runtimeModels ?? {}, null, 2));
    const path = posix.join(this.out, "剧本.md");
    if (this.options.preserveSourceText !== false) {
      const expectedLedger = buildSourceLedger(this.options.story);
      const existing = await exists(this.abs(path)) ? await readFile(this.abs(path), "utf8") : undefined;
      const ledgerPath = posix.join(this.out, "source_ledger.json");
      const previousLedger = await exists(this.abs(ledgerPath)) ? await this.readJson<{ sourceHash?: string }>(ledgerPath).catch(() => undefined) : undefined;
      const cacheMatches = existing === this.options.story && previousLedger?.sourceHash === expectedLedger.sourceHash;
      if (!cacheMatches && (this.state.artifacts.cast || this.state.artifacts.storyboard || Object.keys(this.state.artifacts.cards ?? {}).length || Object.keys(this.state.shots ?? {}).length)) {
        this.log("原文或原文账本与旧 run 不一致；清除旧角色/分镜/镜头缓存，防止复用改写章节的资产");
        this.state.artifacts.cast = undefined; this.state.artifacts.storyboard = undefined;
        this.state.artifacts.cards = {}; this.state.artifacts.scenes = {}; this.state.artifacts.props = undefined;
        this.state.artifacts.final = undefined; this.state.artifacts.finalContactSheet = undefined; this.state.artifacts.report = undefined;
        this.state.shots = {}; this.state.gates = undefined; this.state.projectBible = undefined; this.state.crossEpisodeMemory = undefined;
        if (!this.options.characterDirectory) this.options.characterDirectory = posix.join(this.out, `角色_原文_${expectedLedger.sourceHash.slice(0, 12)}`);
      }
      await this.writeText(posix.join(this.out, "原文.md"), this.options.story);
      await this.writeText(ledgerPath, JSON.stringify(expectedLedger, null, 2));
      if (!cacheMatches) this.state.artifacts.script = await this.writeText(path, this.options.story);
      else this.state.artifacts.script ??= path;
      await this.save("script");
      this.log("原文保护模式：章节原文逐字保留，跳过编剧改写阶段");
      return this.options.story;
    }
    if (this.state.artifacts.script && await exists(this.abs(path))) return readFile(this.abs(path), "utf8");
    await this.save("script");
    const text = await writeScript(this.deps.text, this.brief(), this.deps.signal);
    this.state.artifacts.script = await this.writeText(path, text);
    this.log("剧本完成");
    return text;
  }

  async cast(script: string): Promise<CastPlan> {
    const path = posix.join(this.out, "cast.json");
    if (this.state.artifacts.cast && await exists(this.abs(path))) return this.readJson<CastPlan>(path);
    await this.save("cast");
    const plan = await planCast(this.deps.text, this.brief(), script, { repairAttempts: this.options.repairAttempts, signal: this.deps.signal, log: message => this.log(message) });
    if (this.options.style) plan.style = this.options.style;
    this.state.artifacts.cast = await this.writeText(path, JSON.stringify(plan, null, 2));
    this.log(`角色 ${plan.characters.length} 个，场景 ${plan.scenes.length} 个`);
    return plan;
  }

  /** 角色卡落盘：已存在同名角色卡时复用（锚点与种子不变），否则新建；随后补齐锚点与正脸视图。 */
  async cards(plan: CastPlan) {
    await this.save("characters");
    const directory = this.options.characterDirectory ?? "角色";
    const ordered: CharacterCard[] = [];
    await runPool(plan.characters, this.concurrency, async (draft, index) => {
      const cardPath = posix.join(directory, safeName(draft.name), "card.json");
      const wantedStyle = draft.style ?? plan.style;
      const imageModelKey = `${this.options.imageModel.providerId}/${this.options.imageModel.modelId}`;
      let card: CharacterCard;
      if (await exists(this.abs(cardPath))) {
        card = characterCardSchema.parse(await this.readJson(cardPath));
        // 旧视图是按另一种画风或另一个图像模型出的：继续当参考图会把旧画风带进每个镜头，所以清空视图重出（旧图片文件不删除）
        const stale = [
          card.style && wantedStyle && card.style !== wantedStyle ? "画风" : undefined,
          card.imageModel && card.imageModel !== imageModelKey ? "图像模型" : undefined,
        ].filter(Boolean);
        if (stale.length) {
          for (const outfit of card.outfits) outfit.views = {};
          card.style = wantedStyle ?? card.style;
          card.imageModel = imageModelKey;
          this.log(`角色卡 ${cardPath} 的${stale.join("、")}与本次运行不一致，重新生成锚点与正脸（旧图片保留在原目录）`);
        } else {
          this.log(`复用已有角色卡 ${cardPath}`);
          if (!card.style || !card.imageModel) this.log(`角色卡 ${cardPath} 没有记录${[!card.style && "画风", !card.imageModel && "图像模型"].filter(Boolean).join("和")}，无法核对旧视图是否与本次运行一致；画风不符时请删除该角色卡的 views 后重跑`);
        }
      } else {
        card = characterCardSchema.parse({ ...draft, version: 1, style: wantedStyle, imageModel: imageModelKey, seed: draft.seed ?? ((this.options.seed ?? 0) + hashSeed(draft.name)) % 4294967296 });
      }
      // 补齐每套造型的视图（锚点优先）：先锚点（纯文本），再以锚点为参考派生正脸，H3 风格再以锚点+正脸派生多视角设定表
      const { providerId, modelId, size } = this.options.imageModel;
      for (const outfit of card.outfits) {
        outfit.views ??= {};
        const outputDirectory = posix.join(directory, safeName(card.name), outfit.id);
        if (!outfit.views.anchor || !await exists(this.abs(outfit.views.anchor))) {
          const view = this.style.characterAnchor(card, outfit.id);
          outfit.views.anchor = await this.generateStill({ providerId, modelId, prompt: view.prompt, ratio: view.ratio, size, seed: view.seed, outputDirectory });
          await this.writeText(cardPath, JSON.stringify(card, null, 2));
          this.log(`${card.name}/${outfit.label} 锚点完成`);
        }
        const anchorReference = { path: outfit.views.anchor, mimeType: imageMimeType(outfit.views.anchor) };
        if (!outfit.views.face || !await exists(this.abs(outfit.views.face))) {
          const view = this.style.characterFace(card, outfit.id);
          outfit.views.face = await this.generateStill({ providerId, modelId, prompt: view.prompt, ratio: view.ratio, size, seed: view.seed, outputDirectory,
            images: [anchorReference], referenceLabels: this.labels([{ role: "character" as const, name: card.name }]) });
          await this.writeText(cardPath, JSON.stringify(card, null, 2));
        }
        const sheetPrompt = this.style.characterSheet;
        if (sheetPrompt && (!outfit.views.sheet || !await exists(this.abs(outfit.views.sheet)))) {
          const face = !!outfit.views.face && (this.options.imageModel.maxReferenceImages ?? 8) >= 2;
          const view = sheetPrompt(card, outfit.id, { face });
          outfit.views.sheet = await this.generateStill({ providerId, modelId, prompt: view.prompt, ratio: view.ratio, size, seed: view.seed, outputDirectory,
            images: face ? [anchorReference, { path: outfit.views.face!, mimeType: imageMimeType(outfit.views.face!) }] : [anchorReference] });
          this.log(`${card.name}/${outfit.label} 多视角设定表完成`);
        }
      }
      await this.writeText(cardPath, JSON.stringify(card, null, 2));
      this.state.artifacts.cards[card.id] = cardPath;
      ordered[index] = card;
      await this.save();
    });
    // 保持与角色表一致的顺序
    return new Map(ordered.filter(Boolean).map(card => [card.id, card] as const));
  }

  async sceneImages(plan: CastPlan, style: string) {
    await this.save("scenes");
    await runPool(plan.scenes, this.concurrency, async scene => {
      const existing = this.state.artifacts.scenes[scene.id];
      if (existing && await exists(this.abs(existing))) return;
      const view = this.style.scene(scene, style, this.options.aspectRatio ?? "16:9");
      this.state.artifacts.scenes[scene.id] = await this.generateStill({
        providerId: this.options.imageModel.providerId, modelId: this.options.imageModel.modelId,
        prompt: view.prompt, ratio: view.ratio, size: this.options.imageModel.size,
        seed: ((this.options.seed ?? 0) + hashSeed(scene.id)) % 4294967296, outputDirectory: posix.join(this.out, "场景"),
      });
      await this.save();
    });
  }

  /** 固定道具/车辆卡的产品照（中性灰台面、单一侧光），生成后回填到 board.props[].image，供镜头挂参考图。 */
  async propImages(board: Storyboard) {
    const props = (board.props ?? []).filter(card => card.kind === "vehicle" || card.kind === "prop");
    if (!props.length || this.options.propImages === false) return;
    this.state.artifacts.props ??= {};
    await runPool(props, this.concurrency, async card => {
      const existing = this.state.artifacts.props![card.id];
      if (!existing || !await exists(this.abs(existing))) {
        this.state.artifacts.props![card.id] = await this.generateStill({
          providerId: this.options.imageModel.providerId, modelId: this.options.imageModel.modelId,
          prompt: propProductPrompt(card, board.style), ratio: "16:9", size: this.options.imageModel.size,
          seed: ((this.options.seed ?? 0) + hashSeed(`prop:${card.id}`)) % 4294967296, outputDirectory: posix.join(this.out, "道具"),
        });
        await this.save();
      }
      card.image = this.state.artifacts.props![card.id];
    });
  }

  /** final=false：只做（免费的）分镜规划并落盘；final=true：挂上角色卡与场景图后过最终质量门（要求锚点就绪）。 */
  async storyboard(script: string, plan: CastPlan, cards: Map<string, CharacterCard>, final = true): Promise<Storyboard> {
    const path = posix.join(this.out, "storyboard.json");
    if (this.options.preserveSourceText !== false) await this.writeText(posix.join(this.out, "source_ledger.json"), JSON.stringify(buildSourceLedger(script, plan.characters), null, 2));
    const gateContext = { params: this.rhythmParams(), cards, maxReferenceImages: this.options.imageModel.maxReferenceImages ?? 8,
      clipRhythm: this.clipRhythm, clipDurations: this.clipRhythm ? this.options.videoModel?.durations : undefined };
    let board: Storyboard | undefined;
    if (this.state.artifacts.storyboard && await exists(this.abs(path))) {
      const parsed = parseStoryboard(normalizeStoryboardEnums(await this.readJson(path)));
      if (!parsed.ok) throw new Error(`已保存的分镜无效：${parsed.errors.join("；")}`);
      board = parsed.data;
      if (this.options.preserveSourceText !== false) {
        const ledger = buildSourceLedger(script, board.characters);
        const coverage = sourceCoverage(board, script);
        const ledgerReport = validateSourceLedger(board, ledger);
        const hashMismatch = !!board.sourceLedgerHash && board.sourceLedgerHash !== ledger.sourceHash;
        if (hashMismatch || !ledgerReport.ok || !coverage.ordered || coverage.ratio < 1 || coverage.missingLines.length) {
          this.log("旧分镜与当前原文账本不匹配或缺少完整 ID 映射，废弃缓存并重新规划，避免复用旧对白/镜头");
          this.state.artifacts.storyboard = undefined; board = undefined;
        } else board.sourceLedgerHash = ledger.sourceHash;
      }
    }
    if (!board && this.options.storyboard) {
      const parsed = parseStoryboard(normalizeStoryboardEnums(this.options.storyboard));
      if (!parsed.ok) throw new Error(`传入的分镜无效：${parsed.errors.join("；")}`);
      board = parsed.data;
      if (this.options.preserveSourceText !== false) {
        const ledger = buildSourceLedger(script, board.characters);
        const coverage = sourceCoverage(board, script);
        const ledgerReport = validateSourceLedger(board, ledger);
        if ((board.sourceLedgerHash && board.sourceLedgerHash !== ledger.sourceHash) || !ledgerReport.ok || !coverage.ordered || coverage.ratio < 1 || coverage.missingLines.length) {
          throw new Error("自定义分镜未通过完整原文账本校验（sourceRefs、quoteAssignments、顺序或逐字覆盖）；请先通过原文账本生成分镜，或关闭 preserveSourceText（不推荐）");
        }
        board.sourceLedgerHash = ledger.sourceHash;
      }
    }
    if (!board) {
      await this.save("storyboard");
      const result = await planStoryboard(this.deps.text, this.brief(), script, plan, {
        repairAttempts: this.options.repairAttempts, signal: this.deps.signal, log: message => this.log(message),
        gateContext, allowedDurations: this.options.videoModel?.durations,
        onAttempt: async (episode, attempt, output, errors) => {
          const dir = posix.join(this.out, "planner_attempts");
          const stem = `storyboard_E${String(episode ?? 0).padStart(2, "0")}_attempt_${String(attempt).padStart(2, "0")}`;
          await this.writeText(posix.join(dir, `${stem}.json`), output);
          await this.writeText(posix.join(dir, `${stem}_errors.json`), JSON.stringify(errors, null, 2));
        },
      });
      board = result.storyboard;
    }
    if (!board) throw new Error("分镜规划未产生结果");
    if (this.options.preserveSourceText !== false) applyDeathEventsFromSource(board, board.characters.map(character => ({ id: character.id, name: character.name })));
    propagateDeadStates(board);
    if (!final) {
      this.state.artifacts.storyboard = await this.writeText(path, JSON.stringify(board, null, 2));
      const shots = [...iterateShots(board)];
      this.log(`分镜完成：${shots.length} 镜，共 ${shots.reduce((sum, item) => sum + (item.shot.seconds ?? 0), 0)} 秒`);
      await this.save();
      return board;
    }
    if ((this.options.annotateContinuity ?? true) && !hasContinuity(board)) {
      const source = script || await readFile(this.abs(posix.join(this.out, "剧本.md")), "utf8").catch(() => this.options.story);
      this.log("分镜缺少连续性标注，补注死亡状态与左右手持物");
      board = await annotateContinuity(this.deps.text, board, source, { repairAttempts: this.options.repairAttempts, signal: this.deps.signal, log: message => this.log(message) });
    }
    if (this.options.preserveSourceText !== false) applyDeathEventsFromSource(board, board.characters.map(character => ({ id: character.id, name: character.name })));
    propagateDeadStates(board);
    for (const character of board.characters) character.card ??= this.state.artifacts.cards[character.id];
    for (const scene of board.scenes) scene.image ??= this.state.artifacts.scenes[scene.id];
    // 有问题的场景图（如带家具 / 人造物 / 其他动物）：不作参考图，改在描述里写明昆虫尺度约束
    for (const scene of board.scenes) {
      if (!this.options.problemScenes?.includes(scene.id)) continue;
      delete scene.image;
      if (!scene.description.includes(problemSceneGuard)) scene.description = `${scene.description.replace(/[.\s]*$/, "")}. ${problemSceneGuard}`;
    }
    // 生成前的最终质量门：要求锚点就绪
    const report = runGates(board, { ...gateContext, requireAnchors: true, allowedDurations: this.clipRhythm ? undefined : this.options.videoModel?.durations,
      chapter: this.options.preserveSourceText !== false ? script : undefined });
    this.state.gates = report.gates;
    this.state.artifacts.storyboard = await this.writeText(path, JSON.stringify(board, null, 2));
    this.state.projectBible = projectBibleSchema.parse({ version: 1, projectId: board.bible?.projectId ?? board.title, title: board.title, canon: board.bible?.canon ?? [], threads: board.bible?.threads ?? [],
      style: { description: board.style, palette: board.bible?.style?.palette ?? [], forbidden: board.bible?.style?.forbidden ?? [] },
      characters: board.characters.map(character => { const card = cards.get(character.id); return { id: character.id,
        identityInvariants: card ? [card.invariant.face, card.invariant.hair, card.invariant.body, card.invariant.marks].filter((value): value is string => !!value) : [],
        outfits: card?.outfits.map(outfit => ({ id: outfit.id, description: [outfit.label, outfit.upper, outfit.lower, outfit.shoes, outfit.accessories].filter(Boolean).join("；") })) ?? [],
        temporaryState: card?.temporaryState ?? [], voice: card?.voice }; }),
      scenes: board.scenes.map(scene => ({ id: scene.id, layout: scene.layout ?? scene.description, lightingBaseline: scene.lightingBaseline, cameraViews: scene.cameraViews ?? [] })),
      assets: [...board.characters.map(character => ({ id: character.id, kind: "character" as const, version: "v1", contentHash: cards.get(character.id) ? stableHash(cards.get(character.id)) : undefined })),
        ...board.scenes.map(scene => ({ id: scene.id, kind: "scene" as const, version: "v1", contentHash: stableHash(scene) })),
        ...(board.props ?? []).map(prop => ({ id: prop.id, kind: (prop.kind === "vehicle" ? "vehicle" : "prop") as "vehicle" | "prop", version: "v1", contentHash: stableHash(prop) }))] });
    this.state.crossEpisodeMemory = deriveCrossEpisodeMemory(board);
    await this.writeText(posix.join(this.out, "project_bible.json"), JSON.stringify(this.state.projectBible, null, 2));
    await this.writeText(posix.join(this.out, "cross_episode_memory.json"), JSON.stringify(this.state.crossEpisodeMemory, null, 2));
    if (!report.ok) throw new Error(`分镜未通过质量门：${report.gates.filter(gate => !gate.ok && gate.severity === "error").map(gate => `${gate.label}（${gate.details.slice(0, 3).join("；")}）`).join("；")}`);
    for (const gate of report.gates) if (!gate.ok) this.log(`质量门警告：${gate.label}：${gate.details.slice(0, 5).join("；")}`);
    return board;
  }

  /** 角色/场景阶段预计花费（只算“视频取首帧”的静帧；复用的角色卡、已有场景图不计）。 */
  async estimateCast(plan: CastPlan) {
    const still = this.stillCost();
    if (!still) return 0;
    let count = 0;
    const directory = this.options.characterDirectory ?? "角色";
    for (const draft of plan.characters) {
      if (await exists(this.abs(posix.join(directory, safeName(draft.name), "card.json")))) continue;
      count += draft.outfits.length * (this.style.characterSheet ? 3 : 2);
    }
    for (const scene of plan.scenes) if (!this.state.artifacts.scenes[scene.id]) count++;
    return round(count * still);
  }

  /** 镜头阶段预计花费（不含重试）：关键帧静帧 + 尾帧静帧 + 视频。clip 节奏一镜一条，短镜头按不少于 5 秒报价。 */
  estimateShots(board: Storyboard) {
    const video = this.options.videoModel;
    const still = this.stillCost();
    const quoteVideo = (seconds: number) => video && this.options.stopAfter !== "keyframes"
      ? this.quote({ providerId: video.providerId, modelId: video.modelId, prompt: "x", duration: seconds } as MediaGenerationRequest)?.usd ?? 0 : 0;
    let total = 0;
    if (this.clipRhythm) {
      let clips = 0;
      for (const episode of board.episodes) for (const segment of episode.segments) {
        for (const pack of packRenderClips(segment.shots, this.clipPackOptions())) {
          if (this.options.preview?.maxClips && clips >= this.options.preview.maxClips) return round(total);
          clips++;
          const lead = pack.shots[0]!;
          const state = this.state.shots[lead.id];
          if (state?.video) continue;
          if (!state?.keyframe && video?.input !== "directReference") total += still;
          if (video?.useEndFrame !== false && video?.input !== "directReference" && !state?.endKeyframe) total += still;
          total += quoteVideo(this.options.preview?.seconds ?? pack.seconds);
        }
      }
      return round(total);
    }
    for (const { shot, index } of iterateShots(board)) {
      const state = this.state.shots[shot.id];
      if (state?.video) continue;
      const chained = (this.options.chainContinuous ?? false) && shot.transition === "continuous" && index > 0;
      if (!state?.keyframe && !chained && video?.input !== "directReference") total += still;
      if (video?.useEndFrame !== false && shot.endFrame && !state?.endKeyframe && video.input !== "directReference") total += still;
      total += quoteVideo(shot.seconds ?? 5);
    }
    return round(total);
  }

  preflight(stage: string, estimate: number) {
    if (estimate > 0) this.log(`预计花费（${stage}，不含重试）：$${estimate.toFixed(3)}；已花费 $${(this.state.spend?.usd ?? 0).toFixed(3)}${this.budget.cap !== undefined ? `；上限 $${this.budget.cap}` : "；不限额"}`);
    this.budget.preflight(stage, estimate);
  }

  /**
   * 生成并评分关键帧：低于阈值时换种子重试（最多 keyframeAttempts 次），保留得分最高的一张。
   * 严格模式下重试用完仍低于阈值则抛 KeyframeRejectedError（不静默接受）。续跑时种子接着之前的尝试次数往后换，不会重复坏种子。
   */
  async keyframe(shotState: ShotState, request: MediaGenerationRequest, scoreReferences: { path: string; name: string; outfit?: string }[], description: string, baseSeed: number,
    extra: { traits?: string[]; staging?: string } = {}) {
    let best: { file: string; score: ScoreResult; seed: number } | undefined;
    const offset = shotState.attempts.filter(item => item.stage === "keyframe").length;
    for (let attempt = 0; attempt < this.keyframeAttempts; attempt++) {
      const index = offset + attempt;
      const seed = index === 0 ? baseSeed : nextSeed(baseSeed, index);
      let file: string;
      try { file = await this.generateStill({ ...request, seed }); }
      catch (error) { shotState.attempts.push({ stage: "keyframe", seed, error: error instanceof Error ? error.message : String(error) }); throw error; }
      const score = await this.scorer.score({
        candidate: this.abs(file), description, signal: this.deps.signal, traits: extra.traits, staging: extra.staging,
        references: scoreReferences.map(reference => ({ ...reference, path: this.abs(reference.path), role: "character" as const })),
      });
      shotState.attempts.push({ stage: "keyframe", seed, file, score: score.score });
      if (!best || score.score > best.score.score) best = { file, score, seed };
      if (score.score >= this.threshold) break;
      this.log(`关键帧一致性 ${score.score.toFixed(2)} 低于阈值 ${this.threshold}（第 ${attempt + 1}/${this.keyframeAttempts} 次），换种子重试：${score.reasons.join("；")}`);
    }
    if (best!.score.score < this.threshold) {
      const message = `关键帧一致性最高 ${best!.score.score.toFixed(2)}，低于阈值 ${this.threshold}${best!.score.reasons.length ? `（${best!.score.reasons.slice(0, 3).join("；")}）` : ""}`;
      if (this.strictKeyframes) throw new KeyframeRejectedError(message, best!);
      shotState.warnings.push(message);
    }
    return best!;
  }

  /** 上一镜画面能否作为参考：qa 模式只挂通过手/肢体检查的帧（优先尾帧，其次首帧）。 */
  previousReference(previous: ShotState | undefined) {
    const mode = this.options.previousFrameReference ?? "qa";
    if (!previous || mode === "never") return undefined;
    if (mode === "always") return previous.lastFrame ?? previous.keyframe;
    if (previous.lastFrame && previous.lastFrameHandsOk === true) return previous.lastFrame;
    if (previous.keyframe && previous.keyframeHandsOk === true) return previous.keyframe;
    // v5.2.5：手指检查只记录、不断链；人物变样或特征串用的尾帧仍不挂
    if (!handsBlockChain(this.options.continuation) && previous.qa?.pass !== false) {
      if (previous.lastFrame && previous.chainable !== false && previous.lastFrameTraitsOk !== false) return previous.lastFrame;
      if (previous.keyframe && previous.keyframeHandsOk !== false) return previous.keyframe;
    }
    return undefined;
  }

  /** 逐段生成：段与段互不依赖（接力只在段内），按 concurrency 并行；段内镜头按顺序接力。 */
  #previewClips = 0;
  #countedClips = new Set<string>();

  async shots(board: Storyboard, cards: Map<string, CharacterCard>) {
    await this.save("keyframes");
    const segments = board.episodes.flatMap(episode => episode.segments);
    // v5.2.5：跨段接力时，上一段最后一镜要先生成完，段落只能串行；只在两段是同一场景时承接
    const across = !!this.options.chainAcrossSegments;
    const carryInto = (from: SegmentCarry | undefined, fromSegment: (typeof segments)[number] | undefined, segment: (typeof segments)[number]) =>
      across && from && fromSegment && fromSegment.sceneId === segment.sceneId ? from : undefined;
    if (this.options.preview?.maxClips) {
      this.log(`预览：最多 ${this.options.preview.maxClips} 条，每条 ${this.options.preview.seconds ?? "按素材时长"} 秒，分辨率 ${this.options.preview.resolution ?? this.options.videoModel?.resolution ?? "模型默认"}`);
      let carry: SegmentCarry | undefined;
      let last: (typeof segments)[number] | undefined;
      for (const segment of segments) {
        if (this.#previewClips >= this.options.preview.maxClips) break;
        carry = await this.segmentShots(board, cards, segment, carryInto(carry, last, segment));
        last = segment;
      }
    } else if (across) {
      if (this.concurrency > 1) this.log(`跨段接力已开启：段落改为串行生成（concurrency=${this.concurrency} 只用于角色和场景图）`);
      let carry: SegmentCarry | undefined;
      let last: (typeof segments)[number] | undefined;
      for (const segment of segments) {
        carry = await this.segmentShots(board, cards, segment, carryInto(carry, last, segment));
        last = segment;
      }
    } else await runPool(segments, this.concurrency, segment => this.segmentShots(board, cards, segment));
    const redo = [...iterateShots(board)].filter(({ shot }) => this.state.shots[shot.id]?.needsRedo).map(({ shot }) => shot.id);
    if (redo.length) throw new Error(`以下镜头关键帧多次未达阈值 ${this.threshold}，已标记需重做（未生成视频、未导出成片；用同一 runId 续跑会换新种子重做）：${redo.join("、")}`);
  }

  async segmentShots(board: Storyboard, cards: Map<string, CharacterCard>, segment: Storyboard["episodes"][number]["segments"][number], carry?: SegmentCarry): Promise<SegmentCarry | undefined> {
    const image = this.options.imageModel;
    const video = this.options.videoModel;
    const [width, height] = ratioSize[board.aspectRatio] ?? [1280, 720];
    // v5.2.5：跨段接力时，上一段最后一镜作为本段第一镜的“上一镜”（只有生成完成的镜头才承接）
    let previous: SegmentCarry | undefined = carry && carry.state.status === "done" && carry.state.video ? { ...carry, segmentId: segment.id } : undefined;
    const carried = !!previous;
    if (carried) this.log(`${segment.id} 与上一段同场景，第一镜承接 ${carry!.shotId}`);
    const allSegments = board.episodes.flatMap(episode => episode.segments);
    const followingSegment = allSegments[allSegments.findIndex(item => item.id === segment.id) + 1];
    const chainOn = this.options.chainContinuous ?? this.clipRhythm;
    const handsBlock = handsBlockChain(this.options.continuation);
    for (const [index, shot] of segment.shots.entries()) {
      this.deps.signal?.throwIfAborted();
      if (this.options.preview?.maxClips && this.#previewClips >= this.options.preview.maxClips) return previous;
      const state: ShotState = this.state.shots[shot.id] ??= { status: "pending", attempts: [], warnings: [] };
      const pack = this.clipRhythm ? packContaining(segment.shots, shot.id, this.clipPackOptions()) : undefined;
      if (pack && pack.shots[0]!.id !== shot.id) {
        const note = `并入 ${pack.shots[0]!.id} 的 ${pack.seconds} 秒素材（${pack.shots.length} 个镜头，镜内切 ${pack.plannedCuts} 次）`;
        if (!state.warnings.includes(note)) state.warnings.push(note);
        state.status = "done";
        const lead = this.state.shots[pack.shots[0]!.id];
        previous = { segmentId: segment.id, shotId: pack.shots[0]!.id, state: lead ?? state };
        await this.save();
        continue;
      }
      const sameSegment = previous?.segmentId === segment.id && (index > 0 || carried);
      // clip 节奏缺省接力：下一镜首帧用上一镜尾帧。显式 chainContinuous:false 才每镜重画。
      // v5.2.5：只有人物变样（chainable=false）或特征串用才断链；手指瑕疵只记警告（continuation.handsGate=block 恢复旧行为）
      // 逐帧质检明确不通过（qaGate=block 时才会跑）的镜头也不接力
      const chainFrom = chainOn && sameSegment && previous!.state.lastFrame && previous!.state.chainable !== false && previous!.state.lastFrameTraitsOk !== false
        && previous!.state.qa?.pass !== false && (!handsBlock || previous!.state.lastFrameHandsOk !== false)
        ? previous!.state.lastFrame : undefined;
      const previousFrame = sameSegment ? this.previousReference(previous!.state) : undefined;
      const outputDirectory = posix.join(this.out, "镜头", shot.id);
      const baseSeed = ((this.options.seed ?? 0) + hashSeed(shot.id)) % 4294967296;
      const scene = board.scenes.find(item => item.id === segment.sceneId);

      // 1. 首帧关键帧
      const includeSheet = this.style.id === "h3";
      // 视频参考图带上多视角设定表（H3 一次可喂 9 张）；静帧仍只有 h3 风格带，避免挤掉锚点和正脸
      const videoSheet = includeSheet || !!this.style.characterSheet;
      const plan = resolveShotReferences({
        shot, cards, maxImages: image.maxReferenceImages ?? 8, includeSheet,
        sceneImage: scene?.image ? { path: scene.image, name: scene.name } : undefined,
        propImages: shotPropImages(board.props, segment, shot),
        previousFrame,
      });
      state.warnings.push(...plan.warnings.filter(warning => !state.warnings.includes(warning)));
      state.referenceManifests ??= {};
      // v5run fix: on resume a finished shot keeps the manifest/fingerprints recorded when its video was generated
      // (recomputing them here made export flag every resumed shot as stale: referenceManifestHash/promptHash).
      const shotDone = !!state.video && await exists(this.abs(state.video));
      if (!shotDone) {
        state.referenceManifests.keyframe = plan.manifest;
        state.inputFingerprints = {
          ...state.inputFingerprints,
          shotContractHash: contentHash({ shot, segment: { sceneId: segment.sceneId, blocking: segment.blocking }, style: board.style }),
          referenceManifestHash: contentHash(plan.manifest),
        };
      }
      const promptContext = { board, segment, shot, cards };
      const firstFramePrompt = this.style.keyframe(promptContext, plan);
      const scoreReferences = shot.characters.flatMap(character => {
        const card = cards.get(character.id);
        const anchor = card ? characterReferenceImages(card, character.outfit)[0] : undefined;
        return card && anchor ? [{ path: anchor, name: card.name, outfit: characterOutfitText(card, character.outfit) }] : [];
      });
      const traits = shotTraits(shot.characters, cards);
      const scoreExtra = {
        traits: [...traits.lines, ...traits.constraints],
        staging: [segment.blocking, shot.composition, shot.cameraPosition, `cameraContract=${JSON.stringify(shot.cameraContract ?? { viewpoint: "third_person" })}`, `spatialContract=${JSON.stringify(shot.spatialContract ?? {})}`, ...shot.characters.map(character => character.pose ? `${cards.get(character.id)?.name ?? character.id}：${character.pose}` : "")].filter(Boolean).join("；"),
      };
      const direct = video?.input === "directReference";
      if (!state.keyframe || !await exists(this.abs(state.keyframe))) {
        if (direct && !(chainFrom && (shot.transition === "continuous" || this.clipRhythm))) {
          // 直接参考图驱动：不单独出关键帧，视频生成后取第 0 帧作为记录
          this.log(`${shot.id} 跳过关键帧，直接以角色参考图驱动视频`);
        } else if (chainFrom && (shot.transition === "continuous" || this.clipRhythm)) {
          // 动作连续：直接用上一镜尾帧作为首帧，保证无缝衔接
          state.keyframe = posix.join(outputDirectory, "首帧.png");
          await mkdir(this.abs(outputDirectory), { recursive: true });
          await copyFile(this.abs(chainFrom), this.abs(state.keyframe));
          state.seed = previous!.state.seed;
          state.chainedFrom = previous!.shotId;
          state.keyframeHandsOk = previous!.state.lastFrameHandsOk;
          if (previous!.state.lastFrameHandsOk === false) {
            const note = `承接的上一镜尾帧手指/肢体检查未通过，仍按接力承接（只记录）`;
            if (!state.warnings.includes(note)) state.warnings.push(note);
          }
          this.log(`${shot.id} 承接上一镜尾帧作为首帧`);
        } else {
          let result: Awaited<ReturnType<Run["keyframe"]>>;
          try {
            result = await this.keyframe(state, {
              providerId: image.providerId, modelId: image.modelId, prompt: firstFramePrompt,
              ratio: board.aspectRatio, size: image.size, outputDirectory, images: plan.images, referenceLabels: this.labels(plan.referenceLabels),
            }, scoreReferences, shot.firstFrame, baseSeed, scoreExtra);
          } catch (error) {
            if (!(error instanceof KeyframeRejectedError)) throw error;
            // 严格模式：不接受低于阈值的首帧，镜头标记需重做，本段后续镜头不再承接它
            state.status = "failed";
            state.needsRedo = true;
            state.rejectedKeyframe = error.best.file;
            state.score = error.best.score;
            state.prompts = { firstFrame: firstFramePrompt, video: "" };
            if (!state.warnings.includes(error.message)) state.warnings.push(error.message);
            this.log(`${shot.id} ${error.message}，标记需重做`);
            previous = undefined;
            await this.save();
            continue;
          }
          state.keyframe = result.file;
          state.score = result.score;
          state.seed = result.seed;
          state.keyframeHandsOk = handsPass(result.score, this.threshold);
          state.needsRedo = false;
          delete state.rejectedKeyframe;
        }
        if (state.keyframe) { state.status = "keyframe"; await this.save(); }
      }
      const endPlan = !direct && video?.useEndFrame !== false && (shot.endFrame || this.clipRhythm) ? resolveShotReferences({ shot, cards, maxImages: image.maxReferenceImages ?? 8, previousFrame: state.keyframe, includeSheet }) : undefined;
      if (endPlan) state.referenceManifests!.endFrame = endPlan.manifest;
      const endFramePrompt = endPlan ? this.style.endFrame(promptContext, endPlan) : undefined;
      if (endPlan && endFramePrompt && (!state.endKeyframe || !await exists(this.abs(state.endKeyframe)))) {
        state.endKeyframe = await this.generateStill({
          providerId: image.providerId, modelId: image.modelId, prompt: endFramePrompt,
          ratio: board.aspectRatio, size: image.size, outputDirectory, images: endPlan.images, referenceLabels: this.labels(endPlan.referenceLabels), seed: state.seed,
        });
        delete state.endKeyframeHandsOk;
      }
      if (state.endKeyframe && await exists(this.abs(state.endKeyframe)) && state.endKeyframeHandsOk === undefined) {
        const endScore = await this.scorer.score({
          candidate: this.abs(state.endKeyframe), description: shot.endFrame ?? shot.action, signal: this.deps.signal, ...scoreExtra,
          references: scoreReferences.map(reference => ({ ...reference, path: this.abs(reference.path), role: "character" as const })),
        });
        state.endKeyframeHandsOk = handsPass(endScore, this.threshold);
        state.score = endScore;
        if (!state.endKeyframeHandsOk) {
          const message = `尾帧手或肢体未通过（${endScore.score.toFixed(2)}），不提交视频`;
          if (!state.warnings.includes(message)) state.warnings.push(message);
        }
        await this.save();
      }
      if (!shotDone) state.prompts = { firstFrame: firstFramePrompt, video: "", endFrame: endFramePrompt };  // v5run fix: keep recorded prompts of finished shots
      if (this.options.stopAfter === "keyframes" || !video) { previous = { segmentId: segment.id, shotId: shot.id, state }; continue; }
      if (state.endKeyframeHandsOk === false) {
        state.needsRedo = true;
        state.status = "failed";
        previous = undefined;
        await this.save();
        continue;
      }

      // 2. 视频：首帧（+尾帧）驱动或多参考图驱动；FFmpeg 审片不过则换种子重试
      if (!state.video || !await exists(this.abs(state.video))) {
        let accepted: { file: string; review: ReviewResult; seed: number; score?: ScoreResult } | undefined;
        let best: typeof accepted;
        // v5.2.5：接力镜头（首帧 = 上一镜尾帧）缺省按首帧模式提交，保证姿势、道具、门的样子从上一条直接接上
        const chainedFrame = !!state.chainedFrom && (this.options.chainedVideoInput ?? "firstFrame") === "firstFrame";
        const branch: "direct" | "reference" | "frames" = direct && !state.chainedFrom ? "direct"
          : video.input === "reference" && !chainedFrame ? "reference" : "frames";
        // 首尾帧能否与参考图同请求：ai& 不能（网关限制），其他供应商缺省可以
        const mixFrames = video.framesWithReferences ?? video.providerId !== "aiand";
        // v5.2.5：续接上下文真正接进视频请求（v5.2.4 里 continuationContext() 定义了但没有任何地方调用）
        const continuation = branch !== "frames" || mixFrames
          ? await this.continuationContext(shot, segment.id, sameSegment ? previous : undefined, outputDirectory, cards) : undefined;
        const tailFrames = continuation ? continuation.frames.map((path, frame) => ({ path, label: continuation.frameLabels[frame]! })) : undefined;
        if (branch === "frames" && state.chainedFrom && video.input === "reference") this.log(`${shot.id} 接力镜头改用首帧模式提交（chainedVideoInput=firstFrame）`);
        const nextIndex = pack ? segment.shots.findIndex(item => item.id === pack.shots.at(-1)!.id) + 1 : index + 1;
        const nextShot = segment.shots[nextIndex] ?? (this.options.chainAcrossSegments && followingSegment?.sceneId === segment.sceneId ? followingSegment.shots[0] : undefined);
        const handoff = this.handoffNote(board, shot, nextShot, sameSegment ? previous?.shotId : undefined, cards, chainOn);
        for (let attempt = 0; attempt < this.maxAttempts; attempt++) {
          const seed = attempt === 0 ? state.seed ?? baseSeed : nextSeed(state.seed ?? baseSeed, attempt);
          const seconds = this.options.preview?.seconds ?? pack?.seconds ?? shot.seconds ?? 5;
          const frameVideo = branch === "frames";
          const clipPrompt = {
            internalCuts: pack?.plannedCuts,
            followingShots: pack && pack.plannedCuts > 0 ? pack.shots.slice(1).map(item => ({
              seconds: item.seconds, action: item.action, dialogue: item.dialogue?.map(line => ({ speaker: line.speaker, text: line.text })),
            })) : undefined,
            voiceReferences: frameVideo ? undefined : (this.voiceAudios().length || undefined),
          };
          const request: MediaGenerationRequest = {
            // 首帧模式不挂角色参考图，视频提示词中不能出现“图N”指代
            providerId: video.providerId, modelId: video.modelId, prompt: "", ratio: board.aspectRatio,
            duration: seconds, resolution: this.options.preview?.resolution ?? video.resolution, generateAudio: video.generateAudio, seed, outputDirectory,
          };
          if (branch === "direct") {
            // 角色锚点/设定表/场景图/上一镜画面（+ 上一镜结尾几帧）直接作为 references（H3 最多 9 张）
            const referencePlan = resolveShotReferences({
              shot, cards, maxImages: video.maxReferenceImages ?? 9, includeSheet: videoSheet,
              sceneImage: scene?.image ? { path: scene.image, name: scene.name } : undefined,
              propImages: shotPropImages(board.props, segment, shot),
              previousFrame, tailFrames,
            });
            state.referenceManifests!.video = referencePlan.manifest;
            state.inputFingerprints = { ...state.inputFingerprints, referenceManifestHash: contentHash(referencePlan.manifest) };
            Object.assign(request, {
              prompt: this.style.video(promptContext, { mode: "reference", seconds, plan: referencePlan, ...clipPrompt }),
              images: referencePlan.images, referenceLabels: this.labels(referencePlan.referenceLabels),
              mode: referencePlan.images.length ? [`imageReference:${referencePlan.images.length}`] : "text",
            });
          } else if (branch === "reference") {
            // 参考图上限含本镜首帧，角色参考少取一张。v5.2.5：同时带场景图、道具图和上一镜结尾几帧（v5.2.4 只带首帧和角色图）
            const referencePlan = prependReference(
              resolveShotReferences({ shot, cards, maxImages: Math.max(0, (video.maxReferenceImages ?? 4) - 1), includeSheet: videoSheet,
                sceneImage: scene?.image ? { path: scene.image, name: scene.name } : undefined,
                propImages: shotPropImages(board.props, segment, shot), tailFrames }),
              state.keyframe!, { role: "other", name: "首帧", note: "本镜开场画面：构图、站位与光线以此为准" } satisfies ReferenceLabel, { kind: "keyframe" });
            state.referenceManifests!.video = referencePlan.manifest;
            state.inputFingerprints = { ...state.inputFingerprints, referenceManifestHash: contentHash(referencePlan.manifest) };
            Object.assign(request, {
              prompt: this.style.video(promptContext, { mode: "reference", seconds, plan: referencePlan, ...clipPrompt }),
              images: referencePlan.images,
              referenceLabels: this.labels(referencePlan.referenceLabels),
              mode: [`imageReference:${referencePlan.images.length}`],
            });
          } else {
            request.firstFrame = { path: state.keyframe!, mimeType: imageMimeType(state.keyframe!) };
            if (state.endKeyframe) request.lastFrame = { path: state.endKeyframe, mimeType: imageMimeType(state.endKeyframe) };
            request.mode = state.endKeyframe ? "startEndRequired" : "startFrameOptional";
            request.prompt = this.style.video(promptContext, { mode: state.endKeyframe ? "firstLast" : "firstFrame", seconds, ...clipPrompt });
            if (continuation && mixFrames) {
              // 供应商允许时，首帧之外再挂上一镜结尾几帧 + 角色锚点（v5 原版行为）
              request.images = continuation.images;
              request.referenceLabels = this.labels(continuation.labels);
            } else {
              // ai& 的首尾帧不能和参考图、参考音频放在同一次请求里；接力镜头靠“首帧 = 上一镜尾帧”保证连续
              delete request.images;
              delete request.referenceLabels;
              delete request.audios;
            }
          }
          if (continuation && (branch !== "frames" || mixFrames)) state.continuation = continuation.record;
          else delete state.continuation;
          // 交接说明追加在末尾；ai& 提示词上限 7000 字符，放不下就不加（只记日志）
          if (handoff && request.prompt.length + handoff.length + 1 <= 6950) request.prompt = `${request.prompt}\n${handoff}`;
          else if (handoff && attempt === 0) this.log(`${shot.id} 提示词已接近上限，未追加结尾交接说明`);
          const audios = this.voiceAudios();
          if (audios.length && !request.firstFrame && !request.lastFrame) {
            request.audios = audios;
            if (Array.isArray(request.mode) && request.mode.length < 3) request.mode = [...request.mode, `audioReference:${audios.length}`];
          }
          if (this.options.shotTagInPrompt) request.prompt = `${request.prompt}\n【镜头ID】${shot.id}`;
          state.prompts = { ...state.prompts!, video: request.prompt };
          state.inputFingerprints = { ...state.inputFingerprints, promptHash: contentHash(request.prompt) };
          const activeManifest = state.referenceManifests?.video ?? state.referenceManifests?.keyframe ?? [];
          const referenceFiles = await Promise.all(activeManifest.map(entry => fileFingerprint(this.abs(entry.path)).catch(() => ({ path: entry.path, size: -1, sha256: "missing" }))));
          state.referenceManifests!.fileMetadata = activeManifest.map((entry, index) => ({ ...entry, size: referenceFiles[index]!.size, sha256: referenceFiles[index]!.sha256, source: "local_file" as const }));
          const cardInputs = shot.characters.map(character => cards.get(character.id)).filter(Boolean) as CharacterCard[];
          state.inputFingerprints = { ...buildInputFingerprints({
            bible: this.state.projectBible ?? board.bible ?? null, shotContract: { shot, segment: { sceneId: segment.sceneId, blocking: segment.blocking }, style: board.style },
            characterCards: cardInputs, scene: scene ?? null, props: (board.props ?? []).filter(prop => shot.props?.includes(prop.name) || shot.action.includes(prop.name) || shot.firstFrame.includes(prop.name)),
            references: activeManifest.map((entry, index) => ({ ...entry, file: referenceFiles[index] })), prompt: JSON.stringify(state.prompts ?? {}),
            generatorConfig: { image, video, promptStyle: this.options.promptStyle ?? "h3", h3: this.options.h3 ?? {} }, qaPolicyVersion: "toonflow-qa-v5.1",
          }), referenceFiles };
          let file: string;
          try { file = await this.generate("video", request); }
          catch (error) { state.attempts.push({ stage: "video", seed, error: error instanceof Error ? error.message : String(error) }); throw error; }
          const signals = await detectVideoSignals(this.abs(file), {}, this.ffmpeg, this.deps.signal);
          const spoken = (pack?.shots ?? [shot]).some(item => item.dialogue?.length);
          const review = reviewVideoSignals(signals, { seconds, expectAudio: spoken && !!video.generateAudio, allowedCuts: pack?.plannedCuts ?? 0 });
          // 参考图直驱没有关键帧评分：取视频中段一帧对照角色锚点打分，低于阈值换种子重试
          let score: ScoreResult | undefined;
          if (direct && scoreReferences.length) {
            const probe = file.replace(/\.[^./\\]+$/, "") + "-mid.png";
            await extractFrame(this.abs(file), Math.max(0, (signals.duration || seconds) / 2), this.abs(probe), this.ffmpeg, this.deps.signal);
            score = await this.scorer.score({ candidate: this.abs(probe), description: shot.action, signal: this.deps.signal, ...scoreExtra,
              references: scoreReferences.map(reference => ({ ...reference, path: this.abs(reference.path), role: "character" as const })) });
          }
          state.attempts.push({ stage: "video", seed, file, review, score: score?.score });
          const rank = (item: { review: ReviewResult; score?: ScoreResult }) => (item.score?.score ?? 1) - item.review.issues.length * 0.1;
          const candidate = { file, review, seed, score };
          if (!best || rank(candidate) > rank(best)) best = candidate;
          const consistent = !score || score.score >= this.threshold;
          if (review.ok && consistent) { accepted = candidate; break; }
          this.log(`${shot.id} 视频未通过（第 ${attempt + 1}/${this.maxAttempts} 次）：${[...review.issues.map(issue => issue.message), ...(consistent ? [] : [`角色一致性 ${score!.score.toFixed(2)} 低于阈值 ${this.threshold}${score!.reasons.length ? `（${score!.reasons.slice(0, 2).join("；")}）` : ""}`])].join("；")}`);
        }
        const chosen = accepted ?? best!;
        if (!accepted) state.warnings.push(`视频多次未通过，保留最好的一版：${[...chosen.review.issues.map(issue => issue.message), ...(chosen.score && chosen.score.score < this.threshold ? [`一致性 ${chosen.score.score.toFixed(2)}`] : [])].join("；")}`);
        state.video = chosen.file;
        state.review = chosen.review;
        // v5.2.5：首帧就是上一镜尾帧时，拼接时丢掉本镜第 0 帧，避免同一画面出现两次（顿一下），并触发接缝音频交叉淡化
        if (branch === "frames" && state.chainedFrom) state.trimHeadFrames = 1;
        else delete state.trimHeadFrames;
        if (chosen.score) { state.score = chosen.score; state.seed = chosen.seed; }
        if (!state.keyframe) {
          state.keyframe = posix.join(outputDirectory, "首帧.png");
          await extractFrame(this.abs(state.video), 0, this.abs(state.keyframe), this.ffmpeg, this.deps.signal);
        }
        state.status = "video";
        await this.save();
      }
      // 3. 尾帧提取 + 漂移检查 + 联系表
      state.lastFrame = posix.join(outputDirectory, "尾帧.png");
      await extractLastFrame(this.abs(state.video), this.abs(state.lastFrame), this.ffmpeg, this.deps.signal);
      {
        // 尾帧检查：角色一致性决定能否接力；手指/肢体检查决定能否作为下一镜参考图（空镜也检查手与肢体）
        const drift = await this.scorer.score({ candidate: this.abs(state.lastFrame), description: shot.endFrame ?? shot.action, signal: this.deps.signal, ...scoreExtra,
          references: scoreReferences.map(reference => ({ ...reference, path: this.abs(reference.path), role: "character" as const })) });
        state.chainable = scoreReferences.length ? drift.score >= this.threshold : true;
        state.lastFrameHandsOk = handsPass(drift, this.threshold);
        state.lastFrameTraitsOk = (drift.checks?.traitBleed ?? 1) >= this.threshold;
        if (!state.lastFrameTraitsOk) state.warnings.push(`尾帧角色特征串用 ${drift.checks!.traitBleed!.toFixed(2)}，不作为下一镜续接上下文`);
        if (!state.chainable) state.warnings.push(`尾帧角色一致性 ${drift.score.toFixed(2)} 低于阈值，下一镜不接力尾帧，改为重新出关键帧`);
        if (!state.lastFrameHandsOk) state.warnings.push(`尾帧手指/肢体检查未通过，不作为下一镜参考`);
      }
      state.contactSheet = posix.join(outputDirectory, "联系表.jpg");
      await contactSheet(this.abs(state.video), this.abs(state.contactSheet), { columns: 4, rows: 1, width: Math.round(320 * width / Math.max(width, height)) }, this.ffmpeg, this.deps.signal);
      if (pack && state.video && !this.#countedClips.has(pack.id)) { this.#countedClips.add(pack.id); this.#previewClips++; }
      if (this.options.qaGate === "block" && this.options.shotQa && !state.qaResult) {
        state.qaResult = await this.externalQa(shot, segment.id, state);
        state.repairPlan = routeQaFailure(state.qaResult);
        state.qa = { pass: state.qaResult.status === "pass", issues: [...state.qaResult.hardFailures, ...state.qaResult.softIssues] };
        if (state.qaResult.status !== "pass") this.log(`${shot.id} QA ${state.qaResult.status}：${state.repairPlan.action}`);
      } else if (this.options.qaGate !== "block" && this.options.shotQa) {
        const note = "质检只记录：未运行逐镜硬质检，不挡成片";
        if (!state.warnings.includes(note)) state.warnings.push(note);
      }
      if (this.options.clipBin !== false) {
        const record = await this.clipBin.archive(shot.id, outputDirectory, state, {
          model: video.modelId, parentClipId: state.continuation?.parentClipId ?? (sameSegment ? previous?.state.clipId : undefined),
        }).catch(error => { this.log(`${shot.id} 归档到 Clip Bin 失败：${error instanceof Error ? error.message : String(error)}`); return undefined; });
        if (record) state.clipId = record.clipId;
      }
      state.status = "done";
      previous = { segmentId: segment.id, shotId: shot.id, state };
      await this.save();
    }
    return previous;
  }

  /**
   * v5.2.5：结尾交接与带入状态（追加在视频提示词末尾）。
   * 下一镜要接力时，要求本镜最后一秒不切、停在主角脸清楚可见的画面上；有上一镜时写明从上一镜带过来的位置/道具状态。
   */
  handoffNote(board: Storyboard, shot: Storyboard["episodes"][number]["segments"][number]["shots"][number],
    next: Storyboard["episodes"][number]["segments"][number]["shots"][number] | undefined, previousShotId: string | undefined, cards: Map<string, CharacterCard>, chainOn: boolean) {
    if (this.options.endOnSubject === false) return "";
    const zh = this.style.id === "generic";
    const nameOf = (id: string) => cards.get(id)?.name ?? board.characters.find(item => item.id === id)?.name ?? id;
    const lines: string[] = [];
    const previousShot = previousShotId ? [...iterateShots(board)].find(item => item.shot.id === previousShotId)?.shot : undefined;
    const carried = previousShot ? (previousShot.spatialContract?.endState || previousShot.endFrame || "").trim().slice(0, 300) : "";
    if (carried) lines.push(zh
      ? `承接上一条（同一地点，刚刚结束）：${carried}。人物各自在门/墙的哪一侧、门和道具的状态、手里拿着什么，除非本镜动作改变，否则保持不变。`
      : `Carried over from the previous clip (same place, moments earlier): ${carried}. Keep which side of any door or wall each person is on, door and prop states, and what each hand holds unless this shot's action changes them.`);
    const continuationOn = (this.options.continuation?.mode ?? "never") !== "never";
    const relay = !!next && next.characters.length > 0 && ((chainOn && (next.transition === "continuous" || this.clipRhythm)) || continuationOn);
    if (relay && shot.characters.length) {
      const names = [...new Set(shot.characters.filter(item => next!.characters.some(other => other.id === item.id)).map(item => nameOf(item.id)))];
      const who = (names.length ? names : shot.characters.map(item => nameOf(item.id))).join(zh ? "、" : " and ");
      lines.push(zh
        ? `结尾交接：下一条从本条最后一帧开始。最后一秒不要切镜，停在${who}脸部清楚可见的画面上；道具和手里拿着的东西要看得清；不要停在插入特写、空镜或眼睛大特写上。`
        : `Ending handoff: the next clip starts from this video's final frame. In the last second, do not cut; hold on ${who} with the face clearly visible, and keep props and what each hand holds readable. Do not end on an insert, an empty frame or an extreme close-up of an eye.`);
    }
    return lines.join("\n");
  }

  #clipBin?: ClipBin;
  get clipBin() { return this.#clipBin ??= new ClipBin(this.out, path => this.abs(path), this.ffmpeg, this.deps.signal); }

  /** 续接上下文：上一镜通过检查时取其结尾帧（+ 出场角色锚点）作为参考图。 */
  async continuationContext(shot: Storyboard["episodes"][number]["segments"][number]["shots"][number], segmentId: string,
    previous: { segmentId: string; shotId: string; state: ShotState } | undefined, outputDirectory: string, cards: Map<string, CharacterCard>) {
    const options = this.options.continuation;
    if (!options || options.mode === "never") return undefined;
    const gate = continuationGate(previous?.state, previous?.segmentId === segmentId, options);
    if (!gate.ok) { if (previous?.segmentId === segmentId) this.log(`${shot.id} 不续接上一镜：${gate.reason}`); return undefined; }
    const maxImages = this.options.videoModel?.maxReferenceImages ?? 4;
    const frameCount = Math.max(1, Math.min(options.frames ?? 3, maxImages));
    const anchors = this.options.continuationAnchors === false ? undefined
      : resolveShotReferences({ shot, cards, maxImages: Math.max(0, maxImages - frameCount) });
    const frames = await extractTailFrames(previous!.state.video!, outputDirectory, path => this.abs(path), { ...options, frames: frameCount }, this.ffmpeg, this.deps.signal);
    const frameLabels = tailFrameLabels(frames.length);
    const images = [...(anchors?.images ?? []), ...frames.map(path => ({ path, mimeType: imageMimeType(path) }))];
    const labels: ReferenceLabel[] = [...(anchors?.referenceLabels ?? []), ...frameLabels];
    this.log(`${shot.id} 续接 ${previous!.shotId} 结尾 ${frames.length} 帧（${gate.reason}）`);
    return { images, labels, frames, frameLabels, record: { from: previous!.shotId, frames, parentClipId: previous!.state.clipId } };
  }

  /** 外部逐镜质检（如多模型逐帧手指/特征/连续性检查）。 */
  async externalQa(shot: Storyboard["episodes"][number]["segments"][number]["shots"][number], segmentId: string, state: ShotState) {
    const qa = this.options.shotQa!;
    const info = posix.join(dirname(state.video!), "质检输入.json");
    await this.writeText(info, JSON.stringify({ shotId: shot.id, segmentId, shot, prompts: state.prompts }, null, 2));
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), qa.timeoutMs ?? 20 * 60_000);
    try {
      const [command, ...args] = qa.command;
      const result = await runProcess(command!, [...args, this.abs(state.video!), this.abs(info)], controller.signal);
      const line = result.stdout.trim().split("\n").reverse().find(item => item.trim().startsWith("{"));
      const parsed = line ? JSON.parse(line) as Record<string, unknown> : undefined;
      const unified = normalizeExternalQa(parsed);
      if (unified.status !== "pass") state.warnings.push(`逐帧质检${unified.status}：${[...unified.hardFailures, ...unified.abstentions.map(item => item.reason)].slice(0, 4).join("；")}`);
      this.log(`${shot.id} 逐帧质检${unified.status}${unified.hardFailures.length ? `：${unified.hardFailures.slice(0, 3).join("；")}` : ""}`);
      return unified;
    } catch (error) {
      const reason = error instanceof Error ? error.message : String(error);
      this.log(`${shot.id} 逐帧质检出错：${reason}`);
      return normalizeExternalQa({ status: "abstain", abstentions: [{ source: "external_qa", reason }] });
    } finally { clearTimeout(timer); }
  }

  /** 应用 pick / redo：先归档当前版本，再切换或清空镜头状态（旧版本目录不改动）。 */
  async applyVersioning(board: Storyboard) {
    const known = new Set([...iterateShots(board)].map(({ shot }) => shot.id));
    const shotDir = (id: string) => this.state.shots[id]?.video ? dirname(this.state.shots[id]!.video!) : posix.join(this.out, "镜头", id);
    for (const item of this.options.pick ?? []) {
      const [id, version] = item.split("@");
      if (!id || !known.has(id)) throw new Error(`pick 的镜头 ${item} 不在分镜中`);
      const state = this.state.shots[id];
      if (state?.video && await exists(this.abs(state.video))) {
        const record = await this.clipBin.archive(id, shotDir(id), state, { note: "pick 前自动归档" });
        state.clipId = record.clipId;
      }
      const clip = await this.clipBin.get(`${id}@${version}`);
      if (!clip) throw new Error(`Clip Bin 中没有 ${item}`);
      const target = this.state.shots[id] ??= { status: "pending", attempts: [], warnings: [] };
      target.video = clip.video;
      target.clipId = clip.clipId;
      target.qa = clip.qa;
      target.seed = clip.seed;
      target.status = "done";
      await this.clipBin.update(index => { index.current[id] = clip.clipId; });
      this.log(`${id} 切回版本 ${clip.clipId}`);
    }
    const keep = new Set(this.options.redoKeepKeyframe ?? []);
    for (const id of new Set([...(this.options.redo ?? []), ...keep])) {
      if (!known.has(id)) throw new Error(`redo 的镜头 ${id} 不在分镜中`);
      const state = this.state.shots[id];
      if (!state) continue;
      // 上次 redo 尚未完成（续跑时仍带着同样的 --redo）：不再清空，避免丢进度
      if (state.redoOf && state.status !== "done") continue;
      let archived: string | undefined;
      if (state.video && await exists(this.abs(state.video))) {
        const record = await this.clipBin.archive(id, shotDir(id), state, { note: "redo 前归档" });
        archived = record.clipId;
        this.log(`${id} 重做：当前版本已归档为 ${record.clipId}`);
      }
      const keyframe = keep.has(id) ? { keyframe: state.keyframe, keyframeHandsOk: state.keyframeHandsOk, score: state.score, seed: state.seed, prompts: state.prompts } : undefined;
      for (const field of shotOutputFields) delete (state as unknown as Record<string, unknown>)[field];
      delete state.prompts;
      if (keyframe) Object.assign(state, keyframe);
      state.status = "pending";
      state.redoOf = archived ?? state.redoOf ?? "none";
      state.warnings = state.warnings.filter(item => !/逐帧质检|尾帧/.test(item));
    }
    if (this.options.redo?.length || keep.size || this.options.pick?.length) await this.save();
  }

  async export(board: Storyboard) {
    await this.save("export");
    const stale: string[] = [];
    for (const { segment, shot } of iterateShots(board)) {
      const state = this.state.shots[shot.id];
      if (!state?.video) continue;
      if (this.options.qaGate === "block" && this.options.shotQa && state.qaResult?.status !== "pass") stale.push(`${shot.id}: QA ${state.qaResult?.status ?? "missing"}，禁止自动进入最终成片`);
      const expected = state.inputFingerprints as unknown as Record<string, unknown> | undefined;
      if (!expected || !expected.projectBibleHash || !expected.generatorConfigHash || !expected.qaPolicyVersion) { stale.push(`${shot.id}: 缺少完整 v5 输入指纹`); continue; }
      const manifest = state.referenceManifests?.video ?? state.referenceManifests?.keyframe ?? [];
      const files = await Promise.all(manifest.map(entry => fileFingerprint(this.abs(entry.path)).catch(() => ({ path: entry.path, size: -1, sha256: "missing" }))));
      const cards = await Promise.all(shot.characters.map(async character => {
        const path = this.state.artifacts.cards[character.id];
        return path && await exists(this.abs(path)) ? this.readJson(path) : null;
      }));
      const scene = board.scenes.find(item => item.id === segment.sceneId);
      const props = (board.props ?? []).filter(prop => shot.props?.includes(prop.name) || shot.action.includes(prop.name) || shot.firstFrame.includes(prop.name));
      const prompt = JSON.stringify(state.prompts ?? {});
      const current = buildInputFingerprints({ bible: this.state.projectBible ?? board.bible ?? null, shotContract: { shot, segment: { sceneId: segment.sceneId, blocking: segment.blocking }, style: board.style }, characterCards: cards,
        scene: scene ?? null, props, references: manifest.map((entry, index) => ({ ...entry, file: files[index] })), prompt,
        generatorConfig: { image: this.options.imageModel, video: this.options.videoModel, promptStyle: this.options.promptStyle ?? "h3", h3: this.options.h3 ?? {} }, qaPolicyVersion: "toonflow-qa-v5.1" });
      const compare = compareFingerprints(expected, current);
      const expectedFiles = JSON.stringify(expected.referenceFiles ?? []);
      if (!compare.fresh || expectedFiles !== JSON.stringify(files)) stale.push(`${shot.id}: 输入已变化（${[...compare.stale, ...(expectedFiles !== JSON.stringify(files) ? ["referenceFiles"] : [])].join(", ")}）`);
    }
    if (stale.length) throw new Error(`检测到过期镜头，已阻止导出，需重新生成或人工确认：${stale.join("；")}`);
    const videos: string[] = [];
    const clips: { file: string; trimHeadFrames?: number; segmentId?: string; edgeHeadSeconds?: number; edgeTailSeconds?: number }[] = [];
    for (const { segment, shot } of iterateShots(board)) {
      const file = this.state.shots[shot.id]?.video;
      if (file) { videos.push(this.abs(file)); clips.push({ file: this.abs(file), trimHeadFrames: this.state.shots[shot.id]?.trimHeadFrames, segmentId: segment.id }); }
    }
    if (videos.length) {
      const master = this.options.master || undefined;
      let [width, height] = ratioSize[board.aspectRatio] ?? [1280, 720];
      if (master) {
        const portrait = height > width;
        width = master.width ?? (portrait ? 1080 : 1920);
        height = master.height ?? (portrait ? 1920 : 1080);
        for (const clip of clips) {
          const probe = await probeMedia(clip.file, this.ffmpeg, this.deps.signal);
          const edges = await speechSafeEdges(clip.file, probe.duration, master.edgeTrimSeconds ?? 0.12, this.ffmpeg, this.deps.signal);
          clip.edgeHeadSeconds = edges.head; clip.edgeTailSeconds = edges.tail;
        }
      }
      this.state.artifacts.final = posix.join(this.out, "成片.mp4");
      const stitchTarget = master ? posix.join(this.out, "成片_未混音.mp4") : this.state.artifacts.final;
      if (this.options.stitch === false) await concatVideos(videos, this.abs(stitchTarget), { width, height }, this.ffmpeg, this.deps.signal);
      else {
        const { plans } = await stitchVideos(clips, this.abs(stitchTarget), { ...this.options.stitch, width, height, ...(master ? { fps: master.fps ?? 24, crf: 18 } : {}) }, this.ffmpeg, this.deps.signal);
        const adjusted = plans.filter(plan => plan.gain !== 1 || plan.trimHeadFrames || plan.audioCrossfade);
        this.log(`接缝处理：${adjusted.length ? adjusted.map(plan => `#${plan.index + 1}${plan.gain !== 1 ? ` 亮度×${plan.gain.toFixed(3)}` : ""}${plan.trimHeadFrames ? ` 裁头${plan.trimHeadFrames}帧` : ""}${plan.audioCrossfade ? ` 音频交叉${Math.round(plan.audioCrossfade * 1000)}ms` : ""}`).join("，") : "无需调整"}`);
      }
      if (master) {
        const raw = await probeMedia(this.abs(stitchTarget), this.ffmpeg, this.deps.signal);
        const { measured } = await masterFilm(this.abs(stitchTarget), this.abs(this.state.artifacts.final), raw.duration, master, this.ffmpeg, this.deps.signal);
        const trimmed = clips.filter(clip => clip.edgeHeadSeconds || clip.edgeTailSeconds).length;
        this.log(`母版：${width}×${height} ${master.fps ?? 24}fps，${trimmed} 段首尾按静音多剪，底噪 ${master.bedDb === null ? "关" : `${master.bedDb ?? -40} dBFS`}，响度 ${measured?.input_i ?? "?"} → ${master.targetLufs ?? -15} LUFS（真峰值 ≤ ${master.truePeak ?? -1.5} dBTP）`);
      }
      this.state.artifacts.finalContactSheet = posix.join(this.out, "成片联系表.jpg");
      await contactSheet(this.abs(this.state.artifacts.final), this.abs(this.state.artifacts.finalContactSheet), { columns: 6, rows: Math.min(6, Math.ceil(videos.length / 2) + 1) }, this.ffmpeg, this.deps.signal);
      const probe = await probeMedia(this.abs(this.state.artifacts.final), this.ffmpeg, this.deps.signal);
      this.log(`成片导出完成：${probe.duration.toFixed(1)} 秒`);
    }
    this.state.artifacts.report = await this.writeText(posix.join(this.out, "报告.md"), renderReport(this.state, board));
  }
}

/** 严格关键帧：重试用完仍低于阈值 */
export class KeyframeRejectedError extends Error {
  constructor(message: string, readonly best: { file: string; score: ScoreResult; seed: number }) { super(message); this.name = "KeyframeRejectedError"; }
}

export function renderReport(state: RunState, board: Storyboard) {
  const lines = [`# ${board.title} · 一键成片报告`, "", `- 运行 ID：${state.runId}`, `- 状态：${state.status}`, `- 成片：${state.artifacts.final ?? "（未导出）"}`, ""];
  if (state.spend?.entries.length) lines.push(`- 花费（按报价估算）：$${state.spend.usd.toFixed(3)}（${state.spend.entries.filter(entry => entry.status === "charged").length} 次成功计费${state.spend.entries.some(entry => entry.status === "uncertain") ? "，含无法确认是否扣费的请求" : ""}）`, "");
  lines.push("## 质量门", "");
  for (const gate of state.gates ?? []) lines.push(`- ${gate.ok ? "✅" : gate.severity === "error" ? "❌" : "⚠️"} ${gate.label}${gate.ok ? "" : `：${gate.details.slice(0, 5).join("；")}`}`);
  lines.push("", "## 镜头", "", "| 镜头 | 秒 | 角色 | 种子 | 一致性 | 审片 | 尝试 | 备注 |", "|---|---|---|---|---|---|---|---|");
  for (const { shot } of iterateShots(board)) {
    const item = state.shots[shot.id];
    const review = item?.review ? (item.review.ok ? "通过" : "未通过") + (item.review.issues.length ? `（${item.review.issues.map(issue => issue.message).join("；")}）` : "") : "-";
    lines.push(`| ${shot.id} | ${shot.seconds ?? "-"} | ${shot.characters.map(character => character.id).join("、") || "空镜"} | ${item?.seed ?? "-"} | ${item?.score ? item.score.score.toFixed(2) : "-"} | ${review} | ${item?.attempts.length ?? 0} | ${(item?.warnings ?? []).join("；").replace(/\|/g, "/")} |`);
  }
  return lines.join("\n") + "\n";
}

export const problemSceneGuard = "Insect-scale macro setting made only of natural plants, bark, soil, water and light: no furniture, no human-made objects, and no animals or insects other than the characters in this shot.";

/** 执行（或续跑）一次一键成片。 */
export async function runAutoflow(options: AutoflowOptions, deps: AutoflowDeps, runId: string = crypto.randomUUID()): Promise<RunState> {
  const outputDirectory = options.outputDirectory ?? posix.join("一键成片", runId);
  const statePath = join(deps.cwd, outputDirectory, "run.json");
  const existing = await readFile(statePath, "utf8").then(text => JSON.parse(text) as RunState, () => undefined);
  const run = new Run({ ...options, outputDirectory }, deps, runId, existing);
  try {
    await run.save("start");
    let script = "";
    let plan: CastPlan;
    if (options.storyboard && existing?.artifacts.cast === undefined) {
      const parsed = parseStoryboard(options.storyboard);
      if (!parsed.ok) throw new Error(`传入的分镜无效：${parsed.errors.join("；")}`);
      const cards: CharacterCard[] = [];
      for (const character of parsed.data.characters) {
        if (!character.card) throw new Error(`直接传入分镜时，角色 ${character.id} 必须提供 card 路径`);
        cards.push(characterCardSchema.parse(JSON.parse(await readFile(join(deps.cwd, character.card), "utf8"))));
      }
      plan = { title: parsed.data.title, style: parsed.data.style, characters: cards, scenes: parsed.data.scenes };
    } else {
      script = await run.script();
      plan = await run.cast(script);
    }
    // 先做免费的分镜规划，规划失败时还没花钱
    await run.storyboard(script, plan, new Map(plan.characters.map(card => [card.id, card] as const)), false);
    if (options.stopAfter === "storyboard") { run.state.status = "stopped"; await run.save("storyboard"); return run.state; }
    run.preflight("角色与场景", await run.estimateCast(plan));
    const cards = await run.cards(plan);
    await run.sceneImages(plan, plan.style);
    if (options.stopAfter === "characters") { run.state.status = "stopped"; await run.save("characters"); return run.state; }
    const board = await run.storyboard(script, plan, cards);
    await run.propImages(board);
    await run.applyVersioning(board);
    run.preflight("镜头", run.estimateShots(board));
    await run.shots(board, cards);
    if (options.stopAfter === "keyframes" || !options.videoModel) { run.state.status = "stopped"; run.state.artifacts.report = await run.writeText(posix.join(run.out, "报告.md"), renderReport(run.state, board)); await run.save("keyframes"); return run.state; }
    await run.export(board);
    run.state.status = "done";
    run.log("完成");
    run.state.artifacts.report = await run.writeText(posix.join(run.out, "报告.md"), renderReport(run.state, board));
    await run.save("done");
    return run.state;
  } catch (error) {
    const aborted = deps.signal?.aborted === true;
    run.state.status = aborted ? "stopped" : "failed";
    run.state.error = aborted ? "已手动停止，可用同一 runId 续跑" : error instanceof Error ? error.message : String(error);
    run.log(`${aborted ? "已停止" : "失败"}：${run.state.error}`);
    await run.save().catch(() => {});
    throw Object.assign(error instanceof Error ? error : new Error(String(error)), { runState: run.state });
  }
}

