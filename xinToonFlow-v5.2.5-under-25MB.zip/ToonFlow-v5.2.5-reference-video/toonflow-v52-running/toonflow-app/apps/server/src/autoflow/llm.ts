/** 文本/视觉模型的最小接口，以及基于用户已配置语言模型的实现。 */
import type { Context } from "@earendil-works/pi-ai";

export interface TextModel {
  /** json：本次期望严格 JSON 输出（OpenAI 兼容网关据此开启 response_format json_object） */
  complete(input: { system: string; prompt: string; images?: { data: string; mimeType: string }[]; signal?: AbortSignal; json?: boolean }): Promise<string>;
}

export interface ModelSelection { providerId: string; modelId: string }

/** 使用设置页中配置的语言模型（与 /api/ai/generate 相同的调用链）。 */
export async function createConfiguredTextModel(selection: ModelSelection): Promise<TextModel> {
  const ai = await import("@/utils/ai");
  const configured = ai.getConfiguredModel(selection.providerId, selection.modelId);
  return {
    async complete({ system, prompt, images = [], signal }) {
      const context: Context = {
        systemPrompt: system,
        messages: [{
          role: "user",
          content: [{ type: "text", text: prompt }, ...images.map(image => ({ type: "image" as const, data: image.data, mimeType: image.mimeType }))],
          timestamp: Date.now(),
        }],
      };
      const stream = ai.streamAi(configured, context, signal ?? new AbortController().signal);
      for await (const _ of stream) { /* 只取最终结果 */ }
      const message = await stream.result();
      if (message.stopReason === "error" || message.stopReason === "aborted") throw new Error(message.errorMessage || "模型请求失败");
      return message.content.filter(part => part.type === "text").map(part => (part as { text: string }).text).join("");
    },
  };
}

export interface OpenAICompatibleOptions {
  baseUrl: string;
  apiKey: string;
  model: string;
  /** JSON 任务使用的 reasoning_effort（Nebius 上 "none" 可关闭思考）；undefined 表示不传 */
  jsonReasoningEffort?: string;
  /** 所有请求（含非 JSON）都带的 reasoning_effort，JSON 任务以 jsonReasoningEffort 为准。看图评分用 "none"：默认思考会耗尽 max_tokens，content 返回 null。 */
  reasoningEffort?: string;
  maxTokens?: number;
  timeoutMs?: number;
  fetch?: typeof fetch;
}

/** Nebius Token Factory（OpenAI 兼容）的缺省地址与推荐模型（模型 ID 区分大小写）。 */
export const nebiusDefaults = {
  providerId: "nebius",
  baseUrl: "https://api.tokenfactory.us-north1.nebius.com/v1",
  model: "moonshotai/Kimi-K3",
  /** 看图一致性评分缺省用 Nemotron 视觉模型（与文本模型共用同一个 Nebius Key）；DeepSeek 也能看图，作为备选 */
  scorerModel: "nvidia/Nemotron-3.5-Super-VL",
  alternativeScorerModel: "deepseek-ai/DeepSeek-V4.1-Flash-1017",
} as const;

/**
 * 解析 Nebius 文本模型凭据：设置页“语言模型”里保存的 nebius 供应商（apiKey / apiUrl）> 环境变量 NEBIUS_API_KEY / NEBIUS_BASE_URL。
 * 只在内存里使用，不写回配置、不打印。
 */
export function resolveNebiusCredentials(saved: { apiKey?: unknown; apiUrl?: unknown; baseUrl?: unknown } = {}, env: Record<string, string | undefined> = process.env) {
  const apiKey = String(saved.apiKey ?? "").trim() || env.NEBIUS_API_KEY?.trim() || "";
  const baseUrl = (String(saved.apiUrl ?? saved.baseUrl ?? "").trim() || env.NEBIUS_BASE_URL?.trim() || nebiusDefaults.baseUrl).replace(/\/+$/, "");
  if (!apiKey) throw Object.assign(new Error("没有 Nebius API Key：请在设置 → 语言模型中添加 Nebius Token Factory，或设置环境变量 NEBIUS_API_KEY"), { status: 401 });
  return { apiKey, baseUrl };
}

type ChatResponse = {
  choices?: { message?: { content?: string | { type?: string; text?: string }[] | null; reasoning?: string | null; reasoning_content?: string | null }; finish_reason?: string }[];
  error?: { message?: string; code?: string | number; type?: string };
  detail?: unknown;
  message?: string;
};

/** 只取最终回答 content（忽略 reasoning / reasoning_content 思考字段），并去掉个别模型内联的 <think>…</think>。 */
export function finalContent(data: ChatResponse) {
  const content = data.choices?.[0]?.message?.content;
  const text = typeof content === "string" ? content
    : Array.isArray(content) ? content.map(part => (typeof part?.text === "string" ? part.text : "")).join("") : "";
  return text.replace(/<think>[\s\S]*?<\/think>/g, "").trim();
}

/** 服务端拒绝 response_format / reasoning_effort 这类可选参数时的特征（不同网关措辞不同，宽松匹配）。 */
function rejectsOptionalParameter(status: number, message: string) {
  return (status === 400 || status === 422) && /response_format|json_object|json mode|reasoning|extra (fields|inputs)|unrecognized|not supported|unsupported/i.test(message);
}

/**
 * 直连 OpenAI 兼容 /chat/completions（用于 Nebius Token Factory）。不输出任何请求头或 Key；错误信息只带状态码与服务端 message。
 * JSON 任务带 response_format {"type":"json_object"}，并按配置带 reasoning_effort；服务端不支持时自动去掉这些可选参数重试一次，
 * 之后的请求不再携带（靠提示词 + extractJson 容错）。
 */
export function createOpenAICompatibleTextModel(options: OpenAICompatibleOptions): TextModel {
  const request = options.fetch ?? fetch;
  const url = `${options.baseUrl.replace(/\/+$/, "")}/chat/completions`;
  let jsonExtras = true;
  const redact = (value: string) => options.apiKey ? value.replaceAll(options.apiKey, "••••••") : value;
  return {
    async complete({ system, prompt, images = [], signal, json }) {
      // 图片以 data URI 的 image_url 发送（Nebius 的 DeepSeek-V4.1-Flash / Nemotron-3.5-Super-VL 均支持）
      const content = images.length
        ? [{ type: "text", text: prompt }, ...images.map(image => ({ type: "image_url", image_url: { url: `data:${image.mimeType};base64,${image.data}` } }))]
        : prompt;
      const baseTokenLimit = options.maxTokens ?? Number(process.env.TOONFLOW_LLM_MAX_TOKENS || 32000);
      const tokenCap = Math.max(baseTokenLimit, Number(process.env.TOONFLOW_LLM_MAX_TOKENS_CAP || 64000));
      const send = async (withExtras: boolean, tokenLimit = baseTokenLimit) => {
        const body: Record<string, unknown> = {
          model: options.model, max_tokens: tokenLimit,
          messages: [{ role: "system", content: system }, { role: "user", content }],
        };
        if (process.env.TOONFLOW_LLM_STREAM === "1" && !options.fetch) body.stream = true;
        if (withExtras) {
          if (json) body.response_format = { type: "json_object" };
          const effort = json ? options.jsonReasoningEffort ?? options.reasoningEffort : options.reasoningEffort;
          if (effort) body.reasoning_effort = effort;
        }
        const timeout = AbortSignal.timeout(options.timeoutMs ?? Number(process.env.TOONFLOW_LLM_TIMEOUT_MS || 300_000));
        const response = await request(url, {
          method: "POST", headers: { Authorization: `Bearer ${options.apiKey}`, "Content-Type": "application/json" },
          body: JSON.stringify(body), signal: signal ? AbortSignal.any([signal, timeout]) : timeout,
        });
        if (body.stream && response.ok && response.body) {
          // SSE streaming keeps long model generations alive (some gateways close idle non-streamed sockets).
          const reader = response.body.getReader(); const decoder = new TextDecoder();
          let buffer = "", content = "", reasoning = "", finish: string | undefined;
          for (;;) {
            const { done, value } = await reader.read();
            if (value) buffer += decoder.decode(value, { stream: true });
            let index: number;
            while ((index = buffer.indexOf("\n")) >= 0) {
              const line = buffer.slice(0, index).trim(); buffer = buffer.slice(index + 1);
              if (!line.startsWith("data:")) continue;
              const payload = line.slice(5).trim();
              if (!payload || payload === "[DONE]") continue;
              try {
                const chunk = JSON.parse(payload) as { choices?: { delta?: { content?: string; reasoning_content?: string; reasoning?: string }; finish_reason?: string }[] };
                const choice = chunk.choices?.[0];
                if (choice?.delta?.content) content += choice.delta.content;
                if (choice?.delta?.reasoning_content || choice?.delta?.reasoning) reasoning += choice.delta.reasoning_content ?? choice.delta.reasoning ?? "";
                if (choice?.finish_reason) finish = choice.finish_reason;
              } catch { /* ignore keep-alive / partial lines */ }
            }
            if (done) break;
          }
          const data = { choices: [{ message: { content, reasoning_content: reasoning || undefined }, finish_reason: finish }] } as unknown as ChatResponse;
          return { response, data, message: "" };
        }
        const text = await response.text();
        let data: ChatResponse = {};
        try { data = JSON.parse(text); } catch { /* 非 JSON 响应按错误处理 */ }
        const message = redact(String(data.error?.message ?? data.message ?? (typeof data.detail === "string" ? data.detail : data.detail ? JSON.stringify(data.detail) : text)).slice(0, 300));
        return { response, data, message };
      };
      const hasExtras = Boolean(json || options.reasoningEffort);
      // Retry transient network failures / timeouts / 429 / 5xx; never retry a caller abort.
      const sendRetry = async (withExtras: boolean, tokenLimit = baseTokenLimit) => {
        const tries = Number(process.env.TOONFLOW_LLM_RETRIES || 4);
        for (let attempt = 1; ; attempt++) {
          try {
            const r = await send(withExtras, tokenLimit);
            if ((r.response.status === 429 || r.response.status >= 500) && attempt < tries) { await new Promise(res => setTimeout(res, 10_000 * attempt)); continue; }
            return r;
          } catch (error) {
            if (signal?.aborted || attempt >= tries) throw error;
            console.error(`[llm] transient error (attempt ${attempt}/${tries}), retrying: ${error instanceof Error ? error.message : String(error)}`);
            await new Promise(res => setTimeout(res, 10_000 * attempt));
          }
        }
      };
      let tokenLimit = baseTokenLimit;
      let result = await sendRetry(jsonExtras, tokenLimit);
      if (hasExtras && jsonExtras && !result.response.ok && rejectsOptionalParameter(result.response.status, result.message)) {
        jsonExtras = false;
        result = await sendRetry(false, tokenLimit);
      }
      // finish_reason=length means the model consumed the output budget before completing JSON/text.
      // Retry the whole text-only request with a larger output budget; never silently accept a truncated result.
      for (let expansion = 0; result.response.ok && result.data.choices?.[0]?.finish_reason === "length" && tokenLimit < tokenCap && expansion < 2; expansion++) {
        tokenLimit = Math.min(tokenCap, Math.max(tokenLimit + 4096, tokenLimit * 2));
        console.warn(`[llm] finish_reason=length; retrying ${options.model} with max_tokens=${tokenLimit}`);
        result = await sendRetry(jsonExtras, tokenLimit);
      }
      const { response, data, message } = result;
      if (!response.ok) {
        const code = data.error?.code ?? data.error?.type;
        throw Object.assign(new Error(`文本模型请求失败（HTTP ${response.status}${code ? ` ${code}` : ""}）：${message}`), { status: response.status });
      }
      const output = finalContent(data);
      if (!output) {
        const choice = data.choices?.[0];
        const thinking = choice?.message?.reasoning || choice?.message?.reasoning_content;
        throw new Error(`文本模型返回为空（finish_reason=${choice?.finish_reason ?? "?"}${thinking ? "，只有思考内容，可调大 max_tokens 或降低 reasoningEffort" : ""}）`);
      }
      return output;
    },
  };
}
