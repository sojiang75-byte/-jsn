import { Router } from "express";
import { z } from "zod";
import { validateFields } from "@/lib/middleware";
import { success } from "@/lib/responseFormat";
import { stopAutoflow } from "@/autoflow/service";

export default Router().post("/", validateFields({ runId: z.string().regex(/^[A-Za-z0-9_-]{1,64}$/) }), (req, res) => {
  res.json(success({ stopped: stopAutoflow(req.body.runId) }));
});
