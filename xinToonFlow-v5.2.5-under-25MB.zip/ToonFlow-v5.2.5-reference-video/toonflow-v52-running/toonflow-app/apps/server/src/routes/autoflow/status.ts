import { Router } from "express";
import { z } from "zod";
import { validateFields } from "@/lib/middleware";
import { success, errorFromCause } from "@/lib/responseFormat";
import u from "@/utils";
import { autoflowStatus } from "@/autoflow/service";

export default Router().post("/", validateFields({ directory: z.string().min(1).max(4096), runId: z.string().regex(/^[A-Za-z0-9_-]{1,64}$/) }), async (req, res) => {
  try {
    const cwd = await u.workspace.resolveWorkspace(req, req.body.directory);
    res.set("Cache-Control", "no-store").json(success(await autoflowStatus(cwd, req.body.runId)));
  } catch (cause) {
    res.status((cause as { status?: number }).status ?? 400).json(errorFromCause(cause));
  }
});
