import { Router } from "express";

/** 一键成片的极简操作页（无外部资源，所有请求只发往本服务）。 */
const page = `<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Toonflow 一键成片</title><style>
body{font:14px/1.6 system-ui,sans-serif;max-width:960px;margin:24px auto;padding:0 16px;color:#222}
label{display:block;margin:10px 0 4px;font-weight:600}input,select,textarea{width:100%;box-sizing:border-box;padding:6px;font:inherit}
textarea{min-height:120px}.row{display:grid;grid-template-columns:repeat(3,1fr);gap:12px}button{padding:8px 18px;margin:12px 8px 0 0;font:inherit;cursor:pointer}
pre{background:#f5f5f5;padding:12px;white-space:pre-wrap;max-height:420px;overflow:auto}table{border-collapse:collapse;width:100%}td,th{border:1px solid #ddd;padding:4px 6px;font-size:12px}
.warn{color:#b45309}</style></head><body>
<h1>Toonflow 一键成片</h1>
<p class="warn">⚠️ 本服务端口没有登录鉴权，请只在本机或可信内网使用，不要直接暴露到公网。</p>
<label>工作目录（绝对路径；服务器部署时须位于数据目录的 workspaces/ 下）</label><input id="directory" placeholder="/data/workspaces/my-film">
<label>故事 / 梗概</label><textarea id="story" placeholder="一段故事梗概或小说片段"></textarea>
<div class="row"><div><label>语言模型（编剧/分镜）</label><select id="text"></select></div>
<div><label>图片模型</label><select id="image"></select></div><div><label>视频模型（可选）</label><select id="video"><option value="">不生成视频</option></select></div></div>
<div class="row"><div><label>一致性评分</label><select id="scorer"><option value="nebius:nvidia/Nemotron-3.5-Super-VL" selected>Nebius / Nemotron-3.5-Super-VL 看图评分（默认）</option><option value="nebius:deepseek-ai/DeepSeek-V4.1-Flash-1017">Nebius / DeepSeek-V4.1-Flash 看图评分</option><option value="model">用上面的语言模型看图评分（需能看图）</option><option value="none">不评分</option></select></div>
<div><label>画幅</label><select id="ratio"><option>16:9</option><option>9:16</option><option>1:1</option></select></div>
<div><label>目标时长（秒/集）</label><input id="seconds" type="number" value="60"></div></div>
<div class="row"><div><label>提示词风格档</label><select id="promptStyle"><option value="h3">MiniMax H3 官方格式（默认）</option><option value="generic">通用中文分层提示词</option></select></div>
<div><label>H3 角色设定表</label><select id="sheet"><option value="full13">13 视角完整设定表</option><option value="turnaround5">5 视角转面</option><option value="none">不生成</option></select></div>
<div><label>视频驱动方式</label><select id="videoInput"><option value="firstFrame">首帧驱动（镜头衔接好）</option><option value="reference">参考图驱动（角色一致性强）</option><option value="directReference">直接参考图驱动（不出关键帧，省钱）</option></select></div></div>
<p class="warn">MiniMax H3 只有视频接口：选它作“图片模型”时，角色锚点/设定表/关键帧会用最短视频取第 0 帧，每张静帧按一次视频计费；H3 API 不支持固定种子。</p>
<div class="row"><div><label>集数</label><input id="episodes" type="number" value="1" min="1"></div><div><label>固定种子（可选）</label><input id="seed" type="number"></div><div><label>视频花费上限 USD（留空 = 不限制）</label><input id="maxUsd" type="number" step="0.01" min="0" placeholder="不限制"></div>
<div><label>任务 ID（填已有 ID 可续跑）</label><input id="runId" placeholder="自动生成"></div></div>
<label><input type="checkbox" id="mock" style="width:auto"> 演示模式（不调用任何模型，用 FFmpeg 占位素材跑通流程）</label>
<button id="start">开始一键成片</button><button id="stop">停止</button>
<h3>进度</h3><div id="summary"></div><pre id="log">尚未开始</pre>
<script>
const $ = id => document.getElementById(id);
const headers = { "content-type": "application/json", "x-toonflow-workspace": "1" };
const api = async (path, body) => { const r = await fetch(path, body ? { method: "POST", headers, body: JSON.stringify(body) } : { headers }); const j = await r.json(); if (j.code !== 200) throw new Error(j.message + (j.data ? " " + JSON.stringify(j.data) : "")); return j.data; };
const option = (select, value, label) => { const o = document.createElement("option"); o.value = value; o.textContent = label; select.appendChild(o); };
(async () => {
  option($("text"), JSON.stringify({ providerId: "nebius", modelId: "moonshotai/Kimi-K3" }), "Nebius Token Factory / Kimi-K3（Key 取设置页 nebius 或 NEBIUS_API_KEY）");
  try { for (const m of await api("/api/ai/models")) if (!(m.providerId.toLowerCase() === "nebius" && m.modelId === "moonshotai/Kimi-K3")) option($("text"), JSON.stringify({ providerId: m.providerId, modelId: m.modelId }), m.providerLabel + " / " + m.label); } catch (e) { $("log").textContent = "读取语言模型失败：" + e.message; }
  try { for (const m of await api("/api/ai/media/models")) if (m.type === "image" || m.type === "video") { option($(m.type), JSON.stringify({ providerId: m.providerId, modelId: m.modelId }), m.providerLabel + " / " + m.label); if (m.type === "video" && (m.providerId === "minimaxH3" || m.providerId === "aiand")) option($("image"), JSON.stringify({ providerId: m.providerId, modelId: m.modelId }), m.providerLabel + " / " + m.label + "（视频取首帧出图）"); } } catch (e) { $("log").textContent = "读取媒体模型失败：" + e.message; }
  $("directory").value = localStorage.getItem("autoflow.dir") || "";
})();
let timer, current;
async function poll() {
  try {
    const { running, state } = await api("/api/autoflow/status", { directory: $("directory").value, runId: current });
    $("log").textContent = state.log.join("\\n") + (state.error ? "\\n\\n错误：" + state.error : "");
    const rows = Object.entries(state.shots || {}).map(([id, s]) => "<tr><td>" + id + "</td><td>" + s.status + "</td><td>" + (s.score ? s.score.score.toFixed(2) : "-") + "</td><td>" + (s.review ? (s.review.ok ? "通过" : "未通过") : "-") + "</td><td>" + (s.seed ?? "") + "</td></tr>").join("");
    $("summary").innerHTML = "<p>状态：<b>" + state.status + "</b> · 阶段：" + state.stage + (state.artifacts.final ? " · 成片：" + state.artifacts.final : "") + "</p>" + (rows ? "<table><tr><th>镜头</th><th>状态</th><th>一致性</th><th>审片</th><th>种子</th></tr>" + rows + "</table>" : "");
    if (!running && state.status !== "running") clearInterval(timer);
  } catch (e) { $("log").textContent = e.message; }
}
$("start").onclick = async () => {
  const parse = id => $(id).value ? JSON.parse($(id).value) : undefined;
  const body = { directory: $("directory").value, story: $("story").value, mock: $("mock").checked, aspectRatio: $("ratio").value,
    targetSeconds: Number($("seconds").value) || undefined, episodes: Number($("episodes").value) || undefined,
    promptStyle: $("promptStyle").value, h3: { sheet: $("sheet").value } };
  if ($("seed").value) body.seed = Number($("seed").value);
  if (Number($("maxUsd").value) > 0) body.budget = { maxUsd: Number($("maxUsd").value) }; // 留空或 0 = 不限制
  if ($("runId").value) body.runId = $("runId").value;
  if (!body.mock) { body.textModel = parse("text"); body.imageModel = parse("image"); if ($("video").value) body.videoModel = { ...parse("video"), input: $("videoInput").value };
    const scorer = $("scorer").value;
    if (scorer === "none") body.scorer = { type: "none" };
    else if (scorer === "model" && body.textModel) body.scorer = { type: "model", ...body.textModel };
    else if (scorer.startsWith("nebius:")) body.scorer = { type: "model", providerId: "nebius", modelId: scorer.slice(7) }; }
  localStorage.setItem("autoflow.dir", body.directory);
  try { const data = await api("/api/autoflow/start", body); current = data.runId; $("runId").value = current; clearInterval(timer); timer = setInterval(poll, 2000); poll(); }
  catch (e) { $("log").textContent = "启动失败：" + e.message; }
};
$("stop").onclick = async () => { if (current) await api("/api/autoflow/stop", { runId: current }); };
</script></body></html>`;

export default Router().get("/", (_req, res) => {
  res.set("Cache-Control", "no-store").set("Content-Security-Policy", "default-src 'self'; script-src 'unsafe-inline'; style-src 'unsafe-inline'").type("html").send(page);
});
