import { Router } from "express";
import { z } from "zod";
import { validateFields } from "@/lib/middleware";
import { success, errorFromCause } from "@/lib/responseFormat";
import u from "@/utils";
import { startAutoflow } from "@/autoflow/service";

/** 启动一键成片（后台运行）；同一 runId 再次启动时从已完成的步骤续跑。 */
export default Router().post("/", validateFields({ directory: z.string().min(1).max(4096) }), async (req, res) => {
  const { directory, ...body } = req.body;
  try {
    const cwd = await u.workspace.resolveWorkspace(req, directory);
    res.json(success(await startAutoflow(cwd, body)));
  } catch (cause) {
    res.status((cause as { status?: number }).status ?? 400).json(errorFromCause(cause));
  }
});
