/**
 * 参考图角色声明：把 images[] 的每一张标成「图N = 谁/做什么用」，并前置到提示词。
 *
 * 思路借鉴 ArcReel lib/prompts/reference_image_numbering.py（AGPL-3.0，此处为独立重写，未复制代码）：
 * 图像模型只认图数组位置，编排层在参考图列表定稿后机械编号一次，并注明每张图只负责什么，
 * 例如上一镜画面「只参考构图与色调」，避免模型把上一镜里的人物外观当作身份来源。
 */
import { z } from "zod";

export const referenceRoles = ["character", "scene", "prop", "previousFrame", "style", "other"] as const;
export type ReferenceRole = (typeof referenceRoles)[number];

export const referenceLabelSchema = z.strictObject({
  role: z.enum(referenceRoles),
  name: z.string().trim().min(1).max(64).optional(),
  note: z.string().trim().min(1).max(200).optional(),
});
export type ReferenceLabel = z.infer<typeof referenceLabelSchema>;

const roleText: Record<ReferenceRole, (name?: string) => string> = {
  character: name => `角色「${name ?? "未命名"}」身份参考：面部、发型、体型、服装与配饰必须与此图一致`,
  scene: name => `场景${name ? `「${name}」` : ""}参考：只参考空间结构、陈设与光线，不引入图中人物`,
  prop: name => `道具${name ? `「${name}」` : ""}参考：外形、材质与颜色保持一致`,
  previousFrame: () => "上一镜画面：只参考构图、机位连续与色调，不作为人物外观来源",
  style: () => "画风参考：只参考线条、上色与质感，不参考内容",
  other: name => `补充参考${name ? `「${name}」` : ""}`,
};

/** 生成「参考图说明」前缀；labels 必须与实际发出的 images 等长同序。 */
export function buildReferenceDeclaration(labels: ReferenceLabel[] | undefined, imageCount: number): string {
  if (!labels?.length) return "";
  if (labels.length !== imageCount) throw new Error(`referenceLabels 数量（${labels.length}）必须与参考图数量（${imageCount}）一致`);
  const lines = labels.map((label, index) => `图${index + 1}：${roleText[label.role](label.name)}${label.note ? `（${label.note}）` : ""}`);
  return `【参考图说明】\n${lines.join("\n")}\n【画面】\n`;
}

export function applyReferenceDeclaration(prompt: string, labels: ReferenceLabel[] | undefined, imageCount: number) {
  const prefix = buildReferenceDeclaration(labels, imageCount);
  return prefix ? `${prefix}${prompt}` : prompt;
}
