/**
 * 角色卡（角色锚点）：一致性的单一事实来源。存放约定：资产目录 `角色/<名称>/card.json`。
 *
 * 设计借鉴（独立重写，未复制代码）：
 * - shuohao-skills `skills/character-refs`（Apache-2.0）：先出「正面全身锚点」文生图，其余视图全部以锚点为参考派生；
 *   派生提示词第一句只写构图改动，一致性清单要短且按视图取层（大头照只写脸/发/上装）。
 * - H3-Character-Sheet-Designer `h3_character_sheet/view_catalog_13.py`（MIT）：用解剖学方向（鼻尖指向画面哪一侧）描述视角。
 * - moyin-creator `character-prompt-service.ts`（AGPL，仅参考思路）：consistencyElements（面部/体型/独特标记）跨阶段不变。
 */
import { z } from "zod";

/** sheet：H3 风格的多视角角色设定表（一张图含多个视角），由锚点派生。 */
export const characterViewIds = ["anchor", "face", "side", "back", "threeQuarter", "sheet"] as const;
export type CharacterViewId = (typeof characterViewIds)[number];

const imagePath = z.string().trim().min(1).max(2048);

export const characterCardSchema = z.strictObject({
  version: z.literal(1),
  id: z.string().trim().min(1).max(64),
  name: z.string().trim().min(1).max(64),
  identity: z.strictObject({
    gender: z.enum(["female", "male", "other"]),
    age: z.number().int().min(0).max(150),
    /** 非人类角色的物种（英文，如 "praying mantis"、"stag beetle"）；缺省为人类，或由外貌描述推断 */
    species: z.string().trim().max(80).optional(),
  }),
  /** 跨所有状态都不变的身份特征 */
  invariant: z.strictObject({
    face: z.string().trim().min(1).max(500),
    hair: z.string().trim().min(1).max(300),
    body: z.string().trim().min(1).max(300),
    marks: z.string().trim().max(300).optional(),
  }),
  /** 造型 / 衍生态：同一个人的不同服装或时期，不是新角色 */
  outfits: z.array(z.strictObject({
    id: z.string().trim().min(1).max(64),
    label: z.string().trim().min(1).max(64),
    upper: z.string().trim().min(1).max(300),
    lower: z.string().trim().max(300).optional(),
    shoes: z.string().trim().max(200).optional(),
    accessories: z.string().trim().max(300).optional(),
    /** 该造型下的标志性记号（覆盖 invariant.marks，如若虫期只有翅芽上的小缺口） */
    marks: z.string().trim().max(300).optional(),
    views: z.partialRecord(z.enum(characterViewIds), imagePath).optional(),
  })).min(1).max(32),
  /** v5 分层资产：身份不变量与 v4 invariant 并存；归一化时优先使用 invariant */
  identityInvariants: z.array(z.string().trim().max(300)).optional(),
  /** 跨集临时状态，例如受伤、湿身、沾血；不可覆盖身份不变量 */
  temporaryState: z.array(z.string().trim().max(300)).optional(),
  /** 声音资产独立于视觉造型 */
  voice: z.object({ voiceId: z.string().trim().max(120).optional(), timbre: z.string().trim().max(300).optional(), language: z.string().trim().max(80).optional(), speakingRate: z.number().min(0.5).max(2).optional() }).optional(),
  style: z.string().trim().max(500).optional(),
  /** 生成视图所用的图像模型（providerId/modelId）；一键成片复用角色卡时据此判断旧视图是否还能用 */
  imageModel: z.string().trim().max(300).optional(),
  negative: z.string().trim().max(1000).optional(),
  seed: z.number().int().min(0).max(2 ** 32 - 1).optional(),
  lora: z.strictObject({ name: z.string().trim().min(1).max(256), weight: z.number().min(0).max(2).default(1) }).optional(),
});
export type CharacterCard = z.infer<typeof characterCardSchema>;

const viewFirstSentence: Record<Exclude<CharacterViewId, "anchor">, string> = {
  sheet: "Character turnaround sheet of the same character on one canvas, left to right: front full body, side full body with the nose pointing to the RIGHT edge, back full body; identical scale and lighting in every view, thin gutters, no text labels.",
  face: "Zoom in to an extreme close-up head-and-shoulders portrait, passport-photo framing: top of the head near the upper edge, chin at the vertical middle, bottom edge cut at the collarbones. Face the camera squarely, nose on the center line, both ears equally visible.",
  side: "Full-body strict side profile: head, chest and toes all point to the RIGHT edge of the image; only the right half of the face is visible; not looking at the camera.",
  back: "Rotate the camera 180 degrees around the character: direct rear full-body view, no face visible, do not turn the head.",
  threeQuarter: "Head-and-shoulders portrait at 45 degrees: the nose points toward the LEFT edge of the image, left ear visible, right ear hidden.",
};

const viewNegative: Record<CharacterViewId, string> = {
  anchor: "three-quarter view, turned body, contrapposto, multiple views, character sheet, turnaround, text, watermark",
  face: "half body, waist, legs, side face, three-quarter view, multiple views, text",
  side: "facing camera, looking at viewer, three-quarter view, multiple views, text",
  back: "face, eyes, buttons, front pockets, looking back, multiple views, text",
  threeQuarter: "full body, frontal face, profile, multiple views, text",
  sheet: "text, labels, captions, watermark, different characters, inconsistent outfit",
};

export function outfitOf(card: CharacterCard, outfitId?: string) {
  const outfit = outfitId ? card.outfits.find(item => item.id === outfitId) : card.outfits[0];
  if (!outfit) throw new Error(`角色「${card.name}」没有造型 ${outfitId}`);
  return outfit;
}

/**
 * 生成某个视图的提示词。anchor 为文生图完整描述；其余视图须挂 anchor 图作参考，只写「改什么」+ 短一致性清单。
 */
/** 是否为非人类角色（写了物种且不是 human/person） */
export function isCreature(card: Pick<CharacterCard, "identity">) {
  const species = card.identity.species?.trim().toLowerCase();
  return !!species && !/^(human|person|man|woman)$/.test(species);
}

const isNone = (text?: string) => !text || /^(none|n\/a|无|没有)$/i.test(text.trim());

/** 非人类角色（昆虫等）的视图提示词：不写发型/服装/人体站姿，改写全身形态、头部微距与体色标记。 */
function buildCreatureViewPrompt(card: CharacterCard, view: CharacterViewId, outfitId?: string) {
  const outfit = outfitOf(card, outfitId);
  const gender = card.identity.gender === "other" ? "" : `${card.identity.gender} `;
  const who = `a single ${gender}${card.identity.species}`;
  const style = card.style ? ` ${card.style}` : "";
  const marks = outfit.marks ?? card.invariant.marks;
  const looks = [`Head: ${card.invariant.face}`, isNone(card.invariant.hair) ? "" : `Head details: ${card.invariant.hair}`, `Body: ${card.invariant.body}`,
    `Current form: ${[outfit.upper, outfit.lower, outfit.accessories].filter(text => !isNone(text)).join("; ")}`, marks ? `Distinctive marks: ${marks}` : ""].filter(Boolean).join(". ");
  const negative = ["human, person, hands, clothing, cartoon, anthropomorphic, extra legs, missing legs, multiple animals, text, watermark",
    view === "anchor" ? "cropped body, multiple views" : "full body, multiple views", card.negative].filter(Boolean).join(", ");
  if (view === "anchor") return {
    prompt: `Photoreal macro reference photo of ${who}, the whole body in frame from antennae to abdomen tip, natural resting pose on a thin green stem, body seen from the side so every leg and the wing edges are clearly visible. ${looks}. Clean softly blurred neutral background, even soft light, anatomically correct with the right number of legs for its species.${style}`,
    negative, ratio: "2:3", requiresAnchor: false, seed: card.seed,
  };
  const first: Partial<Record<CharacterViewId, string>> = {
    face: "Extreme macro close-up of the head only, facing the camera: both compound eyes, the mouthparts and the base of the antennae fill the frame.",
    side: "Full-body strict side view, head pointing to the RIGHT edge of the image.",
    back: "Full-body view from directly behind and slightly above, showing the folded wings and back.",
    threeQuarter: "Macro close-up of the head and front legs at 45 degrees, head pointing toward the LEFT edge of the image.",
    sheet: "Reference sheet of the same individual on one canvas, left to right: side full body, front head close-up, top view; identical scale and lighting, thin gutters, no text labels.",
  };
  const keep = view === "face" || view === "threeQuarter" ? `head shape, eye color and pattern, coloring (${card.invariant.face})` : `body shape, coloring, wings and distinctive marks`;
  return {
    prompt: `${first[view]} Keep it exactly the same individual as in the reference image: ${keep}${marks ? `; ${marks}` : ""}. Clean softly blurred neutral background, photoreal macro detail.${style}`,
    negative, ratio: view === "face" || view === "threeQuarter" ? "4:5" : view === "sheet" ? "16:9" : "2:3", requiresAnchor: true, seed: card.seed,
  };
}

export function buildCharacterViewPrompt(card: CharacterCard, view: CharacterViewId, outfitId?: string) {
  if (isCreature(card)) return buildCreatureViewPrompt(card, view, outfitId);
  const outfit = outfitOf(card, outfitId);
  const who = `a ${card.identity.age}-year-old ${card.identity.gender === "other" ? "person" : card.identity.gender}`;
  const style = card.style ? ` ${card.style}` : "";
  const negative = [viewNegative[view], card.negative].filter(Boolean).join(", ");
  if (view === "anchor") {
    const clothes = [outfit.upper, outfit.lower, outfit.shoes, outfit.accessories].filter(Boolean).join("; ");
    const marks = card.invariant.marks ? ` Distinctive marks: ${card.invariant.marks}.` : "";
    return {
      prompt: `Full-body front view of ${who}, standing naturally: shoulders, hips and feet all square to the camera, nose on the center line of the face, both ears equally visible. Face: ${card.invariant.face}. Hair: ${card.invariant.hair}. Body: ${card.invariant.body}.${marks} Clothing: ${clothes}. Plain seamless white background, even soft key light, head-to-toe framing with space above the head and below the feet.${style}`,
      negative, ratio: "2:3", requiresAnchor: false, seed: card.seed,
    };
  }
  // 大头照 / 45° 只列脸、发、上装：列出下装和鞋会把镜头拉远（shuohao-skills 实测结论）
  const keep = view === "face" || view === "threeQuarter"
    ? `face, hairstyle and upper garment (${outfit.upper})`
    : `face, hairstyle, body shape and the complete outfit`;
  return {
    prompt: `${viewFirstSentence[view]} Keep the character exactly the same person as in the reference image: ${keep}. Plain seamless white background.${style}`,
    negative, ratio: view === "face" || view === "threeQuarter" ? "4:5" : view === "sheet" ? "16:9" : "2:3", requiresAnchor: true, seed: card.seed,
  };
}

/** 给分镜/视频生成取该角色的锚点参考图（优先正面全身锚点，其次正脸）。 */
export function characterReferenceImages(card: CharacterCard, outfitId?: string) {
  const views = outfitOf(card, outfitId).views ?? {};
  return (["anchor", "face"] as const).map(view => views[view]).filter((path): path is string => !!path);
}

/** 该造型的多视角设定表（H3 风格生成），没有则 undefined。 */
export function characterSheetImage(card: CharacterCard, outfitId?: string) {
  return outfitOf(card, outfitId).views?.sheet;
}

/** 写入分镜/视频提示词的短身份描述：只取不变特征与当前造型的上装，避免长清单稀释画面描述。 */
export function characterBrief(card: CharacterCard, outfitId?: string) {
  const outfit = outfitOf(card, outfitId);
  if (isCreature(card)) {
    const marks = outfit.marks ?? card.invariant.marks;
    return `${card.name}（${card.identity.species}；${card.invariant.body}；${outfit.upper}${marks ? `；${marks}` : ""}）`;
  }
  const gender = { female: "女", male: "男", other: "" }[card.identity.gender];
  const invariantText = card.identityInvariants?.length ? `；身份不变量：${card.identityInvariants.join("；")}` : "";
  const temporaryText = card.temporaryState?.length ? `；当前临时状态：${card.temporaryState.join("；")}` : "";
  return `${card.name}（${card.identity.age}岁${gender}；${card.invariant.hair}；${outfit.upper}${card.invariant.marks ? `；${card.invariant.marks}` : ""}${invariantText}${temporaryText}）`;
}

/** 评分用的服装文字：上装/下装/鞋/配饰，供审查服装连续性。 */
export function characterOutfitText(card: CharacterCard, outfitId?: string) {
  const outfit = outfitOf(card, outfitId) as Record<string, unknown>;
  return (["upper", "lower", "shoes", "accessories"] as const).map(key => outfit[key]).filter(value => typeof value === "string" && value.trim()).join("，");
}
