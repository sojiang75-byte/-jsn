import { describe, expect, test } from "bun:test";
import { buildSourceLedger, hydrateStoryboardFromLedger, partitionSourceLedger, repairSourceLedgerAssignments, validateSourceLedger } from "@/autoflow/sourceLedger";
import { normalizeStoryboardEnums } from "@/autoflow/planner";

describe("不可修改的原文账本", () => {
  test("按顺序完整切分原文，原始片段拼接后逐字相同", () => {
    const source = "第一段。\n第二段：“快点，再快点——”\n第三段：“吱——”“老五”“儍X”。";
    const ledger = buildSourceLedger(source);
    expect(ledger.chunks.map(item => item.text).join("")).toBe(source);
    expect(ledger.sourceHash).toHaveLength(64);
  });
  test("区分对白、拟声词与被引用的人名", () => {
    const ledger = buildSourceLedger("他说：“快点，再快点——”。车轮发出“吱——”，他们提到：“老五”，又骂：“儍X”。");
    expect(ledger.quotes.some(item => item.text === "快点，再快点——" && item.kind === "dialogue")).toBe(true);
    expect(ledger.quotes.some(item => item.text === "吱——" && item.kind === "sfx")).toBe(true);
    expect(ledger.quotes.some(item => item.text === "老五" && item.kind === "quoted_text")).toBe(true);
    expect(ledger.quotes.some(item => item.text === "儍X" && item.kind === "dialogue")).toBe(true);
  });
  test("模型漏分配的引号可按原文位置回填，回填内容来自原文而非模型", () => {
    const source = "林夏喊道：“快点，再快点——”。轮胎发出“吱——”。";
    const ledger = buildSourceLedger(source);
    const board: any = { characters: [{ id: "linxia", name: "林夏" }], episodes: [{ segments: [{ shots: [{ id: "E01-01-01", sourceRefs: ledger.chunks.map(item => item.id), quoteAssignments: [] }] }] }] };
    const repaired = repairSourceLedgerAssignments(board, ledger);
    expect(repaired.autoAssignedQuotes).toBe(2);
    expect(validateSourceLedger(board, ledger).ok).toBe(true);
    hydrateStoryboardFromLedger(board, ledger);
    const shot = board.episodes[0].segments[0].shots[0];
    expect(shot.dialogue.map((item: any) => item.text).join("")).toBe("快点，再快点——");
    expect(shot.sfx).toBe("吱——");
    expect(board.episodes[0].segments[0].shots[0].source).toBe(source);
  });
  test("识别未加引号的角色名冒号式对白，并绑定角色 ID", () => {
    const ledger = buildSourceLedger("林夏：快点，再快点——", [{ id: "linxia", name: "林夏" }]);
    expect(ledger.quotes.map(item => item.text).join("")).toBe("快点，再快点——");
    expect(ledger.quotes.every(item => item.speakerHint === "linxia")).toBe(true);
  });

  test("长对白分段分配到相邻镜头后，程序回填片段拼接仍与原句完全一致", () => {
    const sentence = "这是一段比较长的原文对白，需要拆成连续的小片段，再分配到相邻镜头，最后仍然必须逐字一致，而且不能擅自删除任何一个字或改变原来的标点顺序。";
    const source = `他说：“${sentence}”。`;
    const ledger = buildSourceLedger(source);
    const dialogueQuotes = ledger.quotes.filter(item => item.kind === "dialogue");
    expect(dialogueQuotes.length).toBeGreaterThan(1);
    const shots = ledger.chunks.map((chunk, index) => ({
      id: `E01-01-${String(index + 1).padStart(2, "0")}`,
      sourceRefs: [chunk.id],
      quoteAssignments: dialogueQuotes.filter(item => item.start >= chunk.start && item.start < chunk.end).map(item => ({ sourceId: item.id, kind: "dialogue", speaker: "hero" })),
    }));
    const board: any = { characters: [{ id: "hero", name: "Hero" }], episodes: [{ segments: [{ shots }] }] };
    expect(validateSourceLedger(board, ledger).ok).toBe(true);
    hydrateStoryboardFromLedger(board, ledger);
    const combined = board.episodes[0].segments[0].shots.map((shot: any) => (shot.dialogue ?? []).map((line: any) => line.text).join("")).join("");
    expect(combined).toBe(sentence);
  });

  test("多集分配使用连续原文片段，不重复也不丢失", () => {
    const source = "第一集发生追车。第二集进入废纸厂。第三集完成对峙。";
    const ledger = buildSourceLedger(source);
    const parts = partitionSourceLedger(ledger, 3);
    expect(parts).toHaveLength(3);
    expect(parts.flatMap(part => part.chunks).map(item => item.text).join("")).toBe(source);
    expect(parts.flatMap(part => part.quotes.map(item => item.id))).toEqual(ledger.quotes.map(item => item.id));
  });


  test("多集分割不会把同一句长对白拆到不同集", () => {
    const source = `前情交代。角色说：“${"甲".repeat(180)}”。后续追车。`;
    const ledger = buildSourceLedger(source);
    const parts = partitionSourceLedger(ledger, 2);
    const quoteEpisodes = ledger.quotes.map(quote => parts.findIndex(part => part.quotes.some(item => item.id === quote.id)));
    expect(new Set(quoteEpisodes).size).toBe(1);
    expect(parts.flatMap(part => part.chunks).map(item => item.text).join("")).toBe(source);
  });

  test("无引号的角色名冒号台词也进入原文账本并绑定说话人", () => {
    const source = "林夏：快点，再快点——\n陈默：我马上过来。";
    const ledger = buildSourceLedger(source, [{ id: "linxia", name: "林夏" }, { id: "chenmo", name: "陈默" }]);
    expect(ledger.quotes.map(item => item.text)).toEqual(["快点，再快点——", "我马上过来。"]);
    expect(ledger.quotes.map(item => item.speakerHint)).toEqual(["linxia", "chenmo"]);
  });

  test("长对白拆分后仍属于同一原文组，回填后逐字还原", () => {
    const dialogue = "甲".repeat(900) + "，乙".repeat(80);
    const source = `角色喊道：“${dialogue}”`;
    const ledger = buildSourceLedger(source);
    expect(new Set(ledger.quotes.map(item => item.groupId)).size).toBe(1);
    expect(ledger.quotes.length).toBeGreaterThan(1);
    const board: any = { characters: [{ id: "hero", name: "角色" }], episodes: [{ segments: [{ shots: [{ id: "E01-01-01", sourceRefs: ledger.chunks.map(item => item.id), quoteAssignments: [] }] }] }] };
    repairSourceLedgerAssignments(board, ledger);
    expect(validateSourceLedger(board, ledger).ok).toBe(true);
    hydrateStoryboardFromLedger(board, ledger);
    expect(board.episodes[0].segments[0].shots[0].dialogue.map((item: any) => item.text).join("")).toBe(dialogue);
  });
  test("多集原文分配连续、不重叠、不遗漏", () => {
    const source = "第一句。第二句。第三句。第四句。第五句。第六句。";
    const ledger = buildSourceLedger(source);
    const parts = partitionSourceLedger(ledger, 3);
    expect(parts).toHaveLength(3);
    expect(parts.flatMap(part => part.chunks).map(item => item.text).join("")).toBe(source);
    expect(new Set(parts.flatMap(part => part.chunks).map(item => item.id)).size).toBe(ledger.chunks.length);
  });

  test("缺少源文本片段时不静默通过", () => {
    const ledger = buildSourceLedger("第一段。第二段。");
    const board: any = { episodes: [{ segments: [{ shots: [{ id: "E01-01-01", sourceRefs: [ledger.chunks[0].id] }] }] }] };
    expect(validateSourceLedger(board, ledger).ok).toBe(false);
  });
});

describe("分镜枚举规范化", () => {
  test("把竖线候选列表和常见中文运镜映射成单个合法值", () => {
    const input: any = { episodes: [{ segments: [{ shots: [{ camera: "Static Shot|Push In", size: "wide|full", stability: "轻微晃动", transition: "cut|continuous" }] }] }] };
    const normalized: any = normalizeStoryboardEnums(input);
    const shot = normalized.episodes[0].segments[0].shots[0];
    expect(shot.camera).toBe("Static Shot");
    expect(shot.size).toBe("medium");
    expect(shot.stability).toBe("slight-shake");
    expect(shot.transition).toBe("cut");
  });
  test("POV 从运镜字段迁移到镜头视角合同", () => {
    const input: any = { episodes: [{ segments: [{ shots: [{ camera: "POV", characters: [{ id: "hero" }] }] }] }] };
    const normalized: any = normalizeStoryboardEnums(input);
    const shot = normalized.episodes[0].segments[0].shots[0];
    expect(shot.camera).toBe("Static Shot");
    expect(shot.cameraContract).toEqual({ viewpoint: "first_person", subjectCharacterId: "hero" });
  });
});
