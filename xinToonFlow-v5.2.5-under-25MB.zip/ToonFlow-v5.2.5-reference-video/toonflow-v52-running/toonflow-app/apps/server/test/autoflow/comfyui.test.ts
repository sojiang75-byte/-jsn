import { afterAll, beforeAll, describe, expect, test } from "bun:test";
import { readFile } from "node:fs/promises";
import { join } from "node:path";
import { loadMediaProviderSource, validateMediaProviderSource } from "@/utils/media/provider";

/** 本地假 ComfyUI：实现 /upload/image、/prompt、/history、/view，记录收到的工作流。 */
const received: { uploads: { name: string; size: number; fields: Record<string, string> }[]; prompts: any[] } = { uploads: [], prompts: [] };
let server: ReturnType<typeof Bun.serve>;
let fail = false;
beforeAll(() => {
  server = Bun.serve({ port: 0, hostname: "127.0.0.1", async fetch(request) {
    const url = new URL(request.url);
    if (url.pathname === "/upload/image") {
      const form = await request.formData();
      const file = form.get("image") as File;
      received.uploads.push({ name: file.name, size: file.size, fields: { overwrite: String(form.get("overwrite")), subfolder: String(form.get("subfolder")) } });
      return Response.json({ name: file.name, subfolder: "toonflow", type: "input" });
    }
    if (url.pathname === "/prompt") {
      const body = await request.json() as { prompt: any };
      received.prompts.push(body.prompt);
      return Response.json({ prompt_id: `p${received.prompts.length}`, number: 1, node_errors: {} });
    }
    if (url.pathname.startsWith("/history/")) {
      const id = url.pathname.split("/").pop()!;
      const prompt = received.prompts[Number(id.slice(1)) - 1];
      const isVideo = Object.values(prompt).some((node: any) => node.class_type === "SaveVideo");
      if (fail) return Response.json({ [id]: { status: { status_str: "error", completed: false, messages: [["execution_error", { exception_message: "CUDA out of memory" }]] }, outputs: {} } });
      return Response.json({ [id]: { status: { status_str: "success", completed: true }, outputs: { save: { images: [{ filename: isVideo ? "out.mp4" : "out.png", subfolder: "toonflow", type: "output" }] } } } });
    }
    if (url.pathname === "/view") return new Response(new Uint8Array([1, 2, 3, url.searchParams.get("filename")!.length]));
    return new Response("not found", { status: 404 });
  } });
});
afterAll(() => server.stop(true));

async function provider() {
  const source = await readFile(join(import.meta.dir, "../../../../packages/providers/src/media/comfyui.ts"), "utf8");
  validateMediaProviderSource(source);
  return loadMediaProviderSource(source, { baseUrl: `http://127.0.0.1:${server.port}` }, undefined, fetch) as Promise<any>;
}
const png = { type: "base64" as const, data: Buffer.from("fakepng").toString("base64"), mimeType: "image/png" };

describe("ComfyUI 供应商", () => {
  test("文生图：替换提示词/种子/宽高为正确类型，返回二进制图片", async () => {
    const comfy = await provider();
    const assets = await comfy.generateImage({ model: "qwen-image", prompt: "林夏站在收银台后", ratio: "16:9", size: "1K", seed: 4242 });
    expect(assets[0].mediaType).toBe("image");
    expect(assets[0].mimeType).toBe("image/png");
    const workflow = received.prompts.at(-1);
    expect(workflow.sampler.inputs.seed).toBe(4242);
    expect(workflow.positive.inputs.text).toBe("林夏站在收银台后");
    expect(typeof workflow.latent.inputs.width).toBe("number");
    expect(workflow.latent.inputs.width % 16).toBe(0);
    expect(workflow.latent.inputs.width).toBeGreaterThan(workflow.latent.inputs.height);
    expect(JSON.stringify(workflow)).not.toContain("{{");
  });
  test("参考图生图：上传参考图（multipart），未提供的第 3 张参考节点被裁掉", async () => {
    const comfy = await provider();
    const before = received.uploads.length;
    await comfy.generateImage({ model: "qwen-image", prompt: "图1 的角色站在图2 场景中", images: [png, png], seed: 1 });
    expect(received.uploads.length - before).toBe(2);
    expect(received.uploads.at(-1)!.size).toBe(7);
    expect(received.uploads.at(-1)!.fields.subfolder).toBe("toonflow");
    const workflow = received.prompts.at(-1);
    expect(workflow.load1.inputs.image).toContain("toonflow/ref1_");
    expect(workflow.load3).toBeUndefined();
    expect(workflow.positive.inputs.image3).toBeUndefined();
    expect(workflow.positive.inputs.image2).toEqual(["load2", 0]);
  });
  test("超过工作流参考图槽位时报 400", async () => {
    const comfy = await provider();
    await expect(comfy.generateImage({ model: "qwen-image", prompt: "x", images: [png, png, png, png] })).rejects.toThrow("最多支持 3 张");
  });
  test("首帧生视频：帧数为 4k+1，fps/seed 为数字；无首帧时变为文生视频", async () => {
    const comfy = await provider();
    const assets = await comfy.generateVideo({ model: "wan2.2-ti2v-5b", prompt: "镜头缓慢推近", firstFrame: png, duration: 5, ratio: "16:9", resolution: "720p", seed: 9 });
    expect(assets[0].mediaType).toBe("video");
    expect(assets[0].mimeType).toBe("video/mp4");
    let workflow = received.prompts.at(-1);
    expect(workflow.latent.inputs.length).toBe(121);
    expect(workflow.latent.inputs.height).toBe(704);
    expect(workflow.video.inputs.fps).toBe(24);
    expect(workflow.sampler.inputs.seed).toBe(9);
    expect(workflow.latent.inputs.start_image).toEqual(["first", 0]);
    await comfy.generateVideo({ model: "wan2.2-ti2v-5b", prompt: "雨夜街道", duration: 3 });
    workflow = received.prompts.at(-1);
    expect(workflow.first).toBeUndefined();
    expect(workflow.latent.inputs.start_image).toBeUndefined();
  });
  test("首尾帧模型缺尾帧时报错；自定义 API 工作流可用；执行错误透传", async () => {
    const comfy = await provider();
    await expect(comfy.generateVideo({ model: "wan2.2-flf2v-a14b", prompt: "x", firstFrame: png })).rejects.toThrow("首帧和尾帧");
    const custom = await loadMediaProviderSource(await readFile(join(import.meta.dir, "../../../../packages/providers/src/media/comfyui.ts"), "utf8"),
      { baseUrl: `http://127.0.0.1:${server.port}`, imageWorkflow: JSON.stringify({ "3": { class_type: "KSampler", inputs: { seed: "{{seed}}", text: "风格：{{prompt}}" } }, "9": { class_type: "SaveImage", inputs: {} } }) }, undefined, fetch) as any;
    await custom.generateImage({ model: "qwen-image", prompt: "猫", seed: 5 });
    expect(received.prompts.at(-1)["3"].inputs).toEqual({ seed: 5, text: "风格：猫" });
    await expect(loadMediaProviderSource(await readFile(join(import.meta.dir, "../../../../packages/providers/src/media/comfyui.ts"), "utf8"),
      { baseUrl: `http://127.0.0.1:${server.port}`, imageWorkflow: JSON.stringify({ nodes: [] }) }, undefined, fetch).then((p: any) => p.generateImage({ model: "qwen-image", prompt: "x" }))).rejects.toThrow("API 格式");
    fail = true;
    await expect(comfy.generateImage({ model: "qwen-image", prompt: "x" })).rejects.toThrow("CUDA out of memory");
    fail = false;
  });
});
