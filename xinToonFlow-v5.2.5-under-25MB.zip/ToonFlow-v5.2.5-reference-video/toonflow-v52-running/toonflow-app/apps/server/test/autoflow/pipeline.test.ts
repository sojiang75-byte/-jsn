import { describe, expect, test } from "bun:test";
import { mkdtemp, readFile, stat } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { runAutoflow } from "@/autoflow/pipeline";
import { createMockGenerator, createMockScorer, createMockTextModel } from "@/autoflow/mock";
import { probeMedia, systemFfmpeg } from "@/autoflow/media";
import { imageGenerationSchema, videoGenerationSchema } from "@/utils/media/schemas";

describe("一键成片 mock 端到端", () => {
  test("故事 → 剧本 → 角色卡 → 分镜（修复循环）→ 关键帧（低分换种子重试）→ 视频 → 审片 → 成片", async () => {
    const cwd = await mkdtemp(join(tmpdir(), "af-e2e-"));
    const text = createMockTextModel({ brokenFirstStoryboard: true });
    const generator = createMockGenerator(cwd);
    const scorer = createMockScorer([1]);
    const state = await runAutoflow({
      story: "雨夜便利店，店员林夏把伞借给常客陈默。", seed: 1000, promptStyle: "generic", chainContinuous: true,
      imageModel: { providerId: "mock", modelId: "img", maxReferenceImages: 8 },
      videoModel: { providerId: "mock", modelId: "vid", durations: [3, 4, 5, 6], generateAudio: true },
    }, { cwd, text, generate: generator.generate, scorer, ffmpeg: systemFfmpeg, retryDelayMs: 0 }, "t1");

    expect(state.status).toBe("done");
    // 分镜第一次输出编号错误，被质量门打回后修复
    expect(text.calls.filter(call => call === "storyboard").length).toBe(2);

    // 每个请求都能通过真实 /api/ai/media/generate 的参数校验（真实模式走同一套 schema）
    for (const item of generator.requests) {
      const schema = item.mediaType === "image" ? imageGenerationSchema : videoGenerationSchema;
      const parsed = schema.safeParse({ ...item.request, providerId: "apiMart" });
      if (!parsed.success) throw new Error(`${item.request.outputDirectory}: ${parsed.error.message}`);
    }

    const images = generator.requests.filter(item => item.mediaType === "image");
    const videos = generator.requests.filter(item => item.mediaType === "video");
    // 角色锚点先于正脸视图，正脸视图以锚点为参考
    const anchor = images.find(item => item.request.outputDirectory?.endsWith("林夏/default"))!;
    const face = images.filter(item => item.request.outputDirectory?.endsWith("林夏/default"))[1];
    expect(anchor.request.images ?? []).toEqual([]);
    expect(face.request.images?.[0].path).toContain("角色/林夏/default/");

    // 每个关键帧都强制挂了出场角色锚点，且 referenceLabels 与图片等长
    const keyframes = images.filter(item => item.request.outputDirectory?.includes("/镜头/"));
    for (const item of keyframes) {
      expect(item.request.referenceLabels?.length).toBe(item.request.images?.length);
      expect(item.request.referenceLabels?.[0].role).toBe("character");
      expect(typeof item.request.seed).toBe("number");
    }
    // 第一镜关键帧首次评分低于阈值 → 用新种子重试
    const first = keyframes.filter(item => item.request.outputDirectory?.endsWith("E01-01-01"));
    expect(first.length).toBe(2);
    expect(first[0].request.seed).not.toBe(first[1].request.seed);
    // 视频用同镜种子，首帧模式；连续镜头 E01-01-03 不生成关键帧，直接承接上一镜尾帧
    expect(keyframes.some(item => item.request.outputDirectory?.endsWith("E01-01-03"))).toBe(false);
    const third = videos.find(item => item.request.outputDirectory?.endsWith("E01-01-03"))!;
    expect(third.request.firstFrame?.path).toContain("E01-01-03/首帧.png");
    for (const item of videos) expect(item.request.prompt).not.toMatch(/图\d/);
    expect(state.shots["E01-01-03"].chainedFrom).toBe("E01-01-02");

    const final = join(cwd, state.artifacts.final!);
    const probe = await probeMedia(final);
    expect(probe.duration).toBeGreaterThan(10);
    expect(probe.hasAudio).toBe(true);
    const report = await readFile(join(cwd, state.artifacts.report!), "utf8");
    expect(report).toContain("状态：done");
    expect((await stat(join(cwd, "角色/林夏/card.json"))).isFile()).toBe(true);

    // 再次运行同一 runId：所有步骤已完成，不再产生新的生成请求（断点续跑）
    const before = generator.requests.length;
    const again = await runAutoflow({ story: "雨夜便利店，店员林夏把伞借给常客陈默。", seed: 1000, promptStyle: "generic", chainContinuous: true,
      imageModel: { providerId: "mock", modelId: "img" }, videoModel: { providerId: "mock", modelId: "vid", durations: [3, 4, 5, 6], generateAudio: true } },
      { cwd, text, generate: generator.generate, scorer, ffmpeg: systemFfmpeg, retryDelayMs: 0 }, "t1");
    expect(again.status).toBe("done");
    expect(generator.requests.length).toBe(before);
  }, 120_000);

  test("生成失败会重试，致命错误（401）不重试", async () => {
    const cwd = await mkdtemp(join(tmpdir(), "af-e2e-"));
    const generator = createMockGenerator(cwd);
    let calls = 0;
    const flaky = async (...args: Parameters<typeof generator.generate>) => {
      calls++;
      if (calls === 1) throw Object.assign(new Error("网络抖动"), { status: 503 });
      return generator.generate(...args);
    };
    const state = await runAutoflow({ story: "雨夜便利店的故事", imageModel: { providerId: "mock", modelId: "img" }, stopAfter: "keyframes" },
      { cwd, text: createMockTextModel(), generate: flaky, scorer: createMockScorer([]), ffmpeg: systemFfmpeg, retryDelayMs: 0 }, "t2");
    expect(state.status).toBe("stopped");
    expect(calls).toBeGreaterThan(1);

    const cwd2 = await mkdtemp(join(tmpdir(), "af-e2e-"));
    let fatalCalls = 0;
    const fatal = async () => { fatalCalls++; throw Object.assign(new Error("API Key 无效"), { status: 401 }); };
    await expect(runAutoflow({ story: "雨夜便利店的故事", imageModel: { providerId: "mock", modelId: "img" } },
      { cwd: cwd2, text: createMockTextModel(), generate: fatal as any, scorer: createMockScorer([]), ffmpeg: systemFfmpeg, retryDelayMs: 0 }, "t3")).rejects.toThrow("API Key");
    expect(fatalCalls).toBe(1);
    const saved = JSON.parse(await readFile(join(cwd2, "一键成片/t3/run.json"), "utf8"));
    expect(saved.status).toBe("failed");
  }, 60_000);
});
