import { describe, expect, test } from "bun:test";
import { characterCardSchema } from "@/utils/assets/characterCard";
import { buildH3CharacterSheet, createH3PromptStyle, creatureOf, h3CharacterDescription } from "@/autoflow/promptStyles/h3";

const base = { version: 1 as const, id: "x", name: "网姐", outfits: [{ id: "default", label: "日常装", upper: "brown exoskeleton" }] };

describe("非人类角色的设定图提示词", () => {
  test("物种：identity.species 优先，否则从描述推断；人类不受影响", () => {
    const spider = characterCardSchema.parse({ ...base, identity: { gender: "female", age: 2 }, invariant: { face: "eight eyes", hair: "none", body: "plump brown garden spider, round abdomen" } });
    expect(creatureOf(spider)).toBe("garden spider");
    const beetle = characterCardSchema.parse({ ...base, identity: { gender: "male", age: 3, species: "stag beetle" }, invariant: { face: "black head", hair: "none", body: "glossy black, robust" } });
    expect(creatureOf(beetle)).toBe("stag beetle");
    const human = characterCardSchema.parse({ ...base, identity: { gender: "female", age: 30 }, invariant: { face: "oval face", hair: "black bob", body: "slim" } });
    expect(creatureOf(human)).toBeUndefined();
    expect(h3CharacterDescription(human)).toContain("30-year-old woman");
  });

  test("锚点 / 正脸 / 设定表都带“真实物种、无人脸无人类”约束，且不写年龄、女孩、头发", () => {
    const spider = characterCardSchema.parse({ ...base, identity: { gender: "female", age: 2, species: "orb-weaver spider" }, invariant: { face: "eight eyes", hair: "none", body: "plump brown spider", marks: "pale cross on the abdomen" } });
    const style = createH3PromptStyle({ sheet: "turnaround5" });
    const prompts = [style.characterAnchor(spider, "default").prompt, style.characterFace(spider, "default").prompt, buildH3CharacterSheet(spider, "default", { views: ["headFront", "bodyFront", "bodyBack"], face: true }).prompt];
    for (const prompt of prompts) {
      expect(prompt).toContain("no human face");
      expect(prompt).toContain("real orb-weaver spider");
      expect(prompt).not.toMatch(/year-old|\bgirl\b|Hair:|top of the hair|footwear/);
    }
    expect(prompts[2]).toContain("pale cross on the abdomen) is clearly visible");
  });

  test("翅上记号：锚点改俯拍背面；造型 marks 覆盖；无翅若虫加“不要画翅膀”", () => {
    const mantis = characterCardSchema.parse({ version: 1, id: "adao", name: "阿刀", identity: { gender: "male", age: 1, species: "praying mantis" },
      invariant: { face: "triangular head", hair: "none", body: "slender green mantis", marks: "V-shaped notch on the left forewing" },
      outfits: [{ id: "nymph", label: "若虫", upper: "tiny wingless nymph, two small wing buds", marks: "small V-nick on the left wing bud" }, { id: "adult", label: "成虫", upper: "long translucent wings" }] });
    const style = createH3PromptStyle({ sheet: "turnaround5" });
    const adult = style.characterAnchor(mantis, "adult").prompt;
    expect(adult).toContain("top-down view from directly above");
    expect(adult).toContain("wings slightly spread");
    expect(adult).not.toContain("do not draw any wings");
    const nymph = style.characterAnchor(mantis, "nymph").prompt;
    expect(nymph).toContain("small V-nick on the left wing bud");
    expect(nymph).not.toContain("left forewing");
    expect(nymph).toContain("do not draw any wings");
  });

  test("sceneScale insect：昆虫尺度空景，禁家具、人造物、动物和文字", () => {
    const scene = { id: "s", name: "洞口", description: "a hole at a root, a sign hanging above, an ant inside" };
    const insect = createH3PromptStyle({ sceneScale: "insect" }).scene(scene, "macro", "9:16").prompt;
    expect(insect).toContain("insect-scale macro");
    for (const part of ["no furniture", "no human-made objects", "no animals or insects", "no text"]) expect(insect.toLowerCase()).toContain(part);
    expect(createH3PromptStyle({}).scene(scene, "macro", "9:16").prompt).toContain("main furniture");
  });
});
