import { describe, expect, test } from "bun:test";
import { readFile } from "node:fs/promises";
import { join } from "node:path";
import { createOpenAICompatibleTextModel, finalContent, nebiusDefaults, resolveNebiusCredentials } from "@/autoflow/llm";
import { createModelScorer, extractJson, normalizeScore, parseScoreOutput } from "@/autoflow/scoring";
import { makeSolidImage } from "@/autoflow/media";
import { mkdtemp } from "node:fs/promises";
import { tmpdir } from "node:os";
import { autoflowRequestSchema, createTextModel, defaultModelSelections } from "@/autoflow/service";
import { languageProviders, mediaProviders } from "@toonflow/providers";

type Reply = { status?: number; body: unknown };
/** 假的 Nebius 接口：按顺序返回预设响应，记录请求（不发生任何真实网络请求） */
function fakeNebius(replies: Reply[]) {
  const requests: { url: string; auth: string | null; body: any }[] = [];
  const fetcher = (async (url: string, init: RequestInit) => {
    requests.push({ url: String(url), auth: new Headers(init.headers).get("authorization"), body: JSON.parse(String(init.body)) });
    const reply = replies.shift() ?? { body: { choices: [{ message: { content: "{}" }, finish_reason: "stop" }] } };
    return Response.json(reply.body, { status: reply.status ?? 200 });
  }) as unknown as typeof fetch;
  return { requests, fetcher };
}
const ok = (content: unknown, reasoning: string | null = "We need JSON…", finish = "stop") =>
  ({ body: { choices: [{ message: { role: "assistant", content, reasoning }, finish_reason: finish }] } });
const model = (fetcher: typeof fetch, apiKey = "nb-secret") =>
  createOpenAICompatibleTextModel({ baseUrl: nebiusDefaults.baseUrl + "/", apiKey, model: nebiusDefaults.model, jsonReasoningEffort: "none", fetch: fetcher });

describe("Nebius Token Factory 文本模型", () => {
  test("缺省地址与模型 ID（区分大小写）；凭据：保存的配置 > NEBIUS_API_KEY；不再读取 AIAND_API_KEY", () => {
    expect(nebiusDefaults.baseUrl).toBe("https://api.tokenfactory.us-north1.nebius.com/v1");
    expect(nebiusDefaults.model).toBe("moonshotai/Kimi-K3");
    expect(resolveNebiusCredentials({}, { NEBIUS_API_KEY: " k1 " })).toEqual({ apiKey: "k1", baseUrl: nebiusDefaults.baseUrl });
    expect(resolveNebiusCredentials({ apiKey: "saved", apiUrl: "https://gw.example/v1/" }, { NEBIUS_API_KEY: "k1" })).toEqual({ apiKey: "saved", baseUrl: "https://gw.example/v1" });
    expect(resolveNebiusCredentials({}, { NEBIUS_API_KEY: "k1", NEBIUS_BASE_URL: "https://x/v1" }).baseUrl).toBe("https://x/v1");
    expect(() => resolveNebiusCredentials({}, { AIAND_API_KEY: "sk-a" })).toThrow("NEBIUS_API_KEY");
  });

  test("JSON 任务：/chat/completions、Bearer、json_object + reasoning_effort=none；只取 content 不取 reasoning", async () => {
    const { requests, fetcher } = fakeNebius([ok("{\"shots\":[{\"id\":\"s1\"}]}", "思考：{\"shots\":[]} 不应被返回"), ok("纯文本回答", null)]);
    const text = model(fetcher);
    expect(await text.complete({ system: "s", prompt: "p", json: true })).toBe("{\"shots\":[{\"id\":\"s1\"}]}");
    expect(requests[0]!.url).toBe("https://api.tokenfactory.us-north1.nebius.com/v1/chat/completions");
    expect(requests[0]!.auth).toBe("Bearer nb-secret");
    expect(requests[0]!.body).toMatchObject({ model: "moonshotai/Kimi-K3", response_format: { type: "json_object" }, reasoning_effort: "none",
      messages: [{ role: "system", content: "s" }, { role: "user", content: "p" }] });
    expect(await text.complete({ system: "s", prompt: "p" })).toBe("纯文本回答");
    expect(requests[1]!.body.response_format).toBeUndefined();
    expect(requests[1]!.body.reasoning_effort).toBeUndefined();
  });

  test("不支持 json_object / reasoning_effort 时去掉参数重试一次，之后不再携带；围栏 JSON 仍可解析", async () => {
    const { requests, fetcher } = fakeNebius([
      { status: 400, body: { error: { type: "BadRequestError", message: "response_format json_object is not supported for this model" } } },
      ok("好的：\n```json\n{\"shots\":[{\"id\":\"s1\",\"seconds\":4}]}\n```"),
      ok("{\"shots\":[]}"),
    ]);
    const text = model(fetcher);
    const raw = await text.complete({ system: "s", prompt: "p", json: true });
    expect(extractJson(raw)).toEqual({ shots: [{ id: "s1", seconds: 4 }] });
    expect(requests.length).toBe(2);
    expect(requests[1]!.body.response_format).toBeUndefined();
    expect(requests[1]!.body.reasoning_effort).toBeUndefined();
    await text.complete({ system: "s", prompt: "p", json: true });
    expect(requests[2]!.body.response_format).toBeUndefined();
  });

  test("与参数无关的 400 不重试；错误信息不泄露 Key；只有思考没有回答时报错", async () => {
    const { requests, fetcher } = fakeNebius([
      { status: 400, body: { error: { message: "context too long" } } },
      { status: 401, body: { detail: "invalid key nb-secret" } },
      ok("", "thinking… thinking…", "length"),
    ]);
    const text = model(fetcher);
    await expect(text.complete({ system: "s", prompt: "p", json: true })).rejects.toThrow("HTTP 400");
    expect(requests.length).toBe(1);
    const error = await text.complete({ system: "s", prompt: "p" }).catch((e: Error) => e);
    expect(error.message).toContain("HTTP 401");
    expect(error.message).not.toContain("nb-secret");
    await expect(text.complete({ system: "s", prompt: "p" })).rejects.toThrow("finish_reason=length");
  });

  test("content 为分段数组或内联 <think> 时只保留最终回答", () => {
    expect(finalContent({ choices: [{ message: { content: [{ type: "text", text: "{\"a\":" }, { type: "text", text: "1}" }] } }] })).toBe("{\"a\":1}");
    expect(finalContent({ choices: [{ message: { content: "<think>先想想</think>\n{\"a\":1}" } }] })).toBe("{\"a\":1}");
    expect(finalContent({ choices: [{ message: { content: null, reasoning: "{\"a\":1}" } }] })).toBe("");
  });

  test("语言模型预设只有 Nebius/DeepSeek（Nebius 缺省 Kimi-K3），ai& 只作为媒体（视频）供应商；请求体接受 nebius 文本模型", async () => {
    const nebius = languageProviders.find(item => item.id === "nebius")!;
    expect(nebius.apiUrl).toBe(nebiusDefaults.baseUrl);
    expect(nebius.protocol).toBe("openai-completions");
    expect(nebius.models.map(item => item.id)).toEqual([nebiusDefaults.model, nebiusDefaults.scorerModel, nebiusDefaults.alternativeScorerModel]);
    expect(languageProviders.some(item => item.id.toLowerCase().includes("aiand"))).toBe(false);
    const aiand = mediaProviders.find(item => item.id === "aiand")!;
    expect(aiand.models.every(item => item.type === "video")).toBe(true);
    const parsed = autoflowRequestSchema.parse({ story: "海边的小女孩", textModel: { providerId: "nebius", modelId: nebiusDefaults.model, reasoningEffort: "low" } });
    expect(parsed.textModel).toEqual({ providerId: "nebius", modelId: nebiusDefaults.model, reasoningEffort: "low" });
    const ui = await readFile(join(import.meta.dir, "../../src/routes/autoflow/ui.ts"), "utf8");
    expect(ui).toContain("\"nebius\"");
    expect(ui).toContain('<option value="nebius:nvidia/Nemotron-3.5-Super-VL" selected>');
    expect(ui).toContain('value="nebius:deepseek-ai/DeepSeek-V4.1-Flash-1017"');
    expect(ui.indexOf('providerId: "nebius", modelId: "moonshotai/Kimi-K3"')).toBeGreaterThan(-1);
    expect(ui.indexOf('providerId: "nebius", modelId: "moonshotai/Kimi-K3"')).toBeLessThan(ui.indexOf('api("/api/ai/models")'));
    expect(ui).not.toContain("providerId !== \"nebius\"");
    expect(ui).not.toMatch(/providerId: "aiand", modelId: "deepseek/i);
  });
});

describe("Nebius 看图一致性评分", () => {
  async function images() {
    const dir = await mkdtemp(join(tmpdir(), "nebius-score-"));
    await makeSolidImage(join(dir, "ref.png"), { width: 64, height: 64, color: "0xcc3333" });
    await makeSolidImage(join(dir, "cand.png"), { width: 64, height: 64, color: "0xcc3344" });
    return { ref: join(dir, "ref.png"), candidate: join(dir, "cand.png") };
  }

  test("评分请求：image_url data URI（参考在前、待审在后）、json_object、reasoning_effort=none；只取 content", async () => {
    const { ref, candidate } = await images();
    const { requests, fetcher } = fakeNebius([ok("{\"characters\":{\"小女孩\":0.86},\"artifacts\":0.95,\"reasons\":[\"发色一致\"]}", "{\"characters\":{\"小女孩\":0}}")]);
    const vision = createOpenAICompatibleTextModel({ baseUrl: nebiusDefaults.baseUrl, apiKey: "nb-secret", model: nebiusDefaults.scorerModel,
      reasoningEffort: "none", jsonReasoningEffort: "none", fetch: fetcher });
    const result = await createModelScorer(input => vision.complete(input)).score({ candidate, references: [{ path: ref, name: "小女孩", role: "character" }], description: "海边" });
    expect(result).toMatchObject({ score: 0.86, perCharacter: { 小女孩: 0.86 }, reasons: ["发色一致"], scorer: "model" });
    const body = requests[0]!.body;
    expect(body).toMatchObject({ model: "nvidia/Nemotron-3.5-Super-VL", response_format: { type: "json_object" }, reasoning_effort: "none" });
    const parts = body.messages[1].content;
    expect(parts[0]).toMatchObject({ type: "text" });
    expect(parts.slice(1).map((part: any) => part.type)).toEqual(["image_url", "image_url"]);
    expect(parts[1].image_url.url).toStartWith("data:image/png;base64,");
  });

  test("非 JSON 调用也可强制 reasoning_effort（看图描述），不带 response_format", async () => {
    const { requests, fetcher } = fakeNebius([ok("一个红色方块", null)]);
    const vision = createOpenAICompatibleTextModel({ baseUrl: nebiusDefaults.baseUrl, apiKey: "k", model: nebiusDefaults.model, reasoningEffort: "none", fetch: fetcher });
    expect(await vision.complete({ system: "s", prompt: "描述", images: [{ data: "AAAA", mimeType: "image/png" }] })).toBe("一个红色方块");
    expect(requests[0]!.body.reasoning_effort).toBe("none");
    expect(requests[0]!.body.response_format).toBeUndefined();
  });

  test("宽松解析：百分制/十分制/字符串/数组/大小写空白/单角色单分数/顶层 score；解析失败重试一次", async () => {
    expect(normalizeScore("80%")).toBe(0.8);
    expect(normalizeScore(85)).toBe(0.85);
    expect(normalizeScore(7)).toBe(0.7);
    expect(normalizeScore(" 0.4 ")).toBe(0.4);
    expect(normalizeScore({ score: 0.3 })).toBe(0.3);
    expect(normalizeScore("高")).toBeUndefined();
    expect(parseScoreOutput('{"characters":[{"name":" Lin ","score":"90"}],"artifacts":"1","reasons":"ok"}', ["lin"])).toEqual({ perCharacter: { lin: 0.9 }, artifacts: 1, reasons: ["ok"] });
    expect(parseScoreOutput('{"characters":{"女孩":0.7}}', ["小女孩"]).perCharacter).toEqual({ 小女孩: 0.7 });
    expect(parseScoreOutput('```json\n{"score":0.6}\n```', ["小女孩"]).perCharacter).toEqual({ 小女孩: 0.6 });
    expect(parseScoreOutput('{"characters":{"甲":0.9}}', ["甲", "乙"]).perCharacter).toEqual({ 甲: 0.9, 乙: 0 });
    const { ref, candidate } = await images();
    const outputs = ["我认为很像", "{\"characters\":{\"小女孩\":0.8},\"artifacts\":0.9}"];
    const prompts: string[] = [];
    const scorer = createModelScorer(async input => { prompts.push(input.prompt); expect(input.json).toBe(true); return outputs.shift()!; });
    expect((await scorer.score({ candidate, references: [{ path: ref, name: "小女孩", role: "character" }], description: "" })).score).toBe(0.8);
    expect(prompts[1]).toContain("只输出一个合法 JSON");
  });

  test("服务端：scorer 选 nebius 走 Nebius 客户端，缺省模型 Nemotron，备选 DeepSeek，所有请求 reasoning_effort=none", async () => {
    expect(autoflowRequestSchema.parse({ story: "海边", scorer: { type: "model", providerId: "nebius" } }).scorer).toEqual({ type: "model", providerId: "nebius" });
    const originalFetch = globalThis.fetch;
    const originalKey = process.env.NEBIUS_API_KEY;
    const { requests, fetcher } = fakeNebius([ok("一个红色方块", null), ok("x", null)]);
    globalThis.fetch = fetcher;
    process.env.NEBIUS_API_KEY = "env-key";
    try {
      const vision = await createTextModel({ providerId: "nebius" }, "vision");
      await vision.complete({ system: "s", prompt: "p", images: [{ data: "AAAA", mimeType: "image/png" }] });
      expect(requests[0]!.body).toMatchObject({ model: nebiusDefaults.scorerModel, reasoning_effort: "none" });
      expect(requests[0]!.auth).toBe("Bearer env-key");
      const deepseek = await createTextModel({ providerId: "nebius", modelId: nebiusDefaults.alternativeScorerModel }, "vision");
      await deepseek.complete({ system: "s", prompt: "p" });
      expect(requests[1]!.body.model).toBe("deepseek-ai/DeepSeek-V4.1-Flash-1017");
      expect(requests[1]!.body.reasoning_effort).toBe("none");
    } finally {
      globalThis.fetch = originalFetch;
      if (originalKey === undefined) delete process.env.NEBIUS_API_KEY; else process.env.NEBIUS_API_KEY = originalKey;
    }
  });
});

describe("缺省组合：Kimi-K3 写分镜 + Nemotron 看图评分（同一个 Nebius Key）", () => {
  test("缺省模型与 defaultModelSelections", () => {
    expect(nebiusDefaults.model).toBe("moonshotai/Kimi-K3");
    expect(nebiusDefaults.scorerModel).toBe("nvidia/Nemotron-3.5-Super-VL");
    expect(nebiusDefaults.alternativeScorerModel).toBe("deepseek-ai/DeepSeek-V4.1-Flash-1017");
    expect(defaultModelSelections({})).toEqual({
      text: { providerId: "nebius", modelId: "moonshotai/Kimi-K3" },
      scorer: { type: "model", providerId: "nebius", modelId: "nvidia/Nemotron-3.5-Super-VL" },
    });
    expect(defaultModelSelections({ scorer: { type: "none" } }).scorer).toEqual({ type: "none" });
    expect(defaultModelSelections({ scorer: { type: "model", providerId: "nebius", modelId: nebiusDefaults.alternativeScorerModel } }).scorer)
      .toEqual({ type: "model", providerId: "nebius", modelId: "deepseek-ai/DeepSeek-V4.1-Flash-1017" });
    // 非 Nebius 文本模型不擅自加 Nebius 评分器
    expect(defaultModelSelections({ textModel: { providerId: "deepSeek", modelId: "deepseek-chat" } }).scorer).toBeUndefined();
  });

  test("同一次运行里两个客户端并发使用同一个 Key，各自模型与参数正确", async () => {
    const originalFetch = globalThis.fetch;
    const originalKey = process.env.NEBIUS_API_KEY;
    const requests: { auth: string | null; body: any }[] = [];
    globalThis.fetch = (async (_url: string, init: RequestInit) => {
      const body = JSON.parse(String(init.body));
      requests.push({ auth: new Headers(init.headers).get("authorization"), body });
      await new Promise(resolve => setTimeout(resolve, 5));
      const content = body.model === nebiusDefaults.scorerModel ? "{\"characters\":{\"小女孩\":0.9},\"artifacts\":1}" : "{\"shots\":[{\"id\":\"s1\"}]}";
      return Response.json({ choices: [{ message: { content, reasoning: null }, finish_reason: "stop" }] });
    }) as unknown as typeof fetch;
    process.env.NEBIUS_API_KEY = "shared-key";
    try {
      const { text, scorer } = defaultModelSelections({});
      const writer = await createTextModel(text);
      const vision = await createTextModel(scorer as { providerId: string; modelId?: string }, "vision");
      const [board, score] = await Promise.all([
        writer.complete({ system: "s", prompt: "分镜", json: true }),
        vision.complete({ system: "s", prompt: "评分", json: true, images: [{ data: "AAAA", mimeType: "image/png" }, { data: "BBBB", mimeType: "image/png" }] }),
      ]);
      expect(extractJson(board)).toEqual({ shots: [{ id: "s1" }] });
      expect(parseScoreOutput(score, ["小女孩"]).perCharacter).toEqual({ 小女孩: 0.9 });
      expect(requests.length).toBe(2);
      expect(requests.every(item => item.auth === "Bearer shared-key")).toBe(true);
      const byModel = Object.fromEntries(requests.map(item => [item.body.model, item.body]));
      expect(byModel["moonshotai/Kimi-K3"]).toMatchObject({ response_format: { type: "json_object" }, reasoning_effort: "none", max_tokens: 8000 });
      expect(byModel["nvidia/Nemotron-3.5-Super-VL"]).toMatchObject({ response_format: { type: "json_object" }, reasoning_effort: "none", max_tokens: 2000 });
      expect(byModel["nvidia/Nemotron-3.5-Super-VL"].messages[1].content.filter((part: any) => part.type === "image_url").length).toBe(2);
    } finally {
      globalThis.fetch = originalFetch;
      if (originalKey === undefined) delete process.env.NEBIUS_API_KEY; else process.env.NEBIUS_API_KEY = originalKey;
    }
  });
});
