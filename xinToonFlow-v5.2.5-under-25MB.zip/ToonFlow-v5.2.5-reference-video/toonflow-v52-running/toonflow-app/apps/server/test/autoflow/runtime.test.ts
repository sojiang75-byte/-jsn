import { describe, expect, test } from "bun:test";
import { mkdtemp } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { runAutoflow, runPool } from "@/autoflow/pipeline";
import { normalizeCastReferences } from "@/autoflow/planner";
import { createMockGenerator, createMockTextModel, mockCast, mockStoryboard } from "@/autoflow/mock";
import { systemFfmpeg } from "@/autoflow/media";
import { parseStoryboard } from "@/autoflow/storyboard/schema";

const story = "雨夜便利店，店员林夏把伞借给常客陈默。";
const h3 = { providerId: "aiand", modelId: "minimaxai/minimax-h3" };

describe("并行、限流退避、分阶段停止与参考图直驱评分", () => {
  test("runPool：并行度不超过上限，全部处理；出错时抛出第一个错误", async () => {
    let active = 0, peak = 0;
    const seen: number[] = [];
    await runPool([1, 2, 3, 4, 5, 6, 7], 3, async item => {
      active++; peak = Math.max(peak, active);
      await new Promise(resolve => setTimeout(resolve, 5));
      seen.push(item); active--;
    });
    expect(peak).toBe(3);
    expect(seen.sort()).toEqual([1, 2, 3, 4, 5, 6, 7]);
    await expect(runPool([1, 2, 3], 2, async item => { if (item === 2) throw new Error("boom"); })).rejects.toThrow("boom");
  });

  test("分镜里的造型标签 / 角色名映射回 id，对不上的造型退回第一套", () => {
    const cast = mockCast("雨伞");
    const raw = mockStoryboard(false) as any;
    const shot = raw.episodes[0].segments[0].shots[0];
    shot.characters = [{ id: "林夏", outfit: "便利店制服" }, { id: "chenmo", outfit: "孵化" }];
    shot.dialogue = [{ speaker: "陈默", text: "你好" }, { speaker: "narrator", text: "旁白" }];
    const parsed = parseStoryboard({ version: 1, title: "雨伞", style: cast.style, characters: cast.characters.map(c => ({ id: c.id, name: c.name })), scenes: cast.scenes, ...raw });
    expect(parsed.ok).toBe(true);
    const board = normalizeCastReferences((parsed as any).data, cast as any);
    const fixed = board.episodes[0]!.segments[0]!.shots[0]!;
    expect(fixed.characters).toEqual([{ id: "linxia", outfit: "default" }, { id: "chenmo", outfit: "default" }]);
    expect(fixed.dialogue!.map(line => line.speaker)).toEqual(["chenmo", "narrator"]);
  });

  test("stopAfter storyboard 不花钱；characters 只出角色/场景；去掉 stopAfter 续跑：429 退避不占重试次数、并行段落、直驱评分低分重试", async () => {
    const cwd = await mkdtemp(join(tmpdir(), "af-runtime-"));
    const generator = createMockGenerator(cwd);
    let throttled = 0, active = 0, peak = 0;
    const generate: typeof generator.generate = async (mediaType, request) => {
      // 前两次视频提交返回 429（并发数到上限）
      if (mediaType === "video" && request.outputDirectory?.includes("/镜头/") && throttled < 2) {
        throttled++;
        throw Object.assign(new Error("ai& 正在渲染的任务数已达套餐上限（HTTP 429 concurrency_limit_exceeded）"), { status: 429, code: "concurrency_limit_exceeded" });
      }
      active++; peak = Math.max(peak, active);
      try { await new Promise(resolve => setTimeout(resolve, 20)); return await generator.generate(mediaType, request); }
      finally { active--; }
    };
    const text = createMockTextModel();
    const options = (stopAfter?: "storyboard" | "characters") => ({
      story, seed: 3, stopAfter, concurrency: 2, maxAttempts: 2,
      imageModel: { ...h3, maxReferenceImages: 9, stillFromVideo: { duration: 4 } },
      videoModel: { ...h3, durations: [4, 5, 6], generateAudio: true, input: "directReference" as const, maxReferenceImages: 9 },
    });
    // 第一张视频中段帧给低分 → 该镜重拍一次；其余高分
    let lowGiven = false;
    const scorer = { id: "t", async score(input: { candidate: string }) {
      const low = !lowGiven && input.candidate.endsWith("-mid.png");
      if (low) lowGiven = true;
      const value = low ? 0.35 : 0.92;
      return { score: value, perCharacter: {}, reasons: low ? ["翅膀缺口不见了"] : [], scorer: "t" };
    } };
    const deps = { cwd, text, generate, scorer, ffmpeg: systemFfmpeg, retryDelayMs: 0, throttleDelayMs: 0 };

    const planned = await runAutoflow(options("storyboard"), deps, "r1");
    expect(planned.status).toBe("stopped");
    expect(planned.artifacts.storyboard).toBeTruthy();
    expect(generator.requests.length).toBe(0);

    const characters = await runAutoflow(options("characters"), deps, "r1");
    expect(characters.status).toBe("stopped");
    expect(Object.keys(characters.artifacts.cards).length).toBe(2);
    expect(generator.requests.every(item => !item.request.outputDirectory?.includes("/镜头/"))).toBe(true);
    expect(peak).toBe(2); // 两个角色并行出图
    const before = generator.requests.length;

    const state = await runAutoflow(options(), deps, "r1");
    expect(state.status).toBe("done");
    expect(throttled).toBe(2);
    // 429 没有消耗 maxAttempts（=2）：所有镜头都完成
    for (const shot of Object.values(state.shots)) expect(shot.status).toBe("done");
    expect(state.spend!.entries.filter(entry => entry.status === "free").length).toBe(2);
    expect(state.log.some(line => line.includes("提交被限流"))).toBe(true);
    // 直驱：低分镜头被重拍，记录了视频阶段的评分
    const videoAttempts = Object.values(state.shots).flatMap(shot => shot.attempts.filter(attempt => attempt.stage === "video"));
    expect(videoAttempts.some(attempt => attempt.score === 0.35)).toBe(true);
    expect(generator.requests.length - before).toBe(Object.keys(state.shots).length + 1);
    const retried = Object.values(state.shots).find(shot => shot.attempts.some(attempt => attempt.score === 0.35))!;
    expect(retried.score?.score).toBe(0.92);
  }, 120_000);
});
