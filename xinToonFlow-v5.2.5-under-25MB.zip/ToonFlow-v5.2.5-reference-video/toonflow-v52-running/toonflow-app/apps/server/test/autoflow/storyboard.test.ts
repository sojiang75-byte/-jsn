import { describe, expect, test } from "bun:test";
import { parseStoryboard, iterateShots } from "@/autoflow/storyboard/schema";
import { estimateDialogueSeconds, estimateShotSeconds, fillDurations, snapDuration, spokenUnits } from "@/autoflow/storyboard/timing";
import { runGates, gateFeedback, directorContractProblems, sourceCoverage } from "@/autoflow/storyboard/gates";
import { applyDeathEventsFromSource, propagateDeadStates } from "@/autoflow/storyboard/continuity";
import { buildShotPrompts } from "@/autoflow/storyboard/prompts";
import { normalizeStoryboardEnums, splitOverlongDialogueShots } from "@/autoflow/planner";
import { buildSourceLedger, hydrateStoryboardFromLedger, validateSourceLedger } from "@/autoflow/sourceLedger";
import { boardInput, cards } from "./fixtures";

function board() {
  const parsed = parseStoryboard(boardInput());
  if (!parsed.ok) throw new Error(parsed.errors.join("\n"));
  return parsed.data;
}

describe("分镜 schema", () => {
  test("合法分镜通过，转场默认 cut", () => {
    const data = board();
    expect([...iterateShots(data)].length).toBe(4);
    expect(data.episodes[0].segments[0].shots[0].transition).toBe("cut");
  });
  test("缺少必填字段/多余字段时给出路径化错误", () => {
    const input = boardInput() as any;
    delete input.episodes[0].segments[0].blocking;
    input.episodes[0].segments[0].shots[0].unknown = 1;
    const parsed = parseStoryboard(input);
    expect(parsed.ok).toBe(false);
    if (!parsed.ok) {
      expect(parsed.errors.join("\n")).toContain("blocking");
      expect(parsed.errors.join("\n")).toContain("unknown");
    }
  });
  test("spatialContract.beat 的 activity 别名规范化为 action", () => {
    const input = boardInput() as any;
    input.episodes[0].segments[0].shots[0].spatialContract = { beat: "activity" };
    const normalized = normalizeStoryboardEnums(input) as any;
    expect(normalized.episodes[0].segments[0].shots[0].spatialContract.beat).toBe("action");
  });

  test("模型输出的中英文运镜/景别别名规范化，POV 转为镜头视角合同", () => {
    const input = boardInput() as any;
    const shot = input.episodes[0].segments[0].shots[0];
    shot.camera = "dolly-in";
    shot.size = "wide shot";
    const normalized = normalizeStoryboardEnums(input) as any;
    expect(normalized.episodes[0].segments[0].shots[0].camera).toBe("Push In");
    expect(normalized.episodes[0].segments[0].shots[0].size).toBe("wide");
    shot.camera = "POV";
    const pov = normalizeStoryboardEnums(input) as any;
    expect(pov.episodes[0].segments[0].shots[0].camera).toBe("Static Shot");
    expect(pov.episodes[0].segments[0].shots[0].cameraContract.viewpoint).toBe("first_person");
  });

  test("spatialContract.beat 的常见模型别名会规范化为合法枚举", () => {
    const input = boardInput() as any;
    const shots = input.episodes[0].segments[0].shots;
    shots[0].spatialContract = { beat: "dialogue" };
    shots[1].spatialContract = { beat: "tension" };
    shots[2].spatialContract = { beat: "establish" };
    shots[3].spatialContract = { beat: "explosion" };
    const normalized = normalizeStoryboardEnums(input) as any;
    expect(normalized.episodes[0].segments[0].shots.map((shot: any) => shot.spatialContract.beat)).toEqual(["action", "reaction", "establishing", "action"]);
    expect(parseStoryboard(normalized).ok).toBe(true);
  });

  test("非法景别被拒绝", () => {
    const input = boardInput() as any;
    input.episodes[0].segments[0].shots[0].size = "huge";
    expect(parseStoryboard(input).ok).toBe(false);
  });
  test("v5 镜头合同允许明确声明的第一人称 POV", () => {
    const input = boardInput() as any;
    const shot = input.episodes[0].segments[0].shots[0];
    shot.cameraContract = { viewpoint: "first_person", subjectCharacterId: "linxia", axisSide: "A", axisId: "dialogue-axis" };
    const parsed = parseStoryboard(input);
    expect(parsed.ok).toBe(true);
    if (parsed.ok) expect(parsed.data.episodes[0].segments[0].shots[0].cameraContract?.viewpoint).toBe("first_person");
  });
  test("主观视角缺少主体角色时拒绝", () => {
    const input = boardInput() as any;
    input.episodes[0].segments[0].shots[0].cameraContract = { viewpoint: "subjective_camera" };
    expect(parseStoryboard(input).ok).toBe(false);
  });
  test("v5 空间合同记录人物左右、朝向和镜头起止状态", () => {
    const input = boardInput() as any;
    input.episodes[0].segments[0].shots[0].spatialContract = { positions: [{ characterId: "linxia", screenPosition: "left", facing: "right", eyelineTarget: "陈默" }], startState: "站在门口", endState: "走到桌边", beat: "reaction" };
    const parsed = parseStoryboard(input);
    expect(parsed.ok).toBe(true);
  });
  test("镜头合同不能引用未出场的视点角色", () => {
    const input = boardInput() as any;
    input.episodes[0].segments[0].shots[0].cameraContract = { viewpoint: "first_person", subjectCharacterId: "missing" };
    const parsed = parseStoryboard(input);
    expect(parsed.ok).toBe(true);
    if (parsed.ok) expect(directorContractProblems(parsed.data.episodes[0].segments[0].shots[0] as any).join(" ")).toContain("不在本镜角色清单");
  });
  test("死亡状态在后续镜头自动继承，不能因模型漏填而复活", () => {
    const input = boardInput() as any;
    const shots = input.episodes[0].segments.flatMap((segment: any) => segment.shots);
    shots[0].continuity = { dead: ["gangster"], hands: [], extras: "无" };
    shots[1].continuity = { dead: [], hands: [], extras: "无" };
    const parsed = parseStoryboard(input);
    if (!parsed.ok) throw new Error("parse");
    propagateDeadStates(parsed.data);
    expect(parsed.data.episodes[0].segments[0].shots[1].continuity?.dead).toContain("gangster");
  });

  test("分号后的另一角色不会继承前一角色的尸体状态", () => {
    const input = boardInput() as any;
    input.characters.push({ id: "laoer", name: "老二" }, { id: "laowu", name: "老五" });
    const shots = input.episodes[0].segments.flatMap((segment: any) => segment.shots);
    shots[0].source = "老二成为尸体；老五来不及呼叫。";
    shots[1].characters.push({ id: "laowu", pose: "老五跪地求饶" });
    const parsed = parseStoryboard(input);
    if (!parsed.ok) throw new Error("parse");
    applyDeathEventsFromSource(parsed.data, [
      { id: "laoer", name: "老二" },
      { id: "laowu", name: "老五" },
    ]);
    expect(parsed.data.episodes[0].segments[0].shots[1].continuity?.dead).toContain("laoer");
    expect(parsed.data.episodes[0].segments[0].shots[1].continuity?.dead).not.toContain("laowu");
  });

  test("从不可修改的原文死亡事件建立死亡账本并传递到下一镜", () => {
    const input = boardInput() as any;
    input.characters.push({ id: "gangster", name: "老五" });
    const shots = input.episodes[0].segments.flatMap((segment: any) => segment.shots);
    shots[0].source = "老五被枪杀。";
    shots[1].characters.push({ id: "gangster", pose: "老五的尸体倒在地上，一动不动" });
    const parsed = parseStoryboard(input);
    if (!parsed.ok) throw new Error("parse");
    applyDeathEventsFromSource(parsed.data, [{ id: "gangster", name: "老五" }]);
    expect(parsed.data.episodes[0].segments[0].shots[1].continuity?.dead).toContain("gangster");
  });

  test("原文覆盖按重复次数精确核对，不把一个相同台词算作多次", () => {
    const chapter = "他说：“快点”。又喊：“快点”。";
    const report = sourceCoverage({ episodes: [{ segments: [{ shots: [{ dialogue: [{ speaker: "a", text: "快点" }], source: chapter }] }] }] } as any, chapter);
    expect(report.missingLines).toEqual(["快点"]);
    expect(report.ratio).toBe(1);
  });

});

describe("时长估算", () => {
  test("中文按字计、英文按词计，标点不计", () => {
    expect(spokenUnits("你好，世界！")).toBe(4);
    expect(spokenUnits("hello brave world")).toBeGreaterThan(spokenUnits("你好"));
  });
  test("台词越长镜头越长，并夹在 2–10 秒", () => {
    const short = estimateShotSeconds({ action: "", dialogue: [{ speaker: "a", text: "嗯" }] });
    const long = estimateShotSeconds({ action: "", dialogue: [{ speaker: "a", text: "这".repeat(80) }] });
    expect(short).toBeGreaterThanOrEqual(2);
    expect(long).toBe(10);
    expect(estimateDialogueSeconds({ dialogue: [{ speaker: "a", text: "一二三四五六七八九" }] })).toBeCloseTo(9 / 4.5 + 0.4, 5);
  });
  test("对齐模型时长档位（向上取最近档）", () => {
    expect(snapDuration(4.2, [4, 5, 8])).toBe(5);
    expect(snapDuration(9, [4, 5, 8])).toBe(8);
    expect(snapDuration(3.2)).toBe(4);
  });
  test("fillDurations 只补齐缺失时长", () => {
    const data = board();
    data.episodes[0].segments[0].shots[0].seconds = 7;
    const filled = fillDurations(data, { allowed: [3, 4, 5, 6, 7, 8] });
    const seconds = [...iterateShots(filled)].map(item => item.shot.seconds);
    expect(seconds[0]).toBe(7);
    expect(seconds.every(value => typeof value === "number" && value >= 3)).toBe(true);
  });
});

describe("原文对白自动拆镜", () => {
  test("两个独立 Q 对白超过 15 秒时按 Q 边界拆成相邻镜头，SRC/Q 账本仍完整", () => {
    const script = "萧枫从车里拿起电话，“喂，110吗？凌晨人民路被抢劫的银行车在市西郊废纸厂里，你们赶快过来！”说完，萧枫放下电话，“怎么样，被枪指着爽吧？本来还打算偷偷再杀了你们的，可是你们要早点上路我也没办法，老子最恨黑吃黑了！”";
    const ledger = buildSourceLedger(script, [{ id: "xiaofeng", name: "萧枫" }]);
    expect(ledger.quotes.length).toBe(2);
    const parsed = parseStoryboard(boardInput());
    if (!parsed.ok) throw new Error(parsed.errors.join("\n"));
    const shot = parsed.data.episodes[0]!.segments[0]!.shots[0]!;
    parsed.data.characters.push({ id: "xiaofeng", name: "萧枫" });
    shot.characters.push({ id: "xiaofeng", outfit: "default", pose: "手持电话" });
    shot.sourceRefs = ledger.chunks.map(chunk => chunk.id);
    shot.quoteAssignments = ledger.quotes.map(quote => ({ sourceId: quote.id, kind: "dialogue" as const, speaker: "xiaofeng" }));

    const before = validateSourceLedger(parsed.data as any, ledger);
    expect(before.ok).toBe(true);
    const split = splitOverlongDialogueShots(parsed.data, ledger, { minShotSeconds: 2, maxShotSeconds: 15, charsPerSecond: 4.5, linePadding: 0.4 }, [5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]);
    expect(split.splitShots).toBe(1);
    expect(split.createdShots).toBe(1);
    const segment = split.storyboard.episodes[0]!.segments[0]!;
    expect(segment.shots[0]!.id).toBe("E01-01-01");
    expect(segment.shots[1]!.id).toBe("E01-01-02");
    expect(segment.shots[0]!.quoteAssignments?.map(item => item.sourceId)).toEqual([ledger.quotes[0]!.id]);
    expect(segment.shots[1]!.quoteAssignments?.map(item => item.sourceId)).toEqual([ledger.quotes[1]!.id]);
    expect(segment.shots[1]!.transition).toBe("continuous");
    expect(segment.shots.map(item => item.seconds)).toEqual([7, 11]);
    expect(segment.shots.every(item => (item.seconds ?? 99) <= 15)).toBe(true);

    const after = validateSourceLedger(split.storyboard as any, ledger);
    expect(after.ok).toBe(true);
    hydrateStoryboardFromLedger(split.storyboard as any, ledger, { preserveAssignments: true });
    const dialogue = segment.shots.flatMap(item => item.dialogue ?? []).map(item => item.text).join("");
    expect(dialogue).toBe(ledger.quotes.map(item => item.text).join(""));
    expect(segment.shots[0]!.dialogue?.[0]?.text).toBe(ledger.quotes[0]!.text);
    expect(segment.shots[1]!.dialogue?.[0]?.text).toBe(ledger.quotes[1]!.text);
  });
});

describe("质量门", () => {
  test("mock 分镜在有锚点时全部错误门通过", () => {
    const result = runGates(fillDurations(board()), { cards: cards(), requireAnchors: true });
    expect(result.gates.filter(gate => gate.severity === "error" && !gate.ok)).toEqual([]);
    expect(result.ok).toBe(true);
  });
  test("缺锚点、编号错误、连续镜头跨段、台词过长都会被拦截", () => {
    const input = boardInput() as any;
    input.episodes[0].segments[0].shots[0].id = "E01-01-05";
    input.episodes[0].segments[1].shots[0].transition = "continuous";
    input.episodes[0].segments[0].shots[1].seconds = 2;
    input.episodes[0].segments[0].shots[1].dialogue[0].text = "这是一句非常非常长的台词，两秒钟根本说不完，必须拆镜或者加长时长才行";
    const parsed = parseStoryboard(input);
    expect(parsed.ok).toBe(true);
    if (!parsed.ok) return;
    const result = runGates(parsed.data, { cards: cards(false), requireAnchors: true });
    const failed = result.gates.filter(gate => !gate.ok).map(gate => gate.id);
    expect(result.ok).toBe(false);
    for (const id of ["ids", "anchors", "continuity", "dialogueFit"]) expect(failed).toContain(id);
    expect(gateFeedback(result.gates)).toContain("E01-01-05");
  });
  test("第三人称合同与 POV 描述冲突时被导演门拦截；旧 v4 镜头不受影响", () => {
    const input = boardInput() as any;
    const shot = input.episodes[0].segments[0].shots[0];
    shot.cameraContract = { viewpoint: "third_person" };
    shot.action = "第一人称视角，镜头中伸出主角的右手";
    const parsed = parseStoryboard(input);
    if (!parsed.ok) throw new Error("parse");
    const result = runGates(fillDurations(parsed.data), { cards: cards() });
    expect(result.gates.find(gate => gate.id === "director")?.ok).toBe(false);
    delete shot.cameraContract;
    const old = parseStoryboard(input);
    expect(old.ok).toBe(true);
    if (old.ok) expect(directorContractProblems(old.data.episodes[0].segments[0].shots[0])).toEqual([]);
  });
  test("参考图超过模型上限会被拦截", () => {
    const result = runGates(fillDurations(board()), { cards: cards(), maxReferenceImages: 1 });
    expect(result.gates.find(gate => gate.id === "references")?.ok).toBe(false);
  });
  test("未登记角色、同框超过 3 人", () => {
    const input = boardInput() as any;
    input.episodes[0].segments[0].shots[0].characters.push({ id: "ghost" }, { id: "linxia" }, { id: "chenmo" });
    const parsed = parseStoryboard(input);
    if (!parsed.ok) throw new Error("parse");
    const result = runGates(fillDurations(parsed.data), { cards: cards() });
    expect(result.gates.find(gate => gate.id === "cast")?.ok).toBe(false);
    expect(result.gates.find(gate => gate.id === "crowd")?.ok).toBe(false);
  });
});

describe("三层提示词", () => {
  test("第一人称 POV 合同进入正向提示词，不进入全局负面词", () => {
    const data = fillDurations(board());
    const segment = data.episodes[0].segments[0];
    const shot = { ...segment.shots[0], cameraContract: { viewpoint: "first_person" as const, subjectCharacterId: "linxia" } };
    const result = buildShotPrompts({ board: data, segment, shot, cards: cards() });
    expect(result.video).toContain("第一人称主观视角");
    expect(result.negative).not.toContain("第一人称视角");
  });
  test("包含风格/角色锚点指代/镜头语言，视频首帧模式不含图N", () => {
    const data = fillDurations(board());
    const segment = data.episodes[0].segments[0];
    const shot = segment.shots[0];
    const withRefs = buildShotPrompts({ board: data, segment, shot, cards: cards(), characterImageIndex: new Map([["linxia", 1], ["chenmo", 2]]) });
    expect(withRefs.firstFrame).toContain("图1");
    expect(withRefs.firstFrame).toContain("林夏");
    expect(withRefs.firstFrame).toContain("日系动画");
    expect(withRefs.firstFrame).toContain(segment.blocking);
    expect(withRefs.negative.length).toBeGreaterThan(0);
    const plain = buildShotPrompts({ board: data, segment, shot, cards: cards() });
    expect(plain.video).not.toMatch(/图\d/);
    expect(plain.video).toContain("陈默");
  });
});
