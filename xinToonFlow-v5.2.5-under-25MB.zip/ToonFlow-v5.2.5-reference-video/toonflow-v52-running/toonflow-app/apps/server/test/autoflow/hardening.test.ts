import { describe, expect, test } from "bun:test";
import { mkdtemp } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { parseStoryboard } from "@/autoflow/storyboard/schema";
import { fillDurations } from "@/autoflow/storyboard/timing";
import { buildShotPrompts } from "@/autoflow/storyboard/prompts";
import { runGates, stagingProblems } from "@/autoflow/storyboard/gates";
import { getPromptStyle } from "@/autoflow/promptStyles";
import { resolveShotReferences } from "@/autoflow/references";
import { shotTraits, characterTraitKinds, characterTraitLine } from "@/autoflow/traits";
import { createModelScorer, handsPass, parseScoreOutput, type ConsistencyScorer } from "@/autoflow/scoring";
import { storyboardInstructions } from "@/autoflow/planner";
import { runAutoflow } from "@/autoflow/pipeline";
import { createMockGenerator, createMockScorer, createMockTextModel } from "@/autoflow/mock";
import { makeSolidImage, systemFfmpeg } from "@/autoflow/media";
import { characterCardSchema, type CharacterCard } from "@/utils/assets/characterCard";
import { boardInput, cards } from "./fixtures";

/** 风流杀神式角色：萧枫（疤、半指手套，无纹身）与老五（花臂纹身） */
function gangCards() {
  const map = new Map<string, CharacterCard>();
  map.set("xiao_feng", characterCardSchema.parse({ version: 1, id: "xiao_feng", name: "萧枫", identity: { gender: "male", age: 28 },
    invariant: { face: "剑眉，眼神锐利", hair: "黑色短碎发", body: "身高 182cm，精瘦", marks: "左手虎口处有一道细长旧疤" },
    outfits: [{ id: "default", label: "便装", upper: "黑色夹克", lower: "深色牛仔裤", shoes: "黑色短靴", accessories: "右手黑色半指手套" }] }));
  map.set("laowu", characterCardSchema.parse({ version: 1, id: "laowu", name: "老五", identity: { gender: "male", age: 35 },
    invariant: { face: "方脸，横肉", hair: "寸头", body: "身高 175cm，壮实" },
    outfits: [{ id: "default", label: "劫匪", upper: "黑色连帽卫衣，袖子撸起露出花臂纹身", lower: "黑色运动裤", shoes: "运动鞋" }] }));
  return map;
}

describe("逐角色特征与互斥约束", () => {
  const map = gangCards();
  test("从角色卡推导标记种类与特征行", () => {
    expect(characterTraitKinds(map.get("laowu")!)).toContain("tattoo");
    expect(characterTraitKinds(map.get("xiao_feng")!)).not.toContain("tattoo");
    expect(characterTraitKinds(map.get("xiao_feng")!)).toEqual(expect.arrayContaining(["scar", "glove"]));
    const line = characterTraitLine(map.get("xiao_feng")!);
    expect(line).toContain("萧枫");
    expect(line).toContain("黑色夹克");
    expect(line).toContain("虎口");
  });
  test("同框：只有老五有纹身，萧枫没有；并加不可串用总约束", () => {
    const traits = shotTraits([{ id: "xiao_feng" }, { id: "laowu" }], map);
    expect(traits.lines.length).toBe(2);
    expect(traits.constraints.join("\n")).toContain("只有老五有纹身；萧枫手臂和皮肤干净、没有任何纹身");
    expect(traits.constraints.join("\n")).toContain("不得把一个角色的纹身");
    expect(traits.negatives).toContain("萧枫身上的纹身");
    expect(traits.constraintsEn.join(" ")).toContain("Only 老五 has tattoos; 萧枫 has clean bare skin with no tattoos at all.");
  });
  test("单人镜头也按全片角色判断：老五不在场，萧枫仍写明没有纹身", () => {
    const traits = shotTraits([{ id: "xiao_feng" }], map);
    expect(traits.constraints.join("\n")).toContain("萧枫手臂和皮肤干净、没有任何纹身");
    expect(traits.constraints.join("\n")).not.toContain("不得把一个角色");
    // 老五单人镜头：他自己的纹身不受约束，但没有萧枫的疤/手套
    const wu = shotTraits([{ id: "laowu" }], map);
    expect(wu.constraints.join("\n")).not.toContain("没有任何纹身");
    expect(wu.constraints.join("\n")).toContain("老五不戴手套");
  });
});

function setup() {
  const parsed = parseStoryboard(boardInput());
  if (!parsed.ok) throw new Error(parsed.errors.join("\n"));
  const board = fillDurations(parsed.data);
  return { board, segment: board.episodes[0].segments[0], map: cards() };
}

describe("首帧/视频提示词带逐角色特征、约束与第三人称机位", () => {
  test("通用中文提示词", () => {
    const { board, segment, map } = setup();
    const shot = segment.shots[0];
    const prompts = buildShotPrompts({ board, segment, shot, cards: map });
    expect(prompts.firstFrame).toContain("逐角色特征");
    expect(prompts.firstFrame).toContain("特征约束：");
    expect(prompts.firstFrame).toContain("只有陈默有疤痕；林夏没有疤痕");
    expect(prompts.firstFrame).toContain("第三人称机位");
    expect(prompts.firstFrame).toContain("正好五根手指");
    expect(prompts.negative).toContain("第一人称视角");
    expect(prompts.negative).toContain("六指");
    expect(prompts.negative).toContain("林夏身上的疤痕");
    expect(prompts.video).toContain("特征约束：");
  });
  test("H3 英文提示词", () => {
    const { board, segment, map } = setup();
    const shot = segment.shots[0];
    const style = getPromptStyle("h3");
    const plan = resolveShotReferences({ shot, cards: map, maxImages: 9, includeSheet: false });
    const keyframe = style.keyframe({ board, segment, shot, cards: map }, plan);
    expect(keyframe).toContain("Only 陈默 has scars");
    expect(keyframe).toMatch(/third-person/i);
    expect(keyframe).toMatch(/five fingers/i);
    const video = style.video({ board, segment, shot, cards: map }, { mode: "firstFrame", seconds: shot.seconds! });
    expect(video).toContain("Only 陈默 has scars");
  });
});

describe("看图评分：手指/肢体/串特征/第一人称/空间检查", () => {
  test("解析结构化检查项，低分并入总分并写原因", () => {
    const result = parseScoreOutput(JSON.stringify({ characters: { 萧枫: 0.9 }, fingers: 0.2, limbs: 1, traitBleed: 0.1, pov: 1, spatial: 0.9, artifacts: 1, reasons: ["萧枫手臂出现老五的纹身"] }), ["萧枫"]);
    expect(result.checks).toMatchObject({ fingers: 0.2, limbs: 1, traitBleed: 0.1, pov: 1, spatial: 0.9, artifacts: 1 });
    expect(result.artifacts).toBe(0.1);
    expect(result.reasons.join("；")).toContain("手指数不对");
    expect(result.reasons.join("；")).toContain("角色特征串用");
    // 别名
    expect(parseScoreOutput('{"characters":{},"extra_hands":0.3,"trait_bleed":1,"staging":0.4}', []).checks).toMatchObject({ limbs: 0.3, traitBleed: 1, spatial: 0.4 });
    // 旧格式不附 checks
    expect(parseScoreOutput('{"characters":{"甲":1},"artifacts":1}', ["甲"]).checks).toBeUndefined();
  });
  test("traitsClean is preferred and inverted legacy traitBleed/pov zeros are ignored when reasons deny the problem", () => {
    expect(parseScoreOutput('{"characters":{"萧枫":0.9},"traitsClean":0.1,"thirdPerson":1,"reasons":[]}', ["萧枫"]).checks).toMatchObject({ traitBleed: 0.1, pov: 1 });
    const inverted = parseScoreOutput(JSON.stringify({ characters: { 萧枫: 0.9 }, fingers: 1, traitBleed: 0, pov: 0, reasons: ["萧枫无纹身无痣，未出现他人特征", "非第一人称视角"] }), ["萧枫"]);
    expect(inverted.checks).toMatchObject({ traitBleed: 1, pov: 1 });
    expect(inverted.reasons.some(reason => reason.includes("角色特征串用"))).toBe(false);
    const real = parseScoreOutput(JSON.stringify({ characters: { 萧枫: 0.9 }, traitBleed: 0.1, pov: 0.1, reasons: ["萧枫左臂出现纹身", "第一人称持枪"] }), ["萧枫"]);
    expect(real.checks).toMatchObject({ traitBleed: 0.1, pov: 0.1 });
  });

  test("handsPass：手指与肢体都过阈值才可作参考；无检查项时看总分", () => {
    const base = { score: 0.9, perCharacter: {}, reasons: [], scorer: "x" };
    expect(handsPass({ ...base, checks: { fingers: 0.2, limbs: 1, traitBleed: 1, pov: 1, spatial: 1, artifacts: 1 } }, 0.7)).toBe(false);
    expect(handsPass({ ...base, checks: { fingers: 1, limbs: 0.5, traitBleed: 1, pov: 1, spatial: 1, artifacts: 1 } }, 0.7)).toBe(false);
    expect(handsPass({ ...base, checks: { fingers: 1, limbs: 1, traitBleed: 1, pov: 1, spatial: 1, artifacts: 1 } }, 0.7)).toBe(true);
    expect(handsPass(base, 0.7)).toBe(true);
    expect(handsPass({ ...base, score: 0.3 }, 0.7)).toBe(false);
    expect(handsPass(undefined, 0.7)).toBe(false);
  });
  test("评分提示词带特征约束与站位；六指总分低于阈值；空镜也送检", async () => {
    const dir = await mkdtemp(join(tmpdir(), "af-hard-"));
    await makeSolidImage(join(dir, "ref.png"), { width: 64, height: 64, color: "0xcc3333" });
    await makeSolidImage(join(dir, "cand.png"), { width: 64, height: 64, color: "0xcc3344" });
    const prompts: string[] = [];
    const systems: string[] = [];
    const scorer = createModelScorer(async input => { prompts.push(input.prompt); systems.push(input.system ?? ""); return JSON.stringify({ characters: { 萧枫: 0.95 }, fingers: 0.2, limbs: 1, artifacts: 1, reasons: ["右手六根手指"] }); });
    const result = await scorer.score({ candidate: join(dir, "cand.png"), references: [{ path: join(dir, "ref.png"), name: "萧枫", role: "character" }], description: "持枪",
      traits: ["只有老五有纹身；萧枫手臂和皮肤干净、没有任何纹身"], staging: "萧枫在画面左侧车内驾驶座" });
    expect(result.score).toBe(0.2);
    expect(result.checks?.fingers).toBe(0.2);
    expect(prompts[0]).toContain("萧枫手臂和皮肤干净");
    expect(prompts[0]).toContain("萧枫在画面左侧车内驾驶座");
    expect(systems[0]).toContain("正好五根手指");
    expect(systems[0]).toMatch(/"fingers".*"limbs".*"traitsClean".*"thirdPerson".*"spatial"/);
    expect(systems[0]).toContain("第一人称");
    // 空镜：缺省也调用模型（检查多余的手、站在车前的人等）
    const empty = await scorer.score({ candidate: join(dir, "cand.png"), references: [], description: "高架上面包车疾驰" });
    expect(prompts.length).toBe(2);
    expect(empty.score).toBe(0.2);
    const legacy = createModelScorer(async () => { throw new Error("不应调用"); }, { checkEmptyShots: false });
    expect((await legacy.score({ candidate: join(dir, "cand.png"), references: [], description: "" })).score).toBe(1);
  });
});

describe("分镜调度规则", () => {
  test("规划提示词禁止第一人称持枪镜头与人站在行驶车辆前方，并要求空间清楚", () => {
    const text = storyboardInstructions({ story: "x", episodes: 1, targetSeconds: 60, aspectRatio: "9:16" });
    expect(text).toContain("禁止第一人称/主观视角镜头");
    expect(text).toContain("禁止让人物站在/走在行驶车辆前方");
    expect(text).toContain("每段 blocking 写明谁在画面左/右/前/后");
    expect(text).toContain("可读的招牌");
    expect(text).toContain("不要写英文感叹词");
  });
  const shot = (extra: Record<string, unknown>) => ({ firstFrame: "", action: "", cameraPosition: "侧面平视", composition: "三分法", characters: [{ id: "laowu", pose: "持枪" }], ...extra }) as any;
  test("质量门：检出第一人称镜头与车道上的人；否定说法与车内不误报", () => {
    expect(stagingProblems(shot({ firstFrame: "第一人称视角，一只握枪的手从画面下方伸入" })).join()).toContain("第一人称");
    expect(stagingProblems(shot({ cameraPosition: "POV 镜头" })).join()).toContain("第一人称");
    expect(stagingProblems(shot({ cameraPosition: "第三人称侧拍（非第一人称）" }))).toEqual([]);
    expect(stagingProblems(shot({ action: "三名劫匪站在高架车道上，面包车迎面疾驰而来" })).join()).toContain("车道");
    expect(stagingProblems(shot({ action: "面包车在高架上疾驰，萧枫坐在驾驶座握紧方向盘" }))).toEqual([]);
    expect(stagingProblems(shot({ action: "空镜", characters: [], firstFrame: "面包车在高架车道上疾驰" }))).toEqual([]);
  });
  test("质量门 staging 为 error 级，回喂给模型修复", () => {
    const parsed = parseStoryboard(boardInput());
    if (!parsed.ok) throw new Error("bad");
    const board = fillDurations(parsed.data);
    board.episodes[0].segments[0].shots[0].firstFrame = "第一人称主观镜头，持枪的手伸向镜头";
    const report = runGates(board, {});
    const gate = report.gates.find(item => item.id === "staging")!;
    expect(gate.ok).toBe(false);
    expect(gate.severity).toBe("error");
    expect(report.ok).toBe(false);
  });
});

const story = "雨夜便利店，店员林夏把伞借给常客陈默。";
const models = {
  imageModel: { providerId: "mock", modelId: "img", maxReferenceImages: 8 },
  videoModel: { providerId: "mock", modelId: "vid", durations: [3, 4, 5, 6], generateAudio: true },
};

describe("关键帧严格模式与接力", () => {
  test("缺省：连续镜头也重新出首帧，不接力上一镜尾帧", async () => {
    const cwd = await mkdtemp(join(tmpdir(), "af-hard-"));
    const generator = createMockGenerator(cwd);
    const state = await runAutoflow({ story, seed: 1000, promptStyle: "generic", ...models },
      { cwd, text: createMockTextModel(), generate: generator.generate, scorer: createMockScorer([]), ffmpeg: systemFfmpeg, retryDelayMs: 0 }, "nochain");
    expect(state.status).toBe("done");
    const keyframes = generator.requests.filter(item => item.mediaType === "image" && item.request.outputDirectory?.includes("/镜头/"));
    expect(keyframes.some(item => item.request.outputDirectory?.endsWith("E01-01-03"))).toBe(true);
    expect(state.shots["E01-01-03"].chainedFrom).toBeUndefined();
  }, 120_000);

  test("严格（缺省）：关键帧 5 次都低于阈值 → 标记需重做，不生成视频、不导出成片", async () => {
    const cwd = await mkdtemp(join(tmpdir(), "af-hard-"));
    const generator = createMockGenerator(cwd);
    const low: ConsistencyScorer = { id: "low", async score() { return { score: 0.3, perCharacter: {}, reasons: ["右手六根手指"], scorer: "low",
      checks: { fingers: 0.3, limbs: 1, traitBleed: 1, pov: 1, spatial: 1, artifacts: 1 } }; } };
    let error: any;
    try { await runAutoflow({ story, seed: 1000, promptStyle: "generic", ...models }, { cwd, text: createMockTextModel(), generate: generator.generate, scorer: low, ffmpeg: systemFfmpeg, retryDelayMs: 0 }, "strict"); }
    catch (caught) { error = caught; }
    expect(error?.message).toContain("已标记需重做");
    const state = error.runState;
    expect(state.status).toBe("failed");
    expect(state.artifacts.final).toBeUndefined();
    expect(state.shots["E01-01-01"].needsRedo).toBe(true);
    expect(state.shots["E01-01-01"].status).toBe("failed");
    expect(state.shots["E01-01-01"].rejectedKeyframe).toBeTruthy();
    const first = generator.requests.filter(item => item.mediaType === "image" && item.request.outputDirectory?.endsWith("E01-01-01"));
    expect(first.length).toBe(5);
    expect(new Set(first.map(item => item.request.seed)).size).toBe(5);
    expect(generator.requests.some(item => item.mediaType === "video")).toBe(false);
  }, 120_000);

  test("非严格：保留最高分并记警告（旧行为，可配置）", async () => {
    const cwd = await mkdtemp(join(tmpdir(), "af-hard-"));
    const generator = createMockGenerator(cwd);
    const low: ConsistencyScorer = { id: "low", async score() { return { score: 0.5, perCharacter: {}, reasons: [], scorer: "low" }; } };
    const state = await runAutoflow({ story, seed: 1000, promptStyle: "generic", strictKeyframes: false, keyframeMaxAttempts: 2, ...models },
      { cwd, text: createMockTextModel(), generate: generator.generate, scorer: low, ffmpeg: systemFfmpeg, retryDelayMs: 0 }, "lenient");
    expect(state.status).toBe("done");
    expect(state.shots["E01-01-01"].warnings.join()).toContain("低于阈值");
    expect(generator.requests.filter(item => item.mediaType === "image" && item.request.outputDirectory?.endsWith("E01-01-01")).length).toBe(2);
  }, 120_000);

  test("上一镜尾帧手指检查不过：不作为下一镜参考，改挂通过检查的上一镜首帧", async () => {
    const run = async (tailFingers: number) => {
      const cwd = await mkdtemp(join(tmpdir(), "af-hard-"));
      const generator = createMockGenerator(cwd);
      const scorer: ConsistencyScorer = { id: "tail", async score(input) {
        const fingers = input.candidate.endsWith("尾帧.png") ? tailFingers : 1;
        return { score: 0.92, perCharacter: {}, reasons: [], scorer: "tail", checks: { fingers, limbs: 1, traitBleed: 1, pov: 1, spatial: 1, artifacts: 1 } };
      } };
      const state = await runAutoflow({ story, seed: 1000, promptStyle: "generic", ...models },
        { cwd, text: createMockTextModel(), generate: generator.generate, scorer, ffmpeg: systemFfmpeg, retryDelayMs: 0 }, "prev");
      const second = generator.requests.find(item => item.mediaType === "image" && item.request.outputDirectory?.endsWith("E01-01-02"))!;
      return { state, paths: (second.request.images ?? []).map(image => image.path) };
    };
    const bad = await run(0.2);
    expect(bad.state.shots["E01-01-01"].lastFrameHandsOk).toBe(false);
    expect(bad.state.shots["E01-01-01"].warnings.join()).toContain("手指/肢体检查未通过");
    expect(bad.paths.some(path => path.endsWith("尾帧.png"))).toBe(false);
    expect(bad.state.shots["E01-01-01"].keyframeHandsOk).toBe(true);
    expect(bad.paths).toContain(bad.state.shots["E01-01-01"].keyframe);
    const good = await run(1);
    expect(good.paths.some(path => path.includes("E01-01-01/尾帧.png"))).toBe(true);
  }, 240_000);
});
