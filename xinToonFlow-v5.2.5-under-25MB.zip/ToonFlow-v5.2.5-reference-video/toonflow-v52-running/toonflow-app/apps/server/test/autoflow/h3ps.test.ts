import { describe, expect, test } from "bun:test";
import { mkdtemp, readFile, stat, readdir, writeFile, chmod } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { luminanceGain, planSeams, buildStitchFilter, stitchVideos, measureLuma } from "@/autoflow/stitch";
import { continuationGate, tailFrameTimes, tailFrameLabels } from "@/autoflow/continuation";
import { ClipBin, parseShotList } from "@/autoflow/clipBin";
import { applyContinuity, continuityLines, continuityProblems, hasContinuity } from "@/autoflow/storyboard/continuity";
import { parseStoryboard } from "@/autoflow/storyboard/schema";
import { runGates } from "@/autoflow/storyboard/gates";
import { runAutoflow } from "@/autoflow/pipeline";
import { createMockGenerator, createMockScorer, createMockTextModel } from "@/autoflow/mock";
import { probeMedia, runProcess, systemFfmpeg } from "@/autoflow/media";
import { boardInput } from "./fixtures";

async function tone(file: string, seconds: number, gray: number, frequency = 440) {
  const hex = gray.toString(16).padStart(2, "0");
  const result = await runProcess("ffmpeg", ["-hide_banner", "-nostdin", "-y", "-f", "lavfi", "-i", `color=c=0x${hex}${hex}${hex}:s=160x90:r=24:d=${seconds}`,
    "-f", "lavfi", "-i", `sine=frequency=${frequency}:sample_rate=44100:duration=${seconds}`, "-shortest", "-c:v", "libx264", "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "128k", file]);
  if (result.code !== 0) throw new Error(result.stderr.slice(-300));
  return file;
}

/** 每 10ms 一个窗口的 RMS（dB） */
async function rmsWindows(file: string) {
  const result = await runProcess("ffmpeg", ["-hide_banner", "-nostdin", "-i", file, "-af", "asetnsamples=441,astats=metadata=1:reset=1,ametadata=print:key=lavfi.astats.Overall.RMS_level", "-f", "null", "-"]);
  return [...result.stderr.matchAll(/RMS_level=(-?[\d.]+|-inf)/g)].map(match => match[1] === "-inf" ? -120 : Number(match[1]));
}

describe("接缝处理（H3 Long Video Stitcher 的像素/波形层移植）", () => {
  test("亮度增益：取比值中位数、限幅 ±8%、忽略过暗过曝帧", () => {
    expect(luminanceGain([100, 100, 100], [110, 110, 110])).toBeCloseTo(0.92, 5); // 0.909 被限幅到 0.92
    expect(luminanceGain([100, 100, 100], [98, 98, 98])).toBeCloseTo(100 / 98, 5);
    expect(luminanceGain([100, 100, 100], [50, 50, 50], 10)).toBeCloseTo(1.1, 5);
    expect(luminanceGain([5, 5], [100, 100])).toBe(1); // 黑场不参与
    expect(luminanceGain([], [100])).toBe(1);
    // 中位数抗离群：一帧闪白不影响
    expect(luminanceGain([100, 100, 100, 100, 100], [100, 100, 240, 100, 100])).toBe(1);
  });

  test("接缝计划：只在同段相邻镜头做亮度匹配；有重叠才做音频交叉淡化", () => {
    const luma = [{ head: [100], tail: [100] }, { head: [110], tail: [110] }, { head: [90], tail: [90] }];
    const plans = planSeams([{ file: "a", segmentId: "E01-01" }, { file: "b", segmentId: "E01-01", trimHeadFrames: 12 }, { file: "c", segmentId: "E01-02" }], luma, { fps: 24 });
    expect(plans[0]).toEqual({ index: 0, trimHeadFrames: 0, gain: 1, audioCrossfade: 0 });
    expect(plans[1]!.gain).toBeCloseTo(0.92, 5);
    expect(plans[1]!.trimHeadFrames).toBe(12);
    expect(plans[1]!.audioCrossfade).toBeCloseTo(0.04, 5);
    expect(plans[2]!.gain).toBe(1); // 跨段不匹配
    expect(planSeams([{ file: "a", trimHeadFrames: 5 }], [{ head: [], tail: [] }], {})[0]!.trimHeadFrames).toBe(0); // 首镜不裁
    const { filter, audioLabel } = buildStitchFilter([{ duration: 2, hasAudio: true, hasVideo: true }, { duration: 2, hasAudio: false, hasVideo: true }],
      [{ index: 0, trimHeadFrames: 0, gain: 1, audioCrossfade: 0 }, { index: 1, trimHeadFrames: 0, gain: 1.05, audioCrossfade: 0 }], { width: 160, height: 90 });
    expect(filter).toContain("geq=lum=");
    expect(filter).toContain("anullsrc");
    expect(filter).toContain("curve=hsin");
    expect(audioLabel).toBe("[ax1]");
  });

  test("真实拼接：重叠裁头后时长正确；同源音频交叉淡化为单位增益（不鼓包）；亮度跳变被平滑", async () => {
    const dir = await mkdtemp(join(tmpdir(), "af-stitch-"));
    const a = await tone(join(dir, "a.mp4"), 2, 100);
    const b = await tone(join(dir, "b.mp4"), 2, 116);
    const out = join(dir, "out.mp4");
    const { plans } = await stitchVideos([{ file: a, segmentId: "S1" }, { file: b, segmentId: "S1", trimHeadFrames: 6 }], out, { width: 160, height: 90, crossfadeMs: 120 });
    expect(plans[1]!.gain).toBeLessThan(1);
    const probe = await probeMedia(out);
    expect(Math.abs(probe.duration - (4 - 6 / 24))).toBeLessThan(0.1);
    // 接缝处 RMS 不应比稳态高出 1 dB（等功率曲线在同源信号上会高出约 3 dB）
    const rms = await rmsWindows(out);
    const steady = rms.slice(20, 150).reduce((sum, value) => sum + value, 0) / 130;
    const seam = Math.max(...rms.slice(180, 200));
    expect(seam - steady).toBeLessThan(1);
    // 第二镜开头被拉向第一镜亮度，之后回到原亮度
    const lumaOut = await measureLuma(out, "head", 120, probe.duration);
    const seamFrame = 48; // 第二镜第一帧
    expect(Math.abs(lumaOut[seamFrame]! - lumaOut[seamFrame - 1]!)).toBeLessThan(Math.abs(116 - 100) * 0.6);
    expect(Math.abs(lumaOut[seamFrame + 30]! - lumaOut[seamFrame]!)).toBeGreaterThan(3);
  }, 60_000);
});

describe("续接（Prefix Continuation 的像素层移植）", () => {
  test("只在同段、上一镜通过手指/特征/逐帧质检时续接", () => {
    const good = { video: "v.mp4", lastFrameHandsOk: true, lastFrameTraitsOk: true, chainable: true, qa: { pass: true } };
    expect(continuationGate(good, true).ok).toBe(true);
    expect(continuationGate(good, false).ok).toBe(false);
    expect(continuationGate({ ...good, qa: { pass: false } }, true).reason).toContain("逐帧质检");
    expect(continuationGate({ ...good, lastFrameHandsOk: false }, true).reason).toContain("手指");
    expect(continuationGate({ ...good, lastFrameTraitsOk: false }, true).reason).toContain("串用");
    // v5.2.5：手指检查缺省只记录、不断链；handsGate=block 恢复旧行为
    expect(continuationGate({ ...good, lastFrameHandsOk: false }, true).ok).toBe(true);
    expect(continuationGate({ ...good, lastFrameHandsOk: undefined }, true).ok).toBe(true);
    expect(continuationGate({ ...good, lastFrameHandsOk: undefined }, true).reason).toContain("只记录");
    expect(continuationGate({ ...good, lastFrameHandsOk: undefined }, true, { handsGate: "block" }).ok).toBe(false);
    expect(continuationGate({ ...good, lastFrameHandsOk: false }, true, { handsGate: "block" }).reason).toContain("手指");
    // 人物变样、特征串用仍然断链
    expect(continuationGate({ ...good, chainable: false }, true).ok).toBe(false);
    expect(continuationGate({ ...good, lastFrameTraitsOk: false, lastFrameHandsOk: false }, true).ok).toBe(false);
    expect(continuationGate({ ...good, lastFrameHandsOk: false }, true, { mode: "always" }).ok).toBe(true);
    expect(continuationGate(good, true, { mode: "never" }).ok).toBe(false);
    expect(continuationGate(undefined, true).ok).toBe(false);
  });
  test("结尾帧时间点均匀分布在结尾窗口内", () => {
    expect(tailFrameTimes(6, 3, 1.2)).toEqual([4.68, 5.28, 5.88]);
    expect(tailFrameTimes(0.5, 3, 1.2)[0]).toBe(0);
    expect(tailFrameTimes(6, 1)).toEqual([5.88]);
    expect(tailFrameLabels(2).map(label => label.name)).toEqual(["上一镜结尾第1/2帧", "上一镜结尾第2/2帧"]);
  });
});

describe("剧情连续性（场记）", () => {
  const board = () => {
    const parsed = parseStoryboard(boardInput());
    if (!parsed.ok) throw new Error(parsed.errors.join());
    return parsed.data;
  };
  test("补注、提示词与门检查：死者不复活、武器不无故换手", () => {
    const value = board();
    const shots = value.episodes[0]!.segments.flatMap(segment => segment.shots);
    const [firstId, secondId] = [shots[0]!.id, shots[1]!.id];
    const who = shots[0]!.characters[0]!.id;
    const missing = applyContinuity(value, { shots: shots.map(shot => ({ id: shot.id, dead: [], hands: shot.characters.map(item => ({ id: item.id, left: "空", right: shot.id === firstId ? "手枪" : "手枪" })), extras: "无" })) });
    expect(missing).toEqual([]);
    expect(hasContinuity(value)).toBe(true);
    expect(continuityProblems(value)).toEqual([]);
    const lines = continuityLines(shots[0]!, id => id);
    expect(lines.join("。")).toContain(`${who}右手持手枪，左手空`);
    expect(lines.join("。")).toContain("没有尸体");
    // 换手：第二镜武器到了左手，动作里没写换手
    const hand = shots[1]!.continuity!.hands!.find(item => item.id === who);
    if (hand && shots[1]!.characters.some(item => item.id === who)) {
      Object.assign(hand, { left: "手枪", right: "空" });
      expect(continuityProblems(value).some(problem => problem.includes("左手"))).toBe(true);
      const gates = runGates(value).gates;
      expect(gates.find(gate => gate.id === "story")!.ok).toBe(false);
      Object.assign(hand, { left: "空", right: "手枪" });
    }
    // 复活：第一镜已死，第二镜未列为死亡
    shots[0]!.continuity!.dead = [who];
    shots[0]!.characters = shots[0]!.characters.filter(item => item.id !== who);
    expect(continuityProblems(value).some(problem => problem.startsWith(secondId) && problem.includes("此前已死亡"))).toBe(true);
  });
});

describe("Clip Bin：版本化归档与只重做指定镜头", () => {
  test("parseShotList", () => {
    expect(parseShotList(["E01-02-03,E01-03-02", "E01-02-03"])).toEqual(["E01-02-03", "E01-03-02"]);
    expect(parseShotList("E01-02-03@v1")).toEqual(["E01-02-03@v1"]);
    expect(() => parseShotList("E1-2-3")).toThrow();
  });

  test("归档去重、版本号递增、索引原子写入", async () => {
    const dir = await mkdtemp(join(tmpdir(), "af-bin-"));
    await tone(join(dir, "s1.mp4"), 1, 90);
    await tone(join(dir, "s2.mp4"), 1.5, 120);
    const bin = new ClipBin("run", path => join(dir, path), systemFfmpeg);
    const first = await bin.archive("E01-01-01", "run/镜头/E01-01-01", { video: "s1.mp4", seed: 7, prompts: { firstFrame: "f", video: "v" } }, { model: "m" });
    const again = await bin.archive("E01-01-01", "run/镜头/E01-01-01", { video: "s1.mp4" });
    expect(again.clipId).toBe(first.clipId);
    const second = await bin.archive("E01-01-01", "run/镜头/E01-01-01", { video: "s2.mp4" }, { parentClipId: "E01-00-09@v1" });
    expect(second.clipId).toBe("E01-01-01@v2");
    expect(second.supersedes).toBe("E01-01-01@v1");
    const index = JSON.parse(await readFile(join(dir, "run/clipbin.json"), "utf8"));
    expect(index.clips.length).toBe(2);
    expect(index.current["E01-01-01"]).toBe("E01-01-01@v2");
    expect((await stat(join(dir, "run/镜头/E01-01-01/版本/v1/预览.jpg"))).size).toBeGreaterThan(0);
    const clip = JSON.parse(await readFile(join(dir, "run/镜头/E01-01-01/版本/v1/clip.json"), "utf8"));
    expect(clip.seed).toBe(7);
    expect((await readdir(join(dir, "run"))).some(name => name.endsWith(".tmp"))).toBe(false);
  }, 60_000);

  test("端到端：--redo 只重做指定镜头，旧版本原样保留；--pick 切回旧版本；续接参考随视频提交", async () => {
    const cwd = await mkdtemp(join(tmpdir(), "af-redo-"));
    const text = createMockTextModel();
    const generator = createMockGenerator(cwd);
    const scorer = createMockScorer([1]);
    const base = {
      story: "雨夜便利店，店员林夏把伞借给常客陈默。", seed: 1000, promptStyle: "generic" as const,
      imageModel: { providerId: "mock", modelId: "img", maxReferenceImages: 8 },
      videoModel: { providerId: "mock", modelId: "vid", durations: [3, 4, 5, 6], generateAudio: true, maxReferenceImages: 5 },
      continuation: { mode: "always" as const, frames: 2 },
    };
    const deps = { cwd, text, generate: generator.generate, scorer, ffmpeg: systemFfmpeg, retryDelayMs: 0 };
    const state = await runAutoflow(base, deps, "r1");
    expect(state.status).toBe("done");
    const ids = Object.keys(state.shots).sort();
    // 续接：同段第二镜起视频请求带上一镜结尾帧
    const continued = generator.requests.filter(item => item.mediaType === "video" && item.request.images?.some(image => image.path.includes("续接参考")));
    expect(continued.length).toBeGreaterThan(0);
    for (const item of continued) expect(item.request.referenceLabels?.length).toBe(item.request.images?.length);
    const target = ids[1]!;
    const oldVideo = state.shots[target]!.video!;
    const oldBytes = await readFile(join(cwd, oldVideo));
    const others = Object.fromEntries(ids.filter(id => id !== target).map(id => [id, state.shots[id]!.video]));
    const before = generator.requests.length;

    const redone = await runAutoflow({ ...base, redo: [target] }, deps, "r1");
    expect(redone.status).toBe("done");
    const fresh = generator.requests.slice(before);
    expect(fresh.length).toBeGreaterThan(0);
    expect(fresh.every(item => item.request.outputDirectory?.endsWith(target))).toBe(true);
    for (const id of ids.filter(id => id !== target)) expect(redone.shots[id]!.video).toBe(others[id]);
    const index = JSON.parse(await readFile(join(cwd, "一键成片/r1/clipbin.json"), "utf8"));
    const versions = index.clips.filter((clip: { shotId: string }) => clip.shotId === target);
    expect(versions.length).toBe(2);
    const v1 = versions.find((clip: { version: number }) => clip.version === 1);
    expect(Buffer.compare(await readFile(join(cwd, v1.video)), oldBytes)).toBe(0);
    expect(index.current[target]).toBe(`${target}@v2`);

    const picked = await runAutoflow({ ...base, pick: [`${target}@v1`] }, deps, "r1");
    expect(picked.shots[target]!.video).toBe(v1.video);
    expect(JSON.parse(await readFile(join(cwd, "一键成片/r1/clipbin.json"), "utf8")).current[target]).toBe(`${target}@v1`);
  }, 180_000);
  test("v5.2.5：参考图模式带续接帧和场景图；接力镜头走首帧模式并裁掉重复的第 0 帧；首帧不与参考图混用；同场景跨段接力", async () => {
    const cwd = await mkdtemp(join(tmpdir(), "af-chain-"));
    const generator = createMockGenerator(cwd);
    const state = await runAutoflow({
      story: "雨夜便利店，店员林夏把伞借给常客陈默。", seed: 1000, promptStyle: "generic" as const, chainContinuous: true, chainAcrossSegments: true,
      imageModel: { providerId: "mock", modelId: "img", maxReferenceImages: 8 },
      // framesWithReferences:false 模拟 ai& 网关：首尾帧与参考图不能放在同一个请求
      videoModel: { providerId: "mock", modelId: "vid", durations: [3, 4, 5, 6], generateAudio: true, maxReferenceImages: 9, input: "reference" as const, framesWithReferences: false },
      continuation: { mode: "qa" as const, frames: 2 },
    }, { cwd, text: createMockTextModel(), generate: generator.generate, scorer: createMockScorer([]), ffmpeg: systemFfmpeg, retryDelayMs: 0 }, "c1");
    expect(state.status).toBe("done");
    const videos = generator.requests.filter(item => item.mediaType === "video");
    const videoOf = (id: string) => videos.find(item => item.request.outputDirectory?.endsWith(id))!;
    for (const item of videos.filter(item => item.request.firstFrame)) expect(item.request.images ?? []).toEqual([]);
    // E01-01-03 是连续镜头：首帧 = 上一镜尾帧，按首帧模式提交，拼接时丢 1 帧
    expect(state.shots["E01-01-03"]!.chainedFrom).toBe("E01-01-02");
    expect(videoOf("E01-01-03").request.firstFrame?.path).toContain("E01-01-03/首帧.png");
    expect(state.shots["E01-01-03"]!.trimHeadFrames).toBe(1);
    // E01-01-02 是切镜：参考图模式，带首帧、场景图和上一镜结尾帧
    const second = videoOf("E01-01-02");
    expect(second.request.firstFrame).toBeUndefined();
    expect(second.request.images?.some(image => image.path.includes("续接参考"))).toBe(true);
    expect(second.request.images?.some(image => image.path.includes("场景"))).toBe(true);
    expect(second.request.referenceLabels?.length).toBe(second.request.images?.length);
    expect(state.shots["E01-01-02"]!.continuation?.from).toBe("E01-01-01");
    // 下一镜要接力：提示词要求结尾停在主角脸上
    expect(second.request.prompt).toContain("结尾交接");
    // 同场景跨段：E01-02-01 承接 E01-01-03 的结尾
    expect(state.shots["E01-02-01"]!.continuation?.from).toBe("E01-01-03");
  }, 180_000);
  test("逐帧质检钩子：读取最后一行 JSON，未通过时阻止下一镜续接、接力并禁止导出", async () => {
    const cwd = await mkdtemp(join(tmpdir(), "af-qa-"));
    const script = join(cwd, "qa.sh");
    // 质检脚本：第一镜不通过，其余通过；参数为 视频路径 + 质检输入.json
    await writeFile(script, `#!/bin/sh\necho "log line"\nif grep -q '"shotId": "E01-01-01"' "$2"; then echo '{"pass":false,"score":0.2,"issues":["手指异常@1.5"]}'; else echo '{"pass":true,"score":1,"issues":[]}'; fi\n`);
    await chmod(script, 0o755);
    const generator = createMockGenerator(cwd);
    // v5.2.5：外部质检只在 qaGate=block 时运行（v5.2.4 的这条测试没设 qaGate，质检从未执行）
    let error: any;
    try {
      await runAutoflow({
        story: "雨夜便利店，店员林夏把伞借给常客陈默。", seed: 1000, promptStyle: "generic" as const, chainContinuous: true,
        imageModel: { providerId: "mock", modelId: "img", maxReferenceImages: 8 },
        videoModel: { providerId: "mock", modelId: "vid", durations: [3, 4, 5, 6], generateAudio: true, maxReferenceImages: 5 },
        continuation: { mode: "qa" as const, frames: 2 }, shotQa: { command: [script] }, qaGate: "block",
      }, { cwd, text: createMockTextModel(), generate: generator.generate, scorer: createMockScorer([1]), ffmpeg: systemFfmpeg, retryDelayMs: 0 }, "q1");
    } catch (caught) { error = caught; }
    // 第一镜质检不通过：禁止导出
    expect(error?.message).toContain("禁止自动进入最终成片");
    const state = error.runState;
    expect(state.artifacts.final).toBeUndefined();
    const first = state.shots["E01-01-01"]!;
    expect(first.qa).toEqual({ pass: false, issues: ["手指异常@1.5"] });
    expect(first.qaResult.status).toBe("fail");
    expect(first.warnings.some((item: string) => item.includes("逐帧质检fail"))).toBe(true);
    expect(state.shots["E01-01-02"]?.continuation).toBeUndefined();
    for (const [id, shot] of Object.entries(state.shots) as [string, any][]) if (id !== "E01-01-01" && shot.video) expect(shot.qa?.pass).toBe(true);
  }, 120_000);
});
