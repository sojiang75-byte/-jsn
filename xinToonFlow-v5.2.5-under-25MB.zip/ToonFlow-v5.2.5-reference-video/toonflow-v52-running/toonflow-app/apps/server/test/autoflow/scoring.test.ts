import { describe, expect, test } from "bun:test";
import { mkdtemp, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { createHttpScorer, createModelScorer, extractJson, passThroughScorer } from "@/autoflow/scoring";

async function files() {
  const dir = await mkdtemp(join(tmpdir(), "af-score-"));
  for (const name of ["a.png", "c.png"]) await writeFile(join(dir, name), new Uint8Array([137, 80, 78, 71]));
  return { ref: join(dir, "a.png"), candidate: join(dir, "c.png") };
}

describe("一致性评分", () => {
  test("extractJson 容忍代码块和前后说明", () => {
    expect(extractJson("好的：\n```json\n{\"a\": {\"b\": \"}\"}}\n```\n以上")).toEqual({ a: { b: "}" } });
    expect(() => extractJson("没有 JSON")).toThrow();
  });
  test("模型评分取各角色与崩坏分的最小值，图片按参考在前、待审在后", async () => {
    const { ref, candidate } = await files();
    let seen: any;
    const scorer = createModelScorer(async input => { seen = input; return '{"characters":{"林夏":0.9},"artifacts":0.6,"reasons":["手指异常"]}'; });
    const result = await scorer.score({ candidate, references: [{ path: ref, name: "林夏", role: "character" }, { path: ref, name: "店", role: "scene" }], description: "d" });
    expect(result.score).toBe(0.6);
    expect(result.perCharacter).toEqual({ 林夏: 0.9 });
    expect(seen.images.length).toBe(2);
    expect(seen.prompt).toContain("图1：林夏");
  });
  test("服装连续性与手指检查并入分数，提示词带角色卡服装", async () => {
    const { ref, candidate } = await files();
    let seen: any;
    const scorer = createModelScorer(async input => { seen = input; return '{"characters":{"林夏":0.9},"outfit":{"林夏":0.3},"fingers":0.8,"artifacts":1}'; });
    const result = await scorer.score({ candidate, references: [{ path: ref, name: "林夏", role: "character", outfit: "深灰色高领夹克" }], description: "d" });
    expect(result.perCharacter).toEqual({ 林夏: 0.3 });
    expect(result.score).toBe(0.3);
    expect(seen.prompt).toContain("深灰色高领夹克");
    const scorer2 = createModelScorer(async () => '{"characters":{"林夏":0.9},"fingers":0.2,"artifacts":1}');
    expect((await scorer2.score({ candidate, references: [{ path: ref, name: "林夏", role: "character" }], description: "" })).score).toBe(0.2);
  });
  test("模型漏掉角色记 0 分", async () => {
    const { ref, candidate } = await files();
    const scorer = createModelScorer(async () => '{"characters":{},"artifacts":1}');
    expect((await scorer.score({ candidate, references: [{ path: ref, name: "林夏", role: "character" }], description: "" })).score).toBe(0);
  });
  test("人脸相似度钩子只允许本机/内网", async () => {
    expect(() => createHttpScorer("https://example.com/score")).toThrow();
    expect(() => createHttpScorer("http://127.0.0.1.evil.com/score")).toThrow();
    const { ref, candidate } = await files();
    const scorer = createHttpScorer("http://127.0.0.1:7860/score", (async () => Response.json({ scores: { 林夏: 0.81 } })) as any);
    expect((await scorer.score({ candidate, references: [{ path: ref, name: "林夏", role: "character" }], description: "" })).score).toBe(0.81);
  });
  test("passThrough 评分恒为 1", async () => {
    expect((await passThroughScorer.score({ candidate: "x", references: [], description: "" })).score).toBe(1);
  });
});
