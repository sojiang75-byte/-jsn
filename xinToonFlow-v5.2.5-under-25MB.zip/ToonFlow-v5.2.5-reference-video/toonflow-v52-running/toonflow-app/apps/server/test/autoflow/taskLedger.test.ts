import { describe, expect, test } from "bun:test";
import { mkdtemp, readdir } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { withTaskLedger } from "@/autoflow/taskLedger";

const request = { providerId: "aiand", modelId: "m", prompt: "p", seed: 1 };

describe("已提交任务台账（防重复扣费）", () => {
  test("拿到任务 id 后失败：重试只恢复原任务，不重新提交", async () => {
    const cwd = await mkdtemp(join(tmpdir(), "ledger-"));
    const submits: string[] = [];
    const first = withTaskLedger(cwd, "video", request, async task => {
      expect(task.resume).toBe(false);
      submits.push(task.taskId);
      await task.save({ providerData: { kind: "aiand", videoId: "vid_1" } });
      throw new Error("The operation timed out.");
    });
    await expect(first).rejects.toThrow("timed out");
    const result = await withTaskLedger(cwd, "video", request, async task => {
      expect(task.resume).toBe(true);
      expect((task.checkpoint.providerData as { videoId: string }).videoId).toBe("vid_1");
      return "resumed";
    });
    expect(result).toBe("resumed");
    expect(submits.length).toBe(1);
  });

  test("提交被拒（429，无任务 id）或任务失败（不计费）：清掉记录，允许重新提交", async () => {
    const cwd = await mkdtemp(join(tmpdir(), "ledger-"));
    await expect(withTaskLedger(cwd, "video", request, async task => {
      await task.save({ providerData: { kind: "aiand", videoId: "" } });
      throw Object.assign(new Error("busy"), { status: 429 });
    })).rejects.toThrow("busy");
    expect(await readdir(join(cwd, ".autoflow-tasks"))).toEqual([]);
    await expect(withTaskLedger(cwd, "video", request, async task => {
      await task.save({ providerData: { kind: "aiand", videoId: "vid_2" } });
      throw Object.assign(new Error("failed"), { code: "MEDIA_TASK_FAILED" });
    })).rejects.toThrow("failed");
    expect(await withTaskLedger(cwd, "video", request, async task => (task.resume ? "resume" : "fresh"))).toBe("fresh");
  });

  test("提交中断且没拿到任务 id：拒绝自动重提", async () => {
    const cwd = await mkdtemp(join(tmpdir(), "ledger-"));
    await expect(withTaskLedger(cwd, "video", request, async task => {
      await task.save({ providerData: { kind: "aiand", videoId: "" } });
      throw new Error("socket closed");
    })).rejects.toThrow("socket closed");
    let called = false;
    await expect(withTaskLedger(cwd, "video", request, async () => { called = true; return 1; })).rejects.toThrow("避免重复扣费");
    expect(called).toBe(false);
  });
});
