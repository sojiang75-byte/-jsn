import { describe, expect, test } from "bun:test";
import { parseStoryboard } from "@/autoflow/storyboard/schema";
import { fillDurations } from "@/autoflow/storyboard/timing";
import { buildShotPrompts } from "@/autoflow/storyboard/prompts";
import { shotPropCards } from "@/autoflow/storyboard/propCards";
import { boardInput, cards } from "./fixtures";

const van = {
  id: "van", name: "面包车", kind: "vehicle" as const,
  description: "白色方头微型面包车（五菱式），右侧滑门，深色后窗，车身下沿泥点，前保险杠凹陷；无警灯、无警用涂装",
  match: ["方向盘"], scenes: ["s_van"], negative: "警车，轿车，SUV",
};

function boardWithProps() {
  const input = boardInput() as any;
  input.props = [van];
  const parsed = parseStoryboard(input);
  if (!parsed.ok) throw new Error(parsed.errors.join("\n"));
  return fillDurations(parsed.data);
}

describe("固定道具/车辆卡", () => {
  test("schema 接受 props；未知字段仍报错", () => {
    expect(boardWithProps().props?.[0].name).toBe("面包车");
    const bad = boardInput() as any;
    bad.props = [{ ...van, color: "white" }];
    expect(parseStoryboard(bad).ok).toBe(false);
  });
  test("命中关键词/场景的镜头注入同一描述与负面车型，未命中的不注入", () => {
    const data = boardWithProps();
    const segment = data.episodes[0].segments[0];
    const shot = { ...segment.shots[0], action: `${segment.shots[0].action}，紧握方向盘` };
    expect(shotPropCards(data.props, segment, shot).map(card => card.id)).toEqual(["van"]);
    const prompts = buildShotPrompts({ board: data, segment, shot, cards: cards() });
    expect(prompts.firstFrame).toContain("固定车辆「面包车」");
    expect(prompts.video).toContain("五菱式");
    expect(prompts.negative).toContain("警车");
    const inScene = shotPropCards(data.props, { sceneId: "s_van" }, segment.shots[0]);
    expect(inScene.length).toBe(1);
    const plain = buildShotPrompts({ board: data, segment, shot: segment.shots[0], cards: cards() });
    if (!shotPropCards(data.props, segment, segment.shots[0]).length) {
      expect(plain.firstFrame).not.toContain("面包车");
      expect(plain.negative).not.toContain("警车");
    }
  });
});
