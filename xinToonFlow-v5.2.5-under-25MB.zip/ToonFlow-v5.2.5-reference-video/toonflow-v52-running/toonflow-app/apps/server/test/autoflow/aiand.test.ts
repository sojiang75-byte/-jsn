import { beforeAll, describe, expect, test } from "bun:test";
import { mkdtemp, readFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { loadMediaProviderSource, validateMediaProviderSource } from "@/utils/media/provider";
import { withEnvironmentCredentials } from "@/utils/media/generation";
import { makeSolidImage, systemFfmpeg } from "@/autoflow/media";
import { BudgetExceededError, BudgetGuard, budgetCap, estimateVideoCost, outcomeOfError, videoPricePerSecond } from "@/autoflow/budget";
import { autoflowRequestSchema } from "@/autoflow/service";
import { runAutoflow } from "@/autoflow/pipeline";
import { createMockGenerator, createMockScorer, createMockTextModel } from "@/autoflow/mock";

type Call = { url: string; method: string; headers: Record<string, string>; body?: any; raw?: Uint8Array };
let calls: Call[] = [];
let submit: { status: number; body: unknown } = { status: 200, body: { id: "video_1", status: "moderating", cost: "0.22000000" } };
let pollStates: string[] = [];
let submitThrows = false;
let listed: unknown[] = [];

/** 假的 ai& 网关：不发生任何真实网络请求 */
const fakeFetch = (async (input: string | URL | Request, init?: RequestInit) => {
  const url = String(input);
  const headers = Object.fromEntries(new Headers(init?.headers).entries());
  const isJson = headers["content-type"] === "application/json";
  calls.push({ url, method: init?.method ?? "GET", headers, body: isJson ? JSON.parse(String(init!.body)) : undefined, raw: !isJson && init?.body && ArrayBuffer.isView(init.body) ? new Uint8Array((init.body as Uint8Array).buffer) : undefined });
  if (url.endsWith("/files")) return Response.json({ id: `file-${calls.length}`, object: "file", purpose: "vision" });
  if (url.endsWith("/videos")) {
    if (submitThrows) throw Object.assign(new Error("The operation timed out."), { name: "TimeoutError" });
    return Response.json(submit.body, { status: submit.status });
  }
  if (url.includes("/videos?limit=")) return Response.json({ object: "list", data: listed });
  if (url.endsWith("/videos/video_1/content")) return new Response(new Uint8Array([0, 0, 0, 24, 102, 116, 121, 112]), { headers: { "content-type": "video/mp4" } });
  if (url.endsWith("/videos/video_1")) {
    const status = pollStates.shift() ?? "completed";
    return Response.json({ id: "video_1", status, error: status === "failed" ? { code: "moderation_blocked", message: "rejected" } : null });
  }
  return new Response("not found", { status: 404 });
}) as typeof fetch;

let png: { type: "base64"; data: string; mimeType: string };
let strip: typeof png;
beforeAll(async () => {
  const dir = await mkdtemp(join(tmpdir(), "aiand-"));
  const make = async (name: string, width: number, height: number) => {
    await makeSolidImage(join(dir, name), { width, height, color: "0x6b8cce" });
    return { type: "base64" as const, data: (await readFile(join(dir, name))).toString("base64"), mimeType: "image/png" };
  };
  png = await make("a.png", 640, 360);
  strip = await make("strip.png", 1000, 200);
});

async function provider(config: Record<string, unknown> = { apiKey: "sk-test", pollSeconds: "0.01" }, saved: any[] = []) {
  const source = await readFile(join(import.meta.dir, "../../../../packages/providers/src/media/aiand.ts"), "utf8");
  validateMediaProviderSource(source);
  return loadMediaProviderSource(source, config, undefined, fakeFetch, undefined, async data => { saved.push(data); }) as Promise<any>;
}
const reset = () => { submitThrows = false; listed = []; calls = []; pollStates = []; submit = { status: 200, body: { id: "video_1", status: "moderating" } }; };

describe("ai& 网关 · MiniMax H3 供应商", () => {
  test("首帧图生视频：先 multipart 上传，再以 image_reference 提交；轮询后带鉴权下载二进制；无 seed", async () => {
    reset(); pollStates = ["moderating", "translating", "queued", "in_progress", "completed"];
    const saved: any[] = [];
    const h3 = await provider(undefined, saved);
    const assets = await h3.generateVideo({ model: "minimaxai/minimax-h3", prompt: "she turns", firstFrame: png, duration: 4, seed: 9, ratio: "16:9" });
    expect(assets[0].type).toBe("binary");
    expect(assets[0].mimeType).toBe("video/mp4");
    const upload = calls[0]!;
    expect(upload.url).toBe("https://api.aiand.com/v1/files");
    expect(upload.headers["content-type"]).toStartWith("multipart/form-data; boundary=");
    const text = new TextDecoder().decode(upload.raw!.subarray(0, 400));
    expect(text).toContain('name="purpose"\r\n\r\nvision');
    expect(text).toContain("Content-Type: image/png");
    const create = calls.find(call => call.url.endsWith("/videos"))!;
    expect(create.body).toEqual({ model: "minimaxai/minimax-h3", prompt: "she turns", seconds: 4, aspect_ratio: "16:9", image_reference: [{ file_id: "file-1", role: "first_frame" }] });
    expect(calls.every(call => call.headers.authorization === "Bearer sk-test")).toBe(true);
    expect(calls.filter(call => call.url.endsWith("/videos/video_1")).length).toBe(5);
    expect(calls.at(-1)!.url).toBe("https://api.aiand.com/v1/videos/video_1/content");
    expect(saved.map(item => item.videoId)).toEqual(["", "video_1"]);
    expect(JSON.stringify(saved)).not.toContain("sk-test");
  }, 30_000);

  test("参考图模式：references.images、{{ref N}} → <Picture N>、自定义地址与缺省画幅 Auto", async () => {
    reset();
    const h3 = await provider({ apiKey: "sk-test", baseUrl: "https://gw.example/v1/", pollSeconds: "0.01" });
    await h3.generateVideo({ model: "minimaxai/minimax-h3", prompt: "{{ref 1}} meets {{ref 2}}", images: [png, png], duration: 6,
      referenceOrder: [{ type: "image", index: 0 }, { type: "image", index: 1 }] });
    const create = calls.find(call => call.url.endsWith("/videos"))!;
    expect(create.url).toBe("https://gw.example/v1/videos");
    expect(create.body.prompt).toBe("<Picture 1> meets <Picture 2>");
    expect(create.body.aspect_ratio).toBe("Auto");
    expect(create.body.references.images.length).toBe(2);
    expect(create.body.image_reference).toBeUndefined();
  });

  test("提交前校验：混用、时长、分辨率、长短边比、超长提示词、缺 Key", async () => {
    reset();
    const h3 = await provider();
    const base = { model: "minimaxai/minimax-h3", prompt: "x", duration: 4 };
    await expect(h3.generateVideo({ ...base, firstFrame: png, images: [png] })).rejects.toThrow("不能混用");
    await expect(h3.generateVideo({ ...base, duration: 3 })).rejects.toThrow("4–30");
    await expect(h3.generateVideo({ ...base, duration: 31 })).rejects.toThrow("4–30");
    await expect(h3.generateVideo({ ...base, resolution: "1080p" })).rejects.toThrow("768p");
    await expect(h3.generateVideo({ ...base, firstFrame: strip })).rejects.toThrow("4:1");
    await expect(h3.generateVideo({ ...base, prompt: "a".repeat(7001) })).rejects.toThrow("7000");
    await expect((await provider({})).generateVideo(base)).rejects.toMatchObject({ status: 401 });
    expect(calls.filter(call => call.url.endsWith("/videos")).length).toBe(0);
  });

  test("错误码：402/403/429 带 status 与中文提示；任务 failed 标记为不计费；未拿到 id 时续跑拒绝重复提交", async () => {
    const h3 = await provider();
    for (const [status, code, hint] of [[402, "insufficient_credits", "余额不足"], [403, "agreement_required", "Video Service Terms"], [429, "concurrency_limit_exceeded", "并发"]] as const) {
      reset(); submit = { status, body: { error: { code, message: code } } };
      const error = await h3.generateVideo({ model: "minimaxai/minimax-h3", prompt: "x", duration: 4 }).catch((e: any) => e);
      expect(error.status).toBe(status);
      expect(error.code).toBe(code);
      if (code !== "concurrency_limit_exceeded") expect(error.message).toContain(hint);
    }
    reset(); pollStates = ["failed"];
    await expect(h3.generateVideo({ model: "minimaxai/minimax-h3", prompt: "x", duration: 4 })).rejects.toMatchObject({ code: "MEDIA_TASK_FAILED" });
    await expect(h3.resumeTask({ kind: "aiand", videoId: "", baseUrl: "https://api.aiand.com/v1", seconds: 4 })).rejects.toThrow("不会自动重新提交");
    expect(await h3.getPrice({ type: "video", duration: 10 })).toMatchObject({ price: "$0.550" });
  });

  test("提交响应超时：按提示词找回已建任务继续轮询，不重复提交；找不到才报错", async () => {
    const saved: any[] = [];
    const h3 = await provider({ apiKey: "sk-test", pollSeconds: "0.01" }, saved);
    reset(); submitThrows = true;
    const now = Math.floor(Date.now() / 1000);
    listed = [
      { id: "video_old", prompt: "a mantis waits", created_at: now - 3600, status: "completed" },
      { id: "video_other", prompt: "something else", created_at: now, status: "queued" },
      { id: "video_1", prompt: "a mantis waits", created_at: now, status: "queued" },
    ];
    const assets = await h3.generateVideo({ model: "minimaxai/minimax-h3", prompt: "a mantis waits", duration: 4 });
    expect(assets[0].mimeType).toBe("video/mp4");
    expect(calls.filter(call => call.method === "POST" && call.url.endsWith("/videos")).length).toBe(1);
    expect(saved.at(-1)).toMatchObject({ videoId: "video_1" });
  }, 30_000);

  test("环境变量注入 Key（只对 aiand，配置优先）", () => {
    expect(withEnvironmentCredentials("aiand", {}, { AIAND_API_KEY: "k1" })).toEqual({ apiKey: "k1" });
    expect(withEnvironmentCredentials("aiand", {}, { AIAND_KEY: "k2", AIAND_BASE_URL: "https://x/v1" })).toEqual({ apiKey: "k2", baseUrl: "https://x/v1" });
    expect(withEnvironmentCredentials("aiand", { apiKey: "saved" }, { AIAND_API_KEY: "k1" })).toEqual({ apiKey: "saved" });
    expect(withEnvironmentCredentials("minimaxH3", {}, { AIAND_API_KEY: "k1" })).toEqual({});
  });
});

describe("花费估算与预算守卫", () => {
  test("报价、预留、结算", () => {
    expect(videoPricePerSecond("aiand", "minimaxai/minimax-h3")).toBe(0.055);
    expect(videoPricePerSecond("other", "m")).toBeUndefined();
    expect(estimateVideoCost(4, 0.055)).toBe(0.22);
    const guard = new BudgetGuard({ maxUsd: 0.5 }, { usd: 0, entries: [] });
    const first = guard.reserve("a", 4, 0.22);
    guard.settle(first, "charged");
    const second = guard.reserve("b", 4, 0.22);
    guard.settle(second, "free");
    expect(guard.spend.usd).toBe(0.22);
    guard.reserve("c", 4, 0.22);
    expect(() => guard.reserve("d", 4, 0.22)).toThrow(BudgetExceededError);
    expect(() => guard.preflight("x", 0.1)).toThrow("预算预检");
    expect(outcomeOfError(Object.assign(new Error(), { status: 402 }))).toBe("free");
    expect(outcomeOfError(Object.assign(new Error(), { code: "MEDIA_TASK_FAILED" }))).toBe("free");
    expect(outcomeOfError(new Error("timeout"))).toBe("uncertain");
  });

  test("缺省不限额：maxUsd 缺省 / 0 / 空 / null 都不拦截，但照样记录花费；请求体与操作页接受留空", async () => {
    for (const options of [undefined, {}, { maxUsd: 0 }, { maxUsd: null }, { maxUsd: Number.NaN }, { pricePerSecond: 0.1 }]) {
      expect(budgetCap(options as any)).toBeUndefined();
      const guard = new BudgetGuard(options as any, { usd: 0, entries: [] });
      for (let index = 0; index < 50; index++) guard.settle(guard.reserve(`v${index}`, 30, 1.65), "charged");
      expect(() => guard.preflight("镜头", 100000)).not.toThrow();
      expect(guard.spend.usd).toBeCloseTo(82.5, 3);
      expect(guard.spend.entries.length).toBe(50);
    }
    expect(budgetCap({ maxUsd: 2 })).toBe(2);
    expect(autoflowRequestSchema.parse({ story: "海边", budget: { maxUsd: "" } }).budget).toEqual({ maxUsd: undefined });
    expect(autoflowRequestSchema.parse({ story: "海边", budget: { maxUsd: null } }).budget?.maxUsd).toBeUndefined();
    expect(autoflowRequestSchema.parse({ story: "海边", budget: { maxUsd: 0 } }).budget?.maxUsd).toBe(0);
    expect(autoflowRequestSchema.parse({ story: "海边" }).budget).toBeUndefined();
    const ui = await readFile(join(import.meta.dir, "../../src/routes/autoflow/ui.ts"), "utf8");
    expect(ui).toContain("留空 = 不限制");
    expect(ui).toContain('Number($("maxUsd").value) > 0');
    // 余额不足仍按 402 insufficient_credits 处理（不重试、不计费）
    expect(outcomeOfError(Object.assign(new Error("余额不足"), { status: 402, code: "insufficient_credits" }))).toBe("free");
  });

  const options = (cwd: string, budget: any, input?: any) => ({
    story: "雨夜便利店，店员林夏把伞借给常客陈默。", seed: 7, budget,
    imageModel: { providerId: "aiand", modelId: "minimaxai/minimax-h3", maxReferenceImages: 9, stillFromVideo: { duration: 4 } },
    videoModel: { providerId: "aiand", modelId: "minimaxai/minimax-h3", durations: [4, 5, 6], generateAudio: true, input, maxReferenceImages: 9 },
  });

  test("预检：预计花费超上限时在提交任何付费请求前中止", async () => {
    const cwd = await mkdtemp(join(tmpdir(), "af-budget-"));
    const generator = createMockGenerator(cwd);
    const error = await runAutoflow(options(cwd, { maxUsd: 0.3 }), { cwd, text: createMockTextModel(), generate: generator.generate, scorer: createMockScorer([]), ffmpeg: systemFfmpeg, retryDelayMs: 0 }, "b1").catch(e => e);
    expect(error.code).toBe("BUDGET_EXCEEDED");
    expect(generator.requests.length).toBe(0);
    expect(error.runState.status).toBe("failed");
  });

  test("逐次守卫：关闭预检时花到上限即停，且记录花费；directReference 不出关键帧、视频带角色参考图", async () => {
    const cwd = await mkdtemp(join(tmpdir(), "af-budget-"));
    const generator = createMockGenerator(cwd);
    const deps = { cwd, text: createMockTextModel(), generate: generator.generate, scorer: createMockScorer([]), ffmpeg: systemFfmpeg, retryDelayMs: 0 };
    const error = await runAutoflow(options(cwd, { maxUsd: 1, preflight: false }, "directReference"), deps, "b2").catch(e => e);
    expect(error.code).toBe("BUDGET_EXCEEDED");
    const spend = error.runState.spend;
    expect(spend.usd).toBeLessThanOrEqual(1);
    expect(spend.entries.filter((entry: any) => entry.status === "charged").length).toBe(generator.requests.length);

    // 缺省不限额（不传 budget）：跑完整条流程，照样记录花费并写进报告
    const cwd2 = await mkdtemp(join(tmpdir(), "af-budget-"));
    const generator2 = createMockGenerator(cwd2);
    const state = await runAutoflow(options(cwd2, undefined, "directReference"), { ...deps, cwd: cwd2, generate: generator2.generate }, "b3");
    expect(state.status).toBe("done");
    const shotRequests = generator2.requests.filter(item => item.request.outputDirectory?.includes("/镜头/"));
    expect(shotRequests.every(item => item.request.generateAudio !== false)).toBe(true); // 无静帧关键帧
    expect(shotRequests.some(item => (item.request.images?.length ?? 0) > 0)).toBe(true);
    expect(state.spend!.usd).toBeCloseTo(generator2.requests.reduce((sum, item) => sum + Math.max(4, Math.round(item.request.duration ?? 4)) * 0.055, 0), 3);
    const report = await readFile(join(cwd2, state.artifacts.report!), "utf8");
    expect(report).toContain("花费");
    for (const shot of Object.values(state.shots)) expect(shot.keyframe).toBeTruthy();
  }, 120_000);
});
