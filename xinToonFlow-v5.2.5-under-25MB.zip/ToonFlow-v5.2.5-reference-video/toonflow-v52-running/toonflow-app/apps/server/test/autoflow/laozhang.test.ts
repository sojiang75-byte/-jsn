import { describe, expect, test } from "bun:test";
import { mkdtemp } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { parseStoryboard } from "@/autoflow/storyboard/schema";
import { fillDurations } from "@/autoflow/storyboard/timing";
import { buildShotPrompts } from "@/autoflow/storyboard/prompts";
import { propProductPrompt, shotPropImages } from "@/autoflow/storyboard/propCards";
import { resolveShotReferences } from "@/autoflow/references";
import { buildStitchFilter, planSeams } from "@/autoflow/stitch";
import { buildMasterAudioFilter, edgesFromSilence, masterFilm, parseLoudnorm, speechSafeEdges } from "@/autoflow/mastering";
import { runProcess, probeMedia } from "@/autoflow/media";
import { boardInput, cards } from "./fixtures";

const van = { id: "van", name: "面包车", kind: "vehicle" as const, description: "白色方头微型面包车，无警灯", match: ["方向盘"], negative: "警车", image: "道具/van.png" };
const shot = { id: "E01-01-01", characters: [{ id: "linxia" }, { id: "chenmo" }] };

describe("道具产品照参考图", () => {
  test("产品照提示词：中性灰、单一侧光、无人物无文字", () => {
    const prompt = propProductPrompt(van, "日漫");
    expect(prompt).toContain("中性灰");
    expect(prompt).toContain("一个柔和的侧光");
    expect(prompt).toContain("没有人物");
    expect(prompt).toContain("白色方头微型面包车");
  });
  test("命中道具的镜头挂产品照：排在场景图之后、上一镜与正脸之前，标签为 prop", () => {
    const input = boardInput() as any; input.props = [van];
    const parsed = parseStoryboard(input); if (!parsed.ok) throw new Error(parsed.errors.join("\n"));
    const data = fillDurations(parsed.data); const segment = data.episodes[0].segments[0];
    const hit = { ...segment.shots[0], action: `${segment.shots[0].action}，紧握方向盘` };
    expect(shotPropImages(data.props, segment, hit)).toEqual([{ path: "道具/van.png", name: "面包车" }]);
    const plan = resolveShotReferences({ shot, cards: cards(), sceneImage: { path: "s.png", name: "便利店" }, propImages: [{ path: "道具/van.png", name: "面包车" }], previousFrame: "prev.png" });
    expect(plan.images.map(item => item.path)).toEqual(["角色/林夏/anchor.png", "角色/陈默/anchor.png", "s.png", "道具/van.png", "prev.png", "角色/林夏/face.png", "角色/陈默/face.png"]);
    expect(plan.referenceLabels[3].role).toBe("prop");
    expect(plan.entries[3].kind).toBe("prop");
  });
});

describe("提示词锁", () => {
  test("有台词：台词锁 + 不要音乐；无台词：无人声", () => {
    const input = boardInput() as any;
    const parsed = parseStoryboard(input); if (!parsed.ok) throw new Error(parsed.errors.join("\n"));
    const data = fillDurations(parsed.data); const segment = data.episodes[0].segments[0];
    const talk = { ...segment.shots[0], dialogue: [{ speaker: segment.shots[0].characters[0].id, text: "你好" }] };
    const quiet = { ...segment.shots[0], dialogue: [] };
    expect(buildShotPrompts({ board: data, segment, shot: talk as any, cards: cards() }).video).toContain("台词锁");
    expect(buildShotPrompts({ board: data, segment, shot: talk as any, cards: cards() }).video).toContain("不要音乐");
    expect(buildShotPrompts({ board: data, segment, shot: quiet as any, cards: cards() }).video).toContain("没有任何人声");
  });
});

describe("剪辑母版", () => {
  test("按静音求首尾可剪长度，不剪到声音", () => {
    const err = "silence_start: 0\nsilence_end: 0.30 | silence_duration: 0.3\nsilence_start: 5.85\n";
    expect(edgesFromSilence(err, 6)).toEqual({ head: 0.12, tail: 0.11 });
    expect(edgesFromSilence("silence_start: 0\nsilence_end: 0.06\n", 6)).toEqual({ head: 0.02, tail: 0 });
    expect(edgesFromSilence("", 6)).toEqual({ head: 0, tail: 0 });
  });
  test("接缝计划带首尾剪切；有重叠裁头时不再剪头；画面按剪后时长截取", () => {
    const clips = [{ file: "a", edgeHeadSeconds: 0.1, edgeTailSeconds: 0.08 }, { file: "b", trimHeadFrames: 6, edgeHeadSeconds: 0.1 }];
    const plans = planSeams(clips, [{ head: [], tail: [] }, { head: [], tail: [] }], { fps: 24 });
    expect(plans[0].edgeHead).toBe(0.1); expect(plans[0].edgeTail).toBe(0.08); expect(plans[1].edgeHead).toBeUndefined();
    const probe = { duration: 6, hasAudio: true, width: 720, height: 1280 } as any;
    const { filter } = buildStitchFilter([probe, probe], plans, { width: 1080, height: 1920 });
    expect(filter).toContain("trim=start=0.1000:duration=5.8200");
    expect(filter).toContain("atrim=start=0.1000");
  });
  test("音频母版滤镜：底噪侧链 + 两遍 loudnorm", () => {
    const first = buildMasterAudioFilter(10);
    expect(first).toContain("anoisesrc=color=brown");
    expect(first).toContain("sidechaincompress");
    expect(first).toContain("loudnorm=I=-15:TP=-1.5");
    const m = parseLoudnorm('[Parsed_loudnorm_0]\n{\n "input_i" : "-23.1",\n "input_tp" : "-3.2",\n "input_lra" : "5.0",\n "input_thresh" : "-33.4",\n "target_offset" : "0.2"\n}');
    expect(m?.input_i).toBe("-23.1");
    expect(buildMasterAudioFilter(10, { bedDb: null }, m!)).toContain("measured_I=-23.1");
    expect(buildMasterAudioFilter(10, { bedDb: null })).not.toContain("anoisesrc");
  });
  test("真实 FFmpeg：静音首尾被测出，母版响度落在 -15±1 LUFS、真峰值 ≤ -1 dBTP", async () => {
    const dir = await mkdtemp(join(tmpdir(), "master-"));
    const src = join(dir, "a.mp4");
    // 0.3 s 静音 + 2 s 正弦 + 0.3 s 静音
    await runProcess("ffmpeg", ["-v", "error", "-y", "-f", "lavfi", "-i", "color=c=gray:s=180x320:d=2.6:r=24", "-f", "lavfi", "-i",
      "aevalsrc='if(between(t,0.3,2.3),0.2*sin(2*PI*440*t),0)':s=48000:d=2.6", "-shortest", "-c:v", "libx264", "-c:a", "aac", src]);
    const edges = await speechSafeEdges(src, 2.6, 0.12);
    expect(edges.head).toBeGreaterThan(0.05); expect(edges.tail).toBeGreaterThan(0.05);
    const out = join(dir, "m.mp4");
    await masterFilm(src, out, 2.6);
    const r = await runProcess("ffmpeg", ["-hide_banner", "-nostdin", "-i", out, "-af", "ebur128=peak=true", "-f", "null", "-"]);
    const i = Number(r.stderr.match(/I:\s+(-?[\d.]+) LUFS/g)!.pop()!.match(/-?[\d.]+/)![0]);
    const tp = Number(r.stderr.match(/Peak:\s+(-?[\d.]+) dBFS/g)!.pop()!.match(/-?[\d.]+/)![0]);
    expect(Math.abs(i + 15)).toBeLessThan(1.5);
    expect(tp).toBeLessThanOrEqual(-1);
    expect((await probeMedia(out)).duration).toBeGreaterThan(2.4);
  }, 60000);
});
