import { describe, expect, test } from "bun:test";
import { planVisualRepair } from "@/autoflow/repairLadder";

describe("visual repair ladder", () => {
  test("black confined to the head is trimmed and not rerolled", () => {
    const decision = planVisualRepair({ duration: 10, spans: [{ start: 0, end: 0.8, code: "black" }], issueKey: "black", history: [] });
    expect(decision).toMatchObject({ action: "trim", head: 0.8, tail: 0 });
  });

  test("a cut in the middle patches from the frame before it", () => {
    const decision = planVisualRepair({ duration: 10, spans: [{ start: 4, end: 4, code: "cut" }], issueKey: "cut", history: [] });
    expect(decision).toMatchObject({ action: "patch", at: 3.85, generateSeconds: 7 });
  });

  test("an untimed failure revises the prompt, rerolls once, then stops", () => {
    const revise = planVisualRepair({ duration: 8, spans: [], issueKey: "hands", history: [] });
    expect(revise.action).toBe("revise");
    const reroll = planVisualRepair({ duration: 8, spans: [], issueKey: "hands", history: [{ action: "revise", issueKey: "hands" }] });
    expect(reroll.action).toBe("reroll");
    const stop = planVisualRepair({ duration: 8, spans: [], issueKey: "hands", history: [{ action: "revise", issueKey: "hands" }, { action: "reroll", issueKey: "hands" }] });
    expect(stop).toMatchObject({ action: "stop" });
  });

  test("free path does not pay for a middle defect", () => {
    const decision = planVisualRepair({ duration: 10, spans: [{ start: 4, end: 4, code: "cut" }], issueKey: "cut", history: [], allowPaid: false });
    expect(decision.action).toBe("accept");
  });
});
