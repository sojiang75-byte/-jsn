import { characterCardSchema, type CharacterCard } from "@/utils/assets/characterCard";
import { mockCast, mockStoryboard } from "@/autoflow/mock";
import type { StoryboardInput } from "@/autoflow/storyboard/schema";

export function boardInput(broken = false): StoryboardInput {
  const cast = mockCast("雨伞");
  return {
    version: 1, title: cast.title, aspectRatio: "16:9", style: cast.style,
    characters: cast.characters.map(item => ({ id: item.id, name: item.name })),
    scenes: cast.scenes, ...mockStoryboard(broken),
  } as StoryboardInput;
}

export function cards(withViews = true) {
  const map = new Map<string, CharacterCard>();
  for (const character of mockCast("雨伞").characters) {
    const card = characterCardSchema.parse({ version: 1, ...character, outfits: character.outfits.map(outfit => ({ ...outfit,
      ...(withViews ? { views: { anchor: `角色/${character.name}/anchor.png`, face: `角色/${character.name}/face.png` } } : {}) })) });
    map.set(card.id, card);
  }
  return map;
}
