import { afterAll, beforeAll, describe, expect, test } from "bun:test";
import { mkdtemp, readFile, readdir, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { loadMediaProviderSource, validateMediaProviderSource } from "@/utils/media/provider";
import { estimateVideoCost, videoPricePerSecond } from "@/autoflow/budget";
import { withTaskLedger } from "@/autoflow/taskLedger";

const providerFile = join(import.meta.dir, "../../../../packages/providers/src/media/grokRelay.ts");
const relayDir = join(import.meta.dir, "../../../../tools/grok-relay");
const png = { type: "base64" as const, data: Buffer.from("\x89PNG\r\n\x1a\nfake", "binary").toString("base64"), mimeType: "image/png" };

type Call = { url: string; method: string; headers: Record<string, string>; body?: any };
let calls: Call[] = [];
let states: string[] = [];
let submitFailures = 0;
const fakeFetch = (async (input: string | URL | Request, init?: RequestInit) => {
  const url = String(input);
  const headers = Object.fromEntries(new Headers(init?.headers).entries());
  calls.push({ url, method: init?.method ?? "GET", headers, body: init?.body ? JSON.parse(String(init.body)) : undefined });
  if (init?.method === "POST") {
    if (submitFailures-- > 0) throw new TypeError("fetch failed");
    return Response.json({ id: url.includes("/videos") ? "vid_20261102_000000_abc123" : "img_20261102_000000_abc123", status: "queued" });
  }
  if (url.endsWith("/content")) return new Response(new Uint8Array([1, 2, 3]), { headers: { "content-type": url.includes("/images/") ? "image/jpeg" : "video/mp4" } });
  const status = states.shift() ?? "completed";
  return Response.json({ id: "x", status, error: status === "failed" ? { code: "generation_failed", message: "blocked" } : undefined });
}) as typeof fetch;

async function provider(config: Record<string, unknown> = { pollSeconds: "0.001" }, saved: any[] = [], fetcher = fakeFetch) {
  const source = await readFile(providerFile, "utf8");
  validateMediaProviderSource(source);
  return loadMediaProviderSource(source, config, undefined, fetcher, undefined, async data => { saved.push(data); }) as Promise<any>;
}
const reset = () => { calls = []; states = []; submitFailures = 0; };

describe("grok-relay 供应商（本机 Grok Imagine 中继）", () => {
  test("图片：提交带 Idempotency-Key 与 data URL 参考图，排队若干次后取回字节", async () => {
    reset(); states = ["queued", "queued", "completed"];
    const saved: any[] = [];
    const relay = await provider(undefined, saved);
    const assets = await relay.generateImage({ model: "grok-imagine-image", prompt: "a mantis", images: [png], ratio: "9:16", seed: 7 });
    expect(assets[0]).toMatchObject({ type: "binary", mimeType: "image/jpeg", mediaType: "image" });
    const post = calls[0]!;
    expect(post.url).toBe("http://127.0.0.1:8787/v1/images/generations");
    expect(post.headers["idempotency-key"]).toStartWith("toonflow-image-");
    expect(post.body).toMatchObject({ model: "grok-imagine-image", prompt: "a mantis", aspect_ratio: "9:16", seed: 7, n: 1 });
    expect(post.body.images[0]).toStartWith("data:image/png;base64,");
    expect(calls.filter(call => call.url.endsWith("/images/img_20261102_000000_abc123")).length).toBe(3);
    expect(saved).toEqual([{ kind: "grokRelay", mediaType: "image", taskId: "img_20261102_000000_abc123", baseUrl: "http://127.0.0.1:8787/v1" }]);
  });

  test("视频：秒数 >15 直接拒绝；首帧 + 参考图；{{ref N}} 改写为英文标签；失败任务标记 MEDIA_TASK_FAILED", async () => {
    reset();
    const relay = await provider();
    await expect(relay.generateVideo({ model: "grok-imagine-video", prompt: "x", duration: 16 })).rejects.toMatchObject({ status: 400 });
    expect(calls.length).toBe(0);
    const assets = await relay.generateVideo({ model: "grok-imagine-video", prompt: "{{ref 1}} walks past {{ref 2}}", duration: 6, ratio: "9:16", firstFrame: png, images: [png],
      referenceOrder: [{ type: "firstFrame" }, { type: "image", index: 0 }] });
    expect(assets[0]).toMatchObject({ mimeType: "video/mp4", mediaType: "video" });
    expect(calls[0]!.body).toMatchObject({ prompt: "the first frame walks past reference image 1", seconds: 6, aspect_ratio: "9:16" });
    expect(calls[0]!.body.first_frame).toStartWith("data:image/png;base64,");
    reset(); states = ["failed"];
    await expect(relay.generateVideo({ model: "grok-imagine-video", prompt: "y", duration: 4 })).rejects.toMatchObject({ code: "MEDIA_TASK_FAILED" });
  });

  test("提交时连接失败：用同一个 Idempotency-Key 重发；只允许本机地址", async () => {
    reset(); submitFailures = 2;
    const relay = await provider();
    await relay.generateVideo({ model: "grok-imagine-video", prompt: "z", duration: 5 });
    const posts = calls.filter(call => call.method === "POST");
    expect(posts.length).toBe(3);
    expect(new Set(posts.map(post => post.headers["idempotency-key"])).size).toBe(1);
    const remote = await provider({ baseUrl: "https://example.com/v1" });
    await expect(remote.generateImage({ model: "grok-imagine-image", prompt: "x" })).rejects.toMatchObject({ status: 400 });
  });

  test("resumeTask 只轮询原任务，不重新提交；中继暂时不可用时继续等", async () => {
    reset();
    let down = 2;
    const flaky = (async (input: string | URL | Request, init?: RequestInit) => {
      if (!String(input).endsWith("/content") && down-- > 0) throw new TypeError("connection refused");
      return fakeFetch(input, init);
    }) as typeof fetch;
    const relay = await provider(undefined, [], flaky);
    const assets = await relay.resumeTask({ kind: "grokRelay", mediaType: "video", taskId: "vid_20261102_000000_abc123", baseUrl: "http://127.0.0.1:8787/v1" });
    expect(assets[0].mediaType).toBe("video");
    expect(calls.some(call => call.method === "POST")).toBe(false);
  });

  test("花费：grok-relay 视频单价 $0（花费记录显示 $0、不触发上限）；台账能识别 taskId 并恢复", async () => {
    expect(videoPricePerSecond("grokRelay", "grok-imagine-video")).toBe(0);
    expect(estimateVideoCost(15, videoPricePerSecond("grokRelay", "grok-imagine-video")!)).toBe(0);
    const cwd = await mkdtemp(join(tmpdir(), "relay-ledger-"));
    const request = { providerId: "grokRelay", modelId: "grok-imagine-video", prompt: "p" };
    await expect(withTaskLedger(cwd, "video", request, async task => {
      await task.save({ providerData: { kind: "grokRelay", mediaType: "video", taskId: "vid_1", baseUrl: "http://127.0.0.1:8787/v1" } });
      throw new Error("The operation timed out.");
    })).rejects.toThrow("timed out");
    expect(await withTaskLedger(cwd, "video", request, async task => (task.resume ? "resume" : "fresh"))).toBe("resume");
  });
});

describe("grok-relay 端到端（真实 Python 中继 + finish.py / fail.py）", () => {
  let root = "";
  let port = 0;
  let server: ReturnType<typeof Bun.spawn> | undefined;
  const env = () => ({ ...process.env, RELAY_ROOT: root, RELAY_PORT: String(port) });
  beforeAll(async () => {
    root = await mkdtemp(join(tmpdir(), "relay-"));
    port = 20000 + Math.floor(Math.random() * 20000);
    server = Bun.spawn(["python3", join(relayDir, "server.py")], { env: env(), stdout: "ignore", stderr: "ignore" });
    for (let i = 0; i < 100; i++) {
      if (await fetch(`http://127.0.0.1:${port}/health`).then(r => r.ok, () => false)) return;
      await Bun.sleep(50);
    }
    throw new Error("relay server did not start");
  });
  afterAll(() => { server?.kill(); });
  const run = (script: string, ...args: string[]) => {
    const result = Bun.spawnSync(["python3", join(relayDir, script), ...args], { env: env() });
    if (result.exitCode !== 0) throw new Error(result.stderr.toString());
    return result.stdout.toString();
  };
  const waitQueued = async () => {
    for (let i = 0; i < 200; i++) {
      const names = (await readdir(join(root, "queue"))).filter(name => name.endsWith(".json"));
      if (names.length) return names[0]!.replace(/\.json$/, "");
      await Bun.sleep(25);
    }
    throw new Error("no job queued");
  };

  test("图片 + 视频：排队 → next.py 列出 → finish.py 回填 → 供应商取回；同 key 不重复；fail.py → MEDIA_TASK_FAILED", async () => {
    const relay = await provider({ baseUrl: `http://127.0.0.1:${port}/v1`, pollSeconds: "0.05" }, [], fetch);
    const image = relay.generateImage({ model: "grok-imagine-image", prompt: "mantis on a leaf", images: [png], ratio: "9:16" });
    const imageId = await waitQueued();
    const job = JSON.parse(await readFile(join(root, "queue", `${imageId}.json`), "utf8"));
    expect(job.references.images[0]).toBe(join(root, "inputs", imageId, "ref1.png"));
    expect(run("next.py")).toContain("mantis on a leaf");
    const dummyPng = join(root, "dummy.png");
    await writeFile(dummyPng, Buffer.from("\x89PNG\r\n\x1a\n-dummy-image", "binary"));
    run("finish.py", imageId, dummyPng);
    const [asset] = await image;
    expect(asset.mimeType).toBe("image/png");
    expect(Buffer.from(asset.data).toString("binary")).toContain("-dummy-image");
    // 同一请求重发：中继按 Idempotency-Key 返回已完成的原任务，不再排队
    await relay.generateImage({ model: "grok-imagine-image", prompt: "mantis on a leaf", images: [png], ratio: "9:16" });
    expect((await readdir(join(root, "queue"))).filter(name => name.endsWith(".json"))).toEqual([]);

    const video = relay.generateVideo({ model: "grok-imagine-video", prompt: "mantis turns", duration: 8, ratio: "9:16", firstFrame: png });
    const videoId = await waitQueued();
    expect(videoId).toStartWith("vid_");
    const dummyMp4 = join(root, "dummy.mp4");
    await writeFile(dummyMp4, Buffer.from("\x00\x00\x00\x18ftypmp42-dummy-video", "binary"));
    run("finish.py", videoId, dummyMp4);
    const [clip] = await video;
    expect(clip.mimeType).toBe("video/mp4");
    const done = JSON.parse(await readFile(join(root, "done", `${videoId}.json`), "utf8"));
    expect(done.file).toBe(join(root, "outputs", `${videoId}.mp4`));

    const failing = relay.generateVideo({ model: "grok-imagine-video", prompt: "will fail", duration: 4 });
    const failId = await waitQueued();
    run("fail.py", failId, "content policy");
    await expect(failing).rejects.toMatchObject({ code: "MEDIA_TASK_FAILED" });
    const tooLong = await fetch(`http://127.0.0.1:${port}/v1/videos`, { method: "POST", body: JSON.stringify({ prompt: "x", seconds: 20 }), headers: { "Content-Type": "application/json" } });
    expect(tooLong.status).toBe(400);
  }, 30_000);
});

import { storyboardInstructions } from "../../src/autoflow/planner";
test("storyboard instructions follow configured shot length range", () => {
  const base = { story: "x", episodes: 1, targetSeconds: 60, aspectRatio: "9:16" };
  expect(storyboardInstructions(base)).toContain("每镜 2–10 秒");
  expect(storyboardInstructions({ ...base, shotSeconds: { min: 4, max: 15 } })).toContain("每镜 4–15 秒");
});

describe("grok-relay 画幅映射", () => {
  test("不支持的画幅映射到最接近的受支持画幅，不报错；流水线会请求的画幅都能提交", async () => {
    const relay = await provider();
    const sent = async (ratio: string) => {
      reset();
      await relay.generateImage({ model: "grok-imagine-image", prompt: "x", ratio });
      return calls[0]!.body.aspect_ratio;
    };
    expect(await sent("4:5")).toBe("3:4");
    expect(await sent("5:4")).toBe("4:3");
    expect(await sent("1024x1536")).toBe("2:3");
    expect(await sent("2.39:1")).toBe("21:9");
    for (const ratio of ["16:9", "9:16", "1:1", "4:3", "3:4", "2:3", "21:9"]) expect(await sent(ratio)).toBe(ratio);
    reset();
    await relay.generateVideo({ model: "grok-imagine-video", prompt: "x", duration: 5, ratio: "4:5" });
    expect(calls[0]!.body.aspect_ratio).toBe("3:4");
    await expect(relay.generateImage({ model: "grok-imagine-image", prompt: "x", ratio: "wide" })).rejects.toMatchObject({ status: 400 });
  });
});
