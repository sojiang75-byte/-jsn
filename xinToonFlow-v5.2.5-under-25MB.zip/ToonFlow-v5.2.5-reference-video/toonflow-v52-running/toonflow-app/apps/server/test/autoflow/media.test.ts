import { beforeAll, describe, expect, test } from "bun:test";
import { mkdtemp, stat } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { runProcess, probeMedia, extractLastFrame, detectVideoSignals, parseSignals, contactSheet, concatVideos, makeSolidImage, makePanClip, systemFfmpeg } from "@/autoflow/media";
import { reviewVideoSignals } from "@/autoflow/review";

let dir = "";
let clip = "";
beforeAll(async () => {
  dir = await mkdtemp(join(tmpdir(), "af-media-"));
  // 1 秒黑场 + 2 秒红色静止画面 + 切到 1 秒蓝色画面：用于检测黑场/冻结/切镜
  clip = join(dir, "test.mp4");
  await runProcess(systemFfmpeg.ffmpeg, ["-hide_banner", "-y",
    "-f", "lavfi", "-i", "color=c=black:s=320x180:d=1:r=25", "-f", "lavfi", "-i", "color=c=red:s=320x180:d=2:r=25", "-f", "lavfi", "-i", "color=c=blue:s=320x180:d=1:r=25",
    "-filter_complex", "[0][1][2]concat=n=3:v=1:a=0", "-pix_fmt", "yuv420p", "-c:v", "libx264", clip]);
});

describe("FFmpeg 工具", () => {
  test("抽取最后一帧作为下一镜首帧", async () => {
    const frame = join(dir, "last.png");
    await extractLastFrame(clip, frame);
    expect((await stat(frame)).size).toBeGreaterThan(100);
    const probe = await probeMedia(frame);
    expect(probe.width).toBe(320);
    // 最后一帧应为蓝色
    const pixel = await runProcess(systemFfmpeg.ffmpeg, ["-v", "error", "-i", frame, "-vf", "scale=1:1", "-f", "rawvideo", "-pix_fmt", "rgb24", "-"]);
    const bytes = Buffer.from(pixel.stdoutBytes ?? pixel.stdout, "latin1");
    expect(bytes[2]).toBeGreaterThan(bytes[0]);
  });
  test("检测黑场、冻结、切镜，并由审片判定失败", async () => {
    const signals = await detectVideoSignals(clip);
    expect(signals.duration).toBeCloseTo(4, 0);
    expect(signals.black[0]?.start ?? 9).toBeLessThan(0.1);
    expect(signals.freeze.length).toBeGreaterThan(0);
    expect(signals.sceneCuts.length).toBeGreaterThan(0);
    const review = reviewVideoSignals(signals, { seconds: 4 });
    expect(review.ok).toBe(false);
    const codes = review.issues.map(issue => issue.code);
    expect(codes).toContain("black");
    expect(codes).toContain("cut");
  });
  test("正常的运动镜头通过审片", async () => {
    const image = join(dir, "solid.png");
    await makeSolidImage(image, { width: 640, height: 360, color: "0x6b8cce" });
    const pan = join(dir, "pan.mp4");
    await makePanClip(image, pan, { seconds: 3, width: 320, height: 180, audio: true });
    const signals = await detectVideoSignals(pan);
    const review = reviewVideoSignals(signals, { seconds: 3, expectAudio: true });
    expect(review.issues.filter(issue => issue.severity === "error")).toEqual([]);
  });
  test("parseSignals 解析 FFmpeg 日志", () => {
    const log = [
      "[blackdetect @ 0x1] black_start:0 black_end:1.04 black_duration:1.04",
      "[freezedetect @ 0x2] lavfi.freezedetect.freeze_start: 1.2", "[freezedetect @ 0x2] lavfi.freezedetect.freeze_duration: 1.5", "[freezedetect @ 0x2] lavfi.freezedetect.freeze_end: 2.7",
      "frame:26   pts:26624  pts_time:1.04", "lavfi.scene_score=0.95",
    ].join("\n");
    const parsed = parseSignals(log, 4);
    expect(parsed.black).toEqual([{ start: 0, end: 1.04, duration: 1.04 }]);
    expect(parsed.freeze[0].duration).toBeCloseTo(1.5);
    expect(parsed.sceneCuts).toEqual([1.04]);
  });
  test("空视频/时长不符/缺音轨", () => {
    const empty = reviewVideoSignals({ duration: 0, black: [], freeze: [], sceneCuts: [], hasAudio: false });
    expect(empty.issues[0].code).toBe("empty");
    const wrong = reviewVideoSignals({ duration: 2, black: [], freeze: [], sceneCuts: [], hasAudio: false }, { seconds: 6, expectAudio: true });
    expect(wrong.issues.map(issue => issue.code)).toEqual(expect.arrayContaining(["duration", "audio"]));
  });
  test("联系表与拼接成片", async () => {
    const sheet = join(dir, "sheet.jpg");
    await contactSheet(clip, sheet);
    expect((await stat(sheet)).size).toBeGreaterThan(100);
    const final = join(dir, "final.mp4");
    await concatVideos([clip, join(dir, "pan.mp4")], final, { width: 320, height: 180 });
    const probe = await probeMedia(final);
    expect(probe.duration).toBeCloseTo(7, 0);
    expect(probe.hasAudio).toBe(true);
  });
});
