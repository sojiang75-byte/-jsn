import { beforeAll, describe, expect, test } from "bun:test";
import { mkdtemp, readFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { loadMediaProviderSource, validateMediaProviderSource } from "@/utils/media/provider";
import { makeSolidImage } from "@/autoflow/media";

type Call = { url: string; method: string; headers: Record<string, string>; body?: any };
let calls: Call[] = [];
let submitStatus = 200;
let pollStates: string[] = [];

/** 假的 MiniMax 官方接口：不发生任何真实网络请求 */
const fakeFetch = (async (input: string | URL | Request, init?: RequestInit) => {
  const url = String(input);
  const headers = Object.fromEntries(new Headers(init?.headers).entries());
  calls.push({ url, method: init?.method ?? "GET", headers, body: init?.body ? JSON.parse(String(init.body)) : undefined });
  if (url.endsWith("/v2/video_generation")) {
    if (submitStatus !== 200) return Response.json({ base_resp: { status_code: 1008, status_msg: "insufficient balance" } }, { status: submitStatus });
    return Response.json({ task_id: "task-1" });
  }
  if (url.includes("/v2/query/video_generation/")) {
    const status = pollStates.shift() ?? "succeeded";
    return Response.json({ task: { id: "task-1", status, content: status === "succeeded" ? { url: "https://cdn.example/out.mp4" } : undefined, error: status === "failed" ? { message: "boom" } : undefined } });
  }
  return new Response("not found", { status: 404 });
}) as typeof fetch;

let png: { type: "base64"; data: string; mimeType: string };
let wide: typeof png;
let tiny: typeof png;
beforeAll(async () => {
  const dir = await mkdtemp(join(tmpdir(), "h3-"));
  const make = async (name: string, width: number, height: number) => {
    await makeSolidImage(join(dir, name), { width, height, color: "0x6b8cce" });
    return { type: "base64" as const, data: (await readFile(join(dir, name))).toString("base64"), mimeType: "image/png" };
  };
  png = await make("a.png", 640, 360);
  wide = await make("wide.png", 1200, 300);
  tiny = await make("tiny.png", 200, 150);
});

async function provider(config: Record<string, unknown> = { apiKey: "sk-test", pollSeconds: "1" }, saved: any[] = []) {
  const source = await readFile(join(import.meta.dir, "../../../../packages/providers/src/media/minimaxH3.ts"), "utf8");
  validateMediaProviderSource(source);
  return loadMediaProviderSource(source, config, undefined, fakeFetch, undefined, async data => { saved.push(data); }) as Promise<any>;
}

describe("MiniMax H3 官方 API 供应商", () => {
  test("参考图生视频：官方请求体、data URI 内联、无 seed、{{ref N}} 改写为 <Picture N>", async () => {
    calls = []; submitStatus = 200; pollStates = ["processing", "succeeded"];
    const saved: any[] = [];
    const h3 = await provider(undefined, saved);
    const assets = await h3.generateVideo({ model: "MiniMax-H3", prompt: "{{ref 1}} walks to {{ref 2}}", images: [png, png], duration: 5, resolution: "768P", ratio: "16:9", seed: 42,
      referenceOrder: [{ type: "image", index: 0 }, { type: "image", index: 1 }] });
    expect(assets).toEqual([{ type: "url", url: "https://cdn.example/out.mp4", mimeType: "video/mp4", mediaType: "video" }]);
    const submit = calls[0];
    expect(submit.url).toBe("https://api.minimax.io/v2/video_generation");
    expect(submit.headers.authorization).toBe("Bearer sk-test");
    expect(submit.body.model).toBe("MiniMax-H3");
    expect(submit.body.duration).toBe(5);
    expect(submit.body.resolution).toBe("768P");
    expect(submit.body.ratio).toBe("16:9");
    expect(submit.body.seed).toBeUndefined();
    expect(submit.body.content[0]).toEqual({ type: "text", text: "<Picture 1> walks to <Picture 2>" });
    expect(submit.body.content.slice(1).map((item: any) => item.role)).toEqual(["reference_image", "reference_image"]);
    expect(submit.body.content[1].image_url.url.startsWith("data:image/png;base64,")).toBe(true);
    expect(calls.filter(call => call.url.includes("/v2/query/video_generation/task-1")).length).toBe(2);
    expect(calls.every(call => call.url.startsWith("https://api.minimax.io/"))).toBe(true);
    expect(saved.map(item => item.taskId)).toEqual(["", "task-1"]);
  }, 20_000);
  test("首尾帧：role 与 adaptive 画幅；国内站地址", async () => {
    calls = []; submitStatus = 200; pollStates = [];
    const h3 = await provider({ apiKey: "sk-cn-test", region: "cn", pollSeconds: "1" });
    await h3.generateVideo({ model: "MiniMax-H3", prompt: "go", firstFrame: png, lastFrame: png, duration: 6 });
    expect(calls[0].url).toBe("https://api.minimaxi.com/v2/video_generation");
    expect(calls[0].body.ratio).toBe("adaptive");
    expect(calls[0].body.content.slice(1).map((item: any) => item.role)).toEqual(["first_frame", "last_frame"]);
  });
  test("纯文本：默认给出具体画幅；小图自动放大到 ≥256px", async () => {
    calls = []; pollStates = [];
    const h3 = await provider();
    await h3.generateVideo({ model: "MiniMax-H3-Highspeed", prompt: "rain", duration: 4 });
    expect(calls[0].body.ratio).toBe("16:9");
    await h3.generateVideo({ model: "MiniMax-H3", prompt: "rain", firstFrame: tiny, duration: 4 });
    expect(calls.at(-2)!.body.content[1].image_url.url.startsWith("data:image/png;base64,")).toBe(true);
  });
  test("参数校验：混用模式、尾帧缺首帧、超时长、超宽高比、超长文本、缺 Key 都在提交前报错", async () => {
    calls = [];
    const h3 = await provider();
    await expect(h3.generateVideo({ model: "MiniMax-H3", prompt: "x", firstFrame: png, images: [png], duration: 5 })).rejects.toThrow("不能混用");
    await expect(h3.generateVideo({ model: "MiniMax-H3", prompt: "x", lastFrame: png, duration: 5 })).rejects.toThrow("必须同时提供首帧");
    await expect(h3.generateVideo({ model: "MiniMax-H3", prompt: "x", duration: 3 })).rejects.toThrow("4–15");
    await expect(h3.generateVideo({ model: "MiniMax-H3-Max", prompt: "x", duration: 4 })).rejects.toThrow("5–15");
    await expect(h3.generateVideo({ model: "MiniMax-H3", prompt: "x", images: [wide], duration: 5 })).rejects.toThrow("宽高比");
    await expect(h3.generateVideo({ model: "MiniMax-H3", prompt: "x".repeat(7001), duration: 5 })).rejects.toThrow("7000");
    await expect(h3.generateVideo({ model: "MiniMax-H3", prompt: "x", images: Array(10).fill(png), duration: 5 })).rejects.toThrow("9");
    const noKey = await provider({});
    await expect(noKey.generateVideo({ model: "MiniMax-H3", prompt: "x", duration: 5 })).rejects.toThrow("API Key");
    expect(calls.length).toBe(0);
  });
  test("错误码：402 余额不足带 status；任务失败；未拿到任务ID时续跑拒绝重复提交", async () => {
    calls = []; submitStatus = 402;
    const h3 = await provider();
    const error = await h3.generateVideo({ model: "MiniMax-H3", prompt: "x", duration: 5 }).catch((value: any) => value);
    expect(error.status).toBe(402);
    expect(error.message).toContain("余额不足");
    submitStatus = 200; pollStates = ["failed"];
    await expect(h3.generateVideo({ model: "MiniMax-H3", prompt: "x", duration: 5 })).rejects.toThrow("boom");
    await expect(h3.resumeTask({ kind: "h3", taskId: "", region: "global", model: "MiniMax-H3" })).rejects.toThrow("重复扣费");
    pollStates = [];
    expect((await h3.resumeTask({ kind: "h3", taskId: "task-9", region: "global", model: "MiniMax-H3" }))[0].url).toBe("https://cdn.example/out.mp4");
  });
});
