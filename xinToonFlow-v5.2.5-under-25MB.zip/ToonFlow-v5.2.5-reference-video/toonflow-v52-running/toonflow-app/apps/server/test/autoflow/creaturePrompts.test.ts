import { expect, test } from "bun:test";
import { buildCharacterViewPrompt, characterBrief, characterCardSchema } from "@/utils/assets/characterCard";

const card = characterCardSchema.parse({ version: 1, id: "adao", name: "阿刀", identity: { gender: "male", age: 1, species: "praying mantis" },
  invariant: { face: "amber eyes", hair: "none", body: "slender green mantis", marks: "notch on left forewing" },
  outfits: [{ id: "adult", label: "成虫", upper: "translucent green wings" }] });

test("creature cards get species-aware view prompts and briefs", () => {
  const anchor = buildCharacterViewPrompt(card, "anchor");
  expect(anchor.prompt).toContain("praying mantis");
  expect(anchor.prompt).not.toContain("Hair:");
  expect(anchor.prompt).not.toContain("Clothing");
  expect(anchor.negative).toContain("human");
  expect(buildCharacterViewPrompt(card, "face").prompt).toContain("compound eyes");
  expect(characterBrief(card)).toContain("praying mantis");
  const human = characterCardSchema.parse({ ...card, identity: { gender: "male", age: 30 } });
  expect(buildCharacterViewPrompt(human, "anchor").prompt).toContain("Hair:");
});
