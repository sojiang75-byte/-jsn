import { describe, expect, test } from "bun:test";
import { parseStoryboard } from "@/autoflow/storyboard/schema";
import { fillDurations } from "@/autoflow/storyboard/timing";
import { buildShotPrompts } from "@/autoflow/storyboard/prompts";
import { getPromptStyle, h3ViewIds, h3Views, h3SheetPresets, layoutH3Sheet, closestH3Ratio, dialogueLanguage } from "@/autoflow/promptStyles";
import { resolveShotReferences, prependReference } from "@/autoflow/references";
import { boardInput, cards } from "./fixtures";

const apiRatios = ["21:9", "16:9", "4:3", "1:1", "3:4", "9:16"];
const sectionOrder = ["subject_definitions:", "summary:", "retention_analysis:", "detailed_description:", "overall_soundscape:", "non_diegetic_music:"];

function setup() {
  const parsed = parseStoryboard(boardInput());
  if (!parsed.ok) throw new Error(parsed.errors.join("\n"));
  const board = fillDurations(parsed.data);
  const segment = board.episodes[0].segments[0];
  const map = cards();
  for (const card of map.values()) card.outfits[0].views = { ...card.outfits[0].views, sheet: `角色/${card.name}/sheet.png` } as any;
  return { board, segment, map };
}

function expectSections(prompt: string) {
  const positions = sectionOrder.map(name => prompt.indexOf(`\n${name}`) >= 0 ? prompt.indexOf(`\n${name}`) + 1 : prompt.indexOf(name));
  expect(positions.every(index => index >= 0)).toBe(true);
  expect([...positions].sort((a, b) => a - b)).toEqual(positions);
}

/** 提示词里出现的每个 <Picture N> 都必须在参考图数量范围内 */
function pictureNumbers(prompt: string) {
  return [...new Set([...prompt.matchAll(/<Picture (\d+)>/g)].map(match => Number(match[1])))].sort((a, b) => a - b);
}

describe("H3 多视角规则", () => {
  test("13 个视角、按鼻尖方向描述朝向，预设与画幅都落在 API 支持范围", () => {
    expect(h3ViewIds.length).toBe(13);
    expect(new Set(h3ViewIds.map(id => h3Views[id].group))).toEqual(new Set(["head", "body", "outfit", "detail"]));
    expect(h3Views.headProfileNoseRight.orientation).toContain("nose points to the RIGHT edge of the image");
    expect(h3Views.headProfileNoseLeft.orientation).toContain("nose points to the LEFT edge of the image");
    expect(h3Views.bodyProfileNoseRight.orientation).toContain("RIGHT edge");
    expect(h3Views.headBack.orientation).toContain("behind");
    expect(h3SheetPresets.full13.length).toBe(13);
    expect(h3SheetPresets.turnaround5.length).toBe(5);
    for (const preset of Object.values(h3SheetPresets)) {
      const layout = layoutH3Sheet(preset);
      expect(layout.panels.length).toBe(preset.length);
      expect(apiRatios).toContain(layout.ratio);
    }
    expect(closestH3Ratio(2.4)).toBe("21:9");
    expect(closestH3Ratio(0.55)).toBe("9:16");
  });
  test("台词语言标签", () => {
    expect(dialogueLanguage("外面雨这么大")).toBe("Chinese");
    expect(dialogueLanguage("It is raining")).toBe("English");
  });
});

describe("H3 角色卡提示词", () => {
  const { map } = setup();
  const card = map.get("linxia")!;
  const style = getPromptStyle("h3");
  test("锚点：纯文本 T2VA 内联格式、静帧定格、不出现中文图号", () => {
    const anchor = style.characterAnchor(card, card.outfits[0].id);
    expect(anchor.prompt.startsWith("integrated_multimodal_description:")).toBe(true);
    expect(anchor.prompt).toContain("fully present in the very first frame");
    expect(anchor.prompt).toContain("non_diegetic_music: N/A");
    expect(anchor.prompt).not.toMatch(/图\d/);
    expect(anchor.ratio).toBe("9:16");
  });
  test("正脸：Ref2VA 六段式，<Picture 1> 为锚点", () => {
    const face = style.characterFace(card, card.outfits[0].id);
    expectSections(face.prompt);
    expect(face.prompt).toContain("<Subject 1> from <Picture 1>: fully_preserved");
    expect(pictureNumbers(face.prompt)).toEqual([1]);
  });
  test("13 视角设定表：逐格描述、正脸参考为 Picture 2、长度在上限内", () => {
    const sheet = style.characterSheet!(card, card.outfits[0].id, { face: true });
    expectSections(sheet.prompt);
    expect(sheet.prompt).toContain("13 views");
    expect(sheet.prompt).toContain("Panel 13");
    expect(sheet.prompt).not.toContain("Panel 14");
    expect(sheet.prompt).toContain("the nose points to the RIGHT edge of the image");
    expect(sheet.prompt).toContain("<Subject 1> from <Picture 2>: partially_preserved");
    expect(pictureNumbers(sheet.prompt)).toEqual([1, 2]);
    expect(sheet.prompt.length).toBeLessThanOrEqual(7000);
    expect(apiRatios).toContain(sheet.ratio);
    const noFace = style.characterSheet!(card, card.outfits[0].id, { face: false });
    expect(pictureNumbers(noFace.prompt)).toEqual([1]);
    expect(getPromptStyle("h3", { h3: { sheet: "none" } }).characterSheet).toBeUndefined();
    expect(getPromptStyle("h3", { h3: { sheet: "turnaround5" } }).characterSheet!(card, card.outfits[0].id, { face: false }).prompt).toContain("5 views");
  });
});

describe("H3 分镜提示词", () => {
  const { board, segment, map } = setup();
  const style = getPromptStyle("h3");
  const [shot1, shot2] = segment.shots;
  const context = (shot: typeof shot1) => ({ board, segment, shot, cards: map });

  test("关键帧：<Subject N>/<Picture N> 与参考图顺序一致，上一镜为弱参考", () => {
    const plan = resolveShotReferences({ shot: shot1, cards: map, sceneImage: { path: "s.png", name: "便利店" }, previousFrame: "prev.png", includeSheet: true, maxImages: 9 });
    const prompt = style.keyframe(context(shot1), plan);
    expectSections(prompt);
    expect(pictureNumbers(prompt)).toEqual(plan.images.map((_, index) => index + 1));
    plan.entries.forEach((entry, index) => {
      if (entry.kind === "previousFrame") expect(prompt).toContain(`<Picture ${index + 1}>: weak_reference`);
      if (entry.kind === "anchor") expect(prompt).toMatch(new RegExp(`<Subject \\d> from <Picture ${index + 1}>: fully_preserved`));
    });
    expect(prompt).toContain("[reference generation + keyframe completion]");
    expect(prompt).toContain("<Subject 1> is 林夏");
    expect(prompt).not.toMatch(/图\d/);
    expect(prompt.length).toBeLessThanOrEqual(7000);
    expect(style.hostReferenceLabels).toBe(false);
  });
  test("首帧视频：I2VA 对齐首行 + 空行；台词 <d>[Chinese]，说话人编号", () => {
    const prompt = style.video(context(shot2), { mode: "firstFrame", seconds: shot2.seconds! });
    const [first, blank] = prompt.split("\n");
    expect(first).toBe("For the target video, at 0.00 seconds into the target video, <Picture 1> (from [Shot 1]) is fully referenced.");
    expect(blank).toBe("");
    expect(prompt).toContain("integrated_multimodal_description:");
    expect(prompt).toContain("(S1) says");
    expect(prompt).toMatch(/<d>\[Chinese\] [^<]+<\/d>/);
    expect(prompt).toContain("pushes in");
    expect(prompt).toContain("non_diegetic_music: N/A");
  });
  test("首尾帧视频：FL2VA 对齐首行带秒数", () => {
    const prompt = style.video(context(shot2), { mode: "firstLast", seconds: 6 });
    expect(prompt.split("\n")[0]).toContain("Picture 2 (from Shot 1) aligns with the 6.00-second mark of the target video");
  });
  test("参考图驱动视频：首帧插在最前，六段式，摘要含 keyframe completion", () => {
    const base = resolveShotReferences({ shot: shot1, cards: map, sceneImage: { path: "s.png", name: "便利店" }, includeSheet: true, maxImages: 8 });
    const plan = prependReference(base, "kf.png", { role: "previousFrame" }, { kind: "keyframe" });
    const prompt = style.video(context(shot1), { mode: "reference", seconds: 5, plan });
    expectSections(prompt);
    expect(prompt).toContain("[keyframe completion + reference generation]");
    expect(prompt).toContain("starts exactly from <Picture 1>");
    expect(pictureNumbers(prompt)).toEqual(plan.images.map((_, index) => index + 1));
    expect(plan.characterImageIndex.get("linxia")).toBe(2);
  });
  test("超长字段会被压缩到 H3 文本上限内", () => {
    const long = { ...shot1, firstFrame: "A rain-soaked glass door swings open. ".repeat(400), action: "He shakes off the rain. ".repeat(400) };
    const plan = resolveShotReferences({ shot: long, cards: map, sceneImage: { path: "s.png", name: "便利店" }, includeSheet: true, maxImages: 9 });
    expect(style.keyframe(context(long), plan).length).toBeLessThanOrEqual(7000);
    expect(style.video(context(long), { mode: "firstFrame", seconds: 5 }).length).toBeLessThanOrEqual(7000);
  });
  test("通用档保持原提示词（回归）", () => {
    const generic = getPromptStyle("generic");
    const plan = resolveShotReferences({ shot: shot1, cards: map, sceneImage: { path: "s.png", name: "便利店" } });
    const old = buildShotPrompts({ ...context(shot1), characterImageIndex: plan.characterImageIndex });
    expect(generic.keyframe(context(shot1), plan)).toContain(old.firstFrame);
    expect(generic.hostReferenceLabels).toBe(true);
    expect(generic.characterSheet).toBeUndefined();
  });
});
