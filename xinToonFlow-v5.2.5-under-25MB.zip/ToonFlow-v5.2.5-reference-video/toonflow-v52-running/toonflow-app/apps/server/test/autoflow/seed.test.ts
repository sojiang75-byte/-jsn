import { describe, expect, test } from "bun:test";
import { readFile } from "node:fs/promises";
import { join } from "node:path";
import { prepareRequest, resolveReferenceMarkers } from "@/utils/media/generation";
import { loadMediaProviderSource } from "@/utils/media/provider";
import { imageGenerationSchema, videoGenerationSchema } from "@/utils/media/schemas";
import { nextSeed } from "@/autoflow/scoring";

const providersDir = join(import.meta.dir, "../../../../packages/providers/src/media");
const fakeRead = async () => ({ type: "base64" as const, data: "AAAA", mimeType: "image/png" });

describe("seed 透传", () => {
  test("schema 接受 seed 与 referenceLabels，拒绝越界 seed", () => {
    const base = { providerId: "apiMart", modelId: "m", prompt: "p" };
    expect(imageGenerationSchema.parse({ ...base, seed: 42 }).seed).toBe(42);
    expect(imageGenerationSchema.safeParse({ ...base, seed: -1 }).success).toBe(false);
    expect(imageGenerationSchema.safeParse({ ...base, seed: 2 ** 32 }).success).toBe(false);
    expect(videoGenerationSchema.parse({ ...base, seed: 7 }).seed).toBe(7);
  });
  test("prepareRequest 把 seed 放在顶层，不并入 other", async () => {
    const image = await prepareRequest(undefined, "image", { providerId: "compshare", modelId: "m", prompt: "p", seed: 123 } as any, fakeRead) as any;
    expect(image.seed).toBe(123);
    expect(image.other).toBeUndefined();
    const video = await prepareRequest(undefined, "video", { providerId: "x", modelId: "m", prompt: "p", seed: 5, other: { a: 1 } } as any, fakeRead) as any;
    expect(video.seed).toBe(5);
    expect(video.other).toEqual({ a: 1 });
    const none = await prepareRequest(undefined, "image", { providerId: "x", modelId: "m", prompt: "p" } as any, fakeRead) as any;
    expect("seed" in none).toBe(false);
  });
  test("nextSeed 每次重试换种子且在 uint32 范围", () => {
    const seeds = [0, 1, 2, 3].map(attempt => nextSeed(4294967290, attempt));
    expect(new Set(seeds).size).toBe(4);
    expect(seeds.every(seed => seed >= 0 && seed < 2 ** 32)).toBe(true);
  });
});

describe("referenceOrder 对图片开放 + 引用标记改写", () => {
  test("{{ref N}} 改写为 图N/首帧/参考N", () => {
    const text = resolveReferenceMarkers("{{ref 1}} 和 {{ref 2}} 在 {{ref 3}} 中，{{ref 4}}", [
      { type: "image", index: 1 }, { type: "firstFrame" }, { type: "text" }, { type: "video", index: 0 },
    ] as any);
    expect(text).toBe("图2 和 首帧 在 参考3 中，视频1");
  });
  test("图片请求保留 referenceOrder，并在提示词中改写标记、写入参考说明", async () => {
    const request = imageGenerationSchema.parse({ providerId: "apiMart", modelId: "m", prompt: "让 {{ref 1}} 站在 {{ref 2}} 前",
      images: [{ path: "a.png", mimeType: "image/png" }, { path: "b.png", mimeType: "image/png" }], referenceOrder: [{ type: "image", index: 0 }, { type: "image", index: 1 }],
      referenceLabels: [{ role: "character", name: "林夏" }, { role: "scene", name: "便利店" }] });
    const prepared = await prepareRequest("/tmp", "image", request as any, fakeRead) as any;
    expect(prepared.referenceOrder.length).toBe(2);
    expect(prepared.prompt).toContain("让 图1 站在 图2 前");
    expect(prepared.prompt).toContain("林夏");
    expect(prepared.images.length).toBe(2);
  });
  test("指向不存在素材的引用被拒绝", async () => {
    await expect(prepareRequest(undefined, "image", { providerId: "x", modelId: "m", prompt: "{{ref 1}}", referenceOrder: [{ type: "image", index: 0 }] } as any, fakeRead))
      .rejects.toThrow();
  });
});

/** 在供应商真实 VM 中运行内置适配器，用假的 fetch 截获请求体（不发出任何网络请求）。 */
async function captureBodies(file: string, config: Record<string, unknown>, run: (provider: any) => Promise<unknown>) {
  const bodies: any[] = [];
  const fakeFetch = Object.assign(async (input: unknown, init?: RequestInit) => {
    const text = typeof init?.body === "string" ? init.body : "";
    if (text.startsWith("{")) bodies.push(JSON.parse(text));
    return new Response(JSON.stringify({ error: { message: "mock stop" } }), { status: 418, headers: { "content-type": "application/json" } });
  }, { preconnect: () => {} }) as unknown as typeof fetch;
  const provider = await loadMediaProviderSource(await readFile(join(providersDir, file), "utf8"), config, undefined, fakeFetch);
  await run(provider).catch(() => {});
  return bodies;
}

describe("内置适配器读取 seed", () => {
  test("APIMart 图片与视频请求体带 seed", async () => {
    const image = await captureBodies("apiMart.ts", { apiKey: "k" }, p => p.generateImage({ type: "image", model: "seedream-4.0", prompt: "p", seed: 99 }));
    expect(image.at(-1)?.seed).toBe(99);
    const video = await captureBodies("apiMart.ts", { apiKey: "k" }, p => p.generateVideo({ type: "video", model: "seedance-2.5", prompt: "p", seed: 77, duration: 5, mode: "text" }));
    expect(video.at(-1)?.seed).toBe(77);
  });
  test("兼容 other.seed；非法 seed 被忽略", async () => {
    const legacy = await captureBodies("apiMart.ts", { apiKey: "k" }, p => p.generateImage({ type: "image", model: "seedream-4.0", prompt: "p", other: { seed: 5 } }));
    expect(legacy.at(-1)?.seed).toBe(5);
    const invalid = await captureBodies("apiMart.ts", { apiKey: "k" }, p => p.generateImage({ type: "image", model: "seedream-4.0", prompt: "p", seed: -3 }));
    expect("seed" in (invalid.at(-1) ?? {})).toBe(false);
  });
});
