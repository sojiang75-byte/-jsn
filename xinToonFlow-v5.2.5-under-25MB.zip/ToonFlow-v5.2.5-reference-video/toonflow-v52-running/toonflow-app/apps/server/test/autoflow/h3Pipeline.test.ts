import { describe, expect, test } from "bun:test";
import { mkdtemp, readFile, stat } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { runAutoflow } from "@/autoflow/pipeline";
import { createMockGenerator, createMockScorer, createMockTextModel } from "@/autoflow/mock";
import { systemFfmpeg } from "@/autoflow/media";
import { videoGenerationSchema } from "@/utils/media/schemas";

describe("一键成片 · MiniMax H3 提示词风格档（mock）", () => {
  test("静帧走“短视频取首帧”，角色卡含 13 视角设定表，提示词为 H3 官方格式", async () => {
    const cwd = await mkdtemp(join(tmpdir(), "af-h3-"));
    const mock = createMockTextModel();
    const systems: string[] = [];
    const text = { ...mock, complete: (input: Parameters<typeof mock.complete>[0]) => { systems.push(input.system); return mock.complete(input); } };
    const generator = createMockGenerator(cwd);
    const state = await runAutoflow({
      story: "雨夜便利店，店员林夏把伞借给常客陈默。", seed: 7,
      imageModel: { providerId: "mock", modelId: "MiniMax-H3", maxReferenceImages: 9, stillFromVideo: { duration: 4, resolution: "768P" } },
      videoModel: { providerId: "mock", modelId: "MiniMax-H3", durations: [4, 5, 6], generateAudio: true },
    }, { cwd, text, generate: generator.generate, scorer: createMockScorer([]), ffmpeg: systemFfmpeg, retryDelayMs: 0 }, "h3");
    expect(state.status).toBe("done");

    // H3 只有视频接口：整条流程不发出任何图片请求
    expect(generator.requests.filter(item => item.mediaType === "image").length).toBe(0);
    for (const item of generator.requests) {
      const parsed = videoGenerationSchema.safeParse({ ...item.request, providerId: "minimaxH3" });
      if (!parsed.success) throw new Error(`${item.request.outputDirectory}: ${parsed.error.message}`);
      // 宿主不再追加中文“图N”声明，H3 提示词自带 <Picture N> 定义
      expect(item.request.referenceLabels).toBeUndefined();
      expect(item.request.prompt).not.toMatch(/图\d/);
      expect(item.request.prompt.length).toBeLessThanOrEqual(7000);
      for (const match of item.request.prompt.matchAll(/<Picture (\d+)>/g)) {
        const count = (item.request.images?.length ?? 0) + (item.request.firstFrame ? 1 : 0) + (item.request.lastFrame ? 1 : 0);
        expect(Number(match[1])).toBeLessThanOrEqual(count);
      }
    }
    const stills = generator.requests.filter(item => item.request.generateAudio === false);
    expect(stills.length).toBeGreaterThan(0);
    for (const item of stills) {
      expect(item.request.duration).toBe(4);
      expect(item.request.prompt).toContain("fully present in the very first frame");
      expect((item.request as any).size).toBeUndefined();
    }

    // 角色卡：锚点/正脸/设定表都是视频第 0 帧导出的 PNG
    const card = JSON.parse(await readFile(join(cwd, "角色/林夏/card.json"), "utf8"));
    const views = card.outfits[0].views;
    for (const key of ["anchor", "face", "sheet"]) {
      expect(views[key]).toEndWith("-frame0.png");
      expect((await stat(join(cwd, views[key]))).size).toBeGreaterThan(0);
    }
    const sheet = stills.find(item => item.request.prompt.includes("character design sheet"))!;
    expect(sheet.request.prompt).toContain("13 views");
    expect(sheet.request.images?.length).toBe(2);

    // 关键帧挂载设定表，视频为 I2VA 首帧格式
    const keyframes = stills.filter(item => item.request.outputDirectory?.includes("/镜头/"));
    expect(keyframes.length).toBeGreaterThan(0);
    expect(keyframes.some(item => item.request.images?.some(image => image.path === views.sheet))).toBe(true);
    const shots = generator.requests.filter(item => item.request.generateAudio === true);
    expect(shots.length).toBeGreaterThan(0);
    for (const item of shots) expect(item.request.prompt.split("\n")[0]).toMatch(/^(For the target video, at 0\.00 seconds|How the reference pictures align)/);
    expect(shots.some(item => /<d>\[Chinese\] /.test(item.request.prompt))).toBe(true);

    // 编剧/角色/分镜阶段收到了 H3 写作规则
    const ruled = systems.filter(system => system.includes("MiniMax H3 提示词规则")).map(system => system.match(/<!-- autoflow:(\w+) -->/)?.[1]);
    expect(ruled).toContain("cast");
    expect(ruled).toContain("storyboard");
  }, 180_000);
});
