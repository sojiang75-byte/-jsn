import { describe, expect, test } from "bun:test";
import { normalizeExternalQa, routeQaFailure } from "@/autoflow/qaContract";

describe("v5 unified QA", () => {
  test("missing or malformed evidence is abstain", () => {
    expect(normalizeExternalQa(undefined).status).toBe("abstain");
    expect(normalizeExternalQa({ pass: false, issues: [] }).status).toBe("abstain");
  });
  test("legacy pass/fail payloads normalize", () => {
    expect(normalizeExternalQa({ pass: true }).status).toBe("pass");
    expect(normalizeExternalQa({ pass: false, issues: ["vehicle mismatch"] }).status).toBe("fail");
  });
  test("language failure routes to audio-only/manual, not video redraw", () => {
    expect(routeQaFailure(normalizeExternalQa({ pass: false, issues: ["language mismatch"] }))).toMatchObject({ action: "audio_track_only_if_supported", requiresHuman: true, automaticAttempts: 0 });
  });
});
