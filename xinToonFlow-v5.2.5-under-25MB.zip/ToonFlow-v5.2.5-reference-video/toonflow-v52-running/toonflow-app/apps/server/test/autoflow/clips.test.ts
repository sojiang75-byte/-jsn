import { describe, expect, test } from "bun:test";
import { packRenderClips } from "@/autoflow/storyboard/clips";
import { screenplayInstructions, storyboardInstructions } from "@/autoflow/planner";
import { estimateShotSeconds } from "@/autoflow/storyboard/timing";
import { reviewVideoSignals } from "@/autoflow/review";

const brief = { story: "有人敲门", episodes: 1, targetSeconds: 90, aspectRatio: "9:16" as const };

describe("素材合成", () => {
  test("每个镜头单独成片，短于 5 秒抬到 5 秒，镜头内不切", () => {
    const shots = [1, 2, 3, 4].map(n => ({ id: `E01-01-0${n}`, seconds: 2 }));
    const packs = packRenderClips(shots, { allowedDurations: [5, 10, 15] });
    expect(packs).toHaveLength(4);
    expect(packs.every(pack => pack.shots.length === 1 && pack.seconds === 5 && pack.plannedCuts === 0)).toBe(true);
  });

  test("3 秒镜头对齐到允许的 5 秒档", () => {
    const shots = [1, 2, 3, 4, 5].map(n => ({ id: `s${n}`, seconds: 3 }));
    const packs = packRenderClips(shots, { allowedDurations: [5, 10, 15] });
    expect(packs).toHaveLength(5);
    expect(packs.every(pack => pack.seconds === 5 && pack.plannedCuts === 0)).toBe(true);
  });
});

describe("剧本与节奏", () => {
  test("整集剧本要求冲突、动作和悬念", () => {
    const text = screenplayInstructions(brief);
    expect(text).toContain("750");
    expect(text).toContain("1000");
    expect(text).toContain("冲突");
    expect(text).toContain("悬念");
    expect(text).toContain("动作");
  });

  test("10 秒试拍只留一个冲突", () => {
    const text = screenplayInstructions({ ...brief, targetSeconds: 10 });
    expect(text).toContain("10 秒");
    expect(text).toContain("冲突");
    expect(text).not.toContain("750");
  });

  test("clip 节奏一镜一条、必须有结束画面，并取消原文逐字规则", () => {
    const text = storyboardInstructions({ ...brief, preserveSourceText: false, rhythm: "clip", shotSeconds: { min: 1, max: 4 } });
    expect(text).toContain("镜头内不切镜");
    expect(text).toContain("endFrame");
    expect(text).toContain("单独生成一条视频");
    expect(text).toContain("剧本模式");
    expect(text).toContain("悬念");
  });

  test("H3 对白计入开口前等待，不被 4 秒上限截断", () => {
    const seconds = estimateShotSeconds(
      { action: "她握着门链说话", dialogue: [{ speaker: "lin", text: "再敲我就报警", emotion: "" }] },
      { minShotSeconds: 1, maxShotSeconds: 4, charsPerSecond: 4.1, linePadding: 0.4, speechLeadSeconds: 1.8, speechTailSeconds: 0.5 },
    );
    expect(seconds).toBe(4.4);
  });

  test("反应镜头在下限为 1 秒时估成 1 秒", () => {
    expect(estimateShotSeconds({ action: "他一愣", dialogue: [], spatialContract: { beat: "reaction" } }, { minShotSeconds: 1, maxShotSeconds: 4 })).toBe(1);
  });
});

describe("审片", () => {
  test("计划内的一次切镜不算失败", () => {
    const review = reviewVideoSignals({ duration: 8, black: [], freeze: [], sceneCuts: [3.2], hasAudio: true }, { seconds: 8, allowedCuts: 1, expectAudio: true });
    expect(review.issues.filter(issue => issue.code === "cut")).toHaveLength(0);
    expect(review.ok).toBe(true);
  });
});
