import { describe, expect, test } from "bun:test";
import { resolveShotReferences } from "@/autoflow/references";
import { cards } from "./fixtures";

const shot = { id: "E01-01-01", characters: [{ id: "linxia" }, { id: "chenmo" }] };

describe("强制挂载角色参考图", () => {
  test("锚点优先、场景、上一镜、正脸；标签与图片等长同序", () => {
    const plan = resolveShotReferences({ shot, cards: cards(), sceneImage: { path: "s.png", name: "便利店" }, previousFrame: "prev.png" });
    expect(plan.images.map(item => item.path)).toEqual(["角色/林夏/anchor.png", "角色/陈默/anchor.png", "s.png", "prev.png", "角色/林夏/face.png", "角色/陈默/face.png"]);
    expect(plan.referenceLabels.length).toBe(plan.images.length);
    expect(plan.referenceLabels[0]).toEqual({ role: "character", name: "林夏" });
    expect(plan.referenceLabels[2].role).toBe("scene");
    expect(plan.referenceLabels[3].role).toBe("previousFrame");
    expect(plan.characterImageIndex.get("chenmo")).toBe(2);
    expect(plan.missing).toEqual([]);
    expect(plan.manifest.map(item => item.index)).toEqual([1, 2, 3, 4, 5, 6]);
    expect(plan.manifest[0]).toMatchObject({ path: "角色/林夏/anchor.png", kind: "anchor", characterId: "linxia" });
    expect(plan.dropped).toEqual([]);
  });
  test("指定造型时使用该造型的锚点并在标签中注明", () => {
    const plan = resolveShotReferences({ shot: { id: "x", characters: [{ id: "linxia", outfit: "default" }] }, cards: cards() });
    expect(plan.referenceLabels[0]).toEqual({ role: "character", name: "林夏·便利店制服" });
  });
  test("超过上限时按优先级截断：先丢正脸特写，不丢锚点", () => {
    const plan = resolveShotReferences({ shot, cards: cards(), sceneImage: { path: "s.png", name: "便利店" }, maxImages: 3 });
    expect(plan.images.map(item => item.path)).toEqual(["角色/林夏/anchor.png", "角色/陈默/anchor.png", "s.png"]);
    expect(plan.warnings).toEqual([]);
    const tight = resolveShotReferences({ shot, cards: cards(), sceneImage: { path: "s.png", name: "便利店" }, maxImages: 1 });
    expect(tight.images.map(item => item.path)).toEqual(["角色/林夏/anchor.png"]);
    expect(tight.warnings.length).toBe(2);
    expect(tight.manifest).toHaveLength(1);
    expect(tight.dropped.length).toBeGreaterThan(0);
    expect(tight.dropped.every(item => item.index > 1)).toBe(true);
  });
  test("没有锚点的角色记为 missing", () => {
    const plan = resolveShotReferences({ shot, cards: cards(false) });
    expect(plan.images).toEqual([]);
    expect(plan.missing.sort()).toEqual(["chenmo", "linxia"]);
  });
  test("v5.2.5：上一镜结尾帧排在场景图之后、正脸之前，带 tailFrame 来源", () => {
    const tail = [1, 2].map(index => ({ path: `续接参考${index}.jpg`, label: { role: "other" as const, name: `上一镜结尾第${index}/2帧` } }));
    const plan = resolveShotReferences({ shot, cards: cards(), sceneImage: { path: "s.png", name: "便利店" }, tailFrames: tail });
    expect(plan.images.map(item => item.path)).toEqual(["角色/林夏/anchor.png", "角色/陈默/anchor.png", "s.png", "续接参考1.jpg", "续接参考2.jpg", "角色/林夏/face.png", "角色/陈默/face.png"]);
    expect(plan.entries[3]!.kind).toBe("tailFrame");
    expect(plan.referenceLabels[4]!.name).toBe("上一镜结尾第2/2帧");
    // 上限紧时先丢正脸，不丢场景图
    const tight = resolveShotReferences({ shot, cards: cards(), sceneImage: { path: "s.png", name: "便利店" }, tailFrames: tail, maxImages: 4 });
    expect(tight.images.map(item => item.path)).toEqual(["角色/林夏/anchor.png", "角色/陈默/anchor.png", "s.png", "续接参考1.jpg"]);
    expect(tight.warnings).toEqual([]);
  });
  test("重复图片去重", () => {
    const plan = resolveShotReferences({ shot: { id: "x", characters: [{ id: "linxia" }, { id: "linxia" }] }, cards: cards() });
    expect(new Set(plan.images.map(item => item.path)).size).toBe(plan.images.length);
  });
});
