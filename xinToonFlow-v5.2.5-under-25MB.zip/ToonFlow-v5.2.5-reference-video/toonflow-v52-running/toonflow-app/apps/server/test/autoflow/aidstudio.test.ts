import { describe, expect, test } from "bun:test";
import { parseStoryboard } from "@/autoflow/storyboard/schema";
import { fillDurations } from "@/autoflow/storyboard/timing";
import { runGates, sourceCoverage } from "@/autoflow/storyboard/gates";
import { continuityLines, continuityProblems } from "@/autoflow/storyboard/continuity";
import { boardInput } from "./fixtures";

const board = (edit?: (input: any) => void) => {
  const input = boardInput() as any; edit?.(input);
  const parsed = parseStoryboard(input); if (!parsed.ok) throw new Error(parsed.errors.join("\n"));
  return fillDurations(parsed.data);
};
const shots = (b: any) => b.episodes.flatMap((e: any) => e.segments.flatMap((s: any) => s.shots));

describe("原文覆盖门（aid-studio source coverage）", () => {
  test("台词逐字保留 + source 全覆盖时通过", () => {
    const b = board(); const list = shots(b);
    const lines = list.flatMap((s: any) => (s.dialogue ?? []).map((d: any) => d.text));
    const chapter = list.map((s: any, i: number) => `第${i}镜原文叙述${s.dialogue?.length ? `“${s.dialogue[0].text}”` : ""}`).join("\n");
    list.forEach((s: any, i: number) => { s.source = `第${i}镜原文叙述${s.dialogue?.length ? `“${s.dialogue[0].text}”` : ""}`; });
    const report = sourceCoverage(b, chapter);
    expect(report.missingLines).toEqual([]);
    expect(report.ratio).toBeGreaterThan(0.99);
    expect(lines.length).toBeGreaterThan(0);
    expect(runGates(b, { chapter }).gates.filter(g => g.id === "coverage" || g.id === "sourceSpan").every(g => g.ok)).toBe(true);
  });
  test("原文台词被改写或缺 source 时报错", () => {
    const b = board();
    const chapter = "他大喊：“快！搬钱！”然后跑了。";
    const gate = runGates(b, { chapter }).gates.find(g => g.id === "coverage")!;
    expect(gate.ok).toBe(false);
    expect(gate.severity).toBe("error");
    expect(gate.details.join()).toContain("快！搬钱！");
    expect(runGates(b, { chapter, coverageSeverity: "warning" }).gates.find(g => g.id === "coverage")!.severity).toBe("warning");
  });
  test("不给原文时不加覆盖门（旧分镜续跑不受影响）", () => {
    expect(runGates(board()).gates.some(g => g.id === "coverage")).toBe(false);
  });
});

describe("连续性清单：伤情与道具状态", () => {
  test("伤情写进提示词；伤不会凭空消失", () => {
    const b = board(); const list = shots(b); const who = list[0].characters[0].id;
    list[0].continuity = { injuries: [{ id: who, note: "左臂流血" }], props: [{ name: "面包车", state: "完好" }] };
    expect(continuityLines(list[0], id => id).join()).toContain("伤情保持");
    expect(continuityLines(list[0], id => id).join()).toContain("面包车：完好");
    const next = list.find((s: any, i: number) => i > 0 && s.characters.some((c: any) => c.id === who));
    next.continuity = { injuries: [] };
    expect(continuityProblems(b).join()).toContain("此前已有伤");
  });
  test("道具状态变化需要动作里写明原因", () => {
    const b = board(); const [a, c] = shots(b);
    a.continuity = { props: [{ name: "面包车", state: "完好" }] };
    c.continuity = { props: [{ name: "面包车", state: "车门凹陷" }] };
    c.action = "两人走过去"; a.action = "等待";
    expect(continuityProblems(b).join()).toContain("没有写原因");
    c.action = "面包车撞上护栏，车门凹陷";
    expect(continuityProblems(b).join()).not.toContain("没有写原因");
  });
});
