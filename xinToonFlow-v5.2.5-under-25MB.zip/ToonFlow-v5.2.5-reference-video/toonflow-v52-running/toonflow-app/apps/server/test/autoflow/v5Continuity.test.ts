import { describe, expect, test } from "bun:test";
import { buildEpisodeMemoryPrompt, buildInputFingerprints, compareFingerprints, deriveCrossEpisodeMemory, projectBibleSchema, validateStateTransition } from "@/autoflow/v5Continuity";

describe("ToonFlow v5 Project Bible / 跨集记忆", () => {
  test("Project Bible schema 接受分层资产与剧情线", () => {
    const bible = projectBibleSchema.parse({ projectId: "p1", title: "测试剧", canon: ["不能复活"], threads: [{ id: "t1", description: "寻找钥匙", introducedEpisode: 1 }], characters: [{ id: "hero", identityInvariants: ["黑发"], outfits: [{ id: "default", description: "黑色外套" }], temporaryState: ["左臂受伤"], voice: { voiceId: "voice-a", language: "普通话" } }] });
    expect(bible.threads[0].status).toBe("open");
    expect(bible.characters[0].voice?.voiceId).toBe("voice-a");
  });
  test("从前集分镜提取角色、伤情、服装与道具状态", () => {
    const board = { title: "测试剧", bible: { projectId: "p1", canon: ["城市停电"] }, episodes: [{ ep: 1, segments: [{ sceneId: "street", shots: [{ id: "E01-01-01", characters: [{ id: "hero", outfit: "bloody" }], action: "主角受伤后离开", continuity: { dead: [], injuries: [{ id: "hero", note: "左臂受伤" }], props: [{ name: "van", state: "左车门凹陷" }] } }] }] }] };
    const memory = deriveCrossEpisodeMemory(board);
    expect(memory.characterStates[0]).toMatchObject({ characterId: "hero", alive: true, outfitId: "bloody", injuries: ["左臂受伤"] });
    expect(memory.propStates[0]).toMatchObject({ propId: "van", stateId: "左车门凹陷" });
    expect(buildEpisodeMemoryPrompt(memory, 2)).toContain("左臂受伤");
    expect(buildEpisodeMemoryPrompt(memory, 2)).toContain("不得无解释复活");
  });
  test("道具状态机拒绝非法转换和没有动作依据的转换", () => {
    const machine = { assetId: "van", initialState: "intact", states: [{ id: "intact", description: "完好" }, { id: "damaged", description: "车门凹陷" }], transitions: [{ from: "intact", to: "damaged", trigger: "撞击" }] };
    expect(validateStateTransition(machine, "intact", "damaged", "车辆撞击路边护栏").ok).toBe(true);
    expect(validateStateTransition(machine, "intact", "damaged", "车辆停在路边").ok).toBe(false);
    expect(validateStateTransition(machine, "damaged", "intact", "车辆停在路边").ok).toBe(false);
  });
  test("指纹差异会阻止旧素材混入新成片", () => {
    const expected = buildInputFingerprints({ bible: { projectId: "a" }, shotContract: { id: "s1" }, prompt: "p", generatorConfig: { model: "m1" }, qaPolicyVersion: "v5" });
    const actual = buildInputFingerprints({ bible: { projectId: "a" }, shotContract: { id: "s1" }, prompt: "p", generatorConfig: { model: "m2" }, qaPolicyVersion: "v5" });
    expect(compareFingerprints(expected, actual)).toMatchObject({ fresh: false, stale: ["generatorConfigHash"] });
  });
});
