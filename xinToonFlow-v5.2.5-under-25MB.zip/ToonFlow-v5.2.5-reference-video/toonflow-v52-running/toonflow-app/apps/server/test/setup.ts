// 测试使用独立的临时数据目录，避免读写真实配置。
import { mkdtempSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
process.env.TOONFLOW_DATA_DIR ??= mkdtempSync(join(tmpdir(), "toonflow-test-"));
