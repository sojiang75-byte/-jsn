#!/usr/bin/env bun
/**
 * 真实冒烟（会产生费用）：一次 Nebius 文本调用生成极小分镜 + 一次 4 秒 ai& H3 首帧图生视频。
 *   NEBIUS_API_KEY=… AIAND_API_KEY=… bun scripts/aiand-smoke.ts --out /tmp/aiand-smoke --first-frame 首帧.png [--max-usd 0.5] [--model deepseek-ai/DeepSeek-V4.1-Flash-1017]
 * Key 只从环境变量读取，不打印、不落盘。花费缺省不限额（只记录，只计视频）；可用 --max-usd 设上限。
 */
import { mkdir, readFile, writeFile } from "node:fs/promises";
import { join, resolve } from "node:path";
import { parseArgs } from "node:util";
import { createOpenAICompatibleTextModel, nebiusDefaults, resolveNebiusCredentials } from "../src/autoflow/llm";
import { extractJson } from "../src/autoflow/scoring";
import { BudgetGuard, estimateVideoCost, outcomeOfError } from "../src/autoflow/budget";
import { extractFrame, probeMedia } from "../src/autoflow/media";
import { loadMediaProviderSource } from "../src/utils/media/provider";
import { withEnvironmentCredentials } from "../src/utils/media/generation";

const { values } = parseArgs({ options: { out: { type: "string" }, "first-frame": { type: "string" }, "max-usd": { type: "string" }, model: { type: "string" }, seconds: { type: "string" } } });
if (!values.out || !values["first-frame"]) { console.error("用法：bun scripts/aiand-smoke.ts --out <目录> --first-frame <png>"); process.exit(2); }
const out = resolve(values.out);
await mkdir(out, { recursive: true });
const credentials = resolveNebiusCredentials({});
// 缺省不限额（只记录花费）；--max-usd 给正数时才设上限
const guard = new BudgetGuard({ maxUsd: values["max-usd"] ? Number(values["max-usd"]) : undefined }, { usd: 0, entries: [] });

// 1. 文本（Nebius）：极小分镜（JSON 模式）
const model = values.model ?? nebiusDefaults.model;
const text = createOpenAICompatibleTextModel({ ...credentials, model, jsonReasoningEffort: "none", maxTokens: 1500 });
let started = Date.now();
const raw = await text.complete({ json: true,
  system: "你是短剧分镜师，只输出合法 JSON。",
  prompt: "为画面“黄昏海边，一个穿红色雨衣的小女孩转身望向镜头并微笑”写 1 个 4 秒镜头的分镜，只输出 JSON：{\"title\":\"\",\"shots\":[{\"id\":\"s1\",\"seconds\":4,\"shotSize\":\"\",\"camera\":\"\",\"action\":\"\",\"videoPromptEnglish\":\"不超过 60 词的英文视频提示词\"}]}" });
const board = extractJson(raw) as { title?: string; shots: { seconds?: number; videoPromptEnglish?: string; action?: string }[] };
await writeFile(join(out, "storyboard.json"), JSON.stringify(board, null, 2));
console.log(`文本 ${model}：${((Date.now() - started) / 1000).toFixed(1)}s，镜头 ${board.shots?.length ?? 0} 个`);
const shot = board.shots[0]!;
const prompt = String(shot.videoPromptEnglish || shot.action || "The girl slowly turns toward the camera and smiles.").slice(0, 6800);

// 2. 视频（ai& H3）：4 秒首帧图生视频
const seconds = Number(values.seconds ?? 4);
const quote = estimateVideoCost(seconds, 0.055);
const entry = guard.reserve(`smoke ${seconds}s`, seconds, quote);
console.log(`视频报价 $${quote.toFixed(3)}（${guard.cap !== undefined ? `预算上限 $${guard.cap}` : "不限额"}）`);
const source = await readFile(resolve(import.meta.dir, "../../../packages/providers/src/media/aiand.ts"), "utf8");
const provider = await loadMediaProviderSource(source, withEnvironmentCredentials("aiand", {}), undefined, undefined, undefined, async data => {
  await writeFile(join(out, "task.json"), JSON.stringify(data));
}) as unknown as { generateVideo(request: unknown): Promise<{ type: string; data: Uint8Array }[]> };
const firstFrame = { type: "binary", data: new Uint8Array(await readFile(values["first-frame"])), mimeType: "image/png" };
started = Date.now();
try {
  const [asset] = await provider.generateVideo({ model: "minimaxai/minimax-h3", prompt, firstFrame, duration: seconds, ratio: "16:9" });
  guard.settle(entry, "charged");
  const file = join(out, "h3-firstframe-4s.mp4");
  await writeFile(file, asset!.data);
  const probe = await probeMedia(file);
  await extractFrame(file, 0, join(out, "frame0.png"));
  console.log(`视频完成：${((Date.now() - started) / 1000).toFixed(0)}s，${probe.width}x${probe.height}，${probe.duration.toFixed(2)}s，音轨=${probe.hasAudio}`);
  console.log(`文件：${file}`);
} catch (error) {
  guard.settle(entry, outcomeOfError(error), error instanceof Error ? error.message : String(error));
  console.error("视频失败：", error instanceof Error ? error.message : error);
}
await writeFile(join(out, "spend.json"), JSON.stringify(guard.spend, null, 2));
console.log(`累计花费（报价）：$${guard.spend.usd.toFixed(3)}`);
