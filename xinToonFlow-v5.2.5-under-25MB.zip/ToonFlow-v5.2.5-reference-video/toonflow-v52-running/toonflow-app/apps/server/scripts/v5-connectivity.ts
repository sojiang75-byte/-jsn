#!/usr/bin/env bun
/**
 * v5run connectivity smoke (PAID: 1 xAI grok-imagine image via the v5 grokRelay + auto_worker, then 1 ai& MiniMax H3 4 s
 * first-frame video). Uses the same path as the autoflow pipeline: schema parse -> withTaskLedger -> generateMedia with the
 * provider configs in TOONFLOW_DATA_DIR (grokRelay -> 127.0.0.1:8788). Prompts come from the grokH3 hybrid prompt style.
 * Keys only from env (AIAND_API_KEY for ai&; the worker holds XAI_API_KEY). Spend is logged, no cap.
 *   bun scripts/v5-connectivity.ts --out /workspace/v5run/connectivity
 */
import { mkdir, writeFile, readFile } from "node:fs/promises";
import { join, resolve } from "node:path";
import { parseArgs } from "node:util";
import { parseStoryboard } from "../src/autoflow/storyboard/schema";
import { fillDurations } from "../src/autoflow/storyboard/timing";
import { getPromptStyle } from "../src/autoflow/promptStyles";
import { BudgetGuard, estimateVideoCost, outcomeOfError, videoPricePerSecond } from "../src/autoflow/budget";
import { extractFrame, probeMedia } from "../src/autoflow/media";
import { imageGenerationSchema, videoGenerationSchema } from "../src/utils/media/schemas";
import { generateMedia } from "../src/utils/media/generation";
import { withTaskLedger } from "../src/autoflow/taskLedger";

const { values } = parseArgs({ options: { out: { type: "string" }, seconds: { type: "string" }, "skip-video": { type: "boolean" }, "prompts-only": { type: "boolean" } } });
const out = resolve(values.out ?? "/workspace/v5run/connectivity");
await mkdir(out, { recursive: true });
const seconds = Number(values.seconds ?? 4);
const parsed = parseStoryboard({ version: 1, title: "v5 connectivity", aspectRatio: "9:16",
  style: "high-quality Japanese anime, cel-shaded, cinematic lighting, clean line art, rich color, modern urban noir action drama",
  characters: [], scenes: [{ id: "street", name: "雨夜街道", description: "深夜城市街道，路面积水倒映霓虹灯，两侧是关着门的店铺，招牌没有可读文字" }],
  episodes: [{ ep: 1, segments: [{ id: "E01-01", sceneId: "street", blocking: "空镜，无人物", timeOfDay: "深夜", mood: "紧张",
    shots: [{ id: "E01-01-01", seconds, size: "wide", camera: "Push In", characters: [], extrasPolicy: { mode: "forbidden" },
      cameraContract: { viewpoint: "third_person" },
      firstFrame: "雨夜空旷的城市街道，积水路面倒映红蓝霓虹，一辆深灰色面包车停在画面右侧路边，车灯亮着，没有任何人物",
      action: "镜头缓慢推进，雨丝落下，面包车车灯闪了两下后缓缓驶出画面右侧，水花溅起",
      sfx: "雨声，远处车流声，面包车引擎启动声", lens: "35mm", cameraPosition: "街道中线略高机位", composition: "面包车在画面右三分之一" }] }] }] });
if (!parsed.ok) throw new Error(parsed.errors.join("\n"));
const board = fillDurations(parsed.data);
const segment = board.episodes[0]!.segments[0]!;
const shot = segment.shots[0]!;
const style = getPromptStyle("grokH3");
const context = { board, segment, shot, cards: new Map() };
const plan = { images: [], referenceLabels: [], manifest: [], entries: [], warnings: [], characterImageIndex: new Map() } as any;
const imagePrompt = style.keyframe(context as any, plan);
const videoPrompt = style.video(context as any, { mode: "firstFrame", seconds });
await writeFile(join(out, "prompts.json"), JSON.stringify({ imagePrompt, videoPrompt }, null, 2));
if (values["prompts-only"]) { console.log(imagePrompt, "\n-----\n", videoPrompt); process.exit(0); }
const cwd = out;
const gen = async (mediaType: "image" | "video", request: Record<string, unknown>) => {
  const schema = mediaType === "image" ? imageGenerationSchema : videoGenerationSchema;
  const req = schema.parse(request);
  return withTaskLedger(cwd, mediaType, req, task => generateMedia(cwd, mediaType, req, undefined, task));
};
const t0 = Date.now();
const [image] = await gen("image", { providerId: "grokRelay", modelId: "grok-imagine-image", prompt: imagePrompt, ratio: "9:16", outputDirectory: "image", seed: 307 });
console.log(`IMAGE ok ${((Date.now() - t0) / 1000).toFixed(0)}s: ${join(out, image!.path)}`);
if (values["skip-video"]) process.exit(0);

const price = videoPricePerSecond("aiand", "minimaxai/minimax-h3");
const spendFile = join(out, "spend.json");
const prior = await readFile(spendFile, "utf8").then(JSON.parse).catch(() => ({ usd: 0, entries: [] }));
const guard = new BudgetGuard({}, prior);
const quote = estimateVideoCost(seconds, price);
const entry = guard.reserve(`v5 connectivity H3 first-frame ${seconds}s`, seconds, quote);
await writeFile(spendFile, JSON.stringify(guard.spend, null, 2));
console.log(`VIDEO quote $${quote.toFixed(3)} (no cap)`);
const t1 = Date.now();
try {
  const [video] = await gen("video", { providerId: "aiand", modelId: "minimaxai/minimax-h3", prompt: videoPrompt, ratio: "9:16", duration: seconds,
    generateAudio: true, mode: "startFrameOptional", firstFrame: { path: image!.path, mimeType: image!.mimeType }, outputDirectory: "video" });
  guard.settle(entry, "charged");
  const file = join(out, video!.path);
  const probe = await probeMedia(file);
  await extractFrame(file, 0, join(out, "video_frame0.png"));
  console.log(`VIDEO ok ${((Date.now() - t1) / 1000).toFixed(0)}s: ${file} ${probe.width}x${probe.height} ${probe.duration.toFixed(2)}s audio=${probe.hasAudio}`);
} catch (error) {
  guard.settle(entry, outcomeOfError(error), error instanceof Error ? error.message : String(error));
  console.error("VIDEO failed:", error instanceof Error ? error.message : error);
  process.exitCode = 1;
}
await writeFile(spendFile, JSON.stringify(guard.spend, null, 2));
console.log(`spend logged: $${guard.spend.usd.toFixed(3)} -> ${spendFile}`);
