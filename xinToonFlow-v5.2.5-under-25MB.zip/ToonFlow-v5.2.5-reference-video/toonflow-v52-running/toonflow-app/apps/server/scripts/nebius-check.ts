#!/usr/bin/env bun
/**
 * Nebius 文本模型真实检查（极小，不产生视频费用）：用一键成片的文本模型客户端（JSON 模式）生成 1 个镜头的分镜 JSON。
 *   NEBIUS_API_KEY=… bun scripts/nebius-check.ts [--model deepseek-ai/DeepSeek-V4.1-Flash-1017] [--out storyboard.json]
 * Key 只从环境变量（或参数之外的设置）读取，不打印、不落盘。
 */
import { writeFile } from "node:fs/promises";
import { parseArgs } from "node:util";
import { createOpenAICompatibleTextModel, nebiusDefaults, resolveNebiusCredentials } from "../src/autoflow/llm";
import { extractJson } from "../src/autoflow/scoring";

const { values } = parseArgs({ options: { model: { type: "string" }, out: { type: "string" } } });
const model = values.model ?? nebiusDefaults.model;
const credentials = resolveNebiusCredentials({});
const bodies: Record<string, unknown>[] = [];
// 包一层 fetch 只为记录请求体里的非敏感字段（不含请求头/Key）
const recordingFetch = (async (url: string, init: RequestInit) => {
  const body = JSON.parse(String(init.body)) as Record<string, unknown>;
  bodies.push({ model: body.model, response_format: body.response_format, reasoning_effort: body.reasoning_effort });
  return fetch(url, init);
}) as unknown as typeof fetch;
const text = createOpenAICompatibleTextModel({ ...credentials, model, jsonReasoningEffort: "none", maxTokens: 1500, fetch: recordingFetch });
const started = Date.now();
const raw = await text.complete({ json: true,
  system: "你是短剧分镜师，只输出合法 JSON。",
  prompt: "为画面“黄昏海边，一个穿红色雨衣的小女孩转身望向镜头并微笑”写 1 个 4 秒镜头的分镜，只输出 JSON：{\"title\":\"\",\"shots\":[{\"id\":\"s1\",\"seconds\":4,\"shotSize\":\"\",\"camera\":\"\",\"action\":\"\",\"videoPromptEnglish\":\"不超过 60 词的英文视频提示词\"}]}" });
const board = extractJson(raw) as { title?: string; shots?: { id?: string; seconds?: number; videoPromptEnglish?: string }[] };
if (!Array.isArray(board.shots) || board.shots.length !== 1) throw new Error(`分镜不符合预期：${raw.slice(0, 300)}`);
console.log(`模型 ${model}，用时 ${((Date.now() - started) / 1000).toFixed(1)}s，请求 ${bodies.length} 次：${JSON.stringify(bodies)}`);
console.log(JSON.stringify(board, null, 2));
if (values.out) await writeFile(values.out, JSON.stringify(board, null, 2));
