// fx4 export: same stitch + mastering path as pipeline.export(master) but run standalone after the run finishes,
// with optional per-shot clip overrides (voice-unified clips). Usage: bun scripts/fx4_master.ts RUN_DIR OUT.mp4 [overrides.json]
import { readFileSync } from "node:fs";
import { dirname, isAbsolute, join } from "node:path";
import { stitchVideos } from "../src/autoflow/stitch";
import { masterFilm, speechSafeEdges } from "../src/autoflow/mastering";
import { probeMedia } from "../src/autoflow/media";
const [runDir, out, ovr] = process.argv.slice(2);
const run = JSON.parse(readFileSync(join(runDir, "run.json"), "utf8"));
const board = JSON.parse(readFileSync(join(runDir, "storyboard.json"), "utf8"));
const overrides: Record<string, string> = ovr ? JSON.parse(readFileSync(ovr, "utf8")) : {};
const root = dirname(dirname(runDir));
const clips: any[] = [];
for (const ep of board.episodes) for (const sg of ep.segments) for (const sh of sg.shots) {
  const st = run.shots[sh.id]; const v = overrides[sh.id] ?? st?.video; if (!v) { console.log("MISSING", sh.id); continue; }
  const file = isAbsolute(v) ? v : join(root, v);
  const probe = await probeMedia(file);
  const e = await speechSafeEdges(file, probe.duration, 0.12);
  clips.push({ file, trimHeadFrames: st?.trimHeadFrames, segmentId: sg.id, edgeHeadSeconds: e.head, edgeTailSeconds: e.tail });
  console.log(sh.id, overrides[sh.id] ? "(override)" : "", `edges ${e.head.toFixed(2)}/${e.tail.toFixed(2)}`);
}
const raw = out.replace(/\.mp4$/, "_raw.mp4");
const { plans } = await stitchVideos(clips, raw, { width: 1080, height: 1920, fps: 24, crf: 18 });
console.log("seams", plans.filter(p => p.gain !== 1 || p.trimHeadFrames).length);
const rp = await probeMedia(raw);
const { measured } = await masterFilm(raw, out, rp.duration, { targetLufs: -15, truePeak: -1.5, bedDb: -40 });
console.log("master", out, rp.duration.toFixed(2), "s; measured", JSON.stringify(measured));
