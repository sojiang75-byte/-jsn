#!/usr/bin/env bun
/**
 * Nebius 看图一致性评分真实检查（极小，不产生视频费用）：用一键成片同一条评分链路比较参考图与待审画面。
 *   NEBIUS_API_KEY=… bun scripts/nebius-score-check.ts --reference 首帧.png --candidate 第0帧.png [--name 小女孩] [--model deepseek-ai/DeepSeek-V4.1-Flash-1017]（缺省 nvidia/Nemotron-3.5-Super-VL）
 * Key 只从设置或环境变量读取，不打印、不落盘。
 */
import { parseArgs } from "node:util";
import { resolve } from "node:path";
import { createModelScorer } from "../src/autoflow/scoring";
import { createTextModel } from "../src/autoflow/service";
import { nebiusDefaults } from "../src/autoflow/llm";

const { values } = parseArgs({ options: { reference: { type: "string" }, candidate: { type: "string" }, name: { type: "string" }, model: { type: "string" }, description: { type: "string" } } });
if (!values.reference || !values.candidate) { console.error("用法：bun scripts/nebius-score-check.ts --reference <png> --candidate <png>"); process.exit(2); }
const vision = await createTextModel({ providerId: "nebius", modelId: values.model }, "vision");
const outputs: string[] = [];
const scorer = createModelScorer(async input => { const text = await vision.complete(input); outputs.push(text); return text; });
const started = Date.now();
const result = await scorer.score({
  candidate: resolve(values.candidate),
  references: [{ path: resolve(values.reference), name: values.name ?? "小女孩", role: "character" }],
  description: values.description ?? "黄昏海边，穿红色雨衣的小女孩转身望向镜头并微笑",
});
console.log(`模型 ${values.model ?? nebiusDefaults.scorerModel}，用时 ${((Date.now() - started) / 1000).toFixed(1)}s，请求 ${outputs.length} 次`);
console.log(`原始输出：${outputs.at(-1)}`);
console.log(`评分结果：${JSON.stringify(result)}`);
