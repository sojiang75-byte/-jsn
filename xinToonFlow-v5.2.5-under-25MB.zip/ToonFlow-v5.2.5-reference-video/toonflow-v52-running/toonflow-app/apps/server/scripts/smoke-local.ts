#!/usr/bin/env bun
/**
 * 本地冒烟测试：不访问任何外部/付费接口，验证「真实模式」的完整接线。
 *  - 假的 OpenAI 兼容语言模型服务（流式 SSE），返回固定的剧本/角色/分镜/评分 JSON；
 *  - 假的 ComfyUI（/upload/image、/prompt、/history、/view），用本机 FFmpeg 生成图片与视频；
 *  - 用临时数据目录启动 Toonflow 服务，经 HTTP 调用 /api/autoflow/start → status，
 *    走 createConfiguredTextModel → streamAi、generateMedia → comfyui 供应商 VM、模型评分器、prepareWorkspaceFfmpeg。
 * 用法：bun scripts/smoke-local.ts
 */
import { mkdtemp, mkdir, writeFile, readFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join, resolve } from "node:path";
import { createMockTextModel } from "../src/autoflow/mock";
import { makePanClip, makeSolidImage } from "../src/autoflow/media";

const root = await mkdtemp(join(tmpdir(), "toonflow-smoke-"));
const outputs = join(root, "comfy-output");
await mkdir(outputs, { recursive: true });
const text = createMockTextModel({ brokenFirstStoryboard: true });
const stats = { llm: [] as string[], uploads: 0, prompts: 0, seeds: [] as number[] };

// —— 假的 OpenAI 兼容服务 ——
const llm = Bun.serve({ port: 0, hostname: "127.0.0.1", async fetch(request) {
  if (!new URL(request.url).pathname.endsWith("/chat/completions")) return new Response("not found", { status: 404 });
  const body = await request.json() as { messages: { role: string; content: string | { type: string; text?: string }[] }[]; stream?: boolean };
  const textOf = (content: unknown) => typeof content === "string" ? content : (content as { type: string; text?: string }[]).filter(part => part.type === "text").map(part => part.text).join("");
  const system = textOf(body.messages.find(message => message.role === "system" || message.role === "developer")?.content ?? "");
  const prompt = textOf(body.messages.filter(message => message.role === "user").at(-1)?.content ?? "");
  let answer: string;
  if (system.includes("一致性审查")) {
    const names = [...prompt.matchAll(/图\d+：([^；]+)/g)].map(match => match[1]!).filter(name => name !== "待审画面。画面描述");
    answer = JSON.stringify({ characters: Object.fromEntries(names.map(name => [name, 0.9])), artifacts: 0.95, reasons: [] });
    stats.llm.push("score");
  } else {
    answer = await text.complete({ system, prompt });
    stats.llm.push(text.calls.at(-1)!);
  }
  const id = `chatcmpl-${Date.now()}`;
  const chunk = (delta: Record<string, unknown>, finish: string | null, usage?: Record<string, number>) =>
    `data: ${JSON.stringify({ id, object: "chat.completion.chunk", created: Math.floor(Date.now() / 1000), model: "fake", choices: [{ index: 0, delta, finish_reason: finish }], ...(usage ? { usage } : {}) })}\n\n`;
  const sse = chunk({ role: "assistant", content: answer }, null) + chunk({}, "stop", { prompt_tokens: 10, completion_tokens: 10, total_tokens: 20 }) + "data: [DONE]\n\n";
  return new Response(sse, { headers: { "content-type": "text/event-stream" } });
} });

// —— 假的 ComfyUI ——
const history = new Map<string, unknown>();
let counter = 0;
const comfy = Bun.serve({ port: 0, hostname: "127.0.0.1", async fetch(request) {
  const url = new URL(request.url);
  if (url.pathname === "/upload/image") {
    const file = (await request.formData()).get("image") as File;
    await Bun.write(join(root, "comfy-input", file.name), file);
    stats.uploads++;
    return Response.json({ name: file.name, subfolder: "toonflow", type: "input" });
  }
  if (url.pathname === "/prompt") {
    const { prompt } = await request.json() as { prompt: Record<string, { class_type: string; inputs: Record<string, unknown> }> };
    stats.prompts++;
    const nodes = Object.values(prompt);
    const seed = nodes.map(node => node.inputs.seed ?? node.inputs.noise_seed).find(value => typeof value === "number") as number;
    stats.seeds.push(seed);
    const size = nodes.find(node => "width" in node.inputs)?.inputs as { width: number; height: number; length?: number };
    const video = nodes.some(node => node.class_type === "SaveVideo");
    const id = `p${++counter}`;
    const image = join(outputs, `${id}.png`);
    await makeSolidImage(image, { width: size.width, height: size.height, color: `0x${(seed % 0xffffff).toString(16).padStart(6, "0")}` });
    let filename = `${id}.png`;
    if (video) {
      const fps = Number(nodes.find(node => node.class_type === "CreateVideo")?.inputs.fps ?? 24);
      await makePanClip(image, join(outputs, `${id}.mp4`), { seconds: Math.max(1, ((size.length ?? 49) - 1) / fps), width: Math.round(size.width / 2) * 2, height: Math.round(size.height / 2) * 2, audio: false });
      filename = `${id}.mp4`;
    }
    history.set(id, { status: { status_str: "success", completed: true }, outputs: { save: { images: [{ filename, subfolder: "", type: "output" }] } } });
    return Response.json({ prompt_id: id, number: counter, node_errors: {} });
  }
  if (url.pathname.startsWith("/history/")) {
    const id = url.pathname.split("/").pop()!;
    return Response.json(history.has(id) ? { [id]: history.get(id) } : {});
  }
  if (url.pathname === "/view") return new Response(Bun.file(join(outputs, url.searchParams.get("filename")!)));
  return new Response("not found", { status: 404 });
} });

// —— 临时数据目录 + 配置 ——
const dataDir = join(root, "data");
await mkdir(join(dataDir, "workspaces", "demo"), { recursive: true });
await writeFile(join(dataDir, "settings.json"), JSON.stringify({
  mediaGenerationDisabledOnce: true,
  settings: {
    customProviders: [{ id: "local", label: "本地假模型", apiUrl: `http://127.0.0.1:${llm.port}/v1`, apiKey: "sk-local", protocol: "openai-completions",
      models: [{ id: "fake", label: "fake", contextWindow: 32000, maxOutputTokens: 8000 }] }],
    mediaProviderConfigs: { comfyui: { baseUrl: `http://127.0.0.1:${comfy.port}` } },
  },
}, null, 2));

const port = 39000 + Math.floor(Math.random() * 1000);
const server = Bun.spawn(["bun", "src/index.ts"], { cwd: resolve(import.meta.dir, ".."), env: { ...process.env, NODE_ENV: "dev", TOONFLOW_DATA_DIR: dataDir, TOONFLOW_SERVER_PORT: String(port), NO_PROXY: "127.0.0.1,localhost", no_proxy: "127.0.0.1,localhost" }, stdout: "pipe", stderr: "pipe" });
const base = `http://127.0.0.1:${port}`;
let exitCode = 1;
try {
  for (let i = 0; i < 60; i++) {
    if (await fetch(`${base}/api/ai/models`).then(response => response.ok, () => false)) break;
    await Bun.sleep(500);
  }
  const post = async (path: string, body: unknown) => (await fetch(`${base}${path}`, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(body) })).json() as Promise<any>;
  const directory = join(dataDir, "workspaces", "demo");
  console.log("文本模型：", JSON.stringify(((await (await fetch(`${base}/api/ai/models`)).json()) as any).data.map((m: any) => `${m.providerId}/${m.modelId}`)));
  const started = await post("/api/autoflow/start", {
    directory, runId: "smoke", story: "雨夜便利店，店员林夏把伞借给常客陈默。", seed: 2026,
    textModel: { providerId: "local", modelId: "fake" },
    imageModel: { providerId: "comfyui", modelId: "qwen-image", size: "1K" },
    videoModel: { providerId: "comfyui", modelId: "wan2.2-ti2v-5b", resolution: "480p" },
    scorer: { type: "model", providerId: "local", modelId: "fake" },
  });
  console.log("start：", JSON.stringify(started));
  if (started.code !== 200) throw new Error("启动失败");
  let state: any;
  for (let i = 0; i < 240; i++) {
    await Bun.sleep(1000);
    const status = await post("/api/autoflow/status", { directory, runId: "smoke" });
    state = status.data?.state;
    if (status.data && !status.data.running && ["done", "failed", "stopped"].includes(state?.status)) break;
  }
  console.log(state.log.join("\n"));
  console.log(`\n状态：${state.status}${state.error ? `（${state.error}）` : ""}`);
  console.log("LLM 调用：", stats.llm.join(", "));
  console.log(`ComfyUI：上传 ${stats.uploads} 次、工作流 ${stats.prompts} 个；种子 ${stats.seeds.join(",")}`);
  if (state.artifacts?.final) console.log("成片：", join(directory, state.artifacts.final));
  if (state.artifacts?.report) console.log((await readFile(join(directory, state.artifacts.report), "utf8")).split("\n").slice(-8).join("\n"));
  exitCode = state.status === "done" ? 0 : 1;
} finally {
  server.kill();
  llm.stop(true);
  comfy.stop(true);
  if (exitCode) console.error((await new Response(server.stderr).text()).slice(-3000));
}
process.exit(exitCode);
