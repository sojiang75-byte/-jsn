#!/usr/bin/env bun
/**
 * 命令行一键成片：
 *   bun scripts/autoflow.ts --mock --dir /tmp/demo --story "…"
 *   bun scripts/autoflow.ts --dir <工作区> --story-file 故事.txt --config autoflow.json
 * config 文件即 /api/autoflow/start 的请求体（不含 directory）。真实模式需先在 Toonflow 中配置好模型。
 */
import { readFile, mkdir } from "node:fs/promises";
import { resolve } from "node:path";
import { parseArgs } from "node:util";

const { values } = parseArgs({ options: {
  dir: { type: "string" }, story: { type: "string" }, "story-file": { type: "string" }, config: { type: "string" },
  mock: { type: "boolean" }, "run-id": { type: "string" },
  redo: { type: "string", multiple: true }, "redo-keep-keyframe": { type: "string", multiple: true }, pick: { type: "string", multiple: true },
} });
if (!values.dir || (!values.story && !values["story-file"])) {
  console.error("用法：bun scripts/autoflow.ts --dir <工作区目录> (--story <文本> | --story-file <文件>) [--config autoflow.json] [--mock] [--run-id id] [--redo E01-02-03,E01-03-02] [--redo-keep-keyframe E01-01-04] [--pick E01-02-03@v1]");
  process.exit(2);
}
const cwd = resolve(values.dir);
await mkdir(cwd, { recursive: true });
const config = values.config ? JSON.parse(await readFile(values.config, "utf8")) : {};
const story = values.story ?? await readFile(values["story-file"]!, "utf8");
const { autoflowRequestSchema, buildDeps } = await import("../src/autoflow/service");
const { parseShotList } = await import("../src/autoflow/clipBin");
// 命令行可以使用外部质检命令（HTTP 接口不允许）
process.env.TOONFLOW_ALLOW_SHOT_QA = "1";
const redo = parseShotList(values.redo);
const redoKeepKeyframe = parseShotList(values["redo-keep-keyframe"]);
const pick = parseShotList(values.pick);
if (redo.length) config.redo = redo;
if (redoKeepKeyframe.length) config.redoKeepKeyframe = redoKeepKeyframe;
if (pick.length) config.pick = pick;
const { runAutoflow } = await import("../src/autoflow/pipeline");
const request = autoflowRequestSchema.parse({ ...config, story, mock: values.mock ?? config.mock, runId: values["run-id"] ?? config.runId ?? `run-${Date.now()}` });
const controller = new AbortController();
process.on("SIGINT", () => controller.abort(new Error("已中断")));
const { deps, options } = await buildDeps(cwd, request, controller.signal);
let printed = 0;
deps.onUpdate = state => { for (const line of state.log.slice(printed)) console.log(line); printed = state.log.length; };
const state = await runAutoflow(options, deps, request.runId);
console.log(`\n状态：${state.status}${state.error ? `（${state.error}）` : ""}`);
if (state.artifacts.final) console.log(`成片：${resolve(cwd, state.artifacts.final)}`);
if (state.artifacts.report) console.log(`报告：${resolve(cwd, state.artifacts.report)}`);
process.exit(state.status === "done" || (state.status === "stopped" && Boolean(request.stopAfter)) ? 0 : 1);
