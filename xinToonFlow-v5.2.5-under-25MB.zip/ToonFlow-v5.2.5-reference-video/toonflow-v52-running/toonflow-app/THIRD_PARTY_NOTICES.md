# Third-Party Notices

Toonflow 本体以 MIT 许可发布（见 LICENSE）。以下文件包含移植或改写自第三方 Apache-2.0 项目的内容，
对应部分仍受 Apache License 2.0 约束（https://www.apache.org/licenses/LICENSE-2.0）。

## shuohao-skills

- 来源：https://github.com/eternityspring/shuohao-skills （`skills/novel-storyboard`、`skills/character-refs`）
- 许可：Apache License 2.0
- 涉及文件（均已按 Toonflow 的数据结构重写/修改）：
  - `apps/server/src/autoflow/storyboard/vocab.ts`：景别、运镜、稳定性词表与分镜默认参数
  - `apps/server/src/autoflow/storyboard/gates.ts`：质量门检查项的设计（独立重写为 TypeScript）
  - `apps/server/src/utils/assets/characterCard.ts`、`packages/skills/v118workflow/references/generateAssets.md`：锚点先行、视图派生的做法说明

原 NOTICE 内容如下：

```
shuohao-skills
Copyright 2026 烁皓

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    https://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
```

## H3-Character-Sheet-Designer（MIT）

- 来源：https://github.com/ukr8b3g-cmyk/H3-Character-Sheet-Designer （核对提交 381482e8，2026-10-30）
- 许可：MIT（仅覆盖其原创代码与文档；其 NOTICE.md 明确排除图片、美术、截图、模型权重与用户素材）
- 借用内容：**仅规则与思路**（13 视角清单、以“鼻尖朝向画面左/右”描述侧面朝向、参考图角色分工、种子不进子图），
  由 Toonflow 以 TypeScript 重新编写，提示词措辞为独立撰写；**未复制其任何美术资源**（如 `web/assets/mannequin-atlas.png`、`web/avatar.js` 中的 SVG）。
- 涉及文件：`apps/server/src/autoflow/promptStyles/h3Views.ts`、`apps/server/src/autoflow/promptStyles/h3.ts`

```
MIT License

Copyright (c) 2026 ukr8b3g-cmyk

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
```

## MiniMax H3（模型与 API，非本仓库内容）

- `packages/providers/src/media/minimaxH3.ts` 是 Toonflow 自行编写的官方 API 客户端，**不包含、不下载、不分发**任何 H3 权重或推理代码。
- H3 开源权重适用 **MiniMax H3 Community License Agreement**（https://huggingface.co/MiniMaxAI/MiniMax-H3/blob/main/LICENSE ，2026-08-02 版）：
  - “Excluded Territories” = 欧盟、英国、韩国、美国；在这些地区使用/复制/运行/分发权重或其产出**不在该协议授权范围内**（第 V.4 条与附件 A 第 1 条）。
    因此**在美国自托管 H3 权重未获授权**，除非另行取得 MiniMax 许可。
  - 协议声明其也适用于“通过 Hosted Services 使用”的情形；MiniMax 官方 API 另有平台服务条款，二者在排除地区如何适用请以 MiniMax 官方书面答复为准。
  - 不得用 H3 的产出改进其他 AI 模型（第 V.3 条）；商用产品须在界面上显著标注 “MiniMax H3”（第 IV.2 条，本供应商名称已含此标识）；
    年收入超过 2000 万美元须另行书面授权（第 IV.1 条）；公开发布生成内容须标明为机器生成（附件 A 第 12 条）。
  - 若分发 H3 Works（本仓库不分发），须附带如下 NOTICE：

```
MiniMax H3 is licensed under the MiniMax H3 Community License Agreement, Copyright © 2026 MiniMax. All Rights Reserved.
```

- H3 提示词格式（Ref2VA / T2VA / I2VA / FL2VA 段落名、`<Picture N>`、`<d>[Language] …</d>`）依据 MiniMax 公开文档与官方仓库 README 中的格式说明，
  Toonflow 的模板文字为独立撰写，未复制官方 skills 目录中的文件。

## 仅借鉴思路、未复制代码的项目

以下项目的许可（AGPL-3.0 / CC BY-NC-SA）与 MIT 不兼容，本仓库**没有复制其任何代码**，相关模块均为独立编写，仅在注释中致谢设计思路：

- ArcReel（AGPL-3.0）：参考图编号声明、黑场/冻结/切镜自动审片的思路
- moyin-creator（AGPL-3.0）：首帧/视频/尾帧三层提示词、角色一致性要素的思路
- huobao-drama（CC BY-NC-SA）：未使用

## 模型权重

ComfyUI 内置工作流默认使用 Qwen-Image / Qwen-Image-Edit-2509、Wan2.2（均为 Apache-2.0）。
`docs/comfyui/flux1-kontext-dev.NONCOMMERCIAL.api.json` 使用的 FLUX.1 Kontext [dev] 权重为非商用许可，仅作为需手动启用的示例，不随软件分发任何权重。

## aid-studio (ideas only)

The source-coverage gate (storyboard/gates.ts sourceCoverage) and the injury/prop-state continuity checklist (storyboard/continuity.ts) follow ideas from aid-studio. No code was copied; independent implementation.

MIT License

Copyright (c) 2026 光子讯息(杭州)科技有限公司

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
