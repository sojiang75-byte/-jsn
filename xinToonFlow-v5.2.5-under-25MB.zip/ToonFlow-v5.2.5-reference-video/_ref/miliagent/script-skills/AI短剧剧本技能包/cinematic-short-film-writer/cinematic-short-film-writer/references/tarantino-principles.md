# Tarantino-Informed Principles For Short-Film Development

Use these as craft principles, not as imitation. Do not copy Quentin Tarantino's exact dialogue style, scenes, slurs, violent set pieces, or story premises.

Sources reviewed on 2026-05-25:

- Filmmaker Magazine interview on *Inglourious Basterds*: https://filmmakermagazine.com/oscars/labels/Christoph%20Waltz.html
- BAFTA "A Life in Pictures: Quentin Tarantino" transcript: https://www.bafta.org/media-centre/press-releases/bafta-a-life-in-pictures-quentin-tarantino/
- Rotten Tomatoes interview on *Inglourious Basterds*: https://editorial.rottentomatoes.com/article/quentin-tarantino-talks-inglourious-basterds-rt-interview/
- British GQ interview: https://www.gq-magazine.co.uk/culture/article/quentin-tarantino-interview
- TIME profile on *Pulp Fiction*: https://time.com/3503500/a-blast-to-the-heart/
- GRAMMY article on the *Pulp Fiction* soundtrack: https://www.grammy.com/news/how-pulp-fiction-reinvented-the-film-soundtrack-anniversary

## 1. Genre Is The Doorway, Not The Cage

Tarantino often starts from a basic genre or subgenre attraction: heist film, revenge martial arts movie, men-on-a-mission war movie. The point is not to obey the genre passively. The genre gets the writer to the page; then characters, themes, and unexpected left turns reshape the material.

Short-film application:

- Start with a recognizable container: revenge, dinner-table thriller, workplace black comedy, confession, audition, crime cleanup, funeral, fake wedding.
- Then ask what emotional or moral surprise makes it more than a genre exercise.
- Deliver the genre "goods" in miniature: suspense, payoff, reveal, confrontation, joke, dread, or catharsis.

## 2. Discovery Writing Needs A Strong Game

Tarantino describes writing without a rigid outline, letting characters and themes emerge. For a short-film skill, do not copy the lack of planning. Instead, build a strong scene game, then let characters create turns inside it.

Short-film application:

- Do not over-outline every line of dialogue too early.
- Define the pressure game clearly: who wants what, who controls the space, what cannot be said, what happens if the secret comes out.
- Let the scene discover its best turn, then revise the architecture around that discovery.

## 3. Dialogue Is A Duel, Not Information Delivery

Tarantino scenes often let characters talk around the danger before the danger is named. The surface topic can be food, cinema, etiquette, language, music, or trivia, while the real action is intimidation, testing, seduction, humiliation, or threat.

Short-film application:

- Give every dialogue scene a visible surface topic and a hidden power game.
- The most important line is often not the most direct line.
- Let status shift during the conversation.
- Use callbacks sparingly: an earlier casual phrase returns later with new danger or tenderness.
- Read dialogue aloud for rhythm; cut lines that only explain.

## 4. Suspense Is A Rubber Band

In interviews on *Inglourious Basterds*, Tarantino describes suspense as stretching a rubber band tighter and tighter, then snapping fast. The scene can be long if the tension is genuinely increasing.

Short-film application:

- A long scene is allowed only if each beat tightens the band.
- Stretch with withheld information, ritual, politeness, wrong assumptions, and tiny status shifts.
- Snap with a quick irreversible action: a signature, a public sentence, a slap, a confession, a door opening, a phone playing audio, a body-language reveal.
- After the snap, do not keep explaining. Let the consequence land.

## 5. Nonlinear Structure Must Change Meaning

Tarantino is not simply anti-linear; the useful principle is that structure can rearrange revelation, comedy, dread, and moral judgment. Nonlinear order should make the audience reinterpret what they saw.

Short-film application:

- Use nonlinear structure only when it improves the reveal.
- Good uses: open with aftermath, then show cause; repeat a scene from another POV; hide one missing action until the end; start with a lie and end with the true version.
- Bad uses: random flashbacks, decorative chapter cards, or time jumps that add style but not meaning.

## 6. Body Language Can Carry A Character

In BAFTA's transcript, Tarantino discusses characters who reveal themselves through body language rather than heavy dialogue. This is crucial for short films.

Short-film application:

- Give a quiet character a physical signature: folded posture, dirty-clothes slouch, perfect stillness, compulsive cleaning, delayed eye contact.
- Let the body betray what the mouth hides.
- Replace exposition with behavior when possible.

## 7. Violence, Revenge, And Shock Need Consequence

Tarantino's cinema often uses revenge, violence, and genre shock, but in a short-film skill these should not become empty cruelty. The "snap" matters because of the pressure before it and the meaning after it.

Short-film application:

- Use violence or humiliation only if it reveals character, changes power, or exposes a moral contradiction.
- The aftermath should be more interesting than the impact.
- A nonviolent action can be more devastating: silence, refusal, public truth, deleting a file, serving the wrong dish, returning a gift, playing a recording.

## 8. Music Is A Cinematic Event

Tarantino's use of source music shows that the right song in the right scene can become a cinematic engine, not background decoration.

Short-film application:

- Choose one sound or music idea as a dramatic device: a song that lies, a ringtone that exposes, a radio broadcast that times the scene, a karaoke track that becomes confession.
- Music should create irony, propulsion, memory, or rupture.
- Silence is also a choice; use it when the scene needs the audience to feel trapped.

## 9. Homage Must Transform

Genre references are raw material. They should be metabolized into a new emotional situation, not displayed as trivia.

Short-film application:

- Borrow a structural pleasure, not a scene: standoff, dinner-table interrogation, revenge ritual, chapter-like reveal, pop song collision.
- Localize it into the user's subject, location, culture, production reality, and emotional wound.

## 10. Tarantino-Informed Short-Film Checklist

- Is there a clear genre promise?
- Is there a scene game strong enough to hold attention?
- Does dialogue hide a power struggle beneath a mundane topic?
- Does suspense stretch and then snap?
- Does any nonlinear move change meaning?
- Does the ending deliver genre pleasure and emotional aftertaste?
- Does the piece feel inspired by principles rather than imitating surface style?
