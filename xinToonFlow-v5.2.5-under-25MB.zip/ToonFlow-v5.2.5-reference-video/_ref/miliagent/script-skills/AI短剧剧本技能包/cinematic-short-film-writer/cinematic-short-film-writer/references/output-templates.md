# Output Templates

## First Response: 短片故事总盘

```markdown
## 第一部分：我会把这个想法开发成什么类型的电影感短片

- 类型定位：
- 影调：
- 默认片长：
- 开发假设：

## 第二部分：这个题材最值得做的核心卖点

一句话卖点：

核心钩子：

商业悬疑引擎：

任务/倒计时/公共失败场：

观众为什么会想看：

## 第三部分：短片故事总盘

1. 片名方向：
2. 主角设定：
3. 对手/压力源：
4. 主线冲突：
5. 关系线：
6. 最大秘密/底牌/讽刺机制：
7. 主角的表层目标：
8. 主角的隐藏需求：
9. 短剧爽点如何转译成短片爽感：
10. 商业类型包装：悬疑、任务、骗局、竞赛或倒计时机制：
11. 主要反转路径：
12. 前中后段升级逻辑：
13. 关键戏份：
14. 视听母题：
15. 结局方向：
16. 为什么它适合做短片，而不是竖屏短剧：

## 第四部分：这个故事最有趣的戏在哪里

- 戏份1：
- 戏份2：
- 戏份3：

## 第五部分：是否适合继续拆成短片结构

我的判断：

如果继续，我建议下一步拆成 6-12 场的短片场景大纲。
```

End by waiting for confirmation unless the user explicitly requested full expansion in one pass.

## Continued Response: 场景大纲

```markdown
## 短片场景大纲

### 开场图像

### 第1场
- 场景：
- 戏剧功能：
- 可见行动：
- 冲突/压力：
- 但是/所以：
- 情绪节拍：
- 视听提示：

### 第2场
...

### 高潮场
- 不可逆行动：
- 爽感兑现：
- 代价：

### 结尾图像
- 与开场的呼应/反转：
- 余味：
```

## Scene Deepening

```markdown
## 场景深化

### 场景目标

### 场面调度

### 动作推进

1. ...
2. ...
3. ...

### 台词骨架

（写成可拍的对白，不要小说化。）

### 潜台词

### 镜头/声音

### 这一场的剪辑断点
```

## Dialogue Polish Pass

Use this when the user asks for 更昆汀一点, 更有张力, 更黑色幽默, 更像电影对白:

```markdown
## 对白重写

### 表层话题

### 真正争夺

### 权力变化

### 重写版对白

### 为什么这样更有张力
```

Rules:

- Do not explain character backstory in dialogue.
- Let one character misunderstand the surface topic while another weaponizes it.
- Give at least one line a second meaning after the reveal.
- Use silence, objects, or interruptions as beats.

## Revision Commands

If the user asks to adjust direction, apply the closest mode:

- `更爽`：raise pressure, make the payoff more public/concrete, sharpen status reversal.
- `更深`：make the hidden need clearer, add cost, make the ending more ambivalent.
- `更电影感`：add visual motif, sound motif, embodied action, opening/ending image.
- `更黑色幽默`：make the character pursue a petty goal inside a serious situation, then let the system respond absurdly.
- `更昆汀原则`：strengthen scene game, subtext dialogue, suspense stretch/snap, genre transformation; do not imitate exact voice.
- `更好拍`：reduce locations/characters, convert abstract conflict to action, keep one strong prop or ritual.
