# Commercial Suspense Engine

Use this reference when a premise feels too abstract, worthy, observational, or "topic-first." The goal is to turn a small realistic event into a gripping, accessible short film with commercial suspense, black humor, and clean emotional stakes.

## 1. Bad Genius Model: Small Event, Big Thriller Treatment

The useful lesson from *Bad Genius* / `天才枪手` is not "write about cheating." It is:

```text
ordinary school system + high-pressure rule set + smart plan + class anxiety + ticking clock + moral cost = commercial thriller
```

Apply this model to any small topic:

- Find a familiar institutional ritual: exam, election, interview, defense, scholarship review, dorm inspection, activity budget audit, recommendation letter, volunteer-hour certification.
- Turn it into a mission: cheat, expose, steal, swap, defend, infiltrate, frame, rescue, or win.
- Add a clock: voting closes in 20 minutes, public Q&A starts at 8, audit team arrives after lunch, livestream cannot be stopped.
- Add a rules system the audience can understand quickly.
- Add one clever method with visual steps.
- Add one moral price: friendship, self-respect, scholarship, family expectation, public future, or someone's chance to be seen.
- Let the ending feel bigger than the event: the real subject is class mobility, elite performance, moral compromise, or the machinery that rewards "good students" for becoming better liars.

## 2. Stop Making "Issue Films"; Build Genre Engines

Weak version:

```text
Students compete for student union power and reveal hypocrisy.
```

Stronger genre version:

```text
A campaign manager has 45 minutes to prove the ballot system was rigged before his candidate publicly concedes, but the only evidence is hidden inside a rival team's projected PPT deck.
```

The stronger version has:

- A deadline
- A mission
- A visual object
- A public consequence
- A plan that can go wrong
- A moral or relational cost

Every serious theme needs a vulgar, concrete, watchable body.

## 3. Commercial Hook Questions

Before building the architecture, pick one primary question:

- **Heist question**: Can they steal/swap/recover the thing before exposure?
- **Con question**: Can they fool the room long enough to win?
- **Whodunit question**: Who planted the leak, forged the ballot, or framed the candidate?
- **Howcatchem question**: We know who did it; how will the protagonist prove it?
- **Race question**: Can they beat the countdown?
- **Trial question**: Can they survive a public hearing, defense, or Q&A?
- **Moral trap question**: Will they do the dirty thing for the "right" reason?

If no hook question exists, the story is probably an essay, not a film.

## 4. Stakes Ladder

Make the story feel bigger without making it fake:

1. **Immediate stake**: win the election, stop the concession, protect a friend, save a scholarship, avoid public humiliation.
2. **Social stake**: clique reputation, dorm network, department support, recommendation route, internship pipeline.
3. **Identity stake**: "I am not the kind of person who cheats/lies/begs."
4. **Theme stake**: the institution rewards procedural cleanliness over moral truth.

Do not jump straight to "future of society." Let the small event imply it.

## 5. Save The Cat Adaptation For A 10-15 Minute Short

Use this when the story needs a stronger mainstream skeleton:

1. **Opening Image**: a vivid contradiction, e.g. a campaign poster promising transparency while someone tapes over a camera.
2. **Theme Stated**: a casual line that sounds harmless but becomes the film's thesis.
3. **Set-Up**: introduce the protagonist's role, desire, flaw, and the rule system.
4. **Catalyst**: leak, missing vote, forged document, surprise candidate, system lock, public accusation.
5. **Debate**: should the protagonist play clean or play to win?
6. **Break Into Two**: protagonist commits to the plan.
7. **Fun And Games**: the trailer-friendly set pieces: sneaking, swapping, decoding, live Q&A, public performance, team coordination.
8. **Midpoint**: apparent win or loss; the real trap appears.
9. **Bad Guys Close In**: rivals, rules, cameras, friends, guilt, and time all tighten.
10. **All Is Lost**: evidence destroyed, ally betrays, protagonist exposed, or moral line crossed.
11. **Dark Night**: one quiet beat where the cost becomes clear.
12. **Finale**: protagonist executes the irreversible move.
13. **Final Image**: mirrors the opening with a changed meaning.

For a 5-8 minute short, compress steps 2-5 into one setup sequence and steps 9-11 into one squeeze sequence.

## 6. Hero's Journey Adaptation

Use only as an emotional spine, not as fantasy jargon:

- **Ordinary World**: protagonist believes the institution is playable if they are smart enough.
- **Call**: a concrete injustice or opportunity appears.
- **Refusal**: they do not want to become dirty.
- **Mentor/Trickster**: someone teaches the real rules, often cynically.
- **Threshold**: they enter the hidden system behind the official system.
- **Tests/Allies/Enemies**: alliances and betrayals under time pressure.
- **Ordeal**: the protagonist must choose between winning and remaining clean.
- **Reward**: they get the evidence, vote, confession, or public stage.
- **Road Back**: the system tries to absorb or reframe the truth.
- **Resurrection**: they use the system's own ritual against it.
- **Return**: they are changed; the campus looks the same, but no longer innocent.

## 7. 黑色幽默 Packaging

Make the story light enough to watch and sharp enough to hurt:

- Let characters use grand political language for tiny benefits: milk tea reimbursement, meeting-room priority, poster placement.
- Use procedural politeness as violence: "我们只是走流程", "为了保护你", "大家都很为难".
- Let the funniest beat also reveal the ugliest truth.
- Give one scene a petty surface goal and a serious hidden goal.
- Avoid preaching. Let the institutional absurdity perform itself.

## 8. Campus Election Thriller Engines

For student union / campus politics, prefer these engines over broad "intrigue":

### Ballot Thriller

A vote count, invalid ballot, system freeze, lost ballot box, duplicate QR code, or anonymous challenge creates a countdown.

Best hook: "One vote decides everything, but one extra vote exists."

### Debate Heist

Evidence is hidden inside a public debate, PPT deck, livestream comments, cue cards, or translation script. The protagonist must expose it without stopping the event.

Best hook: "The only way to prove the debate is rigged is to help the opponent finish their speech."

### Endorsement Con

The real prize is not the vote but one endorsement: a faculty signature, student media post, club alliance, or dorm leader support.

Best hook: "A candidate must fake moral purity long enough to win the endorsement of the only person who can destroy him."

### Reputation Bomb

A screenshot, spreadsheet, private audio, or fake apology letter becomes a weapon with a scheduled release time.

Best hook: "A leaked spreadsheet ranks every student as vote value; the protagonist is ranked 'useless' and becomes the only one who can decide the election."

### Procedural Trap

The rules are written to seem neutral but function as a trap. The protagonist wins by understanding the rule's exact wording.

Best hook: "The constitution says no one can campaign after midnight, but it does not define who counts as a person."

## 9. Upgrade A Boring Premise

When a direction feels dull, run this upgrade:

1. Name the **crime-like action**: steal, forge, swap, leak, frame, blackmail, sabotage, impersonate, conceal.
2. Name the **clock**.
3. Name the **object** everyone wants.
4. Name the **public arena** where failure will be witnessed.
5. Name the **ally who may betray**.
6. Name the **moral line** the protagonist refuses to cross, then force them to cross or redefine it.
7. Name the **final reversal**: the win reveals they were already part of the system they hated.

## 10. Quality Gate

Before presenting a direction:

- Can the premise be pitched in one sentence with a mission and deadline?
- Can the middle contain at least three trailer-friendly set pieces?
- Is there one clever plan the audience can understand?
- Does the protagonist make an irreversible choice?
- Is the theme carried by the plot mechanics, not by speeches?
- Is the ending both satisfying and slightly uncomfortable?
